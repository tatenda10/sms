//const BASE_URL = 'http://localhost:5000/api';
const BASE_URL = 'https://learningladderserver.site/api';
export default BASE_URL;