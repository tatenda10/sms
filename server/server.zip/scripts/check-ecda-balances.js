const { pool } = require('./config/database');

async function checkBalances() {
  const students = [
    'R00010M', // Baven - should have -115 (enrollment -115, payment +85)
    'R00010N', // Blessed/Elsie - should have -120 (Blessed: enrollment -115, payment +85; Elsie: opening -5, enrollment -115, payment +25)
    'R00010P', // Alex - should have -160 (opening -45, enrollment -115, payment +75)
    'R00010D', // Keila - should have -130 (opening -15, enrollment -115, payment +115)
    'R00010K'  // Carlton - should have -115 (enrollment -115, payment 0)
  ];
  
  console.log('\n📊 Checking ECD A Student Balances\n');
  console.log('='.repeat(60));
  
  for (const regNumber of students) {
    const [balance] = await pool.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [regNumber]
    );
    
    const [student] = await pool.execute(
      'SELECT Name, Surname FROM students WHERE RegNumber = ?',
      [regNumber]
    );
    
    const [transactions] = await pool.execute(
      'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY created_at',
      [regNumber]
    );
    
    const studentName = student.length > 0 ? `${student[0].Name} ${student[0].Surname}` : regNumber;
    const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
    
    console.log(`\n👤 ${studentName} (${regNumber})`);
    console.log(`   Current Balance: $${currentBalance.toFixed(2)}`);
    console.log(`   Transactions (${transactions.length}):`);
    
    let calculatedBalance = 0;
    transactions.forEach((txn, idx) => {
      const amount = parseFloat(txn.amount);
      if (txn.transaction_type === 'DEBIT') {
        calculatedBalance -= amount;
        console.log(`   ${idx + 1}. DEBIT  $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      } else {
        calculatedBalance += amount;
        console.log(`   ${idx + 1}. CREDIT $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      }
    });
    
    console.log(`   Calculated Balance: $${calculatedBalance.toFixed(2)}`);
    
    if (Math.abs(currentBalance - calculatedBalance) > 0.01) {
      console.log(`   ⚠️  WARNING: Balance mismatch!`);
    } else {
      console.log(`   ✅ Balance matches`);
    }
  }
  
  await pool.end();
  process.exit(0);
}

checkBalances().catch(error => {
  console.error('Error:', error);
  process.exit(1);
});

