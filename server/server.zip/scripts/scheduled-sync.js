const CpanelDataSync = require('./sync-to-cpanel');
const cron = require('node-cron');

class ScheduledSync {
    constructor() {
        this.sync = new CpanelDataSync();
        this.isRunning = false;
    }

    // Schedule sync every 24 hours
    startScheduledSync() {
        console.log('🕐 Starting scheduled sync service...');
        
        // Run every day at 2 AM
        cron.schedule('0 2 * * *', async () => {
            await this.runSync();
        });
        
        // Run every 6 hours for critical data
        cron.schedule('0 */6 * * *', async () => {
            await this.runSync('critical');
        });
        
        console.log('✅ Scheduled sync service started');
        console.log('📅 Full sync: Daily at 2:00 AM');
        console.log('📅 Critical sync: Every 6 hours');
    }

    // Run sync with optional mode
    async runSync(mode = 'full') {
        if (this.isRunning) {
            console.log('⚠️ Sync already running, skipping...');
            return;
        }

        this.isRunning = true;
        const startTime = new Date();
        
        try {
            console.log(`🚀 Starting ${mode} sync at ${startTime.toISOString()}`);
            
            if (mode === 'critical') {
                // Only sync critical data (student balances and recent transactions)
                await this.syncCriticalData();
            } else {
                // Full sync
                await this.sync.sync();
            }
            
            const duration = new Date() - startTime;
            console.log(`✅ ${mode} sync completed in ${duration}ms`);
            
        } catch (error) {
            console.error(`❌ ${mode} sync failed:`, error.message);
            
            // Send notification (you can implement email/SMS here)
            await this.sendNotification(`Sync failed: ${error.message}`);
            
        } finally {
            this.isRunning = false;
        }
    }

    // Sync only critical data
    async syncCriticalData() {
        console.log('🔄 Syncing critical data...');
        
        try {
            // Prepare only critical data
            const criticalData = await this.prepareCriticalData();
            
            // Send to cPanel API
            const response = await axios.post(this.sync.config.apiEndpoint, {
                data: criticalData,
                timestamp: new Date().toISOString(),
                source: 'local_sms_critical',
                mode: 'critical'
            }, {
                headers: {
                    'Authorization': `Bearer ${this.sync.config.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 15000 // 15 seconds timeout for critical sync
            });
            
            if (response.data.success) {
                console.log(`✅ Critical sync completed: ${response.data.syncedRecords} records`);
            } else {
                throw new Error(response.data.message || 'Critical sync failed');
            }
            
        } catch (error) {
            console.error('❌ Critical sync failed:', error.message);
            throw error;
        }
    }

    // Prepare critical data (last 24 hours)
    async prepareCriticalData() {
        const { pool } = require('../config/database');
        
        const [studentBalances] = await pool.execute(`
            SELECT sb.*, s.Name, s.Surname, s.RegNumber
            FROM student_balances sb
            JOIN students s ON sb.student_reg_number = s.RegNumber
            WHERE sb.last_updated >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        `);
        
        const [recentTransactions] = await pool.execute(`
            SELECT * FROM student_transactions 
            WHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        `);
        
        return {
            student_balances: studentBalances,
            student_transactions: recentTransactions,
            sync_timestamp: new Date().toISOString(),
            mode: 'critical'
        };
    }

    // Send notification (implement your preferred method)
    async sendNotification(message) {
        console.log(`📧 Notification: ${message}`);
        
        // Example: Send email notification
        // You can implement email, SMS, or webhook notifications here
        try {
            // Example email notification
            const nodemailer = require('nodemailer');
            const transporter = nodemailer.createTransporter({
                host: process.env.SMTP_HOST,
                port: process.env.SMTP_PORT,
                secure: true,
                auth: {
                    user: process.env.SMTP_USER,
                    pass: process.env.SMTP_PASS
                }
            });
            
            await transporter.sendMail({
                from: process.env.SMTP_FROM,
                to: process.env.ADMIN_EMAIL,
                subject: 'SMS Data Sync Alert',
                text: message,
                html: `<p>${message}</p><p>Time: ${new Date().toISOString()}</p>`
            });
            
            console.log('📧 Notification sent successfully');
            
        } catch (error) {
            console.error('❌ Failed to send notification:', error.message);
        }
    }

    // Manual sync trigger
    async triggerManualSync(mode = 'full') {
        console.log(`🔧 Manual ${mode} sync triggered`);
        await this.runSync(mode);
    }

    // Get sync status
    getStatus() {
        return {
            isRunning: this.isRunning,
            lastSync: this.lastSyncTime,
            nextScheduledSync: this.getNextScheduledSync()
        };
    }

    getNextScheduledSync() {
        const now = new Date();
        const nextDaily = new Date(now);
        nextDaily.setHours(2, 0, 0, 0);
        if (nextDaily <= now) {
            nextDaily.setDate(nextDaily.getDate() + 1);
        }
        
        const nextCritical = new Date(now);
        const hours = Math.ceil(now.getHours() / 6) * 6;
        nextCritical.setHours(hours, 0, 0, 0);
        if (nextCritical <= now) {
            nextCritical.setHours(nextCritical.getHours() + 6);
        }
        
        return {
            daily: nextDaily.toISOString(),
            critical: nextCritical.toISOString()
        };
    }
}

// CLI usage
if (require.main === module) {
    const scheduledSync = new ScheduledSync();
    
    const command = process.argv[2] || 'start';
    
    switch (command) {
        case 'start':
            scheduledSync.startScheduledSync();
            // Keep the process running
            process.on('SIGINT', () => {
                console.log('\n🛑 Stopping scheduled sync service...');
                process.exit(0);
            });
            break;
            
        case 'sync':
            const mode = process.argv[3] || 'full';
            scheduledSync.triggerManualSync(mode).catch(console.error);
            break;
            
        case 'status':
            console.log('📊 Sync Status:', scheduledSync.getStatus());
            break;
            
        default:
            console.log('Usage: node scheduled-sync.js [start|sync|status] [mode]');
            console.log('  start - Start scheduled sync service');
            console.log('  sync [full|critical] - Trigger manual sync');
            console.log('  status - Show sync status');
            break;
    }
}

module.exports = ScheduledSync;
