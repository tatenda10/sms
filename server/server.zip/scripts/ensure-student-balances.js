const { pool } = require('../config/database');

async function ensureStudentBalances() {
    const conn = await pool.getConnection();
    try {
        console.log('Ensuring all students have balance records...');
        
        // Get all students who don't have balance records
        const [studentsWithoutBalances] = await conn.execute(
            `SELECT s.RegNumber 
             FROM students s 
             LEFT JOIN student_balances sb ON s.RegNumber = sb.student_reg_number 
             WHERE sb.student_reg_number IS NULL AND s.Active = 'Yes'`
        );
        
        if (studentsWithoutBalances.length === 0) {
            console.log('All students already have balance records.');
            return;
        }
        
        console.log(`Found ${studentsWithoutBalances.length} students without balance records. Creating them...`);
        
        // Create balance records for students who don't have them
        for (const student of studentsWithoutBalances) {
            await conn.execute(
                'INSERT INTO student_balances (student_reg_number, current_balance) VALUES (?, 0.00)',
                [student.RegNumber]
            );
            console.log(`Created balance record for student: ${student.RegNumber}`);
        }
        
        console.log('Successfully created balance records for all students.');
        
    } catch (error) {
        console.error('Error ensuring student balances:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the script if called directly
if (require.main === module) {
    ensureStudentBalances()
        .then(() => {
            console.log('Student balances script completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Student balances script failed:', error);
            process.exit(1);
        });
}

module.exports = { ensureStudentBalances };
