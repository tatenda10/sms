const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        console.log('🔍 Verifying boarding balance fixes...\n');
        
        // Check student 56-D4353 specifically
        const studentReg = '56-D4353';
        
        console.log(`📋 Checking student: ${studentReg}\n`);
        
        // Get student balance
        const [balance] = await conn.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [studentReg]
        );
        console.log(`   Current balance: ${balance.length > 0 ? balance[0].current_balance : 'No balance record'}`);
        
        // Get all transactions
        const [transactions] = await conn.execute(
            'SELECT id, transaction_type, amount, description, transaction_date FROM student_transactions WHERE student_reg_number = ? ORDER BY transaction_date, id',
            [studentReg]
        );
        console.log(`\n   Transactions (${transactions.length}):`);
        transactions.forEach(t => {
            console.log(`   - ${t.transaction_type} $${t.amount} on ${t.transaction_date}: ${t.description}`);
        });
        
        // Calculate expected balance from transactions
        const calculatedBalance = transactions.reduce((sum, t) => {
            return sum + (t.transaction_type === 'DEBIT' ? -parseFloat(t.amount) : parseFloat(t.amount));
        }, 0);
        console.log(`\n   Calculated balance from transactions: ${calculatedBalance}`);
        
        // Check boarding payments
        const [payments] = await conn.execute(
            'SELECT id, amount_paid, base_currency_amount, payment_date, receipt_number, journal_entry_id FROM boarding_fees_payments WHERE student_reg_number = ? ORDER BY payment_date',
            [studentReg]
        );
        console.log(`\n   Boarding payments (${payments.length}):`);
        payments.forEach(p => {
            console.log(`   - Payment ${p.id}: $${p.base_currency_amount || p.amount_paid} on ${p.payment_date} (Receipt: ${p.receipt_number || 'N/A'}, Journal: ${p.journal_entry_id || 'None'})`);
        });
        
        // Check journal entries for payments
        payments.forEach(async (p) => {
            if (p.journal_entry_id) {
                const [journalLines] = await conn.execute(`
                    SELECT jel.account_id, jel.debit, jel.credit, coa.code, coa.name, coa.type
                    FROM journal_entry_lines jel
                    JOIN chart_of_accounts coa ON jel.account_id = coa.id
                    WHERE jel.journal_entry_id = ?
                `, [p.journal_entry_id]);
                
                console.log(`\n   Journal entry ${p.journal_entry_id} for payment ${p.id}:`);
                journalLines.forEach(line => {
                    console.log(`     - ${line.code} (${line.name}): Debit=${line.debit}, Credit=${line.credit}`);
                });
            }
        });
        
        // Check account balances
        console.log(`\n   Account balances:`);
        const [cashBalance] = await conn.execute(`
            SELECT ab.balance, coa.code, coa.name
            FROM account_balances ab
            JOIN chart_of_accounts coa ON ab.account_id = coa.id
            WHERE coa.code IN ('1000', '1010', '1100')
            ORDER BY ab.as_of_date DESC, coa.code
            LIMIT 3
        `);
        cashBalance.forEach(acc => {
            console.log(`     - ${acc.code} (${acc.name}): ${acc.balance}`);
        });
        
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        conn.release();
        process.exit();
    }
})();

