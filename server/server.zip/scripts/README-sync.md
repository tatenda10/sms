# Database Synchronization Tools

This directory contains tools for synchronizing data between your local database and DigitalOcean database.

## Files

- `bidirectional-sync.js` - Interactive sync tool (asks for credentials each time)
- `sync-with-config.js` - Config-based sync tool (uses configuration file)
- `sync-config.js` - Configuration template
- `README-sync.md` - This guide

## Quick Start

### Option 1: Using Configuration File (Recommended)

1. **Copy the config template:**
   ```bash
   cp sync-config.js my-sync-config.js
   ```

2. **Edit the configuration:**
   ```javascript
   module.exports = {
       local: {
           host: 'localhost',
           user: 'root',
           password: 'your_local_password',
           database: 'sms',
           port: 3306,
           ssl: false
       },
       remote: {
           host: 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
           user: 'doadmin',
           password: 'your_digitalocean_password',
           database: 'sms',
           port: 25060,
           ssl: { rejectUnauthorized: false }
       },
       options: {
           conflictResolution: 'local',  // 'local' or 'remote'
           createMissingTables: true,
           syncStructures: true,
           syncData: true,
           excludeTables: ['test_table'],
           includeTables: []  // Empty = sync all tables
       }
   };
   ```

3. **Run the sync:**
   ```bash
   node sync-with-config.js
   ```

### Option 2: Interactive Mode

```bash
node bidirectional-sync.js
```

## Features

### ✅ **Data Integrity**
- No data loss during sync
- Handles duplicate records intelligently
- Preserves relationships between tables

### ✅ **Conflict Resolution**
- Timestamp-based conflict detection
- Configurable conflict resolution strategy
- Detailed conflict reporting

### ✅ **Table Structure Sync**
- Automatically syncs table schemas
- Handles missing tables
- Preserves indexes and constraints

### ✅ **Bidirectional Sync**
- Local → Remote sync
- Remote → Local sync
- Handles records added online vs locally

### ✅ **Smart Filtering**
- Include/exclude specific tables
- Skip tables without primary keys
- Handle auto-increment columns

## Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| `conflictResolution` | Which database wins conflicts | `'local'` |
| `createMissingTables` | Create tables that don't exist | `true` |
| `syncStructures` | Sync table schemas | `true` |
| `syncData` | Sync table data | `true` |
| `excludeTables` | Tables to skip | `[]` |
| `includeTables` | Only sync these tables | `[]` |

## Conflict Resolution

### Timestamp-Based
- Uses `updated_at` or `created_at` columns
- Newer record wins automatically

### Strategy-Based
- `'local'`: Local database always wins
- `'remote'`: Remote database always wins

## Example Output

```
🔄 Bidirectional Database Synchronization Tool
==============================================

✅ Configuration loaded from sync-config.js
✅ Local database connected
✅ Remote database connected

🚀 Starting bidirectional database synchronization...

📊 Local tables: 45
📊 Remote tables: 0
📊 Total unique tables: 45
📊 Tables to sync: 45

🔄 Syncing table structure: users
✅ Table structure already in sync: users

🔄 Syncing table data: users
📥 Inserting 5 new records to remote
📥 Inserting 5 new records to local

📊 SYNC REPORT
================

📈 Statistics:
  - Tables processed: 45
  - Records inserted: 1250
  - Records updated: 0
  - Conflicts resolved: 0
  - Errors encountered: 0

✅ Successful Operations:
  - Data synced: users - 5 inserted, 0 updated
  - Data synced: students - 150 inserted, 0 updated
  - Data synced: classes - 25 inserted, 0 updated

🕐 Sync completed: 2024-01-15T10:30:45.123Z

🎉 Synchronization completed successfully!
```

## Troubleshooting

### Connection Issues
- Check your database credentials
- Ensure firewall allows connections
- Verify SSL settings for DigitalOcean

### Permission Issues
- Ensure user has CREATE, INSERT, UPDATE, DELETE permissions
- Check if user can access both databases

### Data Conflicts
- Review conflict report in output
- Adjust conflict resolution strategy
- Consider manual data review for critical tables

## Safety Features

- **Read-only operations first** - Analyzes before making changes
- **Transaction safety** - Each table sync is atomic
- **Backup recommendation** - Always backup before major syncs
- **Detailed logging** - Full audit trail of all operations

## Best Practices

1. **Test first** - Run on a copy of your database
2. **Backup regularly** - Before any major sync operation
3. **Monitor conflicts** - Review conflict reports carefully
4. **Incremental syncs** - Run syncs regularly to minimize conflicts
5. **Exclude test tables** - Add test tables to exclude list
