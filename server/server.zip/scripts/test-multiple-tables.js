const axios = require('axios');

async function testMultipleTables() {
  try {
    console.log('🔍 Testing sync with multiple tables...');
    
    // Test with multiple tables that have data
    const testData = {
      database_export: {
        test_students: {
          schema: 'CREATE TABLE `test_students` (`id` int NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Student 1' },
            { id: 2, name: 'Student 2' }
          ],
          record_count: 2
        },
        test_teachers: {
          schema: 'CREATE TABLE `test_teachers` (`id` int NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Teacher 1' },
            { id: 2, name: 'Teacher 2' },
            { id: 3, name: 'Teacher 3' }
          ],
          record_count: 3
        },
        test_subjects: {
          schema: 'CREATE TABLE `test_subjects` (`id` int NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Math' },
            { id: 2, name: 'Science' }
          ],
          record_count: 2
        }
      },
      timestamp: new Date().toISOString(),
      source: 'test_multiple_tables'
    };
    
    console.log('📤 Sending test data to server...');
    console.log('📊 Test data summary:', {
      tables: Object.keys(testData.database_export).length,
      totalRecords: Object.values(testData.database_export).reduce((sum, table) => sum + (table.record_count || 0), 0)
    });
    
    const syncResponse = await axios.post('https://server.learningladder.site/api/sync-full-db.php', testData, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 60000 // 1 minute timeout
    });
    
    console.log('✅ Server response:', JSON.stringify(syncResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testMultipleTables();
