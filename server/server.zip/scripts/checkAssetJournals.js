const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function checkAssetJournals() {
  const conn = await pool.getConnection();
  
  try {
    console.log('🔍 Checking fixed asset journal entries and account balances...\n');
    
    // Check recent assets
    const [assets] = await conn.execute(
      `SELECT 
        fa.id,
        fa.asset_code,
        fa.asset_name,
        fa.total_cost,
        fa.amount_paid,
        fa.outstanding_balance,
        fa.purchase_date,
        fa.is_opening_balance,
        fa.opening_balance_journal_id,
        fat.name as asset_type_name,
        coa.code as account_code,
        coa.name as account_name
       FROM fixed_assets fa
       JOIN fixed_asset_types fat ON fa.asset_type_id = fat.id
       JOIN chart_of_accounts coa ON fat.chart_of_account_id = coa.id
       ORDER BY fa.created_at DESC
       LIMIT 10`
    );
    
    console.log(`📊 Recent Assets (${assets.length}):\n`);
    assets.forEach((asset, index) => {
      console.log(`${index + 1}. ${asset.asset_name} (${asset.asset_code})`);
      console.log(`   Cost: $${asset.total_cost}, Paid: $${asset.amount_paid}, Outstanding: $${asset.outstanding_balance}`);
      console.log(`   Account: ${asset.account_code} - ${asset.account_name}`);
      console.log(`   Opening Balance: ${asset.is_opening_balance ? 'Yes' : 'No'}`);
      console.log(`   Opening Balance Journal ID: ${asset.opening_balance_journal_id || 'NULL'}`);
      console.log('');
    });
    
    // Check journal entries for assets
    console.log('📋 Journal Entries for Assets:\n');
    for (const asset of assets) {
      const [journalEntries] = await conn.execute(
        `SELECT 
          je.id,
          je.entry_date,
          je.description,
          je.reference
         FROM journal_entries je
         WHERE je.reference LIKE ? OR je.description LIKE ?
         ORDER BY je.entry_date DESC`,
        [`%${asset.asset_code}%`, `%${asset.asset_name}%`]
      );
      
      if (journalEntries.length > 0) {
        console.log(`   Asset: ${asset.asset_name}`);
        for (const je of journalEntries) {
          console.log(`     - Journal ID: ${je.id}, Date: ${je.entry_date}, Description: ${je.description}`);
          
          // Get journal entry lines
          const [lines] = await conn.execute(
            `SELECT 
              jel.account_id,
              coa.code as account_code,
              coa.name as account_name,
              jel.debit,
              jel.credit
             FROM journal_entry_lines jel
             JOIN chart_of_accounts coa ON jel.account_id = coa.id
             WHERE jel.journal_entry_id = ?`,
            [je.id]
          );
          
          lines.forEach(line => {
            console.log(`       ${line.account_code} - ${line.account_name}: DR $${line.debit}, CR $${line.credit}`);
          });
        }
        console.log('');
      }
    }
    
    // Check account balances for asset accounts
    console.log('💰 Account Balances for Asset Accounts:\n');
    const [assetAccounts] = await conn.execute(
      `SELECT DISTINCT
        coa.id,
        coa.code,
        coa.name
       FROM fixed_asset_types fat
       JOIN chart_of_accounts coa ON fat.chart_of_account_id = coa.id
       WHERE coa.is_active = TRUE`
    );
    
    for (const account of assetAccounts) {
      const [balanceRows] = await conn.execute(
        `SELECT 
          balance,
          as_of_date
         FROM account_balances
         WHERE account_id = ?
         ORDER BY as_of_date DESC
         LIMIT 1`,
        [account.id]
      );
      
      const currentBalance = balanceRows.length > 0 ? parseFloat(balanceRows[0].balance) : 0;
      const balanceDate = balanceRows.length > 0 ? balanceRows[0].as_of_date : 'No balance record';
      
      console.log(`   ${account.code} - ${account.name}:`);
      console.log(`     Balance: $${currentBalance.toFixed(2)} (as of ${balanceDate})`);
    }
    
    // Check asset payments
    console.log('\n💳 Recent Asset Payments:\n');
    const [payments] = await conn.execute(
      `SELECT 
        fap.id,
        fap.asset_id,
        fap.payment_date,
        fap.amount,
        fap.payment_method,
        fap.journal_entry_id,
        fa.asset_name
       FROM fixed_asset_payments fap
       JOIN fixed_assets fa ON fap.asset_id = fa.id
       ORDER BY fap.created_at DESC
       LIMIT 10`
    );
    
    console.log(`Found ${payments.length} payments:\n`);
    for (let index = 0; index < payments.length; index++) {
      const payment = payments[index];
      console.log(`${index + 1}. Payment for ${payment.asset_name}`);
      console.log(`   Amount: $${payment.amount}, Method: ${payment.payment_method}, Date: ${payment.payment_date}`);
      console.log(`   Journal Entry ID: ${payment.journal_entry_id || 'NULL'}`);
      
      if (payment.journal_entry_id) {
        const [lines] = await conn.execute(
          `SELECT 
            jel.account_id,
            coa.code as account_code,
            coa.name as account_name,
            jel.debit,
            jel.credit
           FROM journal_entry_lines jel
           JOIN chart_of_accounts coa ON jel.account_id = coa.id
           WHERE jel.journal_entry_id = ?`,
          [payment.journal_entry_id]
        );
        
        if (lines.length > 0) {
          console.log(`   Journal Lines:`);
          lines.forEach(line => {
            console.log(`     ${line.account_code} - ${line.account_name}: DR $${line.debit}, CR $${line.credit}`);
          });
        }
      }
      console.log('');
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkAssetJournals();

