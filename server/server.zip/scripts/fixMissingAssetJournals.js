const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const AccountBalanceService = require('../services/accountBalanceService');

async function fixMissingAssetJournals() {
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    console.log('🔧 Fixing missing journal entries for fixed assets...\n');
    
    // Find assets without purchase journal entries (excluding opening balances which have opening_balance_journal_id)
    const [assets] = await conn.execute(
      `SELECT 
        fa.id,
        fa.asset_code,
        fa.asset_name,
        fa.total_cost,
        fa.amount_paid,
        fa.outstanding_balance,
        fa.purchase_date,
        fa.is_opening_balance,
        fa.opening_balance_journal_id,
        fat.chart_of_account_id,
        fat.name as asset_type_name,
        coa.code as account_code,
        coa.name as account_name
       FROM fixed_assets fa
       JOIN fixed_asset_types fat ON fa.asset_type_id = fat.id
       JOIN chart_of_accounts coa ON fat.chart_of_account_id = coa.id
       WHERE fa.is_opening_balance = FALSE
         AND NOT EXISTS (
           SELECT 1 FROM journal_entries je 
           WHERE (je.reference = CONCAT('AST-', fa.asset_code) 
                  OR je.description LIKE CONCAT('Asset Purchase: %', fa.asset_name, '%'))
             AND je.description LIKE '%Asset Purchase%'
         )
       ORDER BY fa.created_at DESC`
    );
    
    console.log(`Found ${assets.length} assets missing journal entries:\n`);
    
    // Get or create journal
    let journalId = 6;
    const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journalId]);
    if (journalCheck.length === 0) {
      const [anyJournal] = await conn.execute('SELECT id FROM journals LIMIT 1');
      if (anyJournal.length > 0) {
        journalId = anyJournal[0].id;
      } else {
        const [journalResult] = await conn.execute(
          'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
          ['Fees Journal', 'Journal for fee payment transactions', 1]
        );
        journalId = journalResult.insertId;
      }
    }
    
    // Get currency
    const [currencies] = await conn.execute(
      'SELECT id FROM currencies WHERE base_currency = TRUE LIMIT 1'
    );
    const currency_id = currencies.length > 0 ? currencies[0].id : 1;
    
    // Get accounts
    const [[cashAccount]] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
      ['1000', 'Asset']
    );
    
    const [[bankAccount]] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
      ['1010', 'Asset']
    );
    
    const [[accountsPayable]] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ?',
      ['2000']
    );
    
    for (const asset of assets) {
      console.log(`Processing: ${asset.asset_name} (${asset.asset_code})`);
      
      const refNumber = `AST-${asset.asset_code}`;
      const journalDescription = `Asset Purchase: ${asset.asset_name} - ${asset.asset_type_name}`;
      
      // Create journal entry
      const [journalResult] = await conn.execute(`
        INSERT INTO journal_entries (
          journal_id, entry_date, description, reference,
          created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 1, NOW(), NOW())
      `, [journalId, asset.purchase_date, journalDescription, refNumber]);
      
      const purchaseJournalId = journalResult.insertId;
      console.log(`   Created journal entry ID: ${purchaseJournalId}`);
      
      // DEBIT: Fixed Asset Account
      await conn.execute(`
        INSERT INTO journal_entry_lines (
          journal_entry_id, account_id, debit, credit, description
        ) VALUES (?, ?, ?, 0, ?)
      `, [purchaseJournalId, asset.chart_of_account_id, asset.total_cost, `${asset.asset_type_name} - ${asset.asset_name}`]);
      console.log(`   DEBIT: ${asset.account_code} - $${asset.total_cost}`);
      
      // Check if there were any payments made at purchase time
      // For now, we'll credit Accounts Payable for the full amount
      // The payment journal entries will handle reducing Accounts Payable
      if (accountsPayable) {
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, 0, ?, ?)
        `, [purchaseJournalId, accountsPayable.id, asset.total_cost, `Accounts Payable - ${asset.asset_name}`]);
        console.log(`   CREDIT: 2000 - Accounts Payable - $${asset.total_cost}`);
      }
      
      // Update account balances
      await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, purchaseJournalId, currency_id);
      console.log(`   ✅ Updated account balances\n`);
    }
    
    await conn.commit();
    console.log(`\n✅ Successfully created ${assets.length} journal entries and updated account balances!`);
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixMissingAssetJournals();

