const { pool } = require('../config/database');

async function checkTransportPaymentsColumns() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking transport_payments table columns...');
    
    const [columns] = await connection.execute('DESCRIBE transport_payments');
    
    console.log('\n📋 transport_payments table structure:');
    console.log('┌─────────────────────┬─────────────┬──────┬─────┬─────────┬─────┐');
    console.log('│ Field               │ Type        │ Null │ Key │ Default │ Extra│');
    console.log('├─────────────────────┼─────────────┼──────┼─────┼─────────┼─────┤');
    
    columns.forEach(col => {
      const field = col.Field.padEnd(19);
      const type = col.Type.padEnd(11);
      const nullAllowed = col.Null.padEnd(4);
      const key = (col.Key || '').padEnd(3);
      const defaultVal = (col.Default || '').padEnd(7);
      const extra = col.Extra || '';
      
      console.log(`│ ${field} │ ${type} │ ${nullAllowed} │ ${key} │ ${defaultVal} │ ${extra} │`);
    });
    
    console.log('└─────────────────────┴─────────────┴──────┴─────┴─────────┴─────┘');
    
    // Check for specific columns we need
    const requiredColumns = ['route_id', 'student_reg_number', 'transport_fee_id'];
    const existingColumns = [];
    const missingColumns = [];
    
    requiredColumns.forEach(reqCol => {
      const found = columns.find(col => col.Field === reqCol);
      if (found) {
        existingColumns.push(reqCol);
      } else {
        missingColumns.push(reqCol);
      }
    });
    
    console.log('\n🎯 Column analysis:');
    console.log('   ✅ Existing columns:');
    existingColumns.forEach(col => {
      console.log(`      • ${col}`);
    });
    
    if (missingColumns.length > 0) {
      console.log('   ❌ Missing columns:');
      missingColumns.forEach(col => {
        console.log(`      • ${col}`);
      });
    }
    
  } catch (error) {
    console.error('\n❌ Error checking transport_payments columns:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkTransportPaymentsColumns()
    .then(() => {
      console.log('\n✅ Transport payments columns check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Transport payments columns check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkTransportPaymentsColumns;
