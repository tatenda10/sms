const { pool } = require('../config/database');

async function testInvoiceAmounts() {
    const conn = await pool.getConnection();
    try {
        console.log('Testing invoice amounts for class enrollments...\n');
        
        // Check if invoice_structures table has data
        const [invoiceStructures] = await conn.execute(
            'SELECT * FROM invoice_structures LIMIT 5'
        );
        
        console.log('Invoice structures found:', invoiceStructures.length);
        if (invoiceStructures.length > 0) {
            console.log('Sample invoice structure:', invoiceStructures[0]);
        }
        
        // Check gradelevel_classes
        const [gradelevelClasses] = await conn.execute(
            'SELECT id, name FROM gradelevel_classes LIMIT 5'
        );
        
        console.log('\nGrade level classes found:', gradelevelClasses.length);
        if (gradelevelClasses.length > 0) {
            console.log('Sample class:', gradelevelClasses[0]);
        }
        
        // Test the query that gets invoice amounts
        if (gradelevelClasses.length > 0) {
            const classId = gradelevelClasses[0].id;
            console.log(`\nTesting invoice amount lookup for class ID: ${classId}`);
            
            const [invoiceAmount] = await conn.execute(
                `SELECT total_amount, term, academic_year 
                 FROM invoice_structures 
                 WHERE gradelevel_class_id = ? 
                 ORDER BY academic_year DESC, term DESC 
                 LIMIT 1`,
                [classId]
            );
            
            if (invoiceAmount.length > 0) {
                console.log(`✓ Found invoice amount: ${invoiceAmount[0].total_amount}`);
                console.log(`✓ Term: ${invoiceAmount[0].term || 'NULL'}`);
                console.log(`✓ Academic Year: ${invoiceAmount[0].academic_year || 'NULL'}`);
            } else {
                console.log('✗ No invoice amount found for this class');
            }
        }
        
        // Check enrollments
        const [enrollments] = await conn.execute(
            'SELECT * FROM enrollments_gradelevel_classes LIMIT 5'
        );
        
        console.log('\nEnrollments found:', enrollments.length);
        if (enrollments.length > 0) {
            console.log('Sample enrollment:', enrollments[0]);
        }
        
        // Test the full query that combines enrollments with invoice amounts
        if (enrollments.length > 0) {
            const studentRegNumber = enrollments[0].student_regnumber;
            console.log(`\nTesting full query for student: ${studentRegNumber}`);
            
            const [fullQuery] = await conn.execute(
                `SELECT 
                    e.id,
                    e.student_regnumber,
                    gc.name as class_name,
                    COALESCE((
                        SELECT total_amount 
                        FROM invoice_structures 
                        WHERE gradelevel_class_id = e.gradelevel_class_id 
                        ORDER BY academic_year DESC, term DESC 
                        LIMIT 1
                    ), 0) as amount,
                    CASE 
                        WHEN (
                            SELECT term 
                            FROM invoice_structures 
                            WHERE gradelevel_class_id = e.gradelevel_class_id 
                            ORDER BY academic_year DESC, term DESC 
                            LIMIT 1
                        ) IS NOT NULL THEN
                            REGEXP_REPLACE((
                                SELECT term 
                                FROM invoice_structures 
                                WHERE gradelevel_class_id = e.gradelevel_class_id 
                                ORDER BY academic_year DESC, term DESC 
                                LIMIT 1
                            ), 'Term\\s*', '')
                        ELSE NULL
                    END as term,
                    COALESCE((
                        SELECT academic_year 
                        FROM invoice_structures 
                        WHERE gradelevel_class_id = e.gradelevel_class_id 
                        ORDER BY academic_year DESC, term DESC 
                        LIMIT 1
                    ), NULL) as academic_year
                 FROM enrollments_gradelevel_classes e
                 LEFT JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
                 WHERE e.student_regnumber = ?
                 LIMIT 3`,
                [studentRegNumber]
            );
            
            console.log('Full query results:');
            fullQuery.forEach((row, index) => {
                console.log(`  ${index + 1}. Class: ${row.class_name}, Amount: ${row.amount}, Term: ${row.term || 'NULL'}, Year: ${row.academic_year || 'NULL'}`);
            });
        }
        
    } catch (error) {
        console.error('Error testing invoice amounts:', error);
    } finally {
        conn.release();
    }
}

// Run the test if called directly
if (require.main === module) {
    testInvoiceAmounts()
        .then(() => {
            console.log('\nTest completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testInvoiceAmounts };
