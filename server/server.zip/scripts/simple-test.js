const { pool } = require('../config/database');

async function simpleTest() {
    try {
        console.log('Testing database connection...');
        
        const [result] = await pool.execute('SELECT 1 as test');
        console.log('Database connection successful:', result[0]);
        
        const [students] = await pool.execute('SELECT COUNT(*) as count FROM students');
        console.log('Students count:', students[0].count);
        
        const [balances] = await pool.execute('SELECT COUNT(*) as count FROM student_balances');
        console.log('Balance records count:', balances[0].count);
        
        const [transactions] = await pool.execute('SELECT COUNT(*) as count FROM student_transactions');
        console.log('Transactions count:', transactions[0].count);
        
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await pool.end();
    }
}

simpleTest();
