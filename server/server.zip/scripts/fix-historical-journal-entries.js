const mysql = require('mysql2/promise');
require('dotenv').config();

class HistoricalJournalEntryFixer {
  constructor() {
    this.pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'school_management',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
  }

  async connect() {
    try {
      const connection = await this.pool.getConnection();
      console.log('✅ Connected to database successfully');
      connection.release();
    } catch (error) {
      console.error('❌ Database connection failed:', error.message);
      throw error;
    }
  }

  async createJournalEntry(description, reference, createdBy = 1) {
    try {
      // First, create a journal entry
      const [journalEntryResult] = await this.pool.execute(
        'INSERT INTO journal_entries (journal_id, entry_date, reference, description, created_by, created_at, updated_at) VALUES (1, CURDATE(), ?, ?, ?, NOW(), NOW())',
        [reference, description, createdBy]
      );
      
      return journalEntryResult.insertId;
    } catch (error) {
      console.error('❌ Error creating journal entry:', error.message);
      throw error;
    }
  }

  async createJournalEntryLine(journalEntryId, accountId, debit, credit, description, currencyId = 1, currencyCode = 'USD', exchangeRate = 1) {
    try {
      const [result] = await this.pool.execute(
        'INSERT INTO journal_entry_lines (journal_entry_id, account_id, description, debit, credit, currency_id, currency_code, exchange_rate, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
        [journalEntryId, accountId, description, debit, credit, currencyId, currencyCode, exchangeRate]
      );
      
      return result.insertId;
    } catch (error) {
      console.error('❌ Error creating journal entry line:', error.message);
      throw error;
    }
  }

  async getAccountIdByType(type, description = '') {
    try {
      let query = 'SELECT id FROM chart_of_accounts WHERE type = ? AND is_active = 1 LIMIT 1';
      let params = [type];

      // For specific revenue types, try to find more specific accounts
      if (type === 'REVENUE') {
        if (description.toLowerCase().includes('tuition')) {
          query = 'SELECT id FROM chart_of_accounts WHERE name LIKE ? AND type = ? AND is_active = 1 LIMIT 1';
          params = ['%tuition%', type];
        } else if (description.toLowerCase().includes('boarding')) {
          query = 'SELECT id FROM chart_of_accounts WHERE name LIKE ? AND type = ? AND is_active = 1 LIMIT 1';
          params = ['%boarding%', type];
        }
      }

      const [accounts] = await this.pool.execute(query, params);
      
      if (accounts.length === 0) {
        console.warn(`⚠️ No account found for type: ${type}, description: ${description}`);
        return null;
      }
      
      return accounts[0].id;
    } catch (error) {
      console.error('❌ Error getting account ID:', error.message);
      return null;
    }
  }

  async fixTuitionFeePayments() {
    console.log('\n🔧 Fixing Tuition Fee Payments...');
    
    try {
      // Get fee payments without journal entries
      const [feePayments] = await this.pool.execute(
        'SELECT * FROM fee_payments WHERE journal_entry_id IS NULL'
      );

      console.log(`📊 Found ${feePayments.length} fee payments without journal entries`);

      let successCount = 0;
      let errorCount = 0;

      for (const payment of feePayments) {
        try {
          // Get Cash account (Asset)
          const cashAccountId = await this.getAccountIdByType('ASSET', 'cash');
          if (!cashAccountId) {
            console.warn(`⚠️ Cash account not found for payment ${payment.id}`);
            continue;
          }

          // Get Tuition Revenue account (Revenue)
          const revenueAccountId = await this.getAccountIdByType('REVENUE', 'tuition');
          if (!revenueAccountId) {
            console.warn(`⚠️ Revenue account not found for payment ${payment.id}`);
            continue;
          }

          // Create journal entry
          const journalEntryId = await this.createJournalEntry(
            `Tuition Fee Payment - ${payment.receipt_number}`,
            payment.receipt_number,
            payment.created_by || 1
          );

          // Create journal entry lines (double-entry)
          // Debit Cash account
          await this.createJournalEntryLine(
            journalEntryId,
            cashAccountId,
            payment.base_currency_amount,
            0,
            `Cash received for tuition payment - ${payment.receipt_number}`,
            payment.payment_currency || 1,
            payment.payment_currency_code || 'USD',
            payment.exchange_rate || 1
          );

          // Credit Tuition Revenue account
          await this.createJournalEntryLine(
            journalEntryId,
            revenueAccountId,
            0,
            payment.base_currency_amount,
            `Tuition revenue from payment - ${payment.receipt_number}`,
            payment.payment_currency || 1,
            payment.payment_currency_code || 'USD',
            payment.exchange_rate || 1
          );

          // Update fee_payments table with journal_entry_id
          await this.pool.execute(
            'UPDATE fee_payments SET journal_entry_id = ? WHERE id = ?',
            [journalEntryId, payment.id]
          );

          console.log(`✅ Fixed fee payment ${payment.id} with journal entry ${journalEntryId}`);
          successCount++;
        } catch (error) {
          console.error(`❌ Error fixing fee payment ${payment.id}:`, error.message);
          errorCount++;
        }
      }

      console.log(`📊 Tuition Fee Payments: ${successCount} fixed, ${errorCount} errors`);
    } catch (error) {
      console.error('❌ Error in fixTuitionFeePayments:', error.message);
    }
  }

  async fixStudentTransactions() {
    console.log('\n🔧 Fixing Student Transactions...');
    
    try {
      // Get student transactions without journal entries
      const [studentTransactions] = await this.pool.execute(
        'SELECT * FROM student_transactions WHERE journal_entry_id IS NULL'
      );

      console.log(`📊 Found ${studentTransactions.length} student transactions without journal entries`);

      let successCount = 0;
      let errorCount = 0;

      for (const transaction of studentTransactions) {
        try {
          // Get Cash account (Asset)
          const cashAccountId = await this.getAccountIdByType('ASSET', 'cash');
          if (!cashAccountId) {
            console.warn(`⚠️ Cash account not found for transaction ${transaction.id}`);
            continue;
          }

          // Determine the corresponding account based on transaction type and description
          let correspondingAccountId;
          let accountType = 'REVENUE'; // Default to revenue

          if (transaction.transaction_type === 'DEBIT') {
            // Student is paying money (credit to revenue/asset)
            correspondingAccountId = await this.getAccountIdByType('REVENUE', transaction.description);
            if (!correspondingAccountId) {
              correspondingAccountId = await this.getAccountIdByType('ASSET', transaction.description);
            }
          } else {
            // Student is receiving money (debit to expense/asset)
            correspondingAccountId = await this.getAccountIdByType('EXPENSE', transaction.description);
            if (!correspondingAccountId) {
              correspondingAccountId = await this.getAccountIdByType('ASSET', transaction.description);
            }
            accountType = 'EXPENSE';
          }

          if (!correspondingAccountId) {
            console.warn(`⚠️ Corresponding account not found for transaction ${transaction.id}`);
            continue;
          }

          // Create journal entry
          const journalEntryId = await this.createJournalEntry(
            `Student Transaction - ${transaction.description}`,
            `ST-${transaction.id}`,
            transaction.created_by || 1
          );

          // Create journal entry lines (double-entry)
          if (transaction.transaction_type === 'DEBIT') {
            // Debit Cash account
            await this.createJournalEntryLine(
              journalEntryId,
              cashAccountId,
              transaction.amount,
              0,
              `Cash received - ${transaction.description}`,
              1, 'USD', 1
            );

            // Credit Revenue/Asset account
            await this.createJournalEntryLine(
              journalEntryId,
              correspondingAccountId,
              0,
              transaction.amount,
              `Revenue from ${transaction.description}`,
              1, 'USD', 1
            );
          } else {
            // Credit Cash account
            await this.createJournalEntryLine(
              journalEntryId,
              cashAccountId,
              0,
              transaction.amount,
              `Cash paid - ${transaction.description}`,
              1, 'USD', 1
            );

            // Debit Expense/Asset account
            await this.createJournalEntryLine(
              journalEntryId,
              correspondingAccountId,
              transaction.amount,
              0,
              `Expense for ${transaction.description}`,
              1, 'USD', 1
            );
          }

          // Update student_transactions table with journal_entry_id
          await this.pool.execute(
            'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
            [journalEntryId, transaction.id]
          );

          console.log(`✅ Fixed student transaction ${transaction.id} with journal entry ${journalEntryId}`);
          successCount++;
        } catch (error) {
          console.error(`❌ Error fixing student transaction ${transaction.id}:`, error.message);
          errorCount++;
        }
      }

      console.log(`📊 Student Transactions: ${successCount} fixed, ${errorCount} errors`);
    } catch (error) {
      console.error('❌ Error in fixStudentTransactions:', error.message);
    }
  }

  async fixBoardingFeePayments() {
    console.log('\n🔧 Fixing Boarding Fee Payments...');
    
    try {
      // Get boarding fee payments without journal entries
      const [boardingPayments] = await this.pool.execute(
        'SELECT * FROM boarding_fees_payments WHERE journal_entry_id IS NULL'
      );

      console.log(`📊 Found ${boardingPayments.length} boarding fee payments without journal entries`);

      let successCount = 0;
      let errorCount = 0;

      for (const payment of boardingPayments) {
        try {
          // Get Cash account (Asset)
          const cashAccountId = await this.getAccountIdByType('ASSET', 'cash');
          if (!cashAccountId) {
            console.warn(`⚠️ Cash account not found for boarding payment ${payment.id}`);
            continue;
          }

          // Get Boarding Revenue account (Revenue)
          const revenueAccountId = await this.getAccountIdByType('REVENUE', 'boarding');
          if (!revenueAccountId) {
            console.warn(`⚠️ Boarding revenue account not found for payment ${payment.id}`);
            continue;
          }

          // Create journal entry
          const journalEntryId = await this.createJournalEntry(
            `Boarding Fee Payment - ${payment.receipt_number}`,
            payment.receipt_number,
            payment.created_by || 1
          );

          // Create journal entry lines (double-entry)
          // Debit Cash account
          await this.createJournalEntryLine(
            journalEntryId,
            cashAccountId,
            payment.amount,
            0,
            `Cash received for boarding payment - ${payment.receipt_number}`,
            payment.currency_id || 1,
            payment.currency_code || 'USD',
            payment.exchange_rate || 1
          );

          // Credit Boarding Revenue account
          await this.createJournalEntryLine(
            journalEntryId,
            revenueAccountId,
            0,
            payment.amount,
            `Boarding revenue from payment - ${payment.receipt_number}`,
            payment.currency_id || 1,
            payment.currency_code || 'USD',
            payment.exchange_rate || 1
          );

          // Update boarding_fees_payments table with journal_entry_id
          await this.pool.execute(
            'UPDATE boarding_fees_payments SET journal_entry_id = ? WHERE id = ?',
            [journalEntryId, payment.id]
          );

          console.log(`✅ Fixed boarding payment ${payment.id} with journal entry ${journalEntryId}`);
          successCount++;
        } catch (error) {
          console.error(`❌ Error fixing boarding payment ${payment.id}:`, error.message);
          errorCount++;
        }
      }

      console.log(`📊 Boarding Fee Payments: ${successCount} fixed, ${errorCount} errors`);
    } catch (error) {
      console.error('❌ Error in fixBoardingFeePayments:', error.message);
    }
  }

  async run() {
    try {
      console.log('🚀 Starting Historical Journal Entry Fixer...');
      
      await this.connect();
      
      // Check if default journal exists, create if not
      const [journals] = await this.pool.execute('SELECT id FROM journals WHERE id = 1');
      if (journals.length === 0) {
        console.log('📝 Creating default journal...');
        await this.pool.execute(
          'INSERT INTO journals (id, name, description, is_active, created_at, updated_at) VALUES (1, "General Journal", "Default journal for system transactions", 1, NOW(), NOW())'
        );
      }

      await this.fixTuitionFeePayments();
      await this.fixStudentTransactions();
      await this.fixBoardingFeePayments();
      
      console.log('\n✅ Historical Journal Entry Fixer completed successfully!');
    } catch (error) {
      console.error('❌ Historical Journal Entry Fixer failed:', error.message);
    } finally {
      await this.pool.end();
    }
  }
}

// Run the fixer
const fixer = new HistoricalJournalEntryFixer();
fixer.run();
