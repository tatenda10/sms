const { pool } = require('../config/database');

async function testTransportStudentTransactions() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing transport payment student transactions...');
    
    // Check recent transport payments
    console.log('\n📋 Recent transport payments:');
    const [recentPayments] = await connection.execute(`
      SELECT 
        tp.id,
        tp.student_reg_number,
        tp.amount,
        tp.payment_date,
        tp.reference_number,
        tr.route_name
      FROM transport_payments tp
      LEFT JOIN transport_routes tr ON tp.route_id = tr.id
      ORDER BY tp.payment_date DESC
      LIMIT 5
    `);
    
    if (recentPayments.length === 0) {
      console.log('   ❌ No transport payments found');
      return;
    }
    
    recentPayments.forEach((payment, index) => {
      console.log(`   ${index + 1}. Student: ${payment.student_reg_number}`);
      console.log(`      Amount: $${payment.amount}`);
      console.log(`      Date: ${payment.payment_date}`);
      console.log(`      Reference: ${payment.reference_number}`);
      console.log(`      Route: ${payment.route_name || 'Unknown'}`);
      console.log('');
    });
    
    // Check student transactions for the most recent payment
    const mostRecentPayment = recentPayments[0];
    console.log(`🔍 Checking student transactions for ${mostRecentPayment.student_reg_number}...`);
    
    const [studentTransactions] = await connection.execute(`
      SELECT 
        st.id,
        st.transaction_type,
        st.amount,
        st.description,
        st.created_at,
        st.created_by
      FROM student_transactions st
      WHERE st.student_reg_number = ?
      ORDER BY st.created_at DESC
      LIMIT 10
    `, [mostRecentPayment.student_reg_number]);
    
    if (studentTransactions.length === 0) {
      console.log('   ❌ No student transactions found for this student');
    } else {
      console.log(`   ✅ Found ${studentTransactions.length} student transactions:`);
      studentTransactions.forEach((transaction, index) => {
        console.log(`   ${index + 1}. ${transaction.transaction_type}: $${transaction.amount}`);
        console.log(`      Description: ${transaction.description}`);
        console.log(`      Date: ${transaction.created_at}`);
        console.log('');
      });
    }
    
    // Check if there's a transaction matching the transport payment
    const [matchingTransactions] = await connection.execute(`
      SELECT 
        st.id,
        st.transaction_type,
        st.amount,
        st.description,
        st.created_at
      FROM student_transactions st
      WHERE st.student_reg_number = ?
        AND st.description LIKE ?
        AND st.amount = ?
      ORDER BY st.created_at DESC
    `, [mostRecentPayment.student_reg_number, `%Transport Payment%`, mostRecentPayment.amount]);
    
    if (matchingTransactions.length > 0) {
      console.log('   ✅ Found matching transport payment transaction:');
      matchingTransactions.forEach(transaction => {
        console.log(`      ID: ${transaction.id}`);
        console.log(`      Type: ${transaction.transaction_type}`);
        console.log(`      Amount: $${transaction.amount}`);
        console.log(`      Description: ${transaction.description}`);
        console.log(`      Date: ${transaction.created_at}`);
      });
    } else {
      console.log('   ❌ No matching transport payment transaction found');
      console.log('   This indicates the transport payment is not creating student transactions properly');
    }
    
    // Check student balance
    console.log('\n💰 Checking student balance...');
    const [studentBalance] = await connection.execute(`
      SELECT 
        sb.student_reg_number,
        sb.balance,
        sb.last_updated
      FROM student_balances sb
      WHERE sb.student_reg_number = ?
    `, [mostRecentPayment.student_reg_number]);
    
    if (studentBalance.length > 0) {
      const balance = studentBalance[0];
      console.log(`   Student: ${balance.student_reg_number}`);
      console.log(`   Balance: $${balance.balance}`);
      console.log(`   Last Updated: ${balance.last_updated}`);
    } else {
      console.log('   ❌ No student balance record found');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing transport student transactions:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testTransportStudentTransactions()
    .then(() => {
      console.log('\n✅ Transport student transactions test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Transport student transactions test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testTransportStudentTransactions;
