const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function fixStudentBalanceDirect() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔧 Fixing balance for student: ${studentRegNumber}\n`);
    
    // Get all transactions to calculate correct balance
    const [transactions] = await conn.execute(
      `SELECT transaction_type, amount FROM student_transactions 
       WHERE student_reg_number = ?`,
      [studentRegNumber]
    );
    
    let calculatedBalance = 0;
    transactions.forEach(tx => {
      const amount = parseFloat(tx.amount);
      if (tx.transaction_type === 'CREDIT') {
        calculatedBalance += amount;
      } else {
        calculatedBalance -= amount;
      }
    });
    
    console.log(`📊 Calculated balance from ${transactions.length} transactions: $${calculatedBalance.toFixed(2)}\n`);
    
    // Update or create balance record
    await conn.execute(
      `INSERT INTO student_balances (student_reg_number, current_balance, last_updated) 
       VALUES (?, ?, CURRENT_TIMESTAMP)
       ON DUPLICATE KEY UPDATE 
         current_balance = VALUES(current_balance),
         last_updated = CURRENT_TIMESTAMP`,
      [studentRegNumber, calculatedBalance]
    );
    
    console.log(`✅ Balance updated to $${calculatedBalance.toFixed(2)}`);
    
    // Verify
    const [balanceRecord] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    if (balanceRecord.length > 0) {
      const finalBalance = parseFloat(balanceRecord[0].current_balance);
      console.log(`\n📋 Final balance: $${finalBalance.toFixed(2)}`);
      if (Math.abs(finalBalance) < 0.01) {
        console.log('✅ Balance is now $0.00');
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixStudentBalanceDirect();

