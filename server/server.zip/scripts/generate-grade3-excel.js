const ExcelJS = require('exceljs');
const { pool } = require('./config/database');

// Student data extracted from the Grade 3 sheet
const studentData = [
  { name: 'Solomon', surname: 'Mutambiranwa', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 100 },
  { name: 'Zerubabbel', surname: 'Chitakatira', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Prosper', surname: 'Choga', balReg: 50, payment1: 50, payment2: 0, payment3: 0, total: 50 },
  { name: 'Tinodaishe', surname: 'Bhudhi', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Princess', surname: 'Gowe', balReg: 30, payment1: 0, payment2: 0, payment3: 0, total: 100 },
  { name: 'Keilla', surname: 'Gwerendende', balReg: 50, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Nick', surname: 'Mademutsa', balReg: 50, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Tashinga', surname: 'Mafuwu', balReg: 20, payment1: 10, payment2: 10, payment3: 0, total: 20 },
  { name: 'Nomilna', surname: 'Makora', balReg: -130, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Asher', surname: 'Mutadzakupa', balReg: -130, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Bradley', surname: 'Majinjiwa', balReg: 100, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Ethan', surname: 'Muchemwenyi', balReg: 100, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'K Mary', surname: 'Mutetwa', balReg: -50, payment1: 50, payment2: 0, payment3: 0, total: 50 },
  { name: 'Kudzaishe', surname: 'Mutukumira', balReg: 40, payment1: 40, payment2: 60, payment3: 0, total: 100 },
  { name: 'Nobuhle', surname: 'Nyoni', balReg: 50, payment1: 25, payment2: 0, payment3: 0, total: 25 },
  { name: 'Tinotenda', surname: 'Ndoro', balReg: 40, payment1: 40, payment2: 60, payment3: 0, total: 100 },
  { name: 'Mufaro', surname: 'Sanyamandwe', balReg: -10, payment1: 70, payment2: 0, payment3: 0, total: 70 },
  { name: 'Lilian', surname: 'Nyamatanga', balReg: -10, payment1: 50, payment2: 20, payment3: 30, total: 100 },
  { name: 'Edmore', surname: 'Muzindi', balReg: 100, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Kupakwashe', surname: 'Nyava', balReg: 40, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Ryley', surname: 'Chasakara', balReg: 45, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Petronella', surname: 'Sithole', balReg: -280, payment1: 25, payment2: 0, payment3: 0, total: 25 },
  { name: 'Martin', surname: 'Mazuru', balReg: 50, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Sean', surname: 'Tambudzi', balReg: -140, payment1: 40, payment2: 0, payment3: 0, total: 40 },
  { name: 'Alicia', surname: 'Kumire', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Jayden', surname: 'Masiiwa', balReg: 25, payment1: 30, payment2: 0, payment3: 0, total: 30 },
  { name: 'Anicia', surname: 'Kumire', balReg: -170, payment1: 30, payment2: 0, payment3: 0, total: 30 },
  { name: 'Soviet', surname: 'Haisa', balReg: 50, payment1: 20, payment2: 30, payment3: 50, total: 100 },
  { name: 'Sean', surname: 'Kasunungura', balReg: -15, payment1: 50, payment2: 0, payment3: 0, total: 50 },
  { name: 'Munashe', surname: 'Nyoni', balReg: 40, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Alma', surname: 'Chakara', balReg: 50, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Tashinga', surname: 'Mupesi', balReg: 100, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Anesu', surname: 'Kamuzondi', balReg: 50, payment1: 20, payment2: 20, payment3: 0, total: 40 },
  { name: 'Benster', surname: 'Gomera', balReg: 50, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Tinevimbo', surname: 'Chitambo', balReg: 55, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Bradley', surname: 'Muzanamombe', balReg: 230, payment1: 10, payment2: 0, payment3: 0, total: 10 },
  { name: 'Moreblessing', surname: 'Somihembe', balReg: -180, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Daryl', surname: 'Mupedzisi', balReg: 50, payment1: 25, payment2: 35, payment3: 0, total: 60 },
  { name: 'Unknown', surname: 'Unknown', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 107 },
  { name: 'Devine', surname: 'Magombe', balReg: -210, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Lloyd', surname: 'Kufakujeri', balReg: -110, payment1: 0, payment2: 0, payment3: 0, total: 120 },
  { name: 'Grace', surname: 'Mukarati', balReg: 30, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Unknown', surname: 'Unknown', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 0 }
];

// Function to generate registration number based on existing pattern
// Pattern: R + 5 digits + letter (e.g., R05688P, R79290B)
async function generateRegNumber(name, surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 0;
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY RegNumber DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  // Generate new number (increment from max)
  const newNumber = maxNumber + 1;
  const numberStr = String(newNumber).padStart(5, '0');
  
  // Generate letter suffix based on surname first letter (or name if no surname)
  const letterSource = surname || name;
  const firstLetter = letterSource.charAt(0).toUpperCase();
  const letter = /[A-Z]/.test(firstLetter) ? firstLetter : 'A';
  
  const regNumber = `R${numberStr}${letter}`;
  
  // Check for duplicates and adjust if needed
  if (existingNumbers.has(regNumber)) {
    // If duplicate, try next letter
    const nextLetter = String.fromCharCode(letter.charCodeAt(0) + 1);
    return `R${numberStr}${nextLetter > 'Z' ? 'A' : nextLetter}`;
  }
  
  existingNumbers.add(regNumber);
  return regNumber;
}

async function generateExcel() {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grade 3 Students');
  
  // Set column headers
  worksheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Surname', key: 'surname', width: 20 },
    { header: 'Registration Number', key: 'regNumber', width: 18 },
    { header: 'Class', key: 'class', width: 15 },
    { header: 'Balance', key: 'balance', width: 12 },
    { header: 'Total Payments', key: 'totalPayments', width: 15 }
  ];
  
  // Style the header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Get existing registration numbers to avoid duplicates
  const existingNumbers = new Set();
  try {
    const [existing] = await pool.execute('SELECT RegNumber FROM students');
    existing.forEach(row => existingNumbers.add(row.RegNumber));
  } catch (error) {
    console.log('Could not fetch existing reg numbers');
  }
  
  // Add student data
  for (const student of studentData) {
    const regNumber = await generateRegNumber(student.name, student.surname, existingNumbers);
    
    // Calculate total payments (use total column if provided, otherwise sum payments)
    const totalPayments = student.total || (student.payment1 || 0) + (student.payment2 || 0) + (student.payment3 || 0);
    
    worksheet.addRow({
      name: student.name,
      surname: student.surname,
      regNumber: regNumber,
      class: 'Grade 3',
      balance: student.balReg || 0,
      totalPayments: totalPayments
    });
  }
  
  // Format balance column (negative values in red)
  worksheet.getColumn('balance').numFmt = '$#,##0.00';
  worksheet.getColumn('totalPayments').numFmt = '$#,##0.00';
  
  // Add conditional formatting for negative balances
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) { // Skip header
      const balanceCell = row.getCell('balance');
      if (balanceCell.value < 0) {
        balanceCell.font = { color: { argb: 'FFFF0000' } }; // Red
      }
    }
  });
  
  // Save the file
  const filename = 'Grade3_Students_Data.xlsx';
  await workbook.xlsx.writeFile(filename);
  console.log(`\n✅ Excel file created: ${filename}`);
  console.log(`📊 Total students: ${studentData.length}`);
  
  // Close database connection
  await pool.end();
}

generateExcel().catch(error => {
  console.error('Error generating Excel file:', error);
  process.exit(1);
});

