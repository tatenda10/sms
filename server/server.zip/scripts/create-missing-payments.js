const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Students missing payments
const missingPayments = {
  'Grade 4': [
    { name: 'Munyaradzi', surname: 'Mudewairi', regNumber: 'R96923M', paymentAmount: 100.00 },
    { name: 'Malcom', surname: 'Mashamba', regNumber: 'R96924M', paymentAmount: 100.00 },
    { name: 'Comfort', surname: 'Mafigu', regNumber: 'R96925M', paymentAmount: 100.00 },
    { name: 'Ashleen', surname: 'Mberi', regNumber: 'R96926M', paymentAmount: 100.00 },
    { name: 'Tanatswa', surname: 'Mupumela', regNumber: 'R96927M', paymentAmount: 20.00 },
    { name: 'B Tanisha', surname: 'Mushonga', regNumber: 'R96928M', paymentAmount: 40.00 },
    { name: 'Brilliant', surname: 'Mabwinya', regNumber: 'R96929M', paymentAmount: 100.00 },
    { name: 'Makanakaishe', surname: 'Muchabaiwa', regNumber: 'R96930M', paymentAmount: 82.00 },
    { name: 'Sharnia', surname: 'Mukwazi', regNumber: 'R96931M', paymentAmount: 100.00 }
  ],
  'ECD A': [
    { name: 'Elsie', surname: 'Nhara', regNumber: 'R96919N', paymentAmount: 25.00 }
  ],
  'ECD B': [
    { name: 'Fidel', surname: 'Marume', regNumber: 'R96920M', paymentAmount: 115.00 },
    { name: 'Tally', surname: 'Madzima', regNumber: 'R96921M', paymentAmount: 110.00 },
    { name: 'Lionel', surname: 'Mashambi', regNumber: 'R96922M', paymentAmount: 115.00 }
  ]
};

async function createMissingPayments() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n💰 CREATING MISSING PAYMENTS\n');
    console.log('='.repeat(70));
    
    // Get or create journal ID
    let journalId = 1;
    try {
      const [journals] = await conn.execute(
        'SELECT id FROM journals WHERE name = ? OR id = ? LIMIT 1',
        ['Fees Journal', 1]
      );
      if (journals.length > 0) {
        journalId = journals[0].id;
      } else {
        const [newJournal] = await conn.execute(
          'INSERT INTO journals (name, description) VALUES (?, ?)',
          ['Fees Journal', 'Journal for fee transactions']
        );
        journalId = newJournal.insertId;
      }
    } catch (error) {
      console.log('Using default journal ID 1');
    }
    
    // Get Cash on Hand and Accounts Receivable accounts
    const [cashAccounts] = await conn.execute(
      "SELECT id FROM chart_of_accounts WHERE code = '1000' AND type = 'Asset' LIMIT 1"
    );
    const [arAccounts] = await conn.execute(
      "SELECT id FROM chart_of_accounts WHERE code = '1100' AND type = 'Asset' LIMIT 1"
    );
    
    if (cashAccounts.length === 0 || arAccounts.length === 0) {
      console.log('⚠️  Required accounts not found, skipping payment creation');
      return;
    }
    
    const cashAccountId = cashAccounts[0].id;
    const arAccountId = arAccounts[0].id;
    
    let totalProcessed = 0;
    
    for (const [className, students] of Object.entries(missingPayments)) {
      console.log(`\n📚 ${className}\n`);
      console.log('-'.repeat(70));
      
      await conn.beginTransaction();
      
      for (const student of students) {
        try {
          // Check if payment already exists
          const [existingPayments] = await conn.execute(`
            SELECT COALESCE(SUM(payment_amount), 0) as total_payments
            FROM fee_payments
            WHERE student_reg_number = ?
          `, [student.regNumber]);
          
          const [existingCredits] = await conn.execute(`
            SELECT COALESCE(SUM(amount), 0) as total_credits
            FROM student_transactions
            WHERE student_reg_number = ? AND transaction_type = 'CREDIT'
          `, [student.regNumber]);
          
          const existingTotal = parseFloat(existingPayments[0].total_payments || 0) + parseFloat(existingCredits[0].total_credits || 0);
          
          if (existingTotal >= student.paymentAmount) {
            console.log(`⏭️  ${student.name} ${student.surname} (${student.regNumber}) - Payment already exists: $${existingTotal.toFixed(2)}`);
            continue;
          }
          
          const paymentNeeded = student.paymentAmount - existingTotal;
          
          // Get student name
          const [studentInfo] = await conn.execute(
            'SELECT Name, Surname FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (studentInfo.length === 0) {
            console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Student not found`);
            continue;
          }
          
          const studentName = `${studentInfo[0].Name} ${studentInfo[0].Surname}`;
          
          // Create journal entry
          const description = `PAYMENT - ${studentName} (${student.regNumber}) - ${className}`;
          const reference = `PAY-${student.regNumber}-${Date.now()}`;
          
          const [journalEntry] = await conn.execute(`
            INSERT INTO journal_entries (journal_id, entry_date, reference, description, created_by, created_at, updated_at)
            VALUES (?, CURDATE(), ?, ?, ?, NOW(), NOW())
          `, [journalId, reference, description, 1]);
          
          const journalEntryId = journalEntry.insertId;
          
          // Create journal entry lines
          // DEBIT: Cash on Hand (money received)
          await conn.execute(`
            INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, cashAccountId, paymentNeeded, 0, `Cash Payment - ${studentName}`]);
          
          // CREDIT: Accounts Receivable (reducing debt)
          await conn.execute(`
            INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, arAccountId, 0, paymentNeeded, `Payment Received - ${studentName}`]);
          
          // Create CREDIT transaction (payment)
          await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'CREDIT',
            paymentNeeded,
            `PAYMENT - ${className}`,
            {
              created_by: 1,
              journal_entry_id: journalEntryId
            }
          );
          
          // Update account balances
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
          
          console.log(`✅ Created payment for: ${student.name} ${student.surname} (${student.regNumber}) - $${paymentNeeded.toFixed(2)}`);
          totalProcessed++;
          
        } catch (error) {
          console.error(`❌ Error processing ${student.name} ${student.surname}:`, error.message);
        }
      }
      
      await conn.commit();
    }
    
    console.log('\n\n' + '='.repeat(70));
    console.log('📊 SUMMARY:\n');
    console.log(`   Payments created: ${totalProcessed}`);
    console.log('\n' + '='.repeat(70));
    console.log('✅ Process complete!');
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

createMissingPayments();

