const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

class BidirectionalSync {
    constructor() {
        this.localConnection = null;
        this.remoteConnection = null;
        this.syncLog = [];
        this.conflicts = [];
    }

    async initializeConnections(localConfig, remoteConfig) {
        try {
            console.log('🔄 Initializing database connections...');
            
            // Local database connection
            this.localConnection = await mysql.createConnection({
                host: localConfig.host,
                user: localConfig.user,
                password: localConfig.password,
                database: localConfig.database,
                port: localConfig.port || 3306,
                ssl: localConfig.ssl || false
            });
            console.log('✅ Local database connected');

            // Remote database connection
            this.remoteConnection = await mysql.createConnection({
                host: remoteConfig.host,
                user: remoteConfig.user,
                password: remoteConfig.password,
                database: remoteConfig.database,
                port: remoteConfig.port || 3306,
                ssl: remoteConfig.ssl || false
            });
            console.log('✅ Remote database connected');

        } catch (error) {
            console.error('❌ Connection error:', error.message);
            throw error;
        }
    }

    async getTableStructure(connection, tableName) {
        try {
            const [columns] = await connection.execute(`SHOW COLUMNS FROM \`${tableName}\``);
            const [indexes] = await connection.execute(`SHOW INDEX FROM \`${tableName}\``);
            const [createTable] = await connection.execute(`SHOW CREATE TABLE \`${tableName}\``);
            
            return {
                columns: columns,
                indexes: indexes,
                createTable: createTable[0]['Create Table']
            };
        } catch (error) {
            console.error(`❌ Error getting structure for ${tableName}:`, error.message);
            return null;
        }
    }

    async getTableData(connection, tableName) {
        try {
            const [rows] = await connection.execute(`SELECT * FROM \`${tableName}\``);
            return rows;
        } catch (error) {
            console.error(`❌ Error getting data for ${tableName}:`, error.message);
            return [];
        }
    }

    async getPrimaryKey(connection, tableName) {
        try {
            const [rows] = await connection.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = '${tableName}' 
                AND CONSTRAINT_NAME = 'PRIMARY'
            `);
            return rows.map(row => row.COLUMN_NAME);
        } catch (error) {
            console.error(`❌ Error getting primary key for ${tableName}:`, error.message);
            return [];
        }
    }

    async getAutoIncrementColumn(connection, tableName) {
        try {
            const [rows] = await connection.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = '${tableName}' 
                AND EXTRA = 'auto_increment'
            `);
            return rows.length > 0 ? rows[0].COLUMN_NAME : null;
        } catch (error) {
            console.error(`❌ Error getting auto increment column for ${tableName}:`, error.message);
            return null;
        }
    }

    async syncTableStructure(tableName) {
        console.log(`\n🔄 Syncing table structure: ${tableName}`);
        
        const localStructure = await this.getTableStructure(this.localConnection, tableName);
        const remoteStructure = await this.getTableStructure(this.remoteConnection, tableName);

        if (!localStructure || !remoteStructure) {
            console.log(`⚠️  Skipping ${tableName} - structure not available`);
            return;
        }

        // Compare structures and sync if different
        if (localStructure.createTable !== remoteStructure.createTable) {
            console.log(`📝 Table structures differ for ${tableName}, syncing...`);
            
            // Use the more recent structure (local as source of truth)
            try {
                await this.remoteConnection.execute(`DROP TABLE IF EXISTS \`${tableName}\``);
                await this.remoteConnection.execute(localStructure.createTable);
                console.log(`✅ Remote table ${tableName} structure updated`);
                this.syncLog.push(`Table structure synced: ${tableName}`);
            } catch (error) {
                console.error(`❌ Error syncing structure for ${tableName}:`, error.message);
            }
        } else {
            console.log(`✅ Table structure already in sync: ${tableName}`);
        }
    }

    async syncTableData(tableName) {
        console.log(`\n🔄 Syncing table data: ${tableName}`);
        
        const localData = await this.getTableData(this.localConnection, tableName);
        const remoteData = await this.getTableData(this.remoteConnection, tableName);
        
        const primaryKeys = await this.getPrimaryKey(this.localConnection, tableName);
        const autoIncrementCol = await this.getAutoIncrementColumn(this.localConnection, tableName);

        if (primaryKeys.length === 0) {
            console.log(`⚠️  No primary key found for ${tableName}, skipping data sync`);
            return;
        }

        // Create lookup maps
        const localMap = new Map();
        const remoteMap = new Map();

        localData.forEach(row => {
            const key = primaryKeys.map(pk => row[pk]).join('|');
            localMap.set(key, row);
        });

        remoteData.forEach(row => {
            const key = primaryKeys.map(pk => row[pk]).join('|');
            remoteMap.set(key, row);
        });

        // Find records to sync
        const toInsert = [];
        const toUpdate = [];
        const conflicts = [];

        // Check local records against remote
        for (const [key, localRow] of localMap) {
            if (!remoteMap.has(key)) {
                toInsert.push(localRow);
            } else {
                const remoteRow = remoteMap.get(key);
                if (JSON.stringify(localRow) !== JSON.stringify(remoteRow)) {
                    // Check if local is newer (has updated_at or created_at)
                    const localDate = localRow.updated_at || localRow.created_at;
                    const remoteDate = remoteRow.updated_at || remoteRow.created_at;
                    
                    if (localDate && remoteDate) {
                        if (new Date(localDate) > new Date(remoteDate)) {
                            toUpdate.push(localRow);
                        } else if (new Date(remoteDate) > new Date(localDate)) {
                            // Remote is newer, add to conflicts
                            conflicts.push({
                                table: tableName,
                                key: key,
                                local: localRow,
                                remote: remoteRow,
                                reason: 'Remote record is newer'
                            });
                        }
                    } else {
                        // No date comparison, use local as source of truth
                        toUpdate.push(localRow);
                    }
                }
            }
        }

        // Check remote records against local
        for (const [key, remoteRow] of remoteMap) {
            if (!localMap.has(key)) {
                // Remote has data that local doesn't - this is a conflict
                conflicts.push({
                    table: tableName,
                    key: key,
                    local: null,
                    remote: remoteRow,
                    reason: 'Remote record not found locally'
                });
            }
        }

        // Handle conflicts
        if (conflicts.length > 0) {
            console.log(`⚠️  Found ${conflicts.length} conflicts in ${tableName}`);
            this.conflicts.push(...conflicts);
            
            // For now, use local as source of truth for conflicts
            // In a real scenario, you might want to prompt the user
            conflicts.forEach(conflict => {
                if (conflict.local) {
                    toUpdate.push(conflict.local);
                } else {
                    toInsert.push(conflict.remote);
                }
            });
        }

        // Execute sync operations
        try {
            // Insert new records
            if (toInsert.length > 0) {
                console.log(`📥 Inserting ${toInsert.length} new records to remote`);
                await this.insertRecords(this.remoteConnection, tableName, toInsert, autoIncrementCol);
            }

            // Update existing records
            if (toUpdate.length > 0) {
                console.log(`📝 Updating ${toUpdate.length} records on remote`);
                await this.updateRecords(this.remoteConnection, tableName, toUpdate, primaryKeys);
            }

            // Sync back to local (remote -> local)
            const remoteDataAfter = await this.getTableData(this.remoteConnection, tableName);
            const localDataAfter = await this.getTableData(this.localConnection, tableName);
            
            const remoteMapAfter = new Map();
            remoteDataAfter.forEach(row => {
                const key = primaryKeys.map(pk => row[pk]).join('|');
                remoteMapAfter.set(key, row);
            });

            const localMapAfter = new Map();
            localDataAfter.forEach(row => {
                const key = primaryKeys.map(pk => row[pk]).join('|');
                localMapAfter.set(key, row);
            });

            // Find records to sync back to local
            const toInsertLocal = [];
            const toUpdateLocal = [];

            for (const [key, remoteRow] of remoteMapAfter) {
                if (!localMapAfter.has(key)) {
                    toInsertLocal.push(remoteRow);
                } else {
                    const localRow = localMapAfter.get(key);
                    if (JSON.stringify(remoteRow) !== JSON.stringify(localRow)) {
                        toUpdateLocal.push(remoteRow);
                    }
                }
            }

            // Execute local sync
            if (toInsertLocal.length > 0) {
                console.log(`📥 Inserting ${toInsertLocal.length} new records to local`);
                await this.insertRecords(this.localConnection, tableName, toInsertLocal, autoIncrementCol);
            }

            if (toUpdateLocal.length > 0) {
                console.log(`📝 Updating ${toUpdateLocal.length} records on local`);
                await this.updateRecords(this.localConnection, tableName, toUpdateLocal, primaryKeys);
            }

            this.syncLog.push(`Data synced: ${tableName} - ${toInsert.length} inserted, ${toUpdate.length} updated`);

        } catch (error) {
            console.error(`❌ Error syncing data for ${tableName}:`, error.message);
        }
    }

    async insertRecords(connection, tableName, records, autoIncrementCol) {
        if (records.length === 0) return;

        const columns = Object.keys(records[0]);
        const placeholders = columns.map(() => '?').join(', ');
        const query = `INSERT INTO \`${tableName}\` (\`${columns.join('`, `')}\`) VALUES (${placeholders})`;

        for (const record of records) {
            const values = columns.map(col => record[col]);
            await connection.execute(query, values);
        }
    }

    async updateRecords(connection, tableName, records, primaryKeys) {
        if (records.length === 0) return;

        const columns = Object.keys(records[0]);
        const setClause = columns
            .filter(col => !primaryKeys.includes(col))
            .map(col => `\`${col}\` = ?`)
            .join(', ');
        
        const whereClause = primaryKeys.map(pk => `\`${pk}\` = ?`).join(' AND ');
        const query = `UPDATE \`${tableName}\` SET ${setClause} WHERE ${whereClause}`;

        for (const record of records) {
            const setValues = columns
                .filter(col => !primaryKeys.includes(col))
                .map(col => record[col]);
            const whereValues = primaryKeys.map(pk => record[pk]);
            const values = [...setValues, ...whereValues];
            
            await connection.execute(query, values);
        }
    }

    async getAllTables(connection) {
        try {
            const [rows] = await connection.execute('SHOW TABLES');
            return rows.map(row => Object.values(row)[0]);
        } catch (error) {
            console.error('❌ Error getting tables:', error.message);
            return [];
        }
    }

    async syncDatabases() {
        try {
            console.log('\n🚀 Starting bidirectional database synchronization...\n');

            // Get all tables from both databases
            const localTables = await this.getAllTables(this.localConnection);
            const remoteTables = await this.getAllTables(this.remoteConnection);
            
            console.log(`📊 Local tables: ${localTables.length}`);
            console.log(`📊 Remote tables: ${remoteTables.length}`);

            // Get all unique tables
            const allTables = [...new Set([...localTables, ...remoteTables])];
            console.log(`📊 Total unique tables: ${allTables.length}\n`);

            // Sync each table
            for (const tableName of allTables) {
                try {
                    // Check if table exists in both databases
                    const localExists = localTables.includes(tableName);
                    const remoteExists = remoteTables.includes(tableName);

                    if (localExists && remoteExists) {
                        // Both exist - sync structure and data
                        await this.syncTableStructure(tableName);
                        await this.syncTableData(tableName);
                    } else if (localExists && !remoteExists) {
                        // Only local exists - create on remote and sync data
                        console.log(`\n🔄 Creating table on remote: ${tableName}`);
                        const localStructure = await this.getTableStructure(this.localConnection, tableName);
                        if (localStructure) {
                            await this.remoteConnection.execute(localStructure.createTable);
                            const localData = await this.getTableData(this.localConnection, tableName);
                            if (localData.length > 0) {
                                await this.insertRecords(this.remoteConnection, tableName, localData, null);
                            }
                            console.log(`✅ Table ${tableName} created on remote with ${localData.length} records`);
                        }
                    } else if (!localExists && remoteExists) {
                        // Only remote exists - create on local and sync data
                        console.log(`\n🔄 Creating table on local: ${tableName}`);
                        const remoteStructure = await this.getTableStructure(this.remoteConnection, tableName);
                        if (remoteStructure) {
                            await this.localConnection.execute(remoteStructure.createTable);
                            const remoteData = await this.getTableData(this.remoteConnection, tableName);
                            if (remoteData.length > 0) {
                                await this.insertRecords(this.localConnection, tableName, remoteData, null);
                            }
                            console.log(`✅ Table ${tableName} created on local with ${remoteData.length} records`);
                        }
                    }

                } catch (error) {
                    console.error(`❌ Error syncing table ${tableName}:`, error.message);
                }
            }

            // Generate sync report
            this.generateSyncReport();

        } catch (error) {
            console.error('❌ Sync error:', error.message);
        }
    }

    generateSyncReport() {
        console.log('\n📊 SYNC REPORT');
        console.log('================');
        
        console.log('\n✅ Successful Operations:');
        this.syncLog.forEach(log => console.log(`  - ${log}`));
        
        if (this.conflicts.length > 0) {
            console.log('\n⚠️  Conflicts Found:');
            this.conflicts.forEach(conflict => {
                console.log(`  - Table: ${conflict.table}`);
                console.log(`    Key: ${conflict.key}`);
                console.log(`    Reason: ${conflict.reason}`);
                console.log('');
            });
        }

        console.log(`\n📈 Summary:`);
        console.log(`  - Tables processed: ${this.syncLog.length}`);
        console.log(`  - Conflicts resolved: ${this.conflicts.length}`);
        console.log(`  - Sync completed: ${new Date().toISOString()}`);
    }

    async closeConnections() {
        if (this.localConnection) {
            await this.localConnection.end();
            console.log('✅ Local connection closed');
        }
        if (this.remoteConnection) {
            await this.remoteConnection.end();
            console.log('✅ Remote connection closed');
        }
    }
}

// Main execution function
async function main() {
    console.log('🔄 Bidirectional Database Synchronization Tool');
    console.log('==============================================\n');

    // Get configuration from user input
    const readline = require('readline');
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const question = (query) => new Promise(resolve => rl.question(query, resolve));

    try {
        console.log('📝 Enter Local Database Configuration:');
        const localHost = await question('Local Host (default: localhost): ') || 'localhost';
        const localUser = await question('Local User: ');
        const localPassword = await question('Local Password: ');
        const localDatabase = await question('Local Database: ');
        const localPort = await question('Local Port (default: 3306): ') || '3306';

        console.log('\n📝 Enter DigitalOcean Database Configuration:');
        const remoteHost = await question('Remote Host: ');
        const remoteUser = await question('Remote User: ');
        const remotePassword = await question('Remote Password: ');
        const remoteDatabase = await question('Remote Database: ');
        const remotePort = await question('Remote Port (default: 25060): ') || '25060';

        rl.close();

        const localConfig = {
            host: localHost,
            user: localUser,
            password: localPassword,
            database: localDatabase,
            port: parseInt(localPort),
            ssl: false
        };

        const remoteConfig = {
            host: remoteHost,
            user: remoteUser,
            password: remotePassword,
            database: remoteDatabase,
            port: parseInt(remotePort),
            ssl: { rejectUnauthorized: false }
        };

        // Initialize and run sync
        const sync = new BidirectionalSync();
        await sync.initializeConnections(localConfig, remoteConfig);
        await sync.syncDatabases();
        await sync.closeConnections();

        console.log('\n🎉 Synchronization completed successfully!');

    } catch (error) {
        console.error('\n❌ Synchronization failed:', error.message);
        process.exit(1);
    }
}

// Run the script
if (require.main === module) {
    main();
}

module.exports = BidirectionalSync;
