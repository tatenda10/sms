const { pool } = require('./config/database');

// All ECD B students from the image
const ecdbStudents = [
  { name: 'Meeghan', surname: 'Shoko', balance: 0.00, totalPayments: 115.00 },
  { name: 'Alvin', surname: 'Mpofu', balance: -131.00, totalPayments: 40.00 },
  { name: 'Mukudzei', surname: 'Kamuzonde', balance: -136.00, totalPayments: 100.00 },
  { name: 'Marlon', surname: 'Mafigu', balance: -1.00, totalPayments: 115.00 },
  { name: 'Christian', surname: 'Zulu', balance: 0.00, totalPayments: 115.00 },
  { name: 'Liam', surname: 'Chawora', balance: 0.00, totalPayments: 115.00 },
  { name: 'Phiri', surname: 'Tawananyasha', balance: 0.00, totalPayments: 115.00 },
  { name: 'Mylar', surname: 'Gwerendende', balance: 0.00, totalPayments: 115.00 },
  { name: 'Rufaro', surname: 'Jekecha', balance: 0.00, totalPayments: 65.00 },
  { name: 'Courtney', surname: 'Pabwe', balance: 0.00, totalPayments: 115.00 },
  { name: 'Blessed', surname: 'Chiza', balance: -15.00, totalPayments: 70.00 },
  { name: 'Fidel', surname: 'Marume', balance: 0.00, totalPayments: 115.00 },
  { name: 'Tally', surname: 'Madzima', balance: 0.00, totalPayments: 110.00 },
  { name: 'Lionel', surname: 'Mashambi', balance: -1.00, totalPayments: 115.00 }
];

async function findStudentByName(conn, name, surname) {
  const [students] = await conn.execute(
    'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
    [name, surname]
  );
  return students.length > 0 ? students[0] : null;
}

async function completeECDBSetup() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 COMPLETING ECD B SETUP\n');
    console.log('='.repeat(70));
    
    // Get ECD B class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.id = 21 OR gc.name LIKE '%ECD B%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ ECD B class not found');
      return;
    }
    
    const ecdbClass = classes[0];
    console.log(`✅ Found ECD B class: ${ecdbClass.name} (ID: ${ecdbClass.id})\n`);
    
    await conn.beginTransaction();
    
    let enrolled = 0;
    
    // Process each student
    for (const student of ecdbStudents) {
      const existing = await findStudentByName(conn, student.name, student.surname);
      
      if (!existing) {
        console.log(`⚠️  ${student.name} ${student.surname} not found, skipping...`);
        continue;
      }
      
      console.log(`📝 Processing: ${student.name} ${student.surname} (${existing.RegNumber})`);
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [existing.RegNumber, ecdbClass.id]);
      
      if (enrollment.length === 0) {
        await conn.execute(`
          INSERT INTO enrollments_gradelevel_classes (student_regnumber, gradelevel_class_id, status)
          VALUES (?, ?, 'active')
        `, [existing.RegNumber, ecdbClass.id]);
        enrolled++;
        console.log(`   ✅ Enrolled in ECD B`);
      } else {
        console.log(`   ⏭️  Already enrolled`);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ ECD B setup completed!');
    console.log(`\n📊 Summary:`);
    console.log(`   Students enrolled: ${enrolled}`);
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error completing ECD B setup:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

completeECDBSetup();

