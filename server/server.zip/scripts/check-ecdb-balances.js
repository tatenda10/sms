const { pool } = require('./config/database');

async function checkBalances() {
  const conn = await pool.getConnection();
  try {
    const regNumbers = ['R00007S', 'R00007M', 'R00007K'];
    
    for (const regNumber of regNumbers) {
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [regNumber]
      );
      
      console.log(`\n${regNumber}: Current balance: $${balance[0]?.current_balance || 0}`);
      
      const [txns] = await conn.execute(
        'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY id',
        [regNumber]
      );
      
      let calculated = 0;
      console.log('Transactions:');
      txns.forEach(t => {
        const amt = parseFloat(t.amount);
        if (t.transaction_type === 'DEBIT') {
          calculated -= amt;
        } else {
          calculated += amt;
        }
        console.log(`  ${t.transaction_type} $${amt} - ${t.description.substring(0, 50)}`);
      });
      
      console.log(`Calculated balance: $${calculated}`);
      console.log(`Actual balance: $${balance[0]?.current_balance || 0}`);
    }
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkBalances();

