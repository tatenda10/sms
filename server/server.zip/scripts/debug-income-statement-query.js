const { pool } = require('../config/database');

async function debugIncomeStatementQuery() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Debugging Income Statement Query...');
    
    // First, let's check what accounts exist
    console.log('\n📋 Checking chart of accounts...');
    const [accounts] = await connection.execute(
      'SELECT id, code, name, type FROM chart_of_accounts WHERE type IN ("Revenue", "Expense") AND is_active = 1 ORDER BY type, code LIMIT 5'
    );
    
    console.log('Sample accounts:');
    accounts.forEach(acc => {
      console.log(`  ${acc.id} - ${acc.code} - ${acc.name} (${acc.type})`);
    });
    
    // Now test the revenue query step by step
    console.log('\n💰 Testing revenue query...');
    const startDate = '2025-01-01';
    const endDate = '2025-12-31';
    
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
      LIMIT 3
    `;
    
    const [revenue] = await connection.execute(revenueQuery, [startDate, endDate]);
    
    console.log('Revenue query results:');
    revenue.forEach((account, index) => {
      console.log(`  ${index + 1}. ID: ${account.account_id}, Code: ${account.account_code}, Name: ${account.account_name}, Amount: ${account.amount}`);
    });
    
  } catch (error) {
    console.error('\n❌ Error debugging query:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the debug if this script is executed directly
if (require.main === module) {
  debugIncomeStatementQuery()
    .then(() => {
      console.log('\n✅ Debug completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Debug failed:', error.message);
      process.exit(1);
    });
}

module.exports = debugIncomeStatementQuery;
