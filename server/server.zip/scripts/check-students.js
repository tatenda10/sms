const { pool } = require('../config/database');

async function checkStudents() {
    try {
        console.log('=== CHECKING STUDENTS AND BALANCES ===\n');
        
        // Check total students
        const [totalStudents] = await pool.execute('SELECT COUNT(*) as count FROM students');
        console.log(`Total students: ${totalStudents[0].count}`);
        
        // Check students with balances
        const [studentsWithBalances] = await pool.execute('SELECT COUNT(*) as count FROM student_balances');
        console.log(`Students with balance records: ${studentsWithBalances[0].count}`);
        
        // Check students with transactions
        const [studentsWithTransactions] = await pool.execute('SELECT COUNT(DISTINCT student_reg_number) as count FROM student_transactions');
        console.log(`Students with transactions: ${studentsWithTransactions[0].count}`);
        
        // Show some sample students
        const [sampleStudents] = await pool.execute(
            `SELECT s.RegNumber, s.Name, s.Surname, 
                    COALESCE(sb.current_balance, 0) as balance,
                    (SELECT COUNT(*) FROM student_transactions st WHERE st.student_reg_number = s.RegNumber) as transaction_count
             FROM students s
             LEFT JOIN student_balances sb ON s.RegNumber = sb.student_reg_number
             LIMIT 10`
        );
        
        console.log('\n=== SAMPLE STUDENTS ===');
        sampleStudents.forEach(student => {
            console.log(`${student.RegNumber}: ${student.Name} ${student.Surname} - Balance: ${student.balance}, Transactions: ${student.transaction_count}`);
        });
        
        // Show students with non-zero balances
        const [nonZeroBalances] = await pool.execute(
            `SELECT s.RegNumber, s.Name, s.Surname, sb.current_balance
             FROM students s
             JOIN student_balances sb ON s.RegNumber = sb.student_reg_number
             WHERE sb.current_balance != 0
             LIMIT 5`
        );
        
        console.log('\n=== STUDENTS WITH NON-ZERO BALANCES ===');
        if (nonZeroBalances.length > 0) {
            nonZeroBalances.forEach(student => {
                console.log(`${student.RegNumber}: ${student.Name} ${student.Surname} - Balance: ${student.current_balance}`);
            });
        } else {
            console.log('No students with non-zero balances found');
        }
        
        // Show recent transactions
        const [recentTransactions] = await pool.execute(
            `SELECT st.student_reg_number, st.transaction_type, st.amount, st.description, st.transaction_date
             FROM student_transactions st
             ORDER BY st.transaction_date DESC
             LIMIT 10`
        );
        
        console.log('\n=== RECENT TRANSACTIONS ===');
        recentTransactions.forEach(t => {
            console.log(`${t.student_reg_number}: ${t.transaction_type} ${t.amount} - ${t.description} (${t.transaction_date})`);
        });
        
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await pool.end();
    }
}

checkStudents().catch(console.error);
