const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

// Use hardcoded configuration for testing
const config = {
    local: {
        host: 'localhost',
        user: 'root',
        password: 'password123',
        database: 'sms',
        port: 3306,
        ssl: false
    },
    remote: {
        host: 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
        user: 'doadmin',
        password: 'AVNS_O_R4Z5_x8aFOV6Pzy6J',
        database: 'sms',
        port: 25060,
        ssl: { rejectUnauthorized: false }
    },
    options: {
        conflictResolution: 'timestamp',
        createMissingTables: true,
        syncStructures: true,
        syncData: true,
        excludeTables: ['test_table'],
        includeTables: []
    }
};

console.log('✅ Using hardcoded configuration');

class DependencySync {
    constructor(config) {
        this.config = config;
        this.localConnection = null;
        this.remoteConnection = null;
        this.syncLog = [];
        this.conflicts = [];
        this.stats = {
            tablesProcessed: 0,
            recordsInserted: 0,
            recordsUpdated: 0,
            conflictsResolved: 0,
            errors: 0
        };
        
        // Define table creation order based on dependencies
        this.tableOrder = [
            // Core tables (no dependencies)
            'currencies',
            'departments',
            'roles',
            'stream',
            'hostels',
            'rooms',
            'transport_routes',
            'suppliers',
            'inventory_categories',
            'subjects',
            'grading_criteria',
            'journals',
            'invoice_structures',
            'job_titles',
            
            // User-related tables
            'users',
            'user_roles',
            
            // Student-related tables
            'students',
            'guardians',
            'student_transport_registrations',
            'student_balances',
            'student_transactions',
            
            // Employee-related tables
            'employees',
            'employee_bank_accounts',
            
            // Class-related tables
            'gradelevel_classes',
            'subject_classes',
            'class_term_year',
            'enrollments_gradelevel_classes',
            'enrollments_subject_classes',
            
            // Accounting tables
            'chart_of_accounts',
            'accounting_periods',
            'account_balances',
            'accounts_payable_balances',
            'accounts_payable_payments',
            'bank_reconciliations',
            'bank_statement_items',
            'bank_transactions',
            'book_transactions',
            'exchange_rates',
            'expenses',
            'fee_payments',
            'invoice_items',
            'journal_entries',
            'journal_entry_lines',
            'period_closing_audit',
            'period_closing_entries',
            'period_opening_balances',
            'reconciliation_matches',
            'transactions',
            'trial_balance',
            
            // Boarding-related tables
            'boarding_enrollments',
            'boarding_fee_balances',
            'boarding_fees',
            'boarding_fees_payments',
            'boarding_payments',
            
            // Transport-related tables
            'transport_fees',
            'transport_payments',
            'transport_schedules',
            
            // Inventory-related tables
            'inventory_items',
            'uniform_issues',
            'uniform_payments',
            
            // Academic-related tables
            'papers',
            'results',
            'mid_term_coursework',
            'paper_marks',
            
            // Payroll-related tables
            'payroll_runs',
            'payroll_run_details',
            'payslips',
            'payslip_earnings',
            'payslip_deductions',
            
            // System tables
            'announcements',
            'audit_logs'
        ];
    }

    async initializeConnections() {
        try {
            console.log('🔄 Initializing database connections...');
            
            // Local database connection
            this.localConnection = await mysql.createConnection({
                host: this.config.local.host,
                user: this.config.local.user,
                password: this.config.local.password,
                database: this.config.local.database,
                port: this.config.local.port || 3306,
                ssl: this.config.local.ssl || false
            });
            console.log('✅ Local database connected');

            // Remote database connection
            this.remoteConnection = await mysql.createConnection({
                host: this.config.remote.host,
                user: this.config.remote.user,
                password: this.config.remote.password,
                database: this.config.remote.database,
                port: this.config.remote.port || 3306,
                ssl: this.config.remote.ssl || false
            });
            console.log('✅ Remote database connected');

        } catch (error) {
            console.error('❌ Connection error:', error.message);
            throw error;
        }
    }

    async getTableStructure(connection, tableName) {
        try {
            const [columns] = await connection.execute(`SHOW COLUMNS FROM \`${tableName}\``);
            const [indexes] = await connection.execute(`SHOW INDEX FROM \`${tableName}\``);
            const [createTable] = await connection.execute(`SHOW CREATE TABLE \`${tableName}\``);
            
            return {
                columns: columns,
                indexes: indexes,
                createTable: createTable[0]['Create Table']
            };
        } catch (error) {
            console.error(`❌ Error getting structure for ${tableName}:`, error.message);
            return null;
        }
    }

    async getTableData(connection, tableName) {
        try {
            const [rows] = await connection.execute(`SELECT * FROM \`${tableName}\``);
            return rows;
        } catch (error) {
            console.error(`❌ Error getting data for ${tableName}:`, error.message);
            return [];
        }
    }

    async getPrimaryKey(connection, tableName) {
        try {
            const [rows] = await connection.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = '${tableName}' 
                AND CONSTRAINT_NAME = 'PRIMARY'
            `);
            return rows.map(row => row.COLUMN_NAME);
        } catch (error) {
            console.error(`❌ Error getting primary key for ${tableName}:`, error.message);
            return [];
        }
    }

    async getAutoIncrementColumn(connection, tableName) {
        try {
            const [rows] = await connection.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = '${tableName}' 
                AND EXTRA = 'auto_increment'
            `);
            return rows.length > 0 ? rows[0].COLUMN_NAME : null;
        } catch (error) {
            console.error(`❌ Error getting auto increment column for ${tableName}:`, error.message);
            return null;
        }
    }

    async createTableWithData(tableName) {
        console.log(`\n🔄 Processing table: ${tableName}`);
        
        try {
            // Check if table exists locally
            const localStructure = await this.getTableStructure(this.localConnection, tableName);
            if (!localStructure) {
                console.log(`⚠️  Table ${tableName} not found locally, skipping`);
                return;
            }

            // Check if table exists remotely
            const remoteStructure = await this.getTableStructure(this.remoteConnection, tableName);
            
            if (!remoteStructure) {
                // Create table on remote
                console.log(`📝 Creating table on remote: ${tableName}`);
                
                // Disable foreign key checks temporarily
                await this.remoteConnection.execute('SET FOREIGN_KEY_CHECKS = 0');
                
                try {
                    await this.remoteConnection.execute(localStructure.createTable);
                    console.log(`✅ Table ${tableName} created on remote`);
                } catch (error) {
                    console.error(`❌ Error creating table ${tableName}:`, error.message);
                    this.stats.errors++;
                    return;
                } finally {
                    // Re-enable foreign key checks
                    await this.remoteConnection.execute('SET FOREIGN_KEY_CHECKS = 1');
                }
            } else {
                console.log(`✅ Table ${tableName} already exists on remote`);
            }

            // Sync data
            await this.syncTableData(tableName);
            
            this.stats.tablesProcessed++;

        } catch (error) {
            console.error(`❌ Error processing table ${tableName}:`, error.message);
            this.stats.errors++;
        }
    }

    async syncTableData(tableName) {
        if (!this.config.options.syncData) {
            console.log(`⏭️  Skipping data sync for ${tableName} (disabled in config)`);
            return;
        }

        console.log(`🔄 Syncing data for: ${tableName}`);
        
        const localData = await this.getTableData(this.localConnection, tableName);
        const remoteData = await this.getTableData(this.remoteConnection, tableName);
        
        const primaryKeys = await this.getPrimaryKey(this.localConnection, tableName);
        const autoIncrementCol = await this.getAutoIncrementColumn(this.localConnection, tableName);

        if (primaryKeys.length === 0) {
            console.log(`⚠️  No primary key found for ${tableName}, skipping data sync`);
            return;
        }

        // Create lookup maps
        const localMap = new Map();
        const remoteMap = new Map();

        localData.forEach(row => {
            const key = primaryKeys.map(pk => row[pk]).join('|');
            localMap.set(key, row);
        });

        remoteData.forEach(row => {
            const key = primaryKeys.map(pk => row[pk]).join('|');
            remoteMap.set(key, row);
        });

        // Find records to sync
        const toInsert = [];
        const toUpdate = [];

        // Check local records against remote
        for (const [key, localRow] of localMap) {
            if (!remoteMap.has(key)) {
                toInsert.push(localRow);
            } else {
                const remoteRow = remoteMap.get(key);
                if (JSON.stringify(localRow) !== JSON.stringify(remoteRow)) {
                    // Use timestamp-based conflict resolution
                    const localDate = localRow.updated_at || localRow.created_at;
                    const remoteDate = remoteRow.updated_at || remoteRow.created_at;
                    
                    if (localDate && remoteDate) {
                        if (new Date(localDate) > new Date(remoteDate)) {
                            // Local is newer
                            toUpdate.push(localRow);
                        } else if (new Date(remoteDate) > new Date(localDate)) {
                            // Remote is newer - this will be handled in the reverse sync
                            console.log(`⏰ Remote record is newer for ${tableName} key ${key}, will sync back to local`);
                        } else {
                            // Same timestamp, use local as fallback
                            toUpdate.push(localRow);
                        }
                    } else {
                        // No timestamps available, use local as fallback
                        toUpdate.push(localRow);
                    }
                }
            }
        }

        // Execute sync operations
        try {
            // Insert new records to remote
            if (toInsert.length > 0) {
                console.log(`📥 Inserting ${toInsert.length} new records to remote`);
                await this.insertRecords(this.remoteConnection, tableName, toInsert, autoIncrementCol);
                this.stats.recordsInserted += toInsert.length;
            }

            // Update existing records on remote
            if (toUpdate.length > 0) {
                console.log(`📝 Updating ${toUpdate.length} records on remote`);
                await this.updateRecords(this.remoteConnection, tableName, toUpdate, primaryKeys);
                this.stats.recordsUpdated += toUpdate.length;
            }

            // Now handle reverse sync (remote -> local) for newer remote records
            const toInsertLocal = [];
            const toUpdateLocal = [];

            for (const [key, remoteRow] of remoteMap) {
                if (!localMap.has(key)) {
                    // Remote has data that local doesn't
                    toInsertLocal.push(remoteRow);
                } else {
                    const localRow = localMap.get(key);
                    if (JSON.stringify(remoteRow) !== JSON.stringify(localRow)) {
                        // Check timestamps for conflict resolution
                        const localDate = localRow.updated_at || localRow.created_at;
                        const remoteDate = remoteRow.updated_at || remoteRow.created_at;
                        
                        if (localDate && remoteDate) {
                            if (new Date(remoteDate) > new Date(localDate)) {
                                // Remote is newer
                                toUpdateLocal.push(remoteRow);
                            }
                        } else {
                            // No timestamps, keep local as is
                        }
                    }
                }
            }

            // Execute local sync for newer remote records
            if (toInsertLocal.length > 0) {
                console.log(`📥 Inserting ${toInsertLocal.length} newer records to local`);
                await this.insertRecords(this.localConnection, tableName, toInsertLocal, autoIncrementCol);
                this.stats.recordsInserted += toInsertLocal.length;
            }

            if (toUpdateLocal.length > 0) {
                console.log(`📝 Updating ${toUpdateLocal.length} newer records on local`);
                await this.updateRecords(this.localConnection, tableName, toUpdateLocal, primaryKeys);
                this.stats.recordsUpdated += toUpdateLocal.length;
            }

            if (toInsert.length > 0 || toUpdate.length > 0 || toInsertLocal.length > 0 || toUpdateLocal.length > 0) {
                this.syncLog.push(`Data synced: ${tableName} - ${toInsert.length} inserted, ${toUpdate.length} updated, ${toInsertLocal.length} synced back to local`);
            }

        } catch (error) {
            console.error(`❌ Error syncing data for ${tableName}:`, error.message);
            this.stats.errors++;
        }
    }

    async insertRecords(connection, tableName, records, autoIncrementCol) {
        if (records.length === 0) return;

        const columns = Object.keys(records[0]);
        const placeholders = columns.map(() => '?').join(', ');
        const query = `INSERT INTO \`${tableName}\` (\`${columns.join('`, `')}\`) VALUES (${placeholders})`;

        for (const record of records) {
            const values = columns.map(col => record[col]);
            await connection.execute(query, values);
        }
    }

    async updateRecords(connection, tableName, records, primaryKeys) {
        if (records.length === 0) return;

        const columns = Object.keys(records[0]);
        const setClause = columns
            .filter(col => !primaryKeys.includes(col))
            .map(col => `\`${col}\` = ?`)
            .join(', ');
        
        const whereClause = primaryKeys.map(pk => `\`${pk}\` = ?`).join(' AND ');
        const query = `UPDATE \`${tableName}\` SET ${setClause} WHERE ${whereClause}`;

        for (const record of records) {
            const setValues = columns
                .filter(col => !primaryKeys.includes(col))
                .map(col => record[col]);
            const whereValues = primaryKeys.map(pk => record[pk]);
            const values = [...setValues, ...whereValues];
            
            await connection.execute(query, values);
        }
    }

    async getAllTables(connection) {
        try {
            const [rows] = await connection.execute('SHOW TABLES');
            return rows.map(row => Object.values(row)[0]);
        } catch (error) {
            console.error('❌ Error getting tables:', error.message);
            return [];
        }
    }

    shouldSyncTable(tableName) {
        // Check if table should be excluded
        if (this.config.options.excludeTables.includes(tableName)) {
            return false;
        }
        
        // Check if only specific tables should be included
        if (this.config.options.includeTables.length > 0) {
            return this.config.options.includeTables.includes(tableName);
        }
        
        return true;
    }

    async syncDatabases() {
        try {
            console.log('\n🚀 Starting dependency-aware database synchronization...\n');
            console.log(`📋 Configuration:`);
            console.log(`  - Conflict resolution: ${this.config.options.conflictResolution} (newest record wins)`);
            console.log(`  - Sync structures: ${this.config.options.syncStructures}`);
            console.log(`  - Sync data: ${this.config.options.syncData}`);
            console.log(`  - Create missing tables: ${this.config.options.createMissingTables}\n`);

            // Get all tables from both databases
            const localTables = await this.getAllTables(this.localConnection);
            const remoteTables = await this.getAllTables(this.remoteConnection);
            
            console.log(`📊 Local tables: ${localTables.length}`);
            console.log(`📊 Remote tables: ${remoteTables.length}`);

            // Filter tables to sync based on order and filters
            const tablesToSync = this.tableOrder.filter(table => 
                localTables.includes(table) && this.shouldSyncTable(table)
            );
            
            console.log(`📊 Tables to sync (in dependency order): ${tablesToSync.length}\n`);

            // Sync each table in dependency order
            for (const tableName of tablesToSync) {
                await this.createTableWithData(tableName);
            }

            // Generate sync report
            this.generateSyncReport();

        } catch (error) {
            console.error('❌ Sync error:', error.message);
            this.stats.errors++;
        }
    }

    generateSyncReport() {
        console.log('\n📊 SYNC REPORT');
        console.log('================');
        
        console.log('\n📈 Statistics:');
        console.log(`  - Tables processed: ${this.stats.tablesProcessed}`);
        console.log(`  - Records inserted: ${this.stats.recordsInserted}`);
        console.log(`  - Records updated: ${this.stats.recordsUpdated}`);
        console.log(`  - Conflicts resolved: ${this.stats.conflictsResolved}`);
        console.log(`  - Errors encountered: ${this.stats.errors}`);
        
        console.log('\n✅ Successful Operations:');
        this.syncLog.forEach(log => console.log(`  - ${log}`));
        
        if (this.conflicts.length > 0) {
            console.log('\n⚠️  Conflicts Found:');
            this.conflicts.forEach(conflict => {
                console.log(`  - Table: ${conflict.table}`);
                console.log(`    Key: ${conflict.key}`);
                console.log(`    Reason: ${conflict.reason}`);
                console.log('');
            });
        }

        console.log(`\n🕐 Sync completed: ${new Date().toISOString()}`);
    }

    async closeConnections() {
        if (this.localConnection) {
            await this.localConnection.end();
            console.log('✅ Local connection closed');
        }
        if (this.remoteConnection) {
            await this.remoteConnection.end();
            console.log('✅ Remote connection closed');
        }
    }
}

// Main execution function
async function main() {
    console.log('🔄 Dependency-Aware Database Synchronization Tool');
    console.log('==================================================\n');

    try {
        // Initialize and run sync
        const sync = new DependencySync(config);
        await sync.initializeConnections();
        await sync.syncDatabases();
        await sync.closeConnections();

        console.log('\n🎉 Synchronization completed successfully!');

    } catch (error) {
        console.error('\n❌ Synchronization failed:', error.message);
        process.exit(1);
    }
}

// Run the script
if (require.main === module) {
    main();
}

module.exports = DependencySync;
