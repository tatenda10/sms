const mysql = require('mysql2/promise');
require('dotenv').config();

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'sms',
  port: process.env.DB_PORT || 3306,
  charset: 'utf8mb4'
};

async function demonstrateAdditionalFees() {
  const connection = await mysql.createConnection(dbConfig);
  
  try {
    console.log('🎯 Demonstrating Additional Fee System Usage...\n');
    
    // 1. Show available fee structures
    console.log('📋 Available Fee Structures:');
    const [structures] = await connection.execute(`
      SELECT 
        afs.*,
        c.name as currency_name,
        c.symbol as currency_symbol
      FROM additional_fee_structures afs
      LEFT JOIN currencies c ON afs.currency_id = c.id
      WHERE afs.is_active = TRUE
      ORDER BY afs.fee_name
    `);
    
    structures.forEach(structure => {
      console.log(`- ${structure.fee_name}: $${structure.amount} (${structure.fee_type}) - ${structure.currency_symbol}`);
    });
    
    // 2. Show how to generate annual textbook fees for all students
    console.log('\n🔄 Generating Annual Textbook Fees for All Students:');
    console.log('POST /api/additional-fees/assignments/bulk-annual');
    console.log('Body: {');
    console.log('  "fee_structure_id": 1,  // Textbook Fees ID');
    console.log('  "academic_year": "2025",');
    console.log('  "due_date": "2025-12-31"');
    console.log('}');
    
    // 3. Show how to manually assign registration fees to specific students
    console.log('\n👥 Manually Assigning Registration Fees to New Students:');
    console.log('POST /api/additional-fees/assignments/manual');
    console.log('Body: {');
    console.log('  "fee_structure_id": 2,  // Registration Fees ID');
    console.log('  "student_reg_numbers": ["STU001", "STU002", "STU003"],');
    console.log('  "academic_year": "2025",');
    console.log('  "due_date": "2025-02-28"');
    console.log('}');
    
    // 4. Show how to manually assign report book fees to specific students
    console.log('\n📚 Manually Assigning Report Book Fees to Specific Students:');
    console.log('POST /api/additional-fees/assignments/manual');
    console.log('Body: {');
    console.log('  "fee_structure_id": 3,  // Report Book Fees ID');
    console.log('  "student_reg_numbers": ["STU001", "STU005", "STU010"],');
    console.log('  "academic_year": "2025",');
    console.log('  "due_date": "2025-03-15"');
    console.log('}');
    
    // 5. Show how to process payments
    console.log('\n💳 Processing Fee Payments:');
    console.log('POST /api/additional-fees/payments');
    console.log('Body: {');
    console.log('  "student_reg_number": "STU001",');
    console.log('  "fee_assignment_id": 1,  // Assignment ID from student assignments');
    console.log('  "payment_amount": 35.00,');
    console.log('  "currency_id": 1,');
    console.log('  "payment_method": "Cash",');
    console.log('  "payment_date": "2025-01-15",');
    console.log('  "reference_number": "REF001"');
    console.log('}');
    
    // 6. Show how to get student fee assignments
    console.log('\n👤 Getting Student Fee Assignments:');
    console.log('GET /api/additional-fees/assignments/student/STU001/year/2025');
    
    // 7. Show how to get payment history
    console.log('\n📊 Getting Student Payment History:');
    console.log('GET /api/additional-fees/payments/student/STU001/year/2025');
    
    // 8. Show how to get statistics
    console.log('\n📈 Getting Fee Assignment Statistics:');
    console.log('GET /api/additional-fees/stats/year/2025');
    
    console.log('\n🎉 Demo completed! The system is ready to use.');
    console.log('\n💡 Key Features:');
    console.log('- Automatic balance updates');
    console.log('- Integration with student transactions');
    console.log('- Bulk operations for annual fees');
    console.log('- Manual assignment for selective fees');
    console.log('- Complete payment tracking');
    
  } catch (error) {
    console.error('❌ Error demonstrating additional fees:', error);
  } finally {
    await connection.end();
  }
}

// Run the demo
demonstrateAdditionalFees();
