#!/usr/bin/env node

/**
 * Fix Class Term Year Records Script
 * 
 * This script:
 * 1. Updates the database constraint to allow only one record per class
 * 2. Cleans up duplicate records, keeping only the most recent one per class
 * 3. Ensures each class has exactly one record
 */

const mysql = require('mysql2/promise');
require('dotenv').config();
const fs = require('fs');
const path = require('path');

// Database configuration
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'sms',
    port: process.env.DB_PORT || 3306,
    charset: 'utf8mb4'
};

async function runMigration() {
    let connection;
    
    try {
        console.log('🔧 Starting Class Term Year Records Fix...\n');
        
        // Connect to database
        console.log('📡 Connecting to database...');
        connection = await mysql.createConnection(dbConfig);
        console.log('✅ Connected to database successfully\n');
        
        // Step 1: Check current state
        console.log('📊 Checking current state...');
        const [totalRecords] = await connection.execute(
            'SELECT COUNT(*) as total FROM class_term_year'
        );
        const [duplicateClasses] = await connection.execute(`
            SELECT gradelevel_class_id, COUNT(*) as count 
            FROM class_term_year 
            GROUP BY gradelevel_class_id 
            HAVING COUNT(*) > 1
        `);
        
        console.log(`📈 Total class term year records: ${totalRecords[0].total}`);
        console.log(`⚠️  Classes with duplicate records: ${duplicateClasses.length}`);
        
        if (duplicateClasses.length > 0) {
            console.log('🔍 Duplicate classes found:');
            for (const dup of duplicateClasses) {
                console.log(`   - Class ID ${dup.gradelevel_class_id}: ${dup.count} records`);
            }
        }
        console.log('');
        
        // Step 2: Clean up duplicate records first
        console.log('🧹 Step 1: Cleaning up duplicate records...');
        
        if (duplicateClasses.length > 0) {
            console.log('🗑️  Removing duplicate records...');
            
            // Get all classes with duplicates
            for (const dup of duplicateClasses) {
                const classId = dup.gradelevel_class_id;
                
                // Get all records for this class, ordered by most recent
                const [records] = await connection.execute(`
                    SELECT id, term, academic_year, created_at, updated_at
                    FROM class_term_year 
                    WHERE gradelevel_class_id = ?
                    ORDER BY updated_at DESC, created_at DESC
                `, [classId]);
                
                console.log(`   📝 Class ${classId}: Found ${records.length} records`);
                console.log(`      🎯 Keeping record ${records[0].id} (${records[0].term} ${records[0].academic_year})`);
                
                // Keep the first (most recent) record, delete the rest
                const recordsToDelete = records.slice(1);
                
                if (recordsToDelete.length > 0) {
                    const deleteIds = recordsToDelete.map(r => r.id);
                    console.log(`      🗑️  Deleting records: ${deleteIds.join(', ')}`);
                    
                    // Delete each record individually to avoid array issues
                    for (const id of deleteIds) {
                        await connection.execute(
                            'DELETE FROM class_term_year WHERE id = ?',
                            [id]
                        );
                    }
                }
            }
            
            console.log('✅ Duplicate records cleaned up');
        } else {
            console.log('✅ No duplicate records found');
        }
        console.log('');
        
        // Step 3: Update database constraint
        console.log('🔧 Step 2: Updating database constraint...');
        
        try {
            // Drop the old constraint
            await connection.execute('ALTER TABLE class_term_year DROP INDEX unique_class_term_year');
            console.log('✅ Dropped old unique constraint');
        } catch (error) {
            if (error.code === 'ER_CANT_DROP_FIELD_OR_KEY') {
                console.log('ℹ️  Old constraint already removed or doesn\'t exist');
            } else {
                throw error;
            }
        }
        
        // Add new constraint
        await connection.execute('ALTER TABLE class_term_year ADD UNIQUE KEY unique_class_active (gradelevel_class_id)');
        console.log('✅ Added new unique constraint (one record per class)');
        console.log('');
        
        // Step 4: Verify final state
        console.log('🔍 Step 3: Verifying final state...');
        
        const [finalTotal] = await connection.execute(
            'SELECT COUNT(*) as total FROM class_term_year'
        );
        const [finalDuplicates] = await connection.execute(`
            SELECT gradelevel_class_id, COUNT(*) as count 
            FROM class_term_year 
            GROUP BY gradelevel_class_id 
            HAVING COUNT(*) > 1
        `);
        const [classesWithoutRecords] = await connection.execute(`
            SELECT gc.id, gc.name, s.name as stream_name
            FROM gradelevel_classes gc
            LEFT JOIN stream s ON gc.stream_id = s.id
            LEFT JOIN class_term_year cty ON gc.id = cty.gradelevel_class_id
            WHERE cty.gradelevel_class_id IS NULL
        `);
        
        console.log(`📊 Final Results:`);
        console.log(`   📈 Total class term year records: ${finalTotal[0].total}`);
        console.log(`   ✅ Classes with duplicate records: ${finalDuplicates.length}`);
        console.log(`   ⚠️  Classes without term/year records: ${classesWithoutRecords.length}`);
        
        if (classesWithoutRecords.length > 0) {
            console.log('\n📋 Classes that need term/year assignment:');
            for (const cls of classesWithoutRecords) {
                console.log(`   - ${cls.name} (${cls.stream_name})`);
            }
            console.log('\n💡 Use the bulk populate feature in the frontend to assign term/year to these classes');
        }
        
        if (finalDuplicates.length > 0) {
            console.log('\n❌ Warning: Some classes still have duplicate records!');
            for (const dup of finalDuplicates) {
                console.log(`   - Class ID ${dup.gradelevel_class_id}: ${dup.count} records`);
            }
        } else {
            console.log('\n✅ Success: All classes now have exactly one record each!');
        }
        
        console.log('\n🎉 Class Term Year Records Fix completed successfully!');
        
    } catch (error) {
        console.error('\n❌ Error during migration:', error.message);
        console.error('Stack trace:', error.stack);
        process.exit(1);
    } finally {
        if (connection) {
            await connection.end();
            console.log('📡 Database connection closed');
        }
    }
}

// Run the migration
if (require.main === module) {
    runMigration()
        .then(() => {
            console.log('\n✨ Script completed successfully!');
            process.exit(0);
        })
        .catch((error) => {
            console.error('\n💥 Script failed:', error.message);
            process.exit(1);
        });
}

module.exports = { runMigration };
