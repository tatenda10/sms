const { pool } = require('./config/database');

// All Grade 7 2024 students from the image
const grade72024Students = [
  { name: 'Nicholas', surname: "Chin'ono", balance: -340.00 },
  { name: 'Anita', surname: 'Chivete', balance: -80.00 },
  { name: 'Talent', surname: 'Choga', balance: -10.00 },
  { name: 'Tapiwa', surname: 'Furutuna', balance: -10.00 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', balance: -10.00 },
  { name: 'Goodson', surname: 'Kankuni', balance: -135.00 },
  { name: 'Adience', surname: 'Madzivaidze', balance: -10.00 },
  { name: 'Tawonga', surname: 'Masango', balance: -66.00 },
  { name: 'Samantha', surname: 'Munyanyi', balance: -20.00 },
  { name: 'Leeroy', surname: 'Muzanamombe', balance: -143.00 },
  { name: 'C Tinotenda', surname: 'Sithole', balance: -35.00 },
  { name: 'Anesu', surname: 'Mutengu', balance: -150.00 },
  { name: 'Ruvimbo', surname: 'Jongwe', balance: -120.00 },
  { name: 'Maseline', surname: 'Gwese', balance: -210.00 },
  { name: 'Sibongile', surname: 'Nyoni', balance: -5.00 },
  { name: 'Tinashe', surname: 'Antonio', balance: -80.00 },
  { name: 'Queen', surname: 'Muswati', balance: -210.00 },
  { name: 'Chipo', surname: 'Nyambodza', balance: -310.00 }
];

// Generate unique registration number
async function generateUniqueRegNumber(conn, surname, existingNumbers) {
  let maxNumber = 0;
  
  try {
    const [existing] = await conn.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY CAST(SUBSTRING(RegNumber, 2, 5) AS UNSIGNED) DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  let newNumber = maxNumber + 1;
  let regNumber;
  let attempts = 0;
  
  do {
    const numberStr = String(newNumber).padStart(5, '0');
    let letter = (surname && surname.trim()) ? surname.charAt(0).toUpperCase() : 'A';
    
    if (!/[A-Z]/.test(letter)) {
      letter = 'A';
    }
    
    regNumber = `R${numberStr}${letter}`;
    newNumber++;
    attempts++;
    
    if (attempts > 100) {
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      letter = letters[Math.floor(Math.random() * letters.length)];
      regNumber = `R${String(newNumber).padStart(5, '0')}${letter}`;
      break;
    }
  } while (existingNumbers.has(regNumber) || await regNumberExists(conn, regNumber));
  
  existingNumbers.add(regNumber);
  return regNumber;
}

async function regNumberExists(conn, regNumber) {
  const [existing] = await conn.execute(
    'SELECT RegNumber FROM students WHERE RegNumber = ?',
    [regNumber]
  );
  return existing.length > 0;
}

async function findStudentByName(conn, name, surname) {
  const [students] = await conn.execute(
    'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
    [name, surname]
  );
  return students.length > 0 ? students[0] : null;
}

async function fixGrade72024Duplicates() {
  const conn = await pool.getConnection();
  const existingNumbers = new Set();
  
  try {
    console.log('\n🔧 FIXING GRADE 7 2024 DUPLICATE REGISTRATION NUMBERS\n');
    console.log('='.repeat(70));
    console.log('Note: These students should NOT be enrolled\n');
    
    await conn.beginTransaction();
    
    // Step 1: Find all students and identify duplicates
    console.log('\n📋 STEP 1: Finding students and identifying duplicates...\n');
    
    const studentMap = new Map();
    const studentsToUpdate = [];
    
    for (const student of grade72024Students) {
      const existing = await findStudentByName(conn, student.name, student.surname);
      
      if (existing) {
        // Check if this reg number is used by multiple students
        const [duplicates] = await conn.execute(
          'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
          [existing.RegNumber]
        );
        
        if (duplicates.length > 1) {
          // This reg number is shared - need to assign new one
          console.log(`⚠️  ${student.name} ${student.surname} shares reg number ${existing.RegNumber} with ${duplicates.length - 1} other(s)`);
          const newRegNumber = await generateUniqueRegNumber(conn, student.surname, existingNumbers);
          studentsToUpdate.push({
            name: student.name,
            surname: student.surname,
            oldRegNumber: existing.RegNumber,
            newRegNumber: newRegNumber
          });
          studentMap.set(`${student.name}|${student.surname}`, { ...student, regNumber: newRegNumber, existing: true });
          console.log(`   → Will assign: ${newRegNumber}`);
        } else {
          // Reg number is unique - keep it
          studentMap.set(`${student.name}|${student.surname}`, { ...student, regNumber: existing.RegNumber, existing: true });
          existingNumbers.add(existing.RegNumber);
          console.log(`✅ ${student.name} ${student.surname} - keeping ${existing.RegNumber}`);
        }
      } else {
        // Student doesn't exist
        const newRegNumber = await generateUniqueRegNumber(conn, student.surname, existingNumbers);
        studentMap.set(`${student.name}|${student.surname}`, { ...student, regNumber: newRegNumber, existing: false });
        console.log(`➕ ${student.name} ${student.surname} - will register with ${newRegNumber}`);
      }
    }
    
    // Step 2: Update students with new reg numbers
    console.log('\n🔄 STEP 2: Updating students with new reg numbers...\n');
    
    for (const update of studentsToUpdate) {
      console.log(`Updating ${update.name} ${update.surname}: ${update.oldRegNumber} → ${update.newRegNumber}`);
      
      // Update students table (this will cascade to related tables)
      await conn.execute(
        'UPDATE students SET RegNumber = ? WHERE RegNumber = ? AND LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [update.newRegNumber, update.oldRegNumber, update.name, update.surname]
      );
      
      console.log(`   ✅ Updated`);
    }
    
    // Step 3: Register missing students
    console.log('\n➕ STEP 3: Registering missing students...\n');
    
    for (const [key, student] of studentMap.entries()) {
      if (!student.existing) {
        console.log(`Registering ${student.name} ${student.surname} (${student.regNumber})`);
        
        const year = 2011; // Grade 7 2024 students
        const month = Math.floor(Math.random() * 12) + 1;
        const day = Math.floor(Math.random() * 28) + 1;
        const dateOfBirth = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const gender = Math.random() > 0.5 ? 'Male' : 'Female';
        const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
        const address = 'Address not provided';
        
        await conn.execute(`
          INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
        
        const guardianName = `Guardian of ${student.name}`;
        const guardianSurname = student.surname;
        const guardianPhone = `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
        
        await conn.execute(`
          INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, 'Parent']);
        
        await conn.execute(`
          INSERT INTO student_balances (student_reg_number, current_balance)
          VALUES (?, 0)
          ON DUPLICATE KEY UPDATE current_balance = current_balance
        `, [student.regNumber]);
        
        console.log(`   ✅ Registered`);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ All students processed successfully!');
    console.log('\n📊 Summary:');
    console.log(`   Total students: ${studentMap.size}`);
    console.log(`   Students updated with new reg numbers: ${studentsToUpdate.length}`);
    console.log(`   New students registered: ${Array.from(studentMap.values()).filter(s => !s.existing).length}`);
    
    // Show final list
    console.log('\n📋 FINAL GRADE 7 2024 STUDENTS:\n');
    console.log('-'.repeat(70));
    let idx = 1;
    for (const [key, student] of studentMap.entries()) {
      console.log(`${String(idx).padStart(3)}. ${student.name.padEnd(20)} ${student.surname.padEnd(25)} ${student.regNumber}`);
      idx++;
    }
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error fixing duplicates:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixGrade72024Duplicates();

