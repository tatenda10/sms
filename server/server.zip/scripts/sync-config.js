// Configuration file for bidirectional database sync
// Copy this file and rename to sync-config.js, then fill in your credentials

module.exports = {
    // Local database configuration
    local: {
        host: 'localhost',
        user: 'root',
        password: 'password123',
        database: 'sms'
    },
    
    // DigitalOcean database configuration
    remote: {
        host: 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
        user: 'doadmin',
        password: 'AVNS_O_R4Z5_x8aFOV6Pzy6J',
        database: 'sms',
        port: 25060
    },
    
    // Sync options
    options: {
        // Which database to use as source of truth for conflicts
        // 'local' = local database wins, 'remote' = remote database wins
        conflictResolution: 'local',
        
        // Whether to create missing tables
        createMissingTables: true,
        
        // Whether to sync table structures
        syncStructures: true,
        
        // Whether to sync data
        syncData: true,
        
        // Tables to exclude from sync (optional)
        excludeTables: [
            'test_table',
            'temp_table'
        ],
        
        // Tables to include only (if empty, all tables are synced)
        includeTables: []
    }
};