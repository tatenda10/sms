const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function checkStudentBalance() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔍 Checking balance for student: ${studentRegNumber}\n`);
    
    // 1. Check student balance record
    const [balanceRecord] = await conn.execute(
      'SELECT * FROM student_balances WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    console.log('1️⃣ Student Balance Record:');
    if (balanceRecord.length > 0) {
      console.log(`   Current Balance: $${balanceRecord[0].current_balance}`);
      console.log(`   Last Updated: ${balanceRecord[0].last_updated}`);
    } else {
      console.log('   No balance record found');
    }
    
    // 2. Check all transactions
    const [transactions] = await conn.execute(
      `SELECT id, transaction_type, amount, description, transaction_date, journal_entry_id, hostel_id, enrollment_id
       FROM student_transactions 
       WHERE student_reg_number = ?
       ORDER BY transaction_date DESC`,
      [studentRegNumber]
    );
    
    console.log(`\n2️⃣ Student Transactions (${transactions.length} total):`);
    let totalDebit = 0;
    let totalCredit = 0;
    transactions.forEach(tx => {
      const amount = parseFloat(tx.amount);
      if (tx.transaction_type === 'DEBIT') {
        totalDebit += amount;
      } else {
        totalCredit += amount;
      }
      console.log(`   - ID: ${tx.id}, Type: ${tx.transaction_type}, Amount: $${amount}, Date: ${tx.transaction_date}`);
      console.log(`     Description: ${tx.description}`);
      console.log(`     Journal Entry ID: ${tx.journal_entry_id || 'NULL'}, Hostel ID: ${tx.hostel_id || 'NULL'}, Enrollment ID: ${tx.enrollment_id || 'NULL'}`);
    });
    
    console.log(`\n   Total DEBIT: $${totalDebit}`);
    console.log(`   Total CREDIT: $${totalCredit}`);
    console.log(`   Calculated Balance: $${(totalCredit - totalDebit).toFixed(2)}`);
    
    // 3. Check boarding enrollments
    const [enrollments] = await conn.execute(
      'SELECT id, student_reg_number, hostel_id, status, enrollment_date, term, academic_year FROM boarding_enrollments WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    console.log(`\n3️⃣ Boarding Enrollments (${enrollments.length} total):`);
    enrollments.forEach(en => {
      console.log(`   - ID: ${en.id}, Status: ${en.status}, Hostel: ${en.hostel_id}, Date: ${en.enrollment_date}`);
    });
    
    // 4. Check journal entries linked to transactions
    const journalEntryIds = transactions.filter(tx => tx.journal_entry_id).map(tx => tx.journal_entry_id);
    if (journalEntryIds.length > 0) {
      const placeholders = journalEntryIds.map(() => '?').join(',');
      const [journalEntries] = await conn.execute(
        `SELECT id, entry_date, description, reference FROM journal_entries WHERE id IN (${placeholders})`,
        journalEntryIds
      );
      
      console.log(`\n4️⃣ Linked Journal Entries (${journalEntries.length} total):`);
      journalEntries.forEach(je => {
        console.log(`   - ID: ${je.id}, Date: ${je.entry_date}, Description: ${je.description}`);
      });
    }
    
    // 5. Summary
    console.log('\n📊 SUMMARY:');
    const currentBalance = balanceRecord.length > 0 ? parseFloat(balanceRecord[0].current_balance) : 0;
    const calculatedBalance = totalCredit - totalDebit;
    console.log(`   Current Balance (from DB): $${currentBalance.toFixed(2)}`);
    console.log(`   Calculated Balance (from transactions): $${calculatedBalance.toFixed(2)}`);
    
    if (Math.abs(currentBalance - calculatedBalance) > 0.01) {
      console.log(`   ⚠️  DISCREPANCY DETECTED! Balance mismatch of $${Math.abs(currentBalance - calculatedBalance).toFixed(2)}`);
    } else {
      console.log(`   ✅ Balances match`);
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkStudentBalance();

