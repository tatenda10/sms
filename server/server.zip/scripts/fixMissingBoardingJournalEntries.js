const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const AccountBalanceService = require('../services/accountBalanceService');

async function fixMissingBoardingJournalEntries() {
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    console.log('🔍 Finding boarding DEBIT transactions without journal entries...\n');
    
    // Find boarding DEBIT transactions without journal entries
    const [unlinkedTransactions] = await conn.execute(`
      SELECT 
        st.id as transaction_id,
        st.student_reg_number,
        st.amount,
        st.transaction_date,
        st.description,
        st.class_id,
        be.id as enrollment_id,
        be.hostel_id,
        be.term,
        be.academic_year
      FROM student_transactions st
      LEFT JOIN boarding_enrollments be ON st.student_reg_number = be.student_reg_number
        AND DATE(st.transaction_date) = DATE(be.enrollment_date)
      WHERE st.transaction_type = 'DEBIT'
        AND st.description LIKE '%BOARDING%'
        AND (st.journal_entry_id IS NULL OR st.journal_entry_id = 0)
      ORDER BY st.transaction_date DESC
    `);
    
    console.log(`Found ${unlinkedTransactions.length} unlinked boarding transactions\n`);
    
    if (unlinkedTransactions.length === 0) {
      console.log('✅ No missing journal entries found!');
      await conn.commit();
      return;
    }
    
    // Get account IDs
    const [accountsReceivable] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
      ['1100', 'Asset']
    );
    
    const [boardingRevenue] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
      ['4002', 'Revenue']
    );
    
    if (accountsReceivable.length === 0 || boardingRevenue.length === 0) {
      throw new Error('Required accounts not found (1100 or 4002)');
    }
    
    const accountsReceivableId = accountsReceivable[0].id;
    const boardingRevenueId = boardingRevenue[0].id;
    
    // Get or create Fees Journal (ID: 6)
    let journalId = 6;
    const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journalId]);
    if (journalCheck.length === 0) {
      // Try to find any existing journal
      const [existingJournal] = await conn.execute('SELECT id FROM journals ORDER BY id LIMIT 1');
      if (existingJournal.length > 0) {
        journalId = existingJournal[0].id;
      } else {
        // Create Fees Journal if no journals exist
        const [journalResult] = await conn.execute(
          'INSERT INTO journals (id, name, description, is_active) VALUES (?, ?, ?, ?)',
          [6, 'Fees Journal', 'All student fee-related transactions, including tuition, exam fees, and boarding fees.', 1]
        );
        journalId = journalResult.insertId || 6;
      }
    }
    
    let fixedCount = 0;
    
    for (const tx of unlinkedTransactions) {
      try {
        console.log(`Processing transaction ID ${tx.transaction_id} - $${tx.amount} for student ${tx.student_reg_number}`);
        
        // Check if a journal entry already exists for this transaction
        const [existingJournal] = await conn.execute(`
          SELECT je.id
          FROM journal_entries je
          INNER JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
          WHERE je.description LIKE ?
            AND je.entry_date = DATE(?)
            AND jel.account_id = ?
            AND jel.debit = ?
          LIMIT 1
        `, [
          `%${tx.student_reg_number}%`,
          tx.transaction_date,
          accountsReceivableId,
          tx.amount
        ]);
        
        let journalEntryId;
        
        if (existingJournal.length > 0) {
          journalEntryId = existingJournal[0].id;
          console.log(`  ✓ Reusing existing journal entry ${journalEntryId}`);
        } else {
          // Create new journal entry
          const description = tx.description || `BOARDING ENROLLMENT - ${tx.student_reg_number}`;
          const [journalEntry] = await conn.execute(
            `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by) 
             VALUES (?, DATE(?), ?, ?, ?)`,
            [
              journalId,
              tx.transaction_date,
              description,
              `BOARDING-${tx.student_reg_number}-${Date.now()}`,
              1 // Default created_by
            ]
          );
          
          journalEntryId = journalEntry.insertId;
          console.log(`  ✓ Created journal entry ${journalEntryId}`);
          
          // Create journal entry lines
          // Debit: Accounts Receivable
          await conn.execute(
            `INSERT INTO journal_entry_lines 
             (journal_entry_id, account_id, debit, credit, description) 
             VALUES (?, ?, ?, ?, ?)`,
            [
              journalEntryId,
              accountsReceivableId,
              tx.amount,
              0,
              `Accounts Receivable - ${tx.student_reg_number}`
            ]
          );
          
          // Credit: Boarding Revenue
          await conn.execute(
            `INSERT INTO journal_entry_lines 
             (journal_entry_id, account_id, debit, credit, description) 
             VALUES (?, ?, ?, ?, ?)`,
            [
              journalEntryId,
              boardingRevenueId,
              0,
              tx.amount,
              `Boarding Revenue - ${tx.student_reg_number}`
            ]
          );
          
          // Update account balances
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId);
          console.log(`  ✓ Updated account balances for journal entry ${journalEntryId}`);
        }
        
        // Link the transaction to the journal entry
        await conn.execute(
          'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
          [journalEntryId, tx.transaction_id]
        );
        console.log(`  ✓ Linked transaction ${tx.transaction_id} to journal entry ${journalEntryId}`);
        
        fixedCount++;
        console.log('');
        
      } catch (error) {
        console.error(`  ❌ Error processing transaction ${tx.transaction_id}:`, error.message);
      }
    }
    
    await conn.commit();
    console.log(`\n✅ Successfully fixed ${fixedCount} out of ${unlinkedTransactions.length} transactions!`);
    
    // Show updated balances
    console.log('\n📊 Updated Account Balances:');
    const [updatedBalances] = await conn.execute(`
      SELECT 
        coa.code,
        coa.name,
        COALESCE(ab.balance, 0) as balance
      FROM chart_of_accounts coa
      LEFT JOIN (
        SELECT 
          ab1.account_id,
          ab1.balance
        FROM account_balances ab1
        INNER JOIN (
          SELECT 
            account_id,
            MAX(as_of_date) as max_date
          FROM account_balances
          WHERE as_of_date <= CURDATE()
          GROUP BY account_id
        ) ab2 ON ab1.account_id = ab2.account_id AND ab1.as_of_date = ab2.max_date
      ) ab ON coa.id = ab.account_id
      WHERE coa.code IN ('1100', '4002')
        AND coa.is_active = TRUE
      ORDER BY coa.code
    `);
    
    updatedBalances.forEach(ab => {
      console.log(`   ${ab.code} (${ab.name}): $${ab.balance}`);
    });
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
  }
}

fixMissingBoardingJournalEntries();

