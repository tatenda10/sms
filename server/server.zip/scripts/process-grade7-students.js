const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Corrected student data from the Excel
const studentData = [
  { name: 'Naison', surname: 'Alifasi', regNumber: 'R00001N', balance: 0.00, totalPayments: 100.00 },
  { name: 'Patience', surname: 'Gowe', regNumber: 'R00001P', balance: 0.00, totalPayments: 100.00 },
  { name: 'Kupakwashe', surname: 'Chiteve', regNumber: 'R00001K', balance: -60.00, totalPayments: 0.00 },
  { name: 'Maudy', surname: 'Hahisa', regNumber: 'R00001M', balance: 0.00, totalPayments: 50.00 },
  { name: 'Miguel', surname: 'Gomera', regNumber: 'R00002M', balance: 0.00, totalPayments: 50.00 },
  { name: 'Ruvarashe', surname: 'Bhudhi', regNumber: 'R00001R', balance: 0.00, totalPayments: 100.00 },
  { name: 'Joseph', surname: 'Masanganise', regNumber: 'R00001J', balance: -5.00, totalPayments: 0.00 },
  { name: 'Juliet', surname: 'Mudisi', regNumber: 'R00002J', balance: 0.00, totalPayments: 100.00 },
  { name: 'Andrew', surname: 'Mudzviti', regNumber: 'R00001A', balance: -25.00, totalPayments: 0.00 },
  { name: 'Thandeka', surname: 'Mushonga', regNumber: 'R00001T', balance: 0.00, totalPayments: 40.00 },
  { name: 'Nelisha', surname: 'Mutonzi', regNumber: 'R00002N', balance: 0.00, totalPayments: 100.00 },
  { name: 'Nigel', surname: 'Vainet', regNumber: 'R00003N', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tadiwanashe', surname: 'Mudewairi', regNumber: 'R00003M', balance: 0.00, totalPayments: 100.00 },
  { name: 'Sharon', surname: 'Mashati', regNumber: 'R00001S', balance: -5.00, totalPayments: 100.00 },
  { name: 'Shanice', surname: 'Matsheza', regNumber: 'R00002S', balance: 0.00, totalPayments: 100.00 },
  { name: 'Mitchelle', surname: 'Kasunungura', regNumber: 'R00004M', balance: 0.00, totalPayments: 100.00 },
  { name: 'Brayden', surname: 'Majinjiwa', regNumber: 'R00001B', balance: 0.00, totalPayments: 100.00 },
  { name: 'Shyleen', surname: 'Chatiza', regNumber: 'R00003S', balance: 0.00, totalPayments: 70.00 },
  { name: 'Anotidaishe', surname: 'Hlebo', regNumber: 'R00002A', balance: -10.00, totalPayments: 50.00 },
  { name: 'Junior', surname: 'Nyaude', regNumber: 'R00003J', balance: 0.00, totalPayments: 0.00 },
  { name: 'Jayden', surname: 'Nhidza', regNumber: 'R00004J', balance: -70.00, totalPayments: 0.00 },
  { name: 'Tadiwa', surname: 'Tsiko', regNumber: 'R00004K', balance: 0.00, totalPayments: 60.00 },
  { name: 'Bianga', surname: 'Phiri', regNumber: 'R00002B', balance: -272.00, totalPayments: 0.00 },
  { name: 'Junior', surname: 'Gwaze', regNumber: 'R00005J', balance: -80.00, totalPayments: 0.00 }
];

// Helper function to generate random date of birth (between 2008 and 2010 for Grade 7)
function generateRandomDOB() {
  const year = 2008 + Math.floor(Math.random() * 3);
  const month = Math.floor(Math.random() * 12) + 1;
  const day = Math.floor(Math.random() * 28) + 1;
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

// Helper function to generate random gender
function generateRandomGender() {
  return Math.random() > 0.5 ? 'Male' : 'Female';
}

// Helper function to generate random phone number
function generateRandomPhone() {
  return `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
}

// Helper function to get or create journal
async function getOrCreateJournal(conn, journalName, description) {
  let [journals] = await conn.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', [journalName]);
  
  if (journals.length === 0) {
    [journals] = await conn.execute(
      'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
      [journalName, description, 1]
    );
    return journals.insertId;
  }
  
  return journals[0].id;
}

// Step 1: Register students
async function registerStudents() {
  console.log('\n📝 STEP 1: Registering students...\n');
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    let registered = 0;
    let skipped = 0;
    
    for (const student of studentData) {
      try {
        // Check if student already exists
        const [existing] = await conn.execute(
          'SELECT RegNumber FROM students WHERE RegNumber = ?',
          [student.regNumber]
        );
        
        if (existing.length > 0) {
          console.log(`⏭️  Skipping ${student.name} ${student.surname} (${student.regNumber}) - already exists`);
          skipped++;
          continue;
        }
        
        // Generate random details
        const dateOfBirth = generateRandomDOB();
        const gender = generateRandomGender();
        const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
        const address = 'Address not provided';
        
        // Insert student
        await conn.execute(`
          INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
        
        // Insert guardian
        const guardianName = `Guardian of ${student.name}`;
        const guardianSurname = student.surname;
        const guardianPhone = generateRandomPhone();
        const relationship = 'Parent';
        
        await conn.execute(`
          INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, relationship]);
        
        // Initialize balance record
        await conn.execute(`
          INSERT INTO student_balances (student_reg_number, current_balance)
          VALUES (?, 0.00)
          ON DUPLICATE KEY UPDATE current_balance = current_balance
        `, [student.regNumber]);
        
        console.log(`✅ Registered: ${student.name} ${student.surname} (${student.regNumber})`);
        registered++;
      } catch (error) {
        console.error(`❌ Error registering ${student.name} ${student.surname}:`, error.message);
        throw error;
      }
    }
    
    await conn.commit();
    console.log(`\n✅ Registration complete: ${registered} registered, ${skipped} skipped\n`);
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

// Step 2: Add outstanding balances for students with negative balances
async function addOutstandingBalances() {
  console.log('\n💰 STEP 2: Adding outstanding balances...\n');
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    // Get or create General Journal
    const journalId = await getOrCreateJournal(
      conn,
      'General Journal',
      'Journal for general transactions including opening balances'
    );
    
    let processed = 0;
    
    for (const student of studentData) {
      if (student.balance >= 0) continue; // Skip students with no debt
      
      const debtAmount = Math.abs(student.balance); // Convert negative to positive
      
      try {
        // Get student details
        const [students] = await conn.execute(
          'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
          [student.regNumber]
        );
        
        if (students.length === 0) {
          console.log(`⚠️  Student ${student.regNumber} not found, skipping balance adjustment`);
          continue;
        }
        
        const studentInfo = students[0];
        
        // Get current balance
        const [balanceRows] = await conn.execute(
          'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
          [student.regNumber]
        );
        
        const currentBalance = balanceRows.length > 0 ? balanceRows[0].current_balance : 0;
        
        // Create journal entry
        const journalDescription = `Opening Balance - Outstanding Debt for ${studentInfo.Name} ${studentInfo.Surname}`;
        const reference = `OB-${student.regNumber}-${Date.now()}`;
        
        const [journalEntry] = await conn.execute(`
          INSERT INTO journal_entries (
            journal_id, entry_date, description, reference,
            created_by, created_at, updated_at
          ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
        `, [journalId, journalDescription, reference, 1]);
        
        const journalEntryId = journalEntry.insertId;
        
        // Get account IDs
        const [accountsReceivable] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
          ['1100', 'Asset']
        );
        
        const [retainedEarnings] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
          ['3998'] // Retained Earnings (Opening Balance Equity)
        );
        
        if (accountsReceivable.length === 0 || retainedEarnings.length === 0) {
          throw new Error('Required accounts not found in chart of accounts (1100, 3998)');
        }
        
        // Create journal entry lines (use debit/credit columns)
        // For opening balance debt: DEBIT Accounts Receivable, CREDIT Retained Earnings
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, accountsReceivable[0].id, debtAmount, 0, `Accounts Receivable - Opening Balance`]);
        
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, retainedEarnings[0].id, 0, debtAmount, `Retained Earnings - Opening Balance`]);
        
        // Check if transaction already exists to prevent duplicates
        const [existingTxn] = await conn.execute(
          'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
          [student.regNumber, `%Opening Balance - Outstanding Debt%`, 'DEBIT']
        );
        
        if (existingTxn.length > 0) {
          console.log(`⏭️  Skipping outstanding balance for ${student.name} ${student.surname} - transaction already exists`);
          continue;
        }
        
        // Create DEBIT transaction (this automatically updates the balance)
        const transactionId = await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'DEBIT',
          debtAmount,
          `Opening Balance - Outstanding Debt: ${reference}`,
          {
            created_by: 1,
            journal_entry_id: journalEntryId
          }
        );
        
        // Get updated balance (transaction already updated it)
        const [updatedBalance] = await conn.execute(
          'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
          [student.regNumber]
        );
        const newBalance = updatedBalance.length > 0 ? updatedBalance[0].current_balance : 0;
        
        // Update account balances from journal entry
        await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
        
        console.log(`✅ Added outstanding balance: ${student.name} ${student.surname} - $${debtAmount.toFixed(2)} (New balance: $${newBalance.toFixed(2)})`);
        processed++;
      } catch (error) {
        console.error(`❌ Error adding balance for ${student.name} ${student.surname}:`, error.message);
        throw error;
      }
    }
    
    await conn.commit();
    console.log(`\n✅ Outstanding balances complete: ${processed} students processed\n`);
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

// Step 3: Enroll students to Grade 7 class for Term 3 2025
async function enrollStudents() {
  console.log('\n🎓 STEP 3: Enrolling students to Grade 7, Term 3, 2025...\n');
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    // Find Grade 7 class
    const [grade7Classes] = await conn.execute(`
      SELECT gc.id, gc.name, gc.stream_id, s.name as stream_name
      FROM gradelevel_classes gc
      JOIN stream s ON gc.stream_id = s.id
      WHERE gc.name LIKE '%Grade 7%' OR gc.name LIKE '%7%'
      LIMIT 1
    `);
    
    if (grade7Classes.length === 0) {
      throw new Error('Grade 7 class not found. Please create it first.');
    }
    
    const grade7Class = grade7Classes[0];
    console.log(`📚 Found Grade 7 class: ${grade7Class.name} (ID: ${grade7Class.id})`);
    
    // Find invoice structure for Grade 7, Term 3, 2025
    const [invoiceStructures] = await conn.execute(`
      SELECT id, total_amount, currency_id
      FROM invoice_structures
      WHERE gradelevel_class_id = ? AND term = ? AND academic_year = ?
      LIMIT 1
    `, [grade7Class.id, 'Term 3', '2025']);
    
    if (invoiceStructures.length === 0) {
      throw new Error('Invoice structure for Grade 7, Term 3, 2025 not found. Please create it first.');
    }
    
    const invoiceStructure = invoiceStructures[0];
    console.log(`💰 Found invoice structure: $${invoiceStructure.total_amount} (ID: ${invoiceStructure.id})`);
    
    // Get or create Fees Journal
    const journalId = await getOrCreateJournal(
      conn,
      'Fees Journal',
      'Journal for fee payment transactions including class enrollments'
    );
    
    let enrolled = 0;
    let skipped = 0;
    
    for (const student of studentData) {
      try {
        // Check if already enrolled
        const [existing] = await conn.execute(`
          SELECT id FROM enrollments_gradelevel_classes 
          WHERE student_regnumber = ? AND status = 'active'
        `, [student.regNumber]);
        
        if (existing.length > 0) {
          console.log(`⏭️  Skipping enrollment: ${student.name} ${student.surname} - already enrolled`);
          skipped++;
          continue;
        }
        
        // Create enrollment (term and academic_year are not in the table, they come from invoice structure)
        const [enrollment] = await conn.execute(`
          INSERT INTO enrollments_gradelevel_classes (
            student_regnumber, gradelevel_class_id, status
          ) VALUES (?, ?, ?)
        `, [student.regNumber, grade7Class.id, 'active']);
        
        const enrollmentId = enrollment.insertId;
        
        // Create journal entries for enrollment
        const description = `Class Enrollment - ${student.name} ${student.surname} - Grade 7 Term 3 2025`;
        const reference = `ENROLL-${student.regNumber}-${Date.now()}`;
        
        // Get account IDs
        const [accountsReceivable] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
          ['1100', 'Asset']
        );
        
        const [tuitionRevenue] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
          ['4000', 'Revenue']
        );
        
        if (accountsReceivable.length === 0 || tuitionRevenue.length === 0) {
          throw new Error('Required accounts not found in chart of accounts');
        }
        
        // Create journal entry
        const [journalEntry] = await conn.execute(`
          INSERT INTO journal_entries (
            journal_id, entry_date, description, reference, created_by
          ) VALUES (?, CURDATE(), ?, ?, ?)
        `, [journalId, description, reference, 1]);
        
        const journalEntryId = journalEntry.insertId;
        
        // Create journal entry lines (use debit/credit columns)
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, accountsReceivable[0].id, invoiceStructure.total_amount, 0, description]);
        
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, tuitionRevenue[0].id, 0, invoiceStructure.total_amount, description]);
        
        // Check if enrollment transaction already exists
        const [existingEnrollTxn] = await conn.execute(
          'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
          [student.regNumber, `%Class Enrollment - Grade 7 Term 3 2025%`, 'DEBIT']
        );
        
        if (existingEnrollTxn.length > 0) {
          console.log(`⏭️  Skipping enrollment transaction for ${student.name} ${student.surname} - already exists`);
          // Still need to update journal entry link if missing
          if (existingEnrollTxn[0].journal_entry_id !== journalEntryId) {
            await conn.execute(
              'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
              [journalEntryId, existingEnrollTxn[0].id]
            );
          }
          continue;
        }
        
        // Create DEBIT transaction (this automatically updates the balance)
        const transactionId = await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'DEBIT',
          invoiceStructure.total_amount,
          `Class Enrollment - Grade 7 Term 3 2025: ${reference}`,
          {
            created_by: 1,
            journal_entry_id: journalEntryId
          }
        );
        
        // Get updated balance (transaction already updated it)
        const [updatedBalance] = await conn.execute(
          'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
          [student.regNumber]
        );
        const newBalance = updatedBalance.length > 0 ? updatedBalance[0].current_balance : 0;
        
        // Update account balances from journal entry
        await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
        
        console.log(`✅ Enrolled: ${student.name} ${student.surname} - Balance: $${newBalance.toFixed(2)}`);
        enrolled++;
      } catch (error) {
        console.error(`❌ Error enrolling ${student.name} ${student.surname}:`, error.message);
        throw error;
      }
    }
    
    await conn.commit();
    console.log(`\n✅ Enrollment complete: ${enrolled} enrolled, ${skipped} skipped\n`);
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

// Step 4: Record payments
async function recordPayments() {
  console.log('\n💳 STEP 4: Recording payments...\n');
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    // Get default currency (USD)
    const [currencies] = await conn.execute(
      'SELECT id FROM currencies WHERE code = ? LIMIT 1',
      ['USD']
    );
    
    if (currencies.length === 0) {
      throw new Error('USD currency not found');
    }
    
    const currencyId = currencies[0].id;
    
    let processed = 0;
    let skipped = 0;
    
    for (const student of studentData) {
      if (student.totalPayments <= 0) {
        skipped++;
        continue;
      }
      
      try {
        // Check if student exists
        const [students] = await conn.execute(
          'SELECT RegNumber FROM students WHERE RegNumber = ?',
          [student.regNumber]
        );
        
        if (students.length === 0) {
          console.log(`⚠️  Student ${student.regNumber} not found, skipping payment`);
          skipped++;
          continue;
        }
        
        // Check if payment already exists (prevent duplicates)
        const receiptNumber = `PAY-${student.regNumber}-${Date.now()}`;
        const [existingPayment] = await conn.execute(`
          SELECT id FROM fee_payments WHERE receipt_number = ?
        `, [receiptNumber]);
        
        if (existingPayment.length > 0) {
          console.log(`⏭️  Payment already exists for ${student.name} ${student.surname}`);
          skipped++;
          continue;
        }
        
        // Create payment record
        const [paymentResult] = await conn.execute(`
          INSERT INTO fee_payments (
            student_reg_number, payment_amount, payment_currency, exchange_rate,
            base_currency_amount, payment_method, payment_date, receipt_number,
            reference_number, notes, created_by
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          student.regNumber,
          student.totalPayments,
          currencyId,
          1.0,
          student.totalPayments,
          'Cash',
          new Date(),
          receiptNumber,
          receiptNumber,
          'Payment from Grade 7 enrollment batch',
          1
        ]);
        
        const paymentId = paymentResult.insertId;
        
        // Create CREDIT transaction
        const transactionId = await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'CREDIT',
          student.totalPayments,
          `Fee Payment - Receipt #${receiptNumber}`,
          {
            created_by: 1,
            payment_id: paymentId
          }
        );
        
        // Create journal entries for payment
        const [cashAccount] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
          ['1000', 'Asset']
        );
        
        const [accountsReceivable] = await conn.execute(
          'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
          ['1100', 'Asset']
        );
        
        if (cashAccount.length === 0 || accountsReceivable.length === 0) {
          throw new Error('Required accounts not found in chart of accounts');
        }
        
        // Get or create Fees Journal
        const journalId = await getOrCreateJournal(
          conn,
          'Fees Journal',
          'Journal for fee payment transactions'
        );
        
        const journalDescription = `Fee Payment - ${student.name} ${student.surname} - Receipt #${receiptNumber}`;
        const [journalEntry] = await conn.execute(`
          INSERT INTO journal_entries (
            journal_id, entry_date, description, reference, created_by
          ) VALUES (?, CURDATE(), ?, ?, ?)
        `, [journalId, journalDescription, receiptNumber, 1]);
        
        const journalEntryId = journalEntry.insertId;
        
        // Create journal entry lines (use debit/credit columns)
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, cashAccount[0].id, student.totalPayments, 0, journalDescription]);
        
        await conn.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, accountsReceivable[0].id, 0, student.totalPayments, journalDescription]);
        
        // Update transaction with journal entry ID
        await conn.execute(`
          UPDATE student_transactions 
          SET journal_entry_id = ?
          WHERE id = ?
        `, [journalEntryId, transactionId]);
        
        // Get updated balance (transaction already updated it via createTransactionHelper)
        const [updatedBalance] = await conn.execute(
          'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
          [student.regNumber]
        );
        const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
        
        // Update account balances from journal entry
        await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, currencyId);
        
        console.log(`✅ Payment recorded: ${student.name} ${student.surname} - $${student.totalPayments.toFixed(2)} (New balance: $${newBalance.toFixed(2)})`);
        processed++;
      } catch (error) {
        console.error(`❌ Error recording payment for ${student.name} ${student.surname}:`, error.message);
        throw error;
      }
    }
    
    await conn.commit();
    console.log(`\n✅ Payments complete: ${processed} payments recorded, ${skipped} skipped\n`);
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

// Main execution
async function main() {
  try {
    console.log('🚀 Starting Grade 7 Student Processing...\n');
    console.log('='.repeat(60));
    
    await registerStudents();
    await addOutstandingBalances();
    await enrollStudents();
    await recordPayments();
    
    console.log('='.repeat(60));
    console.log('\n✅ All steps completed successfully!\n');
    
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Error during processing:', error);
    process.exit(1);
  }
}

main();

