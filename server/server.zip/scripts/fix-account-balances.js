const { pool } = require('../config/database');
const AccountBalanceService = require('../services/accountBalanceService');

async function fixAccountBalances() {
    const conn = await pool.getConnection();
    
    try {
        console.log('🚀 Starting account balance fix...');
        console.log('This will recalculate all account balances from journal entries.');
        
        // Ask for confirmation
        const readline = require('readline');
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        const answer = await new Promise((resolve) => {
            rl.question('Are you sure you want to proceed? This will clear and recalculate ALL account balances. (yes/no): ', resolve);
        });
        
        rl.close();
        
        if (answer.toLowerCase() !== 'yes') {
            console.log('❌ Operation cancelled.');
            return;
        }
        
        console.log('🔄 Recalculating all account balances...');
        await AccountBalanceService.recalculateAllAccountBalances(conn);
        
        console.log('✅ Account balance fix completed successfully!');
        console.log('📊 All account balances have been recalculated from journal entries.');
        
    } catch (error) {
        console.error('❌ Error fixing account balances:', error);
        throw error;
    } finally {
        conn.release();
        process.exit(0);
    }
}

// Run the fix
fixAccountBalances().catch(console.error);
