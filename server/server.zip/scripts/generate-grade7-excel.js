const ExcelJS = require('exceljs');
const { pool } = require('./config/database');

// Student data extracted from the image
// Note: Some rows may be missing (e.g., row 8, 23) as they weren't visible in the image
const studentData = [
  { number: 1, name: 'Alifasi', surname: 'Naison', transHDay: null, balReg: null, payment1: 100, payment2: null, payment3: null, total: 100 },
  { number: 2, name: 'Gowe', surname: 'Patience', transHDay: null, balReg: null, payment1: 50, payment2: 50, payment3: null, total: 100 },
  { number: 3, name: 'Chiteve', surname: 'Kupakwashe', transHDay: -60, balReg: null, payment1: null, payment2: null, payment3: null, total: null },
  { number: 4, name: 'Hahisa', surname: 'Maudy', transHDay: null, balReg: 50, payment1: null, payment2: null, payment3: null, total: null },
  { number: 5, name: 'Gomera', surname: 'Miguel', transHDay: 4, balReg: 50, payment1: null, payment2: null, payment3: null, total: null },
  { number: 6, name: 'Bhudhi', surname: 'Ruvarashe', transHDay: null, balReg: 48, payment1: null, payment2: 52, payment3: null, total: 100 },
  { number: 7, name: 'Masanganise', surname: 'Joseph', transHDay: null, balReg: -5, payment1: null, payment2: null, payment3: null, total: null },
  { number: 9, name: 'Mudisi', surname: 'Juliet', transHDay: 10, balReg: 20, payment1: null, payment2: 80, payment3: null, total: null },
  { number: 10, name: 'Mudzviti', surname: 'Andrew', transHDay: -25, balReg: null, payment1: null, payment2: null, payment3: null, total: null },
  { number: 11, name: 'Mushonga', surname: 'Thandeka', transHDay: null, balReg: 20, payment1: null, payment2: 20, payment3: null, total: null },
  { number: 12, name: 'Mutonzi', surname: 'Nelisha', transHDay: null, balReg: 100, payment1: null, payment2: null, payment3: null, total: 100 },
  { number: 13, name: 'Vainet', surname: 'Nigel', transHDay: null, balReg: 50, payment1: null, payment2: 50, payment3: null, total: 100 },
  { number: 14, name: 'Mudewairi', surname: '', transHDay: null, balReg: 100, payment1: null, payment2: null, payment3: null, total: 100 },
  { number: 15, name: 'Mashati', surname: 'Sharon', transHDay: null, balReg: -5, payment1: null, payment2: null, payment3: null, total: null },
  { number: 16, name: 'Matsheza', surname: 'Shanice', transHDay: 10, balReg: 40, payment1: null, payment2: 50, payment3: 10, total: 100 },
  { number: 17, name: 'Kasunungura', surname: 'Mitchelle', transHDay: null, balReg: 100, payment1: null, payment2: null, payment3: null, total: 100 },
  { number: 18, name: 'Majinjiwa', surname: 'Brayden', transHDay: null, balReg: 100, payment1: null, payment2: null, payment3: null, total: 100 },
  { number: 19, name: 'Chatiza', surname: 'Shyleen', transHDay: null, balReg: 20, payment1: null, payment2: 50, payment3: null, total: null },
  { number: 20, name: 'Hlebo', surname: 'Anotidaishe', transHDay: null, balReg: -10, payment1: null, payment2: null, payment3: null, total: null },
  { number: 21, name: 'Nyaude', surname: 'Junior', transHDay: null, balReg: -70, payment1: null, payment2: null, payment3: null, total: null },
  { number: 22, name: 'Nhidza', surname: 'Jayden', transHDay: null, balReg: 60, payment1: null, payment2: null, payment3: null, total: null },
  { number: 24, name: 'Phiri', surname: 'Bianga', transHDay: null, balReg: -272, payment1: null, payment2: null, payment3: null, total: null },
  { number: 25, name: 'Gwaze', surname: 'Junior', transHDay: null, balReg: -80, payment1: null, payment2: null, payment3: null, total: null }
];

// Function to generate registration number based on existing pattern
// Pattern: R + 5 digits + 1 letter (e.g., R12345A, R05688P, R79290B)
async function generateRegNumber(name, surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 0;
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY CAST(SUBSTRING(RegNumber, 2, 5) AS UNSIGNED) DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  // Generate new number (increment from max)
  let newNumber = maxNumber + 1;
  let regNumber;
  let attempts = 0;
  
  // Keep trying until we find a unique one
  do {
    const numberStr = String(newNumber).padStart(5, '0');
    
    // Generate letter suffix based on surname first letter, fallback to name
    let letter = (surname && surname.trim()) ? surname.charAt(0).toUpperCase() : name.charAt(0).toUpperCase();
    
    // Ensure letter is A-Z
    if (!/[A-Z]/.test(letter)) {
      letter = 'A';
    }
    
    regNumber = `R${numberStr}${letter}`;
    newNumber++;
    attempts++;
    
    if (attempts > 100) {
      // Fallback: use random letter if we can't find unique
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      letter = letters[Math.floor(Math.random() * letters.length)];
      regNumber = `R${String(newNumber).padStart(5, '0')}${letter}`;
      break;
    }
  } while (existingNumbers.has(regNumber));
  
  return regNumber;
}

async function generateExcel() {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grade 7 Students');
  
  // Get existing registration numbers to avoid duplicates
  const existingNumbers = new Set();
  try {
    const [existing] = await pool.execute('SELECT RegNumber FROM students');
    existing.forEach(row => existingNumbers.add(row.RegNumber));
  } catch (error) {
    console.log('Could not fetch existing registration numbers');
  }
  
  // Set headers
  worksheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Surname', key: 'surname', width: 20 },
    { header: 'Registration Number', key: 'regNumber', width: 18 },
    { header: 'Class', key: 'class', width: 15 },
    { header: 'Balance', key: 'balance', width: 12 },
    { header: 'Total Payments', key: 'totalPayments', width: 15 }
  ];
  
  // Style header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Process each student
  for (const student of studentData) {
    // Calculate total payments
    const payment1 = student.payment1 || 0;
    const payment2 = student.payment2 || 0;
    const payment3 = student.payment3 || 0;
    const totalPayments = payment1 + payment2 + payment3;
    
    // Use provided total if available, otherwise use calculated
    const finalTotal = student.total !== null ? student.total : totalPayments;
    
    // Get balance (use balReg, default to 0 if null)
    const balance = student.balReg !== null ? student.balReg : 0;
    
    // Generate registration number
    const regNumber = await generateRegNumber(student.name, student.surname, existingNumbers);
    existingNumbers.add(regNumber);
    
    // Add row
    worksheet.addRow({
      name: student.name,
      surname: student.surname || '',
      regNumber: regNumber,
      class: 'Grade 7',
      balance: balance,
      totalPayments: finalTotal
    });
  }
  
  // Format number columns
  worksheet.getColumn('balance').numFmt = '#,##0.00';
  worksheet.getColumn('totalPayments').numFmt = '#,##0.00';
  
  // Center align headers
  worksheet.getRow(1).alignment = { horizontal: 'center', vertical: 'middle' };
  
  // Save file
  const filename = 'Grade7_Students_Data.xlsx';
  await workbook.xlsx.writeFile(filename);
  
  console.log(`✅ Excel file created: ${filename}`);
  console.log(`📊 Total students: ${studentData.length}`);
  console.log(`\n📋 Columns:`);
  console.log(`   - Name`);
  console.log(`   - Surname`);
  console.log(`   - Registration Number (auto-generated)`);
  console.log(`   - Class (Grade 7)`);
  console.log(`   - Balance (from Bal /REG column)`);
  console.log(`   - Total Payments (sum of Payment 1, 2, 3, or from TOTAL column)`);
  
  process.exit(0);
}

generateExcel().catch(error => {
  console.error('Error generating Excel:', error);
  process.exit(1);
});

