const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// All Grade 6 students with their data
const grade6Students = [
  { name: 'Chikomborero', surname: 'Chishiri', balance: -10.00, totalPayments: 110.00 },
  { name: 'Micheal', surname: 'Choga', balance: 0.00, totalPayments: 100.00 },
  { name: 'Livetti', surname: 'Divala', balance: 0.00, totalPayments: 100.00 },
  { name: 'Shantel', surname: 'Chiteve', balance: -50.00, totalPayments: 100.00 },
  { name: 'Shaine', surname: 'Majoni', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tatenda', surname: 'Makuwaro', balance: -10.00, totalPayments: 30.00 },
  { name: 'Nokutenda', surname: 'Manyanga', balance: 0.00, totalPayments: 90.00 },
  { name: 'Vanessa', surname: 'Machingauta', balance: 0.00, totalPayments: 75.00 },
  { name: 'Michele', surname: 'Munyanyi', balance: 0.00, totalPayments: 100.00 },
  { name: 'Z Aaron', surname: 'Mutetwa', balance: 0.00, totalPayments: 50.00 },
  { name: 'Tadiwanashe', surname: 'Nguruve', balance: 0.00, totalPayments: 100.00 },
  { name: 'Mable', surname: 'Paza', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tadiwanashe', surname: 'Seremani', balance: 0.00, totalPayments: 100.00 },
  { name: 'Savania', surname: 'Matekenya', balance: 0.00, totalPayments: 100.00 },
  { name: 'Meghan', surname: 'Jamali', balance: 0.00, totalPayments: 100.00 },
  { name: 'Takunda', surname: 'Taderera', balance: 0.00, totalPayments: 100.00 },
  { name: 'Mikel', surname: 'Mazuru', balance: 0.00, totalPayments: 100.00 },
  { name: 'Elmah', surname: 'Nhara', balance: 0.00, totalPayments: 55.00 },
  { name: 'clint', surname: 'Muchengwa', balance: 0.00, totalPayments: 140.00 },
  { name: 'Blessed', surname: 'Munjeri', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tinotenda', surname: 'Madiya', balance: 0.00, totalPayments: 80.00 },
  { name: 'Anesu', surname: 'Hamuhli', balance: 0.00, totalPayments: 90.00 },
  { name: 'Isaac', surname: 'Chimambo', balance: 0.00, totalPayments: 0.00 },
  { name: 'Rumbidzai', surname: 'Chiputura', balance: -50.00, totalPayments: 50.00 }
];

async function getStudentRegNumber(conn, name, surname) {
  const [students] = await conn.execute(
    'SELECT RegNumber FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
    [name, surname]
  );
  return students.length > 0 ? students[0].RegNumber : null;
}

async function getOrCreateJournal(conn, journalName, description) {
  // Try to find existing journal
  let [journals] = await conn.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', [journalName]);
  
  if (journals.length > 0) {
    return journals[0].id;
  }
  
  // Create new journal
  const [result] = await conn.execute(
    'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
    [journalName, description, 1]
  );
  
  return result.insertId;
}

async function completeGrade6Setup() {
  console.log('\n📚 COMPLETING GRADE 6 SETUP\n');
  console.log('='.repeat(70));
  
  const conn = await pool.getConnection();
  
  try {
    // Get Grade 6 class for Term 3 2025
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%Grade 6%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      throw new Error('Grade 6 class not found');
    }
    
    const grade6Class = classes[0];
    console.log(`\n✅ Found Grade 6 class: ${grade6Class.name} (ID: ${grade6Class.id})\n`);
    
    const academicYear = '2025';
    const term = 'Term 3';
    
    // Get or create journal
    const journalId = await getOrCreateJournal(conn, 'Fees Journal', 'Journal for fee-related transactions');
    console.log(`✅ Using journal ID: ${journalId}\n`);
    
    await conn.beginTransaction();
    
    let enrolled = 0;
    let balancesAdded = 0;
    let paymentsAdded = 0;
    
    // Process each student
    for (const student of grade6Students) {
      const regNumber = await getStudentRegNumber(conn, student.name, student.surname);
      
      if (!regNumber) {
        console.log(`⚠️  Student ${student.name} ${student.surname} not found, skipping...`);
        continue;
      }
      
      console.log(`\n📝 Processing: ${student.name} ${student.surname} (${regNumber})`);
      
      // Step 1: Enroll in Grade 6
      const [existingEnrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [regNumber, grade6Class.id]);
      
      if (existingEnrollment.length === 0) {
        await conn.execute(`
          INSERT INTO enrollments_gradelevel_classes (student_regnumber, gradelevel_class_id, status)
          VALUES (?, ?, 'active')
        `, [regNumber, grade6Class.id]);
        enrolled++;
        console.log(`   ✅ Enrolled in Grade 6`);
      } else {
        console.log(`   ⏭️  Already enrolled`);
      }
      
      // Step 2: Add outstanding balance if negative
      if (student.balance < 0) {
        const balanceAmount = Math.abs(student.balance);
        
        // Check if transaction already exists
        const [existingTx] = await conn.execute(`
          SELECT id FROM student_transactions 
          WHERE student_reg_number = ? 
          AND transaction_type = 'DEBIT' 
          AND description LIKE '%Outstanding Balance%'
          AND amount = ?
        `, [regNumber, balanceAmount]);
        
        if (existingTx.length === 0) {
          // Create DEBIT transaction for outstanding balance
          await StudentTransactionController.createTransactionHelper(
            regNumber,
            'DEBIT',
            balanceAmount,
            `Outstanding Balance - Grade 6`,
            {
              term: term,
              academic_year: academicYear,
              class_id: grade6Class.id,
              hostel_id: null,
              enrollment_id: null,
              created_by: 1
            }
          );
          
          balancesAdded++;
          console.log(`   ✅ Added outstanding balance: -$${balanceAmount.toFixed(2)}`);
        } else {
          console.log(`   ⏭️  Outstanding balance already exists`);
        }
      }
      
      // Step 3: Add payment if totalPayments > 0
      if (student.totalPayments > 0) {
        // Check if similar payment transaction already exists
        const [existingTx] = await conn.execute(`
          SELECT id FROM student_transactions 
          WHERE student_reg_number = ? 
          AND transaction_type = 'CREDIT' 
          AND description LIKE '%Payment - Grade 6%'
          AND amount = ?
        `, [regNumber, student.totalPayments]);
        
        if (existingTx.length === 0) {
          // Create CREDIT transaction for payment
          await StudentTransactionController.createTransactionHelper(
            regNumber,
            'CREDIT',
            student.totalPayments,
            `Payment - Grade 6 - Term 3 2025`,
            {
              term: term,
              academic_year: academicYear,
              class_id: grade6Class.id,
              hostel_id: null,
              enrollment_id: null,
              created_by: 1
            }
          );
          
          paymentsAdded++;
          console.log(`   ✅ Added payment: $${student.totalPayments.toFixed(2)}`);
        } else {
          console.log(`   ⏭️  Payment already exists`);
        }
      }
    }
    
    await conn.commit();
    
    console.log('\n' + '='.repeat(70));
    console.log('\n✅ GRADE 6 SETUP COMPLETED!\n');
    console.log(`📊 Summary:`);
    console.log(`   Students enrolled: ${enrolled}`);
    console.log(`   Outstanding balances added: ${balancesAdded}`);
    console.log(`   Payments added: ${paymentsAdded}`);
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error completing Grade 6 setup:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

completeGrade6Setup();

