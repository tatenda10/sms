const { pool } = require('../config/database');

async function checkTransactionsTable() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking transactions table structure...');
    
    const [columns] = await connection.execute('DESCRIBE transactions');
    
    console.log('\n📋 Current transactions table structure:');
    console.log('┌─────────────────────┬─────────────┬──────┬─────┬─────────┬─────┐');
    console.log('│ Field               │ Type        │ Null │ Key │ Default │ Extra│');
    console.log('├─────────────────────┼─────────────┼──────┼─────┼─────────┼─────┤');
    
    columns.forEach(col => {
      const field = col.Field.padEnd(19);
      const type = col.Type.padEnd(11);
      const nullAllowed = col.Null.padEnd(4);
      const key = (col.Key || '').padEnd(3);
      const defaultVal = (col.Default || '').padEnd(7);
      const extra = col.Extra || '';
      
      console.log(`│ ${field} │ ${type} │ ${nullAllowed} │ ${key} │ ${defaultVal} │ ${extra} │`);
    });
    
    console.log('└─────────────────────┴─────────────┴──────┴─────┴─────────┴─────┘');
    
    // Check for required columns for transport payments
    const requiredColumns = ['transaction_date', 'transaction_type', 'amount', 'currency', 'description', 'reference_number', 'created_by', 'journal_entry_id'];
    const missingColumns = [];
    const existingColumns = [];
    
    requiredColumns.forEach(reqCol => {
      const found = columns.find(col => col.Field === reqCol);
      if (found) {
        existingColumns.push(reqCol);
      } else {
        missingColumns.push(reqCol);
      }
    });
    
    console.log('\n🎯 Column analysis for transport payments:');
    console.log('   ✅ Existing columns:');
    existingColumns.forEach(col => {
      console.log(`      • ${col}`);
    });
    
    if (missingColumns.length > 0) {
      console.log('   ❌ Missing columns:');
      missingColumns.forEach(col => {
        console.log(`      • ${col}`);
      });
    }
    
  } catch (error) {
    console.error('\n❌ Error checking transactions table:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkTransactionsTable()
    .then(() => {
      console.log('\n✅ Transactions table check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Transactions table check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkTransactionsTable;
