const { pool } = require('./config/database');

async function checkGrade4ActualRegNumbers() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ACTUAL REGISTRATION NUMBERS IN DATABASE FOR GRADE 4\n');
    console.log('='.repeat(70));
    
    // Get all Grade 4 students from database
    const [students] = await conn.execute(`
      SELECT DISTINCT s.RegNumber, s.Name, s.Surname,
             (SELECT current_balance FROM student_balances WHERE student_reg_number = s.RegNumber) as balance
      FROM students s
      INNER JOIN enrollments_gradelevel_classes e ON s.RegNumber = e.student_regnumber
      INNER JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
      WHERE gc.id = 25 AND e.status = 'active'
      ORDER BY s.RegNumber
    `);
    
    console.log(`\n📊 Total Grade 4 students in database: ${students.length}\n`);
    
    // Group by registration number to find duplicates
    const regNumberMap = {};
    students.forEach(student => {
      if (!regNumberMap[student.RegNumber]) {
        regNumberMap[student.RegNumber] = [];
      }
      regNumberMap[student.RegNumber].push(student);
    });
    
    // Find duplicates
    const duplicates = [];
    const unique = [];
    
    for (const [regNumber, studentList] of Object.entries(regNumberMap)) {
      if (studentList.length > 1) {
        duplicates.push({ regNumber, students: studentList });
      } else {
        unique.push(studentList[0]);
      }
    }
    
    console.log(`✅ Unique registration numbers: ${unique.length}`);
    console.log(`⚠️  Duplicate registration numbers: ${duplicates.length}\n`);
    
    if (duplicates.length > 0) {
      console.log('🔴 DUPLICATE REGISTRATION NUMBERS FOUND IN DATABASE:\n');
      duplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((student, sIdx) => {
          const balance = parseFloat(student.balance || 0);
          console.log(`   ${sIdx + 1}. ${student.Name} ${student.Surname} - Balance: $${balance.toFixed(2)}`);
        });
      });
    }
    
    // Show all students
    console.log(`\n\n📋 ALL GRADE 4 STUDENTS IN DATABASE:\n`);
    console.log('-'.repeat(70));
    students.forEach((student, idx) => {
      const balance = parseFloat(student.balance || 0);
      const balanceStr = balance < 0 ? `-$${Math.abs(balance).toFixed(2)}` : `$${balance.toFixed(2)}`;
      console.log(`${String(idx + 1).padStart(3)}. ${student.Name.padEnd(20)} ${student.Surname.padEnd(25)} ${student.RegNumber.padEnd(12)} ${balanceStr}`);
    });
    
    console.log('\n' + '='.repeat(70));
    console.log(`\n📊 Summary:`);
    console.log(`   Total students: ${students.length}`);
    console.log(`   Unique reg numbers: ${unique.length}`);
    console.log(`   Duplicate reg numbers: ${duplicates.length}`);
    
  } catch (error) {
    console.error('Error checking Grade 4 students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkGrade4ActualRegNumbers();

