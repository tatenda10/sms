const mysql = require('mysql2/promise');
require('dotenv').config();

async function testConnection() {
  try {
    console.log('🔍 Testing DigitalOcean database connection...');
    
    // Log environment variables (without password)
    console.log('Environment variables:');
    console.log('DB_HOST:', process.env.DB_HOST || 'NOT SET');
    console.log('DB_USER:', process.env.DB_USER || 'NOT SET');
    console.log('DB_PASSWORD:', process.env.DB_PASSWORD ? '***SET***' : 'NOT SET');
    console.log('DB_NAME:', process.env.DB_NAME || 'NOT SET');
    console.log('DB_PORT:', process.env.DB_PORT || 'NOT SET');
    console.log('SSL_MODE:', process.env.SSL_MODE || 'NOT SET');
    
    const dbConfig = {
      host: process.env.DB_HOST || 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
      user: process.env.DB_USER || 'doadmin',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'sms',
      port: process.env.DB_PORT || 25060,
      ssl: process.env.SSL_MODE === 'REQUIRED' ? { rejectUnauthorized: false } : false,
      charset: 'utf8mb4'
    };
    
    console.log('\n🔧 Database Config:');
    console.log('Host:', dbConfig.host);
    console.log('User:', dbConfig.user);
    console.log('Database:', dbConfig.database);
    console.log('Port:', dbConfig.port);
    console.log('SSL:', dbConfig.ssl);
    
    console.log('\n🔌 Attempting connection...');
    const connection = await mysql.createConnection(dbConfig);
    
    console.log('✅ Connection successful!');
    
    // Test a simple query
    const [rows] = await connection.execute('SELECT 1 as test');
    console.log('✅ Query test successful:', rows);
    
    await connection.end();
    console.log('✅ Connection closed successfully');
    
  } catch (error) {
    console.error('❌ Connection failed:');
    console.error('Error code:', error.code);
    console.error('Error message:', error.message);
    console.error('Full error:', error);
    
    if (error.code === 'ECONNREFUSED') {
      console.log('\n💡 Possible solutions:');
      console.log('1. Check if the password is set in .env file');
      console.log('2. Verify the host and port are correct');
      console.log('3. Check if the database server is running');
      console.log('4. Verify firewall/network settings');
    }
  }
}

testConnection();