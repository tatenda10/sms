const { pool } = require('../config/database');

async function testIncomeStatementAPI() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing Income Statement API endpoint...');
    
    // Test the exact same query that the API endpoint uses
    const startDate = '2025-09-01';
    const endDate = '2025-09-30';
    
    console.log(`\n📅 Testing period: ${startDate} to ${endDate} (September 2025)`);
    
    // Test revenue query
    console.log('\n💰 Testing Revenue Query...');
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [revenue] = await connection.execute(revenueQuery, [startDate, endDate]);
    
    console.log(`   ✅ Found ${revenue.length} revenue accounts:`);
    revenue.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💰' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Test expense query
    console.log('\n💸 Testing Expense Query...');
    const expenseQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.debit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Expense' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [expenses] = await connection.execute(expenseQuery, [startDate, endDate]);
    
    console.log(`   ✅ Found ${expenses.length} expense accounts:`);
    expenses.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💸' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Calculate totals
    const totalRevenue = revenue.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const netIncome = totalRevenue - totalExpenses;
    
    console.log(`\n📊 Summary:`);
    console.log(`   • Total Revenue: $${totalRevenue.toFixed(2)}`);
    console.log(`   • Total Expenses: $${totalExpenses.toFixed(2)}`);
    console.log(`   • Net Income: $${netIncome.toFixed(2)}`);
    
    // Simulate the API response structure
    const apiResponse = {
      revenue: revenue,
      expenses: expenses,
      totals: {
        total_revenue: totalRevenue,
        total_expenses: totalExpenses,
        net_income: netIncome
      }
    };
    
    console.log(`\n🔍 API Response Structure:`);
    console.log(`   • revenue.length: ${apiResponse.revenue.length}`);
    console.log(`   • expenses.length: ${apiResponse.expenses.length}`);
    console.log(`   • revenue[0]: ${apiResponse.revenue[0] ? JSON.stringify(apiResponse.revenue[0]) : 'null'}`);
    console.log(`   • expenses[0]: ${apiResponse.expenses[0] ? JSON.stringify(apiResponse.expenses[0]) : 'null'}`);
    
    if (expenses.length === 0) {
      console.log('\n❌ PROBLEM: No expense accounts returned by the query!');
    } else {
      console.log('\n✅ SUCCESS: Expense accounts are being returned by the backend!');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing income statement API:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testIncomeStatementAPI()
    .then(() => {
      console.log('\n✅ Income statement API test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Income statement API test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testIncomeStatementAPI;
