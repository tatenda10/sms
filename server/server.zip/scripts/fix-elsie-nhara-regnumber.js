const { pool } = require('./config/database');

async function fixElsieNharaRegNumber() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 FIXING ELSIE NHARA REGISTRATION NUMBER\n');
    console.log('='.repeat(70));
    
    await conn.beginTransaction();
    
    // Find Elsie Nhara
    const [elsie] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
      ['Elsie', 'Nhara']
    );
    
    if (elsie.length === 0) {
      console.log('❌ Elsie Nhara not found in database');
      return;
    }
    
    console.log(`Found: ${elsie[0].Name} ${elsie[0].Surname} with reg number: ${elsie[0].RegNumber}`);
    
    // Check if R00010N is used by others
    const [duplicates] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
      [elsie[0].RegNumber]
    );
    
    if (duplicates.length > 1) {
      console.log(`\n⚠️  Reg number ${elsie[0].RegNumber} is used by ${duplicates.length} students:`);
      duplicates.forEach((s, idx) => {
        console.log(`   ${idx + 1}. ${s.Name} ${s.Surname}`);
      });
      
      // Generate new unique reg number
      const [existing] = await conn.execute(
        "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY CAST(SUBSTRING(RegNumber, 2, 5) AS UNSIGNED) DESC LIMIT 1"
      );
      
      let maxNumber = 0;
      if (existing.length > 0) {
        const lastReg = existing[0].RegNumber;
        const numberPart = parseInt(lastReg.substring(1, 6));
        maxNumber = numberPart;
      }
      
      const newNumber = maxNumber + 1;
      const numberStr = String(newNumber).padStart(5, '0');
      const letter = 'N'; // Based on surname Nhara
      const newRegNumber = `R${numberStr}${letter}`;
      
      console.log(`\n🔄 Assigning new reg number: ${newRegNumber}`);
      
      // Update students table (this will cascade to related tables)
      await conn.execute(
        'UPDATE students SET RegNumber = ? WHERE RegNumber = ? AND LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [newRegNumber, elsie[0].RegNumber, 'Elsie', 'Nhara']
      );
      
      console.log(`✅ Updated Elsie Nhara: ${elsie[0].RegNumber} → ${newRegNumber}`);
    } else {
      console.log(`✅ Reg number ${elsie[0].RegNumber} is unique`);
    }
    
    await conn.commit();
    
    console.log('\n✅ Fix completed!');
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error fixing reg number:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixElsieNharaRegNumber();

