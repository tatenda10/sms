const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');

async function fixDuplicateTransactionsAndBalance() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔧 Fixing duplicate transactions and balance for student: ${studentRegNumber}\n`);
    
    // Find duplicate transactions
    const [duplicates] = await conn.execute(
      `SELECT 
        st1.id as id1,
        st2.id as id2,
        st1.description,
        st1.amount,
        st1.created_at
       FROM student_transactions st1
       INNER JOIN student_transactions st2 
         ON st1.student_reg_number = st2.student_reg_number
         AND st1.transaction_type = st2.transaction_type
         AND st1.amount = st2.amount
         AND st1.description = st2.description
         AND st1.id < st2.id
       WHERE st1.student_reg_number = ?
       ORDER BY st1.created_at DESC`,
      [studentRegNumber]
    );
    
    console.log(`Found ${duplicates.length} duplicate transaction pair(s):\n`);
    
    for (const dup of duplicates) {
      console.log(`Removing duplicate transaction ID ${dup.id2} (keeping ${dup.id1})`);
      console.log(`   Description: ${dup.description}`);
      console.log(`   Amount: $${dup.amount}`);
      
      // Delete the duplicate transaction (the newer one)
      await StudentBalanceService.updateBalanceOnTransactionDelete(
        studentRegNumber,
        'CREDIT',
        dup.amount,
        conn
      );
      
      await conn.execute(
        'DELETE FROM student_transactions WHERE id = ?',
        [dup.id2]
      );
      
      console.log(`   ✅ Deleted duplicate transaction ${dup.id2}\n`);
    }
    
    // Recalculate balance
    console.log('🔄 Recalculating balance...');
    const newBalance = await StudentBalanceService.recalculateBalance(studentRegNumber, conn);
    console.log(`✅ New balance: $${newBalance.toFixed(2)}\n`);
    
    // Verify
    const [balanceRecord] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    if (balanceRecord.length > 0) {
      const finalBalance = parseFloat(balanceRecord[0].current_balance);
      console.log(`📋 Final balance: $${finalBalance.toFixed(2)}`);
      
      // Calculate expected balance from transactions
      const [transactions] = await conn.execute(
        `SELECT transaction_type, amount FROM student_transactions WHERE student_reg_number = ?`,
        [studentRegNumber]
      );
      
      let calculatedBalance = 0;
      transactions.forEach(tx => {
        const amount = parseFloat(tx.amount);
        if (tx.transaction_type === 'CREDIT') {
          calculatedBalance += amount;
        } else {
          calculatedBalance -= amount;
        }
      });
      
      console.log(`📊 Calculated balance: $${calculatedBalance.toFixed(2)}`);
      
      if (Math.abs(finalBalance - calculatedBalance) < 0.01) {
        console.log('✅ Balance is correct!');
      } else {
        console.log(`⚠️  Balance mismatch: $${Math.abs(finalBalance - calculatedBalance).toFixed(2)}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixDuplicateTransactionsAndBalance();

