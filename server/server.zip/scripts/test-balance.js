const { pool } = require('../config/database');

async function testBalance() {
    try {
        // Check if there are any students
        const [students] = await pool.execute('SELECT COUNT(*) as count FROM students');
        console.log('Total students:', students[0].count);
        
        // Check if there are any student transactions
        const [transactions] = await pool.execute('SELECT COUNT(*) as count FROM student_transactions');
        console.log('Total transactions:', transactions[0].count);
        
        // Check if there are any student balances
        const [balances] = await pool.execute('SELECT COUNT(*) as count FROM student_balances');
        console.log('Total balance records:', balances[0].count);
        
        // Show some sample data
        const [sampleStudents] = await pool.execute('SELECT student_reg_number FROM students LIMIT 5');
        console.log('Sample students:', sampleStudents.map(s => s.student_reg_number));
        
        if (sampleStudents.length > 0) {
            const studentReg = sampleStudents[0].student_reg_number;
            console.log(`\nChecking student: ${studentReg}`);
            
            // Check their transactions
            const [studentTransactions] = await pool.execute(
                'SELECT * FROM student_transactions WHERE student_reg_number = ?',
                [studentReg]
            );
            console.log(`Transactions for ${studentReg}:`, studentTransactions.length);
            
            // Check their balance
            const [studentBalance] = await pool.execute(
                'SELECT * FROM student_balances WHERE student_reg_number = ?',
                [studentReg]
            );
            console.log(`Balance for ${studentReg}:`, studentBalance[0] || 'No balance record');
        }
        
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await pool.end();
    }
}

testBalance();
