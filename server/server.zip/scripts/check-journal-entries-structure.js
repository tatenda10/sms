const { pool } = require('../config/database');

async function checkJournalEntriesStructure() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking journal_entries table structure...');
    
    // Get table structure
    const [columns] = await connection.execute('DESCRIBE journal_entries');
    
    console.log('\n📋 Current journal_entries table structure:');
    console.log('┌─────────────────────┬─────────────┬──────┬─────┬─────────┬─────┐');
    console.log('│ Field               │ Type        │ Null │ Key │ Default │ Extra│');
    console.log('├─────────────────────┼─────────────┼──────┼─────┼─────────┼─────┤');
    
    columns.forEach(col => {
      const field = col.Field.padEnd(19);
      const type = col.Type.padEnd(11);
      const nullAllowed = col.Null.padEnd(4);
      const key = (col.Key || '').padEnd(3);
      const defaultVal = (col.Default || '').padEnd(7);
      const extra = col.Extra || '';
      
      console.log(`│ ${field} │ ${type} │ ${nullAllowed} │ ${key} │ ${defaultVal} │ ${extra} │`);
    });
    
    console.log('└─────────────────────┴─────────────┴──────┴─────┴─────────┴─────┘');
    
    // Check for specific columns that the code expects
    const expectedColumns = ['reference_type', 'reference_id', 'entry_date', 'description', 'created_by'];
    const missingColumns = [];
    const existingColumns = [];
    
    expectedColumns.forEach(expectedCol => {
      const found = columns.find(col => col.Field === expectedCol);
      if (found) {
        existingColumns.push(expectedCol);
      } else {
        missingColumns.push(expectedCol);
      }
    });
    
    console.log('\n🎯 Column analysis:');
    console.log('   ✅ Existing columns:');
    existingColumns.forEach(col => {
      console.log(`      • ${col}`);
    });
    
    if (missingColumns.length > 0) {
      console.log('   ❌ Missing columns:');
      missingColumns.forEach(col => {
        console.log(`      • ${col}`);
      });
    }
    
    // Check for similar columns that might be used instead
    console.log('\n🔍 Looking for similar column names...');
    const allColumns = columns.map(col => col.Field);
    const similarColumns = {
      'reference_type': allColumns.filter(col => col.toLowerCase().includes('reference') && col.toLowerCase().includes('type')),
      'reference_id': allColumns.filter(col => col.toLowerCase().includes('reference') && col.toLowerCase().includes('id')),
      'entry_date': allColumns.filter(col => col.toLowerCase().includes('date')),
      'description': allColumns.filter(col => col.toLowerCase().includes('description') || col.toLowerCase().includes('desc')),
      'created_by': allColumns.filter(col => col.toLowerCase().includes('created') && col.toLowerCase().includes('by'))
    };
    
    Object.entries(similarColumns).forEach(([expected, similar]) => {
      if (similar.length > 0) {
        console.log(`   • ${expected}: Found similar columns: ${similar.join(', ')}`);
      }
    });
    
    // Check for indexes
    console.log('\n🔍 Checking indexes...');
    const [indexes] = await connection.execute('SHOW INDEX FROM journal_entries');
    
    if (indexes.length > 0) {
      console.log('\n📊 Current indexes:');
      indexes.forEach(index => {
        console.log(`   • ${index.Key_name}: ${index.Column_name} (${index.Non_unique ? 'Non-unique' : 'Unique'})`);
      });
    } else {
      console.log('\n📊 No indexes found');
    }
    
  } catch (error) {
    console.error('\n❌ Error checking journal_entries structure:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkJournalEntriesStructure()
    .then(() => {
      console.log('\n✅ Journal entries structure check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Journal entries structure check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkJournalEntriesStructure;
