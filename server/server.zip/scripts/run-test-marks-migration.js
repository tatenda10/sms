const fs = require('fs');
const path = require('path');
const { pool } = require('../config/database');

async function runTestMarksMigration() {
  try {
    console.log('🚀 Starting test marks table migration...');
    
    // Read the migration file
    const migrationPath = path.join(__dirname, '../migrations/create_test_marks_table.sql');
    const migrationSQL = fs.readFileSync(migrationPath, 'utf8');
    
    // Split by semicolon and execute each statement
    const statements = migrationSQL
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);
    
    for (const statement of statements) {
      if (statement.trim()) {
        console.log(`📝 Executing: ${statement.substring(0, 50)}...`);
        await pool.execute(statement);
      }
    }
    
    console.log('✅ Test marks table migration completed successfully!');
    
    // Test the table by inserting a sample record (optional)
    console.log('🧪 Testing table structure...');
    
    // Check if table exists
    const [tables] = await pool.execute(
      "SHOW TABLES LIKE 'test_marks'"
    );
    
    if (tables.length > 0) {
      console.log('✅ test_marks table created successfully');
      
      // Show table structure
      const [structure] = await pool.execute('DESCRIBE test_marks');
      console.log('📋 Table structure:');
      structure.forEach(column => {
        console.log(`  - ${column.Field}: ${column.Type} ${column.Null === 'NO' ? 'NOT NULL' : ''}`);
      });
    } else {
      console.log('❌ test_marks table was not created');
    }
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  } finally {
    // Close the connection
    await pool.end();
  }
}

// Run the migration
runTestMarksMigration();
