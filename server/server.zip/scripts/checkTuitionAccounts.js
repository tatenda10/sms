const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        const [accounts] = await conn.execute(
            `SELECT code, name, type, id 
             FROM chart_of_accounts 
             WHERE (code LIKE '%4000%' OR code LIKE '%4040%' OR name LIKE '%tuition%' OR name LIKE '%Tuition%') 
             AND is_active = TRUE 
             ORDER BY code`
        );
        
        console.log('Tuition-related Revenue accounts:');
        console.log(JSON.stringify(accounts, null, 2));
        
        // Also check what the enrollment controller is currently using
        console.log('\nCurrent enrollment controller uses:');
        console.log('- Code 4000: Tuition Revenue - Total');
        console.log('- Code 1100: Accounts Receivable - Tuition');
        
    } catch(e) {
        console.error(e);
    } finally {
        conn.release();
        process.exit();
    }
})();

