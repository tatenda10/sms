const axios = require('axios');

async function testDetailedSync() {
  try {
    console.log('🔍 Testing detailed sync with multiple tables...');
    
    // Test with multiple tables that might not exist
    const testData = {
      database_export: {
        test_table_1: {
          schema: 'CREATE TABLE `test_table_1` (`id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Test Record 1' },
            { id: 2, name: 'Test Record 2' }
          ],
          record_count: 2
        },
        test_table_2: {
          schema: 'CREATE TABLE `test_table_2` (`id` int(11) NOT NULL AUTO_INCREMENT, `value` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'value', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, value: 'Value 1' },
            { id: 2, value: 'Value 2' },
            { id: 3, value: 'Value 3' }
          ],
          record_count: 3
        }
      },
      timestamp: new Date().toISOString(),
      source: 'detailed_test'
    };
    
    console.log('📤 Sending detailed test data to server...');
    const syncResponse = await axios.post('https://server.learningladder.site/api/sync-full-db.php', testData, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    console.log('✅ Server response:', JSON.stringify(syncResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testDetailedSync();
