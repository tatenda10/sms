const { pool } = require('./config/database');

// Final corrected student data from the Excel
const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96904D', balance: -10 },
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96904N', balance: -20 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96904N', balance: -143 },
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96904N', balance: -150 },
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5 },
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96904N', balance: -210 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96904O', balance: -310 }
];

async function checkExistingStudents() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING FOR EXISTING STUDENTS IN SYSTEM\n');
    console.log('='.repeat(80));
    
    const existingStudents = [];
    const newStudents = [];
    
    for (const student of studentData) {
      let found = false;
      
      // First, try exact match by name and surname
      let [matches] = await conn.execute(
        `SELECT RegNumber, Name, Surname, DateOfBirth, Gender 
         FROM students 
         WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) 
         AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))`,
        [student.name, student.surname]
      );
      
      // If no exact match, try by registration number
      if (matches.length === 0) {
        [matches] = await conn.execute(
          `SELECT RegNumber, Name, Surname, DateOfBirth, Gender 
           FROM students 
           WHERE RegNumber = ?`,
          [student.regNumber]
        );
      }
      
      // If still no match, try partial name match (surname only or name only)
      if (matches.length === 0) {
        [matches] = await conn.execute(
          `SELECT RegNumber, Name, Surname, DateOfBirth, Gender 
           FROM students 
           WHERE LOWER(TRIM(Surname)) = LOWER(TRIM(?)) 
           AND (LOWER(TRIM(Name)) LIKE LOWER(TRIM(CONCAT('%', ?, '%'))) 
                OR LOWER(TRIM(Name)) LIKE LOWER(TRIM(CONCAT('%', ?, '%'))))`,
          [student.surname, student.name.split(' ')[0], student.name]
        );
      }
      
      if (matches.length > 0) {
        const existing = matches[0];
        existingStudents.push({
          ...student,
          existingRegNumber: existing.RegNumber,
          existingName: existing.Name,
          existingSurname: existing.Surname,
          dateOfBirth: existing.DateOfBirth,
          gender: existing.Gender,
          matchType: matches.length > 0 ? 'Found' : 'Not Found'
        });
        found = true;
      }
      
      if (!found) {
        newStudents.push(student);
      }
    }
    
    console.log(`\n✅ FOUND ${existingStudents.length} EXISTING STUDENTS:\n`);
    console.log('-'.repeat(80));
    
    for (const student of existingStudents) {
      const idx = existingStudents.indexOf(student) + 1;
      console.log(`\n${idx}. ${student.name} ${student.surname}`);
      console.log(`   📋 Excel Reg Number: ${student.regNumber}`);
      console.log(`   🆔 Existing Reg Number: ${student.existingRegNumber}`);
      console.log(`   📝 Existing Name: ${student.existingName} ${student.existingSurname}`);
      console.log(`   💰 Balance from Excel: $${student.balance.toFixed(2)}`);
      console.log(`   📅 Date of Birth: ${student.dateOfBirth || 'N/A'}`);
      console.log(`   👤 Gender: ${student.gender || 'N/A'}`);
      
      // Check current balance in system
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.existingRegNumber]
      );
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      console.log(`   💵 Current System Balance: $${currentBalance.toFixed(2)}`);
    }
    
    console.log(`\n\n🆕 NEW STUDENTS (${newStudents.length}):\n`);
    console.log('-'.repeat(80));
    
    if (newStudents.length > 0) {
      newStudents.forEach((student, idx) => {
        console.log(`${idx + 1}. ${student.name} ${student.surname} (${student.regNumber}) - Balance: $${student.balance.toFixed(2)}`);
      });
    } else {
      console.log('   No new students - all students already exist in system.');
    }
    
    console.log('\n' + '='.repeat(80));
    console.log(`\n📊 SUMMARY:`);
    console.log(`   Total in Excel: ${studentData.length}`);
    console.log(`   Already in System: ${existingStudents.length}`);
    console.log(`   New Students: ${newStudents.length}`);
    
    // Return the results
    return { existingStudents, newStudents };
    
  } catch (error) {
    console.error('Error checking existing students:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkExistingStudents();

