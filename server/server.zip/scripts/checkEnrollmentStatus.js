const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        // Total active enrollments
        const [total] = await conn.execute('SELECT COUNT(*) as count FROM enrollments_gradelevel_classes WHERE status = "active"');
        console.log(`Total active enrollments: ${total[0].count}`);
        
        // Enrollments with transactions
        const [withTransactions] = await conn.execute(`
            SELECT COUNT(DISTINCT e.id) as count 
            FROM enrollments_gradelevel_classes e
            JOIN student_transactions st ON st.enrollment_id = e.id
            WHERE e.status = 'active'
            AND st.transaction_type = 'DEBIT'
            AND st.description LIKE '%TUITION INVOICE%'
        `);
        console.log(`Enrollments with transactions: ${withTransactions[0].count}`);
        
        // Transactions missing journal entries
        const [missingJournal] = await conn.execute(`
            SELECT COUNT(*) as count 
            FROM student_transactions st
            JOIN enrollments_gradelevel_classes e ON st.enrollment_id = e.id
            WHERE e.status = 'active'
            AND st.transaction_type = 'DEBIT'
            AND st.description LIKE '%TUITION INVOICE%'
            AND st.journal_entry_id IS NULL
        `);
        console.log(`Transactions missing journal entries: ${missingJournal[0].count}`);
        
        // Enrollments missing transactions
        const [missingTransactions] = await conn.execute(`
            SELECT COUNT(*) as count
            FROM enrollments_gradelevel_classes e
            WHERE e.status = 'active'
            AND NOT EXISTS (
                SELECT 1 FROM student_transactions st
                WHERE st.enrollment_id = e.id
                AND st.transaction_type = 'DEBIT'
                AND st.description LIKE '%TUITION INVOICE%'
            )
        `);
        console.log(`Enrollments missing transactions: ${missingTransactions[0].count}`);
        
        // Students with balance records
        const [withBalances] = await conn.execute('SELECT COUNT(*) as count FROM student_balances');
        console.log(`Students with balance records: ${withBalances[0].count}`);
        
    } catch(e) {
        console.error(e);
    } finally {
        conn.release();
        process.exit();
    }
})();

