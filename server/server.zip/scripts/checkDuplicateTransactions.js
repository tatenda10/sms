const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function checkDuplicateTransactions() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔍 Checking transactions for student: ${studentRegNumber}\n`);
    
    // Get all transactions
    const [transactions] = await conn.execute(
      `SELECT 
        id,
        transaction_type,
        amount,
        description,
        transaction_date,
        journal_entry_id,
        hostel_id,
        enrollment_id,
        created_at
       FROM student_transactions 
       WHERE student_reg_number = ?
       ORDER BY transaction_date DESC, created_at DESC`,
      [studentRegNumber]
    );
    
    console.log(`Found ${transactions.length} transactions:\n`);
    
    transactions.forEach((tx, index) => {
      console.log(`Transaction ${index + 1}:`);
      console.log(`   ID: ${tx.id}`);
      console.log(`   Type: ${tx.transaction_type}`);
      console.log(`   Amount: $${tx.amount}`);
      console.log(`   Description: ${tx.description}`);
      console.log(`   Date: ${tx.transaction_date}`);
      console.log(`   Journal Entry ID: ${tx.journal_entry_id || 'NULL'}`);
      console.log(`   Hostel ID: ${tx.hostel_id || 'NULL'}`);
      console.log(`   Enrollment ID: ${tx.enrollment_id || 'NULL'}`);
      console.log(`   Created At: ${tx.created_at}`);
      console.log('');
    });
    
    // Check for duplicates by description and date
    console.log('🔍 Checking for duplicates...\n');
    const duplicates = [];
    for (let i = 0; i < transactions.length; i++) {
      for (let j = i + 1; j < transactions.length; j++) {
        const tx1 = transactions[i];
        const tx2 = transactions[j];
        
        // Check if same type, amount, and similar description
        if (tx1.transaction_type === tx2.transaction_type &&
            Math.abs(parseFloat(tx1.amount) - parseFloat(tx2.amount)) < 0.01 &&
            tx1.description.toLowerCase().includes('boarding') &&
            tx2.description.toLowerCase().includes('boarding') &&
            Math.abs(new Date(tx1.transaction_date) - new Date(tx2.transaction_date)) < 86400000) { // Same day
          duplicates.push({ tx1, tx2 });
        }
      }
    }
    
    if (duplicates.length > 0) {
      console.log(`⚠️  Found ${duplicates.length} potential duplicate pairs:\n`);
      duplicates.forEach((dup, index) => {
        console.log(`Duplicate Pair ${index + 1}:`);
        console.log(`   Transaction 1: ID ${dup.tx1.id} - "${dup.tx1.description}"`);
        console.log(`   Transaction 2: ID ${dup.tx2.id} - "${dup.tx2.description}"`);
        console.log('');
      });
    } else {
      console.log('✅ No duplicates found');
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkDuplicateTransactions();

