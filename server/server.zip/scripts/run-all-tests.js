#!/usr/bin/env node

const ComprehensiveSystemTest = require('./comprehensive-system-test');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class TestRunner {
  constructor() {
    this.testResults = [];
    this.startTime = Date.now();
  }

  async runTest(testName, testFunction) {
    try {
      console.log(`\n🧪 Running: ${testName}`);
      const startTime = Date.now();
      await testFunction();
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      this.testResults.push({
        name: testName,
        status: 'PASSED',
        duration: duration
      });
      
      console.log(`✅ ${testName} - PASSED (${duration}ms)`);
    } catch (error) {
      this.testResults.push({
        name: testName,
        status: 'FAILED',
        error: error.message,
        duration: 0
      });
      
      console.log(`❌ ${testName} - FAILED: ${error.message}`);
    }
  }

  async runComprehensiveTest() {
    console.log('🚀 Starting Comprehensive System Test...');
    const tester = new ComprehensiveSystemTest();
    await tester.runAllTests();
  }

  async runIndividualTests() {
    console.log('\n🔍 Running Individual Module Tests...');
    
    // Test scripts to run
    const testScripts = [
      { name: 'Chart of Accounts Check', script: 'check-chart-of-accounts.js' },
      { name: 'Income Statement All Accounts', script: 'test-income-statement-all-accounts.js' },
      { name: 'Monthly Income Statement API', script: 'test-monthly-income-statement-api.js' },
      { name: 'Student Financial Record Fix', script: 'test-student-financial-record-fix.js' },
      { name: 'Transport Payments Test', script: 'test-transport-payments.js' },
      { name: 'Student Statement Endpoint', script: 'test-student-statement-endpoint.js' }
    ];

    for (const test of testScripts) {
      await this.runTest(test.name, () => {
        const scriptPath = path.join(__dirname, test.script);
        if (fs.existsSync(scriptPath)) {
          execSync(`node ${scriptPath}`, { stdio: 'pipe' });
        } else {
          throw new Error(`Test script not found: ${test.script}`);
        }
      });
    }
  }

  async runDatabaseTests() {
    console.log('\n🗄️ Running Database Tests...');
    
    await this.runTest('Database Connection', async () => {
      const { pool } = require('../config/database');
      const connection = await pool.getConnection();
      const [rows] = await connection.execute('SELECT 1 as test');
      connection.release();
      if (rows[0].test !== 1) throw new Error('Database connection failed');
    });

    await this.runTest('Required Tables Exist', async () => {
      const { pool } = require('../config/database');
      const connection = await pool.getConnection();
      
      const requiredTables = [
        'students', 'student_transactions', 'student_balances',
        'transport_routes', 'transport_payments', 'student_transport_registrations',
        'inventory_categories', 'inventory_items', 'uniform_issues', 'uniform_payments',
        'chart_of_accounts', 'journal_entries', 'journal_entry_lines', 'accounting_periods'
      ];
      
      for (const table of requiredTables) {
        const [result] = await connection.execute(`SHOW TABLES LIKE '${table}'`);
        if (result.length === 0) throw new Error(`Required table '${table}' does not exist`);
      }
      
      connection.release();
    });

    await this.runTest('Transport Payments Schema', async () => {
      const { pool } = require('../config/database');
      const connection = await pool.getConnection();
      
      // Test route_id column exists
      const [columns] = await connection.execute(
        "SHOW COLUMNS FROM transport_payments LIKE 'route_id'"
      );
      if (columns.length === 0) throw new Error('transport_payments table missing route_id column');
      
      // Test transport_fee_id is nullable
      const [nullableCheck] = await connection.execute(
        "SELECT IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'transport_payments' AND COLUMN_NAME = 'transport_fee_id'"
      );
      if (nullableCheck.length === 0 || nullableCheck[0].IS_NULLABLE !== 'YES') {
        throw new Error('transport_fee_id column is not nullable');
      }
      
      connection.release();
    });
  }

  async runIntegrationTests() {
    console.log('\n🔗 Running Integration Tests...');
    
    await this.runTest('Student Transaction Integration', async () => {
      const { pool } = require('../config/database');
      const connection = await pool.getConnection();
      
      // Check that transport payments create student transactions
      const [transportPayments] = await connection.execute(
        'SELECT COUNT(*) as count FROM transport_payments'
      );
      
      const [transportStudentTransactions] = await connection.execute(
        'SELECT COUNT(*) as count FROM student_transactions WHERE description LIKE "%Transport Payment%"'
      );
      
      if (transportPayments[0].count > 0 && transportStudentTransactions[0].count === 0) {
        throw new Error('Transport payments not creating student transactions');
      }
      
      connection.release();
    });

    await this.runTest('Accounting Integration', async () => {
      const { pool } = require('../config/database');
      const connection = await pool.getConnection();
      
      // Check that journal entries exist
      const [journalEntries] = await connection.execute(
        'SELECT COUNT(*) as count FROM journal_entries'
      );
      
      if (journalEntries[0].count === 0) {
        throw new Error('No journal entries found - accounting integration not working');
      }
      
      connection.release();
    });
  }

  generateReport() {
    const endTime = Date.now();
    const totalDuration = endTime - this.startTime;
    
    const passed = this.testResults.filter(t => t.status === 'PASSED').length;
    const failed = this.testResults.filter(t => t.status === 'FAILED').length;
    const successRate = ((passed / (passed + failed)) * 100).toFixed(1);
    
    console.log('\n' + '='.repeat(80));
    console.log('📊 COMPREHENSIVE TEST REPORT');
    console.log('='.repeat(80));
    console.log(`🕐 Test Duration: ${(totalDuration / 1000).toFixed(2)} seconds`);
    console.log(`✅ Passed: ${passed}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`📈 Success Rate: ${successRate}%`);
    
    if (failed > 0) {
      console.log('\n❌ FAILED TESTS:');
      this.testResults
        .filter(test => test.status === 'FAILED')
        .forEach(test => {
          console.log(`   • ${test.name}: ${test.error}`);
        });
    }
    
    console.log('\n📋 ALL TEST RESULTS:');
    this.testResults.forEach(test => {
      const status = test.status === 'PASSED' ? '✅' : '❌';
      const duration = test.duration > 0 ? ` (${test.duration}ms)` : '';
      console.log(`   ${status} ${test.name}${duration}`);
    });
    
    console.log('\n🎯 SYSTEM STATUS:', failed === 0 ? 'ALL SYSTEMS OPERATIONAL ✅' : 'ISSUES DETECTED ⚠️');
    
    // Generate HTML report
    this.generateHTMLReport();
  }

  generateHTMLReport() {
    const passed = this.testResults.filter(t => t.status === 'PASSED').length;
    const failed = this.testResults.filter(t => t.status === 'FAILED').length;
    const successRate = ((passed / (passed + failed)) * 100).toFixed(1);
    
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>System Test Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background: #f5f5f5; padding: 20px; border-radius: 5px; }
        .passed { color: #28a745; }
        .failed { color: #dc3545; }
        .test-result { margin: 10px 0; padding: 10px; border-left: 4px solid #ddd; }
        .test-result.passed { border-left-color: #28a745; }
        .test-result.failed { border-left-color: #dc3545; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>School Management System - Test Report</h1>
        <p><strong>Test Date:</strong> ${new Date().toLocaleString()}</p>
        <p><strong>Success Rate:</strong> ${successRate}% (${passed} passed, ${failed} failed)</p>
    </div>
    
    <h2>Test Results Summary</h2>
    <table>
        <tr>
            <th>Test Name</th>
            <th>Status</th>
            <th>Duration</th>
            <th>Error (if failed)</th>
        </tr>
        ${this.testResults.map(test => `
        <tr class="${test.status.toLowerCase()}">
            <td>${test.name}</td>
            <td>${test.status === 'PASSED' ? '✅ PASSED' : '❌ FAILED'}</td>
            <td>${test.duration}ms</td>
            <td>${test.error || '-'}</td>
        </tr>
        `).join('')}
    </table>
    
    <h2>System Status</h2>
    <p><strong>Overall Status:</strong> ${failed === 0 ? 'ALL SYSTEMS OPERATIONAL ✅' : 'ISSUES DETECTED ⚠️'}</p>
    
    ${failed > 0 ? `
    <h2>Recommendations</h2>
    <ul>
        <li>Review failed tests and fix underlying issues</li>
        <li>Re-run tests after fixes are applied</li>
        <li>Consider additional testing for affected modules</li>
    </ul>
    ` : `
    <h2>Congratulations!</h2>
    <p>All tests passed successfully. The system is ready for production use.</p>
    `}
</body>
</html>`;

    const reportPath = path.join(__dirname, '../test-reports');
    if (!fs.existsSync(reportPath)) {
      fs.mkdirSync(reportPath, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const reportFile = path.join(reportPath, `test-report-${timestamp}.html`);
    fs.writeFileSync(reportFile, html);
    
    console.log(`\n📄 HTML Report generated: ${reportFile}`);
  }

  async runAllTests() {
    console.log('🚀 Starting Complete System Test Suite...');
    console.log('='.repeat(80));
    
    try {
      await this.runDatabaseTests();
      await this.runIndividualTests();
      await this.runIntegrationTests();
      await this.runComprehensiveTest();
    } catch (error) {
      console.error('💥 Test suite failed:', error.message);
    }
    
    this.generateReport();
  }
}

// Run all tests if this script is executed directly
if (require.main === module) {
  const runner = new TestRunner();
  runner.runAllTests()
    .then(() => {
      console.log('\n✅ Complete test suite finished');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Test suite failed:', error.message);
      process.exit(1);
    });
}

module.exports = TestRunner;
