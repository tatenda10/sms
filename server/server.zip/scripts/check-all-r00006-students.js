const { pool } = require('./config/database');

async function checkAllR00006Students() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ALL STUDENTS WITH R00006 REGISTRATION NUMBERS\n');
    console.log('='.repeat(70));
    
    // Get all students with reg numbers starting with R00006
    const [students] = await conn.execute(`
      SELECT s.RegNumber, s.Name, s.Surname,
             (SELECT current_balance FROM student_balances WHERE student_reg_number = s.RegNumber) as balance,
             (SELECT COUNT(*) FROM enrollments_gradelevel_classes WHERE student_regnumber = s.RegNumber) as enrollment_count
      FROM students s
      WHERE s.RegNumber LIKE 'R00006%'
      ORDER BY s.RegNumber
    `);
    
    console.log(`\n📊 Total students with R00006 reg numbers: ${students.length}\n`);
    
    // Group by registration number to find duplicates
    const regNumberMap = {};
    students.forEach(student => {
      if (!regNumberMap[student.RegNumber]) {
        regNumberMap[student.RegNumber] = [];
      }
      regNumberMap[student.RegNumber].push(student);
    });
    
    // Find duplicates
    const duplicates = [];
    const unique = [];
    
    for (const [regNumber, studentList] of Object.entries(regNumberMap)) {
      if (studentList.length > 1) {
        duplicates.push({ regNumber, students: studentList });
      } else {
        unique.push(studentList[0]);
      }
    }
    
    console.log(`✅ Unique registration numbers: ${unique.length}`);
    console.log(`⚠️  Duplicate registration numbers: ${duplicates.length}\n`);
    
    if (duplicates.length > 0) {
      console.log('🔴 DUPLICATE REGISTRATION NUMBERS FOUND:\n');
      duplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((student, sIdx) => {
          const balance = parseFloat(student.balance || 0);
          console.log(`   ${sIdx + 1}. ${student.Name} ${student.Surname} - Balance: $${balance.toFixed(2)} - Enrollments: ${student.enrollment_count}`);
        });
      });
    }
    
    // Show all students
    console.log(`\n\n📋 ALL STUDENTS WITH R00006 REGISTRATION NUMBERS:\n`);
    console.log('-'.repeat(70));
    students.forEach((student, idx) => {
      const balance = parseFloat(student.balance || 0);
      const balanceStr = balance < 0 ? `-$${Math.abs(balance).toFixed(2)}` : `$${balance.toFixed(2)}`;
      const enrolled = student.enrollment_count > 0 ? '✅ Enrolled' : '❌ Not Enrolled';
      console.log(`${String(idx + 1).padStart(3)}. ${student.Name.padEnd(20)} ${student.Surname.padEnd(20)} ${student.RegNumber.padEnd(12)} ${balanceStr.padEnd(12)} ${enrolled}`);
    });
    
    // Check which students from the Excel are missing
    const excelStudents = [
      { name: 'Chikomborero', surname: 'Chishiri', regNumber: 'R00006C' },
      { name: 'Micheal', surname: 'Choga', regNumber: 'R00006D' },
      { name: 'Livetti', surname: 'Divala', regNumber: 'R00006D' },
      { name: 'Shantel', surname: 'Chiteve', regNumber: 'R00006C' },
      { name: 'Shaine', surname: 'Majoni', regNumber: 'R00006M' },
      { name: 'Tatenda', surname: 'Makuwaro', regNumber: 'R00006N' },
      { name: 'Nokutenda', surname: 'Manyanga', regNumber: 'R00006N' },
      { name: 'Vanessa', surname: 'Machingauta', regNumber: 'R00006N' },
      { name: 'Michele', surname: 'Munyanyi', regNumber: 'R00006N' },
      { name: 'Z Aaron', surname: 'Mutetwa', regNumber: 'R00006N' },
      { name: 'Tadiwanashe', surname: 'Nguruve', regNumber: 'R00006N' },
      { name: 'Mable', surname: 'Paza', regNumber: 'R00006P' },
      { name: 'Tadiwanashe', surname: 'Seremani', regNumber: 'R00006S' },
      { name: 'Savania', surname: 'Matekenya', regNumber: 'R00006N' },
      { name: 'Meghan', surname: 'Jamali', regNumber: 'R00006J' },
      { name: 'Takunda', surname: 'Taderera', regNumber: 'R00006T' },
      { name: 'Mikel', surname: 'Mazuru', regNumber: 'R00006N' },
      { name: 'Elmah', surname: 'Nhara', regNumber: 'R00006O' },
      { name: 'clint', surname: 'Muchengwa', regNumber: 'R00006N' },
      { name: 'Blessed', surname: 'Munjeri', regNumber: 'R00006N' },
      { name: 'Tinotenda', surname: 'Madiya', regNumber: 'R00006N' },
      { name: 'Anesu', surname: 'Hamuhli', regNumber: 'R00006H' },
      { name: 'Isaac', surname: 'Chimambo', regNumber: 'R00006N' },
      { name: 'Rumbidzai', surname: 'Chiputura', regNumber: 'R00006C' }
    ];
    
    console.log(`\n\n📋 CHECKING EXCEL STUDENTS AGAINST DATABASE:\n`);
    console.log('-'.repeat(70));
    
    const missing = [];
    const found = [];
    const duplicateRegNumbers = [];
    
    for (const excelStudent of excelStudents) {
      // Check by reg number first
      const [byReg] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [excelStudent.regNumber]
      );
      
      if (byReg.length === 0) {
        // Check by name
        const [byName] = await conn.execute(
          'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
          [excelStudent.name, excelStudent.surname]
        );
        
        if (byName.length === 0) {
          missing.push(excelStudent);
        } else {
          found.push({ excel: excelStudent, db: byName[0], matchType: 'name' });
        }
      } else {
        // Check if name matches
        const dbStudent = byReg[0];
        if (dbStudent.Name.toLowerCase().trim() === excelStudent.name.toLowerCase().trim() &&
            dbStudent.Surname.toLowerCase().trim() === excelStudent.surname.toLowerCase().trim()) {
          found.push({ excel: excelStudent, db: dbStudent, matchType: 'exact' });
        } else {
          // Same reg number but different name - potential duplicate
          duplicateRegNumbers.push({ excel: excelStudent, db: dbStudent });
        }
      }
    }
    
    console.log(`\n✅ Found in database: ${found.length}`);
    console.log(`❌ Missing from database: ${missing.length}`);
    console.log(`⚠️  Duplicate reg numbers (different names): ${duplicateRegNumbers.length}\n`);
    
    if (missing.length > 0) {
      console.log('\n❌ MISSING STUDENTS:\n');
      missing.forEach((student, idx) => {
        console.log(`${idx + 1}. ${student.name} ${student.surname} (${student.regNumber})`);
      });
    }
    
    if (duplicateRegNumbers.length > 0) {
      console.log('\n⚠️  DUPLICATE REGISTRATION NUMBERS (Different Names):\n');
      duplicateRegNumbers.forEach((dup, idx) => {
        console.log(`${idx + 1}. Reg Number: ${dup.excel.regNumber}`);
        console.log(`   Excel: ${dup.excel.name} ${dup.excel.surname}`);
        console.log(`   Database: ${dup.db.Name} ${dup.db.Surname}`);
      });
    }
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkAllR00006Students();

