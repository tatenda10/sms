const { pool } = require('./config/database');

// All Grade 7 2024 students from the image
const grade72024Students = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340.00 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80.00 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96904D', balance: -10.00 },
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10.00 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10.00 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135.00 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10.00 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66.00 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96904N', balance: -20.00 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96904N', balance: -143.00 },
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35.00 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96904N', balance: -150.00 },
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120.00 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210.00 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5.00 },
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80.00 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96904N', balance: -210.00 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96904O', balance: -310.00 }
];

async function checkGrade72024Students() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING GRADE 7 2024 STUDENTS\n');
    console.log('='.repeat(70));
    console.log('Note: These students should NOT be enrolled in any class\n');
    
    // Check each student
    const results = [];
    const regNumberMap = {};
    const duplicateRegNumbers = [];
    
    for (const student of grade72024Students) {
      // Check by registration number
      const [byReg] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      // Check by name
      const [byName] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      // Check enrollment (should be none)
      const [enrollments] = await conn.execute(`
        SELECT e.*, gc.name as class_name
        FROM enrollments_gradelevel_classes e
        INNER JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
        WHERE e.student_regnumber = ? AND e.status = 'active'
      `, [student.regNumber]);
      
      // Get balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const foundByReg = byReg.length > 0;
      const foundByName = byName.length > 0;
      const enrolled = enrollments.length > 0;
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : null;
      
      // Check for duplicate reg numbers
      if (foundByReg) {
        if (!regNumberMap[student.regNumber]) {
          regNumberMap[student.regNumber] = [];
        }
        regNumberMap[student.regNumber].push({
          expected: student,
          actual: byReg[0]
        });
        
        // Check if name matches
        if (byReg[0].Name.toLowerCase().trim() !== student.name.toLowerCase().trim() ||
            byReg[0].Surname.toLowerCase().trim() !== student.surname.toLowerCase().trim()) {
          duplicateRegNumbers.push({
            regNumber: student.regNumber,
            expected: student,
            actual: byReg[0]
          });
        }
      }
      
      results.push({
        student,
        foundByReg,
        foundByName,
        enrolled,
        enrollments: enrollments,
        currentBalance,
        dbStudent: foundByReg ? byReg[0] : (foundByName ? byName[0] : null)
      });
    }
    
    // Find all duplicates
    const allDuplicates = [];
    for (const [regNumber, students] of Object.entries(regNumberMap)) {
      if (students.length > 1) {
        allDuplicates.push({
          regNumber,
          students: students.map(s => s.expected)
        });
      }
    }
    
    // Summary
    const found = results.filter(r => r.foundByReg || r.foundByName).length;
    const missing = results.filter(r => !r.foundByReg && !r.foundByName).length;
    const enrolledCount = results.filter(r => r.enrolled).length;
    const notEnrolled = results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).length;
    
    console.log(`📊 SUMMARY:\n`);
    console.log(`   Total students in list: ${grade72024Students.length}`);
    console.log(`   Found in database: ${found}`);
    console.log(`   Missing from database: ${missing}`);
    console.log(`   Enrolled in classes: ${enrolledCount} ⚠️`);
    console.log(`   Not enrolled (correct): ${notEnrolled}`);
    console.log(`   Duplicate reg numbers: ${allDuplicates.length}\n`);
    
    // Show duplicates
    if (allDuplicates.length > 0) {
      console.log(`\n⚠️  DUPLICATE REGISTRATION NUMBERS:\n`);
      allDuplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((s, sIdx) => {
          console.log(`   ${sIdx + 1}. ${s.name} ${s.surname} (Expected balance: ${s.balance < 0 ? `-$${Math.abs(s.balance).toFixed(2)}` : `$${s.balance.toFixed(2)}`})`);
        });
      });
    }
    
    // Show missing students
    if (missing > 0) {
      console.log(`\n❌ MISSING STUDENTS:\n`);
      results.filter(r => !r.foundByReg && !r.foundByName).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show enrolled students (should be none)
    if (enrolledCount > 0) {
      console.log(`\n⚠️  ENROLLED STUDENTS (should NOT be enrolled):\n`);
      results.filter(r => r.enrolled).forEach((r, idx) => {
        const classes = r.enrollments.map(e => e.class_name).join(', ');
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber}) - Enrolled in: ${classes}`);
      });
    }
    
    // Show all students with details
    console.log(`\n\n📋 ALL GRADE 7 2024 STUDENTS STATUS:\n`);
    console.log('-'.repeat(70));
    results.forEach((r, idx) => {
      const status = r.foundByReg ? '✅' : (r.foundByName ? '⚠️' : '❌');
      const enrolledStatus = r.enrolled ? '❌ ENROLLED' : '✅ Not Enrolled';
      const balanceStr = r.currentBalance !== null ? 
        (r.currentBalance < 0 ? `-$${Math.abs(r.currentBalance).toFixed(2)}` : `$${r.currentBalance.toFixed(2)}`) : 
        'N/A';
      const expectedBalance = r.student.balance < 0 ? `-$${Math.abs(r.student.balance).toFixed(2)}` : `$${r.student.balance.toFixed(2)}`;
      
      console.log(`${String(idx + 1).padStart(3)}. ${status} ${r.student.name.padEnd(20)} ${r.student.surname.padEnd(25)} ${r.student.regNumber.padEnd(10)} ${enrolledStatus.padEnd(15)} | Balance: ${balanceStr.padEnd(10)} (Expected: ${expectedBalance})`);
    });
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking Grade 7 2024 students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkGrade72024Students();

