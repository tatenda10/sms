const { pool } = require('../config/database');

/**
 * Fix duplicate/incorrect journal entries for boarding payments
 * 
 * Problem: Boarding payments are creating TWO journal entries:
 * 1. One that credits Revenue (4040) - INCORRECT
 * 2. One that credits Accounts Receivable (1100) - CORRECT
 * 
 * Solution: Remove the incorrect Revenue entries and keep only the Accounts Receivable ones
 */

async function fixBoardingPaymentJournals() {
  const conn = await pool.getConnection();
  
  try {
    console.log('🔧 Fixing boarding payment journal entries...\n');
    
    await conn.beginTransaction();

    // Find journal entries for boarding payments that incorrectly credit Revenue (4040)
    // These are created by StudentTransactionController and should be deleted
    const [problematicEntries] = await conn.execute(`
      SELECT DISTINCT je.id as journal_entry_id, je.description, je.entry_date, je.reference
      FROM journal_entries je
      INNER JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
      INNER JOIN chart_of_accounts coa ON jel.account_id = coa.id
      WHERE (je.description LIKE '%BOARDING PAYMENT%' OR je.description LIKE '%Boarding Fees Payment%')
        AND coa.code = '4040' 
        AND coa.type = 'Revenue'
        AND jel.credit > 0
        -- Exclude entries that also have Accounts Receivable (those are correct)
        AND je.id NOT IN (
          SELECT DISTINCT jel2.journal_entry_id
          FROM journal_entry_lines jel2
          INNER JOIN chart_of_accounts coa2 ON jel2.account_id = coa2.id
          WHERE coa2.code = '1100' AND coa2.type = 'Asset' AND jel2.credit > 0
        )
      ORDER BY je.entry_date, je.id
    `);

    console.log(`Found ${problematicEntries.length} incorrect boarding payment journal entries (crediting Revenue instead of AR)\n`);

    let deletedJournalEntries = 0;
    let deletedLines = 0;

    for (const entry of problematicEntries) {
      console.log(`Processing Journal Entry ${entry.journal_entry_id}: ${entry.description}`);
      console.log(`  Date: ${entry.entry_date}, Reference: ${entry.reference || 'N/A'}`);
      
      // Get all lines for this journal entry
      const [lines] = await conn.execute(`
        SELECT jel.id as line_id, jel.debit, jel.credit, coa.code, coa.name, coa.type
        FROM journal_entry_lines jel
        INNER JOIN chart_of_accounts coa ON jel.account_id = coa.id
        WHERE jel.journal_entry_id = ?
        ORDER BY jel.id
      `, [entry.journal_entry_id]);

      console.log(`  Lines:`);
      lines.forEach(line => {
        console.log(`    - Line ${line.line_id}: ${line.code} (${line.name}) - DR: ${line.debit}, CR: ${line.credit}`);
      });

      // Check if this is a duplicate entry (has Revenue but we know there's a correct AR entry elsewhere)
      // OR if this is the only entry and it's wrong
      const revenueLine = lines.find(l => l.code === '4040' && l.type === 'Revenue' && parseFloat(l.credit) > 0);
      const cashLine = lines.find(l => (l.code === '1000' || l.code === '1010') && parseFloat(l.debit) > 0);

      if (revenueLine && cashLine) {
        // This journal entry incorrectly credits Revenue instead of AR
        // Check if there's a corresponding correct entry (same date, same description)
        const [matchingEntries] = await conn.execute(`
          SELECT DISTINCT je.id
          FROM journal_entries je
          INNER JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
          INNER JOIN chart_of_accounts coa ON jel.account_id = coa.id
          WHERE je.description = ?
            AND je.entry_date = ?
            AND coa.code = '1100'
            AND coa.type = 'Asset'
            AND jel.credit > 0
            AND je.id != ?
        `, [entry.description, entry.entry_date, entry.journal_entry_id]);

        if (matchingEntries.length > 0) {
          // There's a correct entry, so we need to remove this incorrect one
          // But we can't delete due to foreign key constraints, so we'll:
          // 1. Set transaction journal_entry_id to NULL (if any)
          // 2. Delete the journal entry lines
          // 3. Update the journal entry description to mark it as deleted
          console.log(`  ✅ Found correct entry (${matchingEntries[0].id}), removing incorrect entry ${entry.journal_entry_id}`);
          
          // Update transactions to remove the reference
          await conn.execute(
            'UPDATE transactions SET journal_entry_id = NULL WHERE journal_entry_id = ?',
            [entry.journal_entry_id]
          );
          
          // Delete all journal entry lines
          await conn.execute(
            'DELETE FROM journal_entry_lines WHERE journal_entry_id = ?',
            [entry.journal_entry_id]
          );
          deletedLines += lines.length;
          
          // Delete the journal entry (now safe since no foreign key references)
          await conn.execute(
            'DELETE FROM journal_entries WHERE id = ?',
            [entry.journal_entry_id]
          );
          deletedJournalEntries++;
          console.log(`  ✅ Deleted incorrect journal entry ${entry.journal_entry_id}`);
        } else {
          // No matching correct entry, convert this one to AR instead
          console.log(`  ⚠️  No matching AR entry found, converting Revenue to Accounts Receivable`);
          
          const [arAccount] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1100', 'Asset']
          );
          
          if (arAccount.length > 0) {
            await conn.execute(
              'UPDATE journal_entry_lines SET account_id = ? WHERE id = ?',
              [arAccount[0].id, revenueLine.line_id]
            );
            console.log(`  ✅ Fixed: Changed Revenue to Accounts Receivable`);
            deletedJournalEntries++; // Count as fixed
          }
        }
      }
      
      console.log('');
    }

    await conn.commit();

    console.log('\n' + '='.repeat(60));
    console.log('SUMMARY');
    console.log('='.repeat(60));
    console.log(`Total problematic entries found: ${problematicEntries.length}`);
    console.log(`Journal entries deleted: ${deletedJournalEntries}`);
    console.log(`Journal entry lines deleted: ${deletedLines}`);
    console.log('\n✅ All boarding payment journal entries have been fixed!');
    console.log('✅ Payments now correctly: DEBIT Cash, CREDIT Accounts Receivable');
    console.log('\n⚠️  Note: You may need to recalculate account balances after this fix.');

  } catch (error) {
    await conn.rollback();
    console.error('❌ Error fixing journal entries:', error);
    throw error;
  } finally {
    conn.release();
  }
}

// Run the fix
fixBoardingPaymentJournals()
  .then(() => {
    console.log('\n✅ Script completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Script failed:', error);
    process.exit(1);
  });

