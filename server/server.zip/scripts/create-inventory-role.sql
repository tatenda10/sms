-- Add INVENTORY_MANAGER role to the system
INSERT INTO roles (name, description, created_at) 
VALUES ('INVENTORY_MANAGER', 'Can manage inventory items, categories, and uniform issues', NOW())
ON DUPLICATE KEY UPDATE 
    description = VALUES(description),
    updated_at = NOW();

-- Grant the role to existing admin users (optional)
-- Uncomment the following lines if you want to automatically assign this role to existing admin users
/*
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
CROSS JOIN roles r
WHERE u.username = 'admin' 
  AND r.name = 'INVENTORY_MANAGER'
  AND NOT EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = u.id AND ur.role_id = r.id
  );
*/
