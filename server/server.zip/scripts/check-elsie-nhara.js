const { pool } = require('./config/database');

async function checkElsieNhara() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ELSIE NHARA\n');
    console.log('='.repeat(70));
    
    // Find Elsie Nhara by name
    const [elsie] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
      ['Elsie', 'Nhara']
    );
    
    if (elsie.length === 0) {
      console.log('❌ Elsie Nhara not found in database');
      return;
    }
    
    console.log(`✅ Found: ${elsie[0].Name} ${elsie[0].Surname} - Reg Number: ${elsie[0].RegNumber}\n`);
    
    // Check balance
    const [balance] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [elsie[0].RegNumber]
    );
    
    const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : null;
    console.log(`Balance: ${currentBalance !== null ? (currentBalance < 0 ? `-$${Math.abs(currentBalance).toFixed(2)}` : `$${currentBalance.toFixed(2)}`) : 'N/A'}\n`);
    
    // Check enrollments
    const [enrollments] = await conn.execute(`
      SELECT e.*, gc.name as class_name
      FROM enrollments_gradelevel_classes e
      INNER JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
      WHERE e.student_regnumber = ?
    `, [elsie[0].RegNumber]);
    
    console.log(`Enrollments: ${enrollments.length}`);
    enrollments.forEach((enrollment, idx) => {
      console.log(`   ${idx + 1}. ${enrollment.class_name} - Status: ${enrollment.status}`);
    });
    
    // Check if enrolled in ECD A
    const [ecdaEnrollment] = await conn.execute(`
      SELECT e.*, gc.name as class_name
      FROM enrollments_gradelevel_classes e
      INNER JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
      WHERE e.student_regnumber = ? AND (gc.name LIKE '%ECD A%' OR gc.name LIKE '%ECD%')
    `, [elsie[0].RegNumber]);
    
    if (ecdaEnrollment.length === 0) {
      console.log('\n⚠️  Elsie Nhara is NOT enrolled in ECD A');
    } else {
      console.log(`\n✅ Elsie Nhara is enrolled in: ${ecdaEnrollment[0].class_name}`);
    }
    
  } catch (error) {
    console.error('Error checking Elsie Nhara:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkElsieNhara();

