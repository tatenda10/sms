const { pool } = require('./config/database');

async function fixStudentBalanceToDebt30() {
    const connection = await pool.getConnection();
    const studentRegNumber = 'R79290B';
    const adjustmentAmount = 60; // Need to apply DEBIT of 60 to go from +30 to -30
    
    try {
        await connection.beginTransaction();
        
        console.log(`🔍 Fixing balance for student ${studentRegNumber}...`);
        console.log(`   Applying DEBIT of ${adjustmentAmount} to change balance from +30 to -30`);
        
        // Get student details
        const [students] = await connection.execute(
            'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
            [studentRegNumber]
        );
        
        if (students.length === 0) {
            throw new Error(`Student with registration number ${studentRegNumber} not found`);
        }
        
        const student = students[0];
        console.log(`✅ Found student: ${student.Name} ${student.Surname}`);
        
        // Get current balance
        const [balanceRows] = await connection.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [studentRegNumber]
        );
        
        const currentBalance = balanceRows.length > 0 ? balanceRows[0].current_balance : 0;
        console.log(`📊 Current balance: ${currentBalance}`);
        
        const newBalance = currentBalance - adjustmentAmount; // DEBIT increases what student owes
        console.log(`📊 New balance will be: ${newBalance}`);
        
        // Get base currency
        const [currencies] = await connection.execute(
            'SELECT id FROM currencies WHERE base_currency = TRUE LIMIT 1'
        );
        const currency_id = currencies.length > 0 ? currencies[0].id : 1;
        
        // Get required accounts from Chart of Accounts
        const [[accountsReceivable]] = await connection.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ?',
            ['1100'] // Accounts Receivable - Tuition
        );
        
        const [[retainedEarnings]] = await connection.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ?',
            ['3998'] // Retained Earnings (Opening Balance Equity)
        );
        
        if (!accountsReceivable || !retainedEarnings) {
            throw new Error('Required accounts not found in Chart of Accounts (1100, 3998)');
        }
        
        // Get or create journal for opening balances
        let journal_id = 1;
        const [journalCheck] = await connection.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
        if (journalCheck.length === 0) {
            const [journalByName] = await connection.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
            if (journalByName.length > 0) {
                journal_id = journalByName[0].id;
            } else {
                const [anyJournal] = await connection.execute('SELECT id FROM journals LIMIT 1');
                if (anyJournal.length > 0) {
                    journal_id = anyJournal[0].id;
                } else {
                    const [journalResult] = await connection.execute(
                        'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
                        ['General Journal', 'Journal for general transactions including opening balances', 1]
                    );
                    journal_id = journalResult.insertId;
                }
            }
        }
        
        // Create Journal Entry for Correction (DEBIT to increase debt)
        const description = `CORRECTION: Opening Balance Adjustment - Setting balance to -30 (owing 30)`;
        const reference = `MBU-FIX-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        const journalDescription = `Opening Balance Correction: ${description} - ${reference} - Student: ${student.Name} ${student.Surname} (${student.RegNumber})`;
        
        const [journalResult] = await connection.execute(`
            INSERT INTO journal_entries (
                journal_id, entry_date, description, reference, 
                created_by, created_at, updated_at
            ) VALUES (?, NOW(), ?, ?, 1, NOW(), NOW())
        `, [journal_id, journalDescription, reference]);
        
        const journalEntryId = journalResult.insertId;
        console.log(`📝 Created journal entry: ${journalEntryId}`);
        
        // DEBIT adjustment: Increases what student owes
        // DEBIT: Accounts Receivable (Asset increases)
        // CREDIT: Retained Earnings (Equity increases to balance)
        
        await connection.execute(`
            INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, 0, ?)
        `, [journalEntryId, accountsReceivable.id, adjustmentAmount, 'Accounts Receivable - Opening Balance Correction']);
        
        await connection.execute(`
            INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, 0, ?, ?)
        `, [journalEntryId, retainedEarnings.id, adjustmentAmount, 'Retained Earnings - Opening Balance Correction']);
        
        // Update Account Balances
        const AccountBalanceService = require('./services/accountBalanceService');
        await AccountBalanceService.updateAccountBalancesFromJournalEntry(connection, journalEntryId, currency_id);
        
        // Update student balance
        if (balanceRows.length > 0) {
            await connection.execute(
                'UPDATE student_balances SET current_balance = ?, last_updated = NOW() WHERE student_reg_number = ?',
                [newBalance, studentRegNumber]
            );
        } else {
            await connection.execute(
                'INSERT INTO student_balances (student_reg_number, current_balance, last_updated) VALUES (?, ?, NOW())',
                [studentRegNumber, newBalance]
            );
        }
        console.log(`✅ Updated student balance to: ${newBalance}`);
        
        // Create student transaction record
        await connection.execute(`
            INSERT INTO student_transactions (
                student_reg_number, transaction_type, amount, description, 
                term, academic_year, transaction_date, created_by, created_at, updated_at
            ) VALUES (?, 'DEBIT', ?, ?, NULL, NULL, NOW(), 1, NOW(), NOW())
        `, [student.RegNumber, adjustmentAmount, description]);
        console.log(`✅ Created DEBIT transaction`);
        
        await connection.commit();
        console.log(`\n✅ SUCCESS! Balance corrected for ${student.Name} ${student.Surname} (${studentRegNumber})`);
        console.log(`   Balance changed from ${currentBalance} to ${newBalance}`);
        console.log(`   Journal Entry ID: ${journalEntryId}`);
        console.log(`   Reference: ${reference}`);
        
    } catch (error) {
        await connection.rollback();
        console.error('\n❌ ERROR:', error.message);
        console.error(error);
        process.exit(1);
    } finally {
        connection.release();
        process.exit(0);
    }
}

// Run the fix
fixStudentBalanceToDebt30();

