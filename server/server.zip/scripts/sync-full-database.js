const { pool } = require('../config/database');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

class FullDatabaseSync {
    constructor() {
        this.config = {
            // Export settings
            exportPath: './database-exports',
            batchSize: 1000, // Records per batch
            compressionEnabled: true
        };
    }

    // Main sync method - exports entire database and sends to cPanel
    async syncFullDatabase() {
        try {
            console.log('🚀 Starting full database export...');
            
            // Create export directory
            if (!fs.existsSync(this.config.exportPath)) {
                fs.mkdirSync(this.config.exportPath, { recursive: true });
            }
            
            // Get all table names
            const tables = await this.getAllTables();
            console.log(`📊 Found ${tables.length} tables to sync`);
            
            // Export all tables
            const exportData = {};
            let totalRecords = 0;
            
            for (const table of tables) {
                console.log(`📦 Exporting table: ${table}`);
                const tableData = await this.exportTable(table);
                exportData[table] = tableData;
                totalRecords += tableData.record_count;
                console.log(`✅ Exported ${tableData.record_count} records from ${table}`);
            }
            
            // Add metadata
            exportData._metadata = {
                export_timestamp: new Date().toISOString(),
                total_tables: tables.length,
                total_records: totalRecords,
                source: 'local_sms_full_sync'
            };
            
            // Save to file
            const filename = `full_database_${new Date().toISOString().split('T')[0]}.json`;
            const filepath = path.join(this.config.exportPath, filename);
            
            fs.writeFileSync(filepath, JSON.stringify(exportData, null, 2));
            console.log(`💾 Saved full database export to ${filename}`);
            
            console.log('🎉 Full database export completed successfully!');
            console.log(`📊 Total: ${totalRecords} records across ${tables.length} tables`);
            
        } catch (error) {
            console.error('❌ Full database sync failed:', error.message);
            throw error;
        }
    }

    // Get all table names from database
    async getAllTables() {
        const [tables] = await pool.execute(`
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        `);
        
        return tables.map(row => row.TABLE_NAME);
    }

    // Export a single table
    async exportTable(tableName) {
        try {
            // Get CREATE TABLE statement
            const [createTableResult] = await pool.execute(`SHOW CREATE TABLE \`${tableName}\``);
            const createTableSQL = createTableResult[0]['Create Table'];
            
            // Get table structure first
            const [columns] = await pool.execute(`
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = ?
                ORDER BY ORDINAL_POSITION
            `, [tableName]);
            
            // Get all data from table
            const [rows] = await pool.execute(`SELECT * FROM \`${tableName}\``);
            
            return {
                schema: createTableSQL,
                structure: columns,
                data: rows,
                record_count: rows.length
            };
            
        } catch (error) {
            console.error(`❌ Error exporting table ${tableName}:`, error.message);
            return {
                schema: null,
                structure: [],
                data: [],
                record_count: 0,
                error: error.message
            };
        }
    }

    // Send data to cPanel API
    async sendToCpanel(data) {
        try {
            console.log('📤 Sending data to cPanel...');
            
            const response = await axios.post(this.config.apiEndpoint, {
                database_export: data,
                timestamp: new Date().toISOString(),
                source: 'local_sms_full_sync'
            }, {
                headers: {
                    'Content-Type': 'application/json'
                },
                timeout: 300000, // 5 minutes timeout for large datasets
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            
            if (response.data.success) {
                console.log('✅ Data sent to cPanel successfully');
                console.log(`📊 Processed: ${response.data.processedTables} tables, ${response.data.processedRecords} records`);
            } else {
                throw new Error(response.data.message || 'cPanel sync failed');
            }
            
        } catch (error) {
            console.error('❌ Failed to send data to cPanel:', error.message);
            
            // Fallback: save to file for manual upload
            const fallbackFile = path.join(this.config.exportPath, 'cpanel_upload_ready.json');
            fs.writeFileSync(fallbackFile, JSON.stringify(data, null, 2));
            console.log(`💾 Saved to fallback file: ${fallbackFile}`);
            console.log('📋 You can manually upload this file to cPanel');
            
            throw error;
        }
    }

    // Alternative: Export to SQL dump format
    async exportToSQL() {
        try {
            console.log('📝 Creating SQL dump...');
            
            const tables = await this.getAllTables();
            let sqlDump = `-- SMS Database Dump\n-- Generated: ${new Date().toISOString()}\n\n`;
            sqlDump += `SET FOREIGN_KEY_CHECKS = 0;\n\n`;
            
            for (const table of tables) {
                console.log(`📦 Dumping table: ${table}`);
                
                // Get table structure
                const [createTable] = await pool.execute(`SHOW CREATE TABLE \`${table}\``);
                sqlDump += `-- Table structure for table \`${table}\`\n`;
                sqlDump += `DROP TABLE IF EXISTS \`${table}\`;\n`;
                sqlDump += `${createTable[0]['Create Table']};\n\n`;
                
                // Get table data
                const [rows] = await pool.execute(`SELECT * FROM \`${table}\``);
                
                if (rows.length > 0) {
                    sqlDump += `-- Data for table \`${table}\`\n`;
                    
                    // Get column names
                    const [columns] = await pool.execute(`SHOW COLUMNS FROM \`${table}\``);
                    const columnNames = columns.map(col => `\`${col.Field}\``).join(', ');
                    
                    // Insert data in batches
                    for (let i = 0; i < rows.length; i += this.config.batchSize) {
                        const batch = rows.slice(i, i + this.config.batchSize);
                        const values = batch.map(row => {
                            const rowValues = Object.values(row).map(value => {
                                if (value === null) return 'NULL';
                                if (typeof value === 'string') return `'${value.replace(/'/g, "''")}'`;
                                return value;
                            });
                            return `(${rowValues.join(', ')})`;
                        });
                        
                        sqlDump += `INSERT INTO \`${table}\` (${columnNames}) VALUES\n`;
                        sqlDump += values.join(',\n') + ';\n\n';
                    }
                }
            }
            
            sqlDump += `SET FOREIGN_KEY_CHECKS = 1;\n`;
            
            // Save SQL dump
            const filename = `sms_database_${new Date().toISOString().split('T')[0]}.sql`;
            const filepath = path.join(this.config.exportPath, filename);
            
            fs.writeFileSync(filepath, sqlDump);
            console.log(`💾 SQL dump saved to ${filename}`);
            
            return filepath;
            
        } catch (error) {
            console.error('❌ SQL export failed:', error.message);
            throw error;
        }
    }

    // Get database statistics
    async getDatabaseStats() {
        try {
            const tables = await this.getAllTables();
            const stats = {
                total_tables: tables.length,
                table_details: {},
                total_records: 0
            };
            
            for (const table of tables) {
                const [count] = await pool.execute(`SELECT COUNT(*) as count FROM \`${table}\``);
                const [size] = await pool.execute(`
                    SELECT 
                        ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
                    FROM information_schema.TABLES 
                    WHERE table_schema = DATABASE() 
                    AND table_name = ?
                `, [table]);
                
                stats.table_details[table] = {
                    record_count: count[0].count,
                    size_mb: size[0]?.size_mb || 0
                };
                stats.total_records += count[0].count;
            }
            
            return stats;
            
        } catch (error) {
            console.error('❌ Failed to get database stats:', error.message);
            throw error;
        }
    }
}

// CLI usage
if (require.main === module) {
    const sync = new FullDatabaseSync();
    
    const command = process.argv[2] || 'sync';
    
    switch (command) {
        case 'sync':
            sync.syncFullDatabase().catch(console.error);
            break;
            
        case 'sql':
            sync.exportToSQL().catch(console.error);
            break;
            
        case 'stats':
            sync.getDatabaseStats().then(stats => {
                console.log('📊 Database Statistics:');
                console.log(`Total Tables: ${stats.total_tables}`);
                console.log(`Total Records: ${stats.total_records}`);
                console.log('\nTable Details:');
                Object.entries(stats.table_details).forEach(([table, details]) => {
                    console.log(`  ${table}: ${details.record_count} records (${details.size_mb} MB)`);
                });
            }).catch(console.error);
            break;
            
        default:
            console.log('Usage: node sync-full-database.js [sync|sql|stats]');
            console.log('  sync  - Full database sync to cPanel (default)');
            console.log('  sql   - Export to SQL dump file');
            console.log('  stats - Show database statistics');
            break;
    }
}

module.exports = FullDatabaseSync;
