const { pool } = require('../config/database');

async function createAnnouncementsTable() {
  try {
    console.log('🚀 Creating announcements table...');
    
    const connection = await pool.getConnection();
    
    // Create announcements table
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS announcements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        announcement_type ENUM('student', 'employee') NOT NULL,
        target_type ENUM('all', 'specific') NOT NULL DEFAULT 'all',
        target_value VARCHAR(255) NULL COMMENT 'Class ID for students, Department ID for employees',
        priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
        status ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'draft',
        start_date DATETIME NULL,
        end_date DATETIME NULL,
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;
    
    await connection.execute(createTableSQL);
    console.log('✅ Announcements table created successfully');
    
    // Create indexes for better performance
    const indexes = [
      'CREATE INDEX idx_announcements_type ON announcements(announcement_type)',
      'CREATE INDEX idx_announcements_status ON announcements(status)',
      'CREATE INDEX idx_announcements_target ON announcements(target_type, target_value)',
      'CREATE INDEX idx_announcements_dates ON announcements(start_date, end_date)',
      'CREATE INDEX idx_announcements_created ON announcements(created_at)'
    ];
    
    for (const indexSQL of indexes) {
      try {
        await connection.execute(indexSQL);
        console.log(`✅ Index created: ${indexSQL.split(' ')[2]}`);
      } catch (error) {
        if (error.code === 'ER_DUP_KEYNAME') {
          console.log(`ℹ️  Index already exists: ${indexSQL.split(' ')[2]}`);
        } else {
          console.log(`⚠️  Index creation failed: ${error.message}`);
        }
      }
    }
    
    connection.release();
    console.log('🎉 Announcements table setup completed successfully!');
    
  } catch (error) {
    console.error('❌ Error creating announcements table:', error.message);
    throw error;
  }
}

// Run the script if executed directly
if (require.main === module) {
  createAnnouncementsTable()
    .then(() => {
      console.log('\n✅ Announcements table creation completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Announcements table creation failed:', error.message);
      process.exit(1);
    });
}

module.exports = createAnnouncementsTable;
