const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const fs = require('fs');

(async () => {
    const conn = await pool.getConnection();
    try {
        console.log('🔍 Checking for duplicate enrollments...\n');
        
        // Check for any duplicates first
        const [duplicates] = await conn.execute(`
            SELECT student_regnumber, COUNT(*) as count
            FROM enrollments_gradelevel_classes
            GROUP BY student_regnumber
            HAVING COUNT(*) > 1
        `);
        
        if (duplicates.length > 0) {
            console.log(`❌ Found ${duplicates.length} students with duplicate enrollments:`);
            duplicates.forEach(dup => {
                console.log(`   - ${dup.student_regnumber}: ${dup.count} enrollments`);
            });
            console.log('\n⚠️  Please remove duplicates before applying the constraint.');
            process.exit(1);
        }
        
        console.log('✅ No duplicate enrollments found.\n');
        
        // Check if constraint already exists
        const [existingIndexes] = await conn.execute(`
            SHOW INDEX FROM enrollments_gradelevel_classes 
            WHERE Key_name = 'unique_student_enrollment'
        `);
        
        if (existingIndexes.length > 0) {
            console.log('⚠️  Unique constraint already exists on student_regnumber.');
            process.exit(0);
        }
        
        console.log('🔧 Adding unique constraint on student_regnumber...\n');
        
        // Add the unique constraint
        await conn.execute(`
            ALTER TABLE enrollments_gradelevel_classes 
            ADD UNIQUE KEY unique_student_enrollment (student_regnumber)
        `);
        
        console.log('✅ Successfully added unique constraint on student_regnumber.');
        console.log('\n📋 This constraint ensures:');
        console.log('   - No student can have multiple enrollments');
        console.log('   - Database-level enforcement of data integrity');
        console.log('   - Attempts to create duplicate enrollments will fail with a database error');
        console.log('\n⚠️  Note: If you need to re-enroll a student, you should update');
        console.log('   the existing enrollment record instead of creating a new one.');
        
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            console.error('❌ Cannot add constraint: Duplicate entries found in the table.');
            console.error('   Please remove duplicates before applying the constraint.');
        } else if (error.code === 'ER_DUP_KEYNAME') {
            console.error('⚠️  Constraint already exists with a different name.');
        } else {
            console.error('❌ Error applying constraint:', error.message);
        }
        process.exit(1);
    } finally {
        conn.release();
        process.exit(0);
    }
})();

