const { pool } = require('./config/database');

async function checkStudentBalance() {
    const connection = await pool.getConnection();
    const studentRegNumber = 'R79290B';
    
    try {
        console.log(`🔍 Checking balance for student ${studentRegNumber}...\n`);
        
        // Get student details
        const [students] = await connection.execute(
            'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
            [studentRegNumber]
        );
        
        if (students.length === 0) {
            throw new Error(`Student with registration number ${studentRegNumber} not found`);
        }
        
        const student = students[0];
        console.log(`✅ Student: ${student.Name} ${student.Surname}\n`);
        
        // Get current balance
        const [balanceRows] = await connection.execute(
            'SELECT current_balance, last_updated FROM student_balances WHERE student_reg_number = ?',
            [studentRegNumber]
        );
        
        const currentBalance = balanceRows.length > 0 ? balanceRows[0].current_balance : 0;
        console.log(`📊 Current Balance: ${currentBalance}`);
        
        // Get latest transaction
        const [transactions] = await connection.execute(
            `SELECT 
                transaction_type, 
                amount, 
                description, 
                transaction_date
             FROM student_transactions 
             WHERE student_reg_number = ? 
             ORDER BY transaction_date DESC, id DESC
             LIMIT 5`,
            [studentRegNumber]
        );
        
        console.log(`\n📝 Latest Transactions:`);
        transactions.forEach((tx, i) => {
            console.log(`${i+1}. ${tx.transaction_type} ${tx.amount} - ${tx.description}`);
            console.log(`   Date: ${tx.transaction_date}`);
        });
        
    } catch (error) {
        console.error('\n❌ ERROR:', error.message);
        console.error(error);
    } finally {
        connection.release();
        process.exit(0);
    }
}

checkStudentBalance();

