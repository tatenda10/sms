const ExcelJS = require('exceljs');
const { pool } = require('./config/database');

// Student data extracted from the Grade 6 sheet
const studentData = [
  { name: 'Chikomborero', surname: 'Chishiri', balReg: -10, payment1: 50, payment2: 0, payment3: 0, total: 50 },
  { name: 'Micheal', surname: 'Choga', balReg: 0, payment1: 50, payment2: 30, payment3: 30, total: 100 },
  { name: 'Livetti', surname: 'Divala', balReg: 0, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Shantel', surname: 'Chiteve', balReg: -50, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Shaine', surname: 'Majoni', balReg: 0, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Tatenda', surname: 'Makuwaro', balReg: -10, payment1: 20, payment2: 10, payment3: 0, total: 30 },
  { name: 'Nokutenda', surname: 'Manyanga', balReg: 0, payment1: 50, payment2: 40, payment3: 0, total: 90 },
  { name: 'Vanessa', surname: 'Machingauta', balReg: 0, payment1: 50, payment2: 25, payment3: 0, total: 75 },
  { name: 'Michele', surname: 'Munyanyi', balReg: 0, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Z Aaron', surname: 'Mutetwa', balReg: 0, payment1: 50, payment2: 0, payment3: 0, total: 50 },
  { name: 'Tadiwanashe', surname: 'Nguruve', balReg: 0, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Mable', surname: 'Paza', balReg: 0, payment1: 40, payment2: 30, payment3: 20, total: 100 },
  { name: 'Tadiwanashe', surname: 'Seremani', balReg: 0, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Savania', surname: 'Matekenya', balReg: 0, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Meghan', surname: 'Jamali', balReg: 0, payment1: 100, payment2: 0, payment3: 0, total: 100 },
  { name: 'Takunda', surname: 'Taderera', balReg: 0, payment1: 50, payment2: 20, payment3: 20, total: 100 },
  { name: 'Mikel', surname: 'Mazuru', balReg: 0, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Elmah', surname: 'Nhara', balReg: 0, payment1: 15, payment2: 0, payment3: 0, total: 15 },
  { name: 'clint', surname: 'Muchengwa', balReg: 0, payment1: 40, payment2: 20, payment3: 20, total: 80 },
  { name: 'Blessed', surname: 'Munjeri', balReg: 0, payment1: 50, payment2: 40, payment3: 10, total: 100 },
  { name: 'Tinotenda', surname: 'Madiya', balReg: 0, payment1: 40, payment2: 20, payment3: 0, total: 60 },
  { name: 'Anesu', surname: 'Hamuhli', balReg: 0, payment1: 30, payment2: 20, payment3: 20, total: 70 },
  { name: 'Isaac', surname: 'Chimambo', balReg: 0, payment1: 0, payment2: 0, payment3: 0, total: 0 },
  { name: 'Rumbidzai', surname: 'Chiputura', balReg: -50, payment1: 50, payment2: 0, payment3: 0, total: 50 }
];

// Function to generate registration number based on existing pattern
// Pattern: R + 5 digits + letter (e.g., R05688P, R79290B)
async function generateRegNumber(name, surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 0;
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY RegNumber DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  // Generate new number (increment from max)
  const newNumber = maxNumber + 1;
  const numberStr = String(newNumber).padStart(5, '0');
  
  // Generate letter suffix based on surname first letter (or name if no surname)
  const letterSource = surname || name;
  const firstLetter = letterSource.charAt(0).toUpperCase();
  const letter = /[A-Z]/.test(firstLetter) ? firstLetter : 'A';
  
  const regNumber = `R${numberStr}${letter}`;
  
  // Check for duplicates and adjust if needed
  if (existingNumbers.has(regNumber)) {
    // If duplicate, try next letter
    const nextLetter = String.fromCharCode(letter.charCodeAt(0) + 1);
    return `R${numberStr}${nextLetter > 'Z' ? 'A' : nextLetter}`;
  }
  
  existingNumbers.add(regNumber);
  return regNumber;
}

async function generateExcel() {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grade 6 Students');
  
  // Set column headers
  worksheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Surname', key: 'surname', width: 20 },
    { header: 'Registration Number', key: 'regNumber', width: 18 },
    { header: 'Class', key: 'class', width: 15 },
    { header: 'Balance', key: 'balance', width: 12 },
    { header: 'Total Payments', key: 'totalPayments', width: 15 }
  ];
  
  // Style the header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Get existing registration numbers to avoid duplicates
  const existingNumbers = new Set();
  try {
    const [existing] = await pool.execute('SELECT RegNumber FROM students');
    existing.forEach(row => existingNumbers.add(row.RegNumber));
  } catch (error) {
    console.log('Could not fetch existing reg numbers');
  }
  
  // Add student data
  for (const student of studentData) {
    const regNumber = await generateRegNumber(student.name, student.surname, existingNumbers);
    
    // Calculate total payments (use total column if provided, otherwise sum payments)
    const totalPayments = student.total || (student.payment1 || 0) + (student.payment2 || 0) + (student.payment3 || 0);
    
    worksheet.addRow({
      name: student.name,
      surname: student.surname,
      regNumber: regNumber,
      class: 'Grade 6',
      balance: student.balReg || 0,
      totalPayments: totalPayments
    });
  }
  
  // Format balance column (negative values in red)
  worksheet.getColumn('balance').numFmt = '$#,##0.00';
  worksheet.getColumn('totalPayments').numFmt = '$#,##0.00';
  
  // Add conditional formatting for negative balances
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) { // Skip header
      const balanceCell = row.getCell('balance');
      if (balanceCell.value < 0) {
        balanceCell.font = { color: { argb: 'FFFF0000' } }; // Red
      }
    }
  });
  
  // Save the file
  const filename = 'Grade6_Students_Data.xlsx';
  await workbook.xlsx.writeFile(filename);
  console.log(`\n✅ Excel file created: ${filename}`);
  console.log(`📊 Total students: ${studentData.length}`);
  
  // Close database connection
  await pool.end();
}

generateExcel().catch(error => {
  console.error('Error generating Excel file:', error);
  process.exit(1);
});

