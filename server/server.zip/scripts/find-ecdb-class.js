const { pool } = require('./config/database');

async function findECDBClass() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 FINDING ECD B CLASS\n');
    console.log('='.repeat(70));
    
    // Get all classes with ECD in the name
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%ECD%'
      ORDER BY gc.name
    `);
    
    console.log(`\n📊 Found ${classes.length} ECD classes:\n`);
    classes.forEach((cls, idx) => {
      console.log(`${idx + 1}. ${cls.name} (ID: ${cls.id})`);
    });
    
  } catch (error) {
    console.error('Error finding ECD B class:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

findECDBClass();

