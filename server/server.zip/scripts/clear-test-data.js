const { pool } = require('../config/database');

class DataCleaner {
  constructor() {
    this.connection = null;
  }

  async connect() {
    this.connection = await pool.getConnection();
  }

  async disconnect() {
    if (this.connection) {
      this.connection.release();
    }
  }

  async clearData() {
    try {
      await this.connect();
      await this.connection.beginTransaction();

      console.log('🧹 Starting data cleanup...');

      // Clear in reverse order of dependencies (child tables first, then parent tables)
      const tablesToClear = [
        'journal_entry_lines',
        'accounts_payable_payments',
        'accounts_payable_balances',
        'expenses',
        'transactions',
        'boarding_fee_balances',
        'boarding_payments',
        'boarding_fees_payments',
        'boarding_enrollments',
        'fee_payments',
        'student_transactions',
        'student_balances',
        'account_balances',
        'enrollments_gradelevel_classes',
        'enrollments_subject_classes',
        'journal_entries'
      ];

      for (const table of tablesToClear) {
        console.log(`🗑️  Clearing ${table}...`);
        const [result] = await this.connection.execute(`DELETE FROM ${table}`);
        console.log(`   ✅ Deleted ${result.affectedRows} records from ${table}`);
      }

      // Reset auto-increment counters
      const resetTables = [
        'journal_entry_lines',
        'accounts_payable_payments',
        'accounts_payable_balances',
        'expenses',
        'transactions',
        'boarding_fee_balances',
        'boarding_payments',
        'boarding_fees_payments',
        'boarding_enrollments',
        'fee_payments',
        'student_transactions',
        'student_balances',
        'account_balances',
        'enrollments_gradelevel_classes',
        'enrollments_subject_classes',
        'journal_entries'
      ];

      for (const table of resetTables) {
        await this.connection.execute(`ALTER TABLE ${table} AUTO_INCREMENT = 1`);
        console.log(`   🔄 Reset auto-increment for ${table}`);
      }

      await this.connection.commit();
      console.log('✅ Data cleanup completed successfully!');

    } catch (error) {
      if (this.connection) {
        await this.connection.rollback();
      }
      console.error('❌ Error during data cleanup:', error);
      throw error;
    } finally {
      await this.disconnect();
    }
  }

  async showSummary() {
    try {
      await this.connect();
      
      console.log('\n📊 Data Summary After Cleanup:');
      console.log('================================');
      
      const tables = [
        'journal_entry_lines',
        'accounts_payable_payments',
        'accounts_payable_balances',
        'expenses',
        'transactions',
        'journal_entries',
        'boarding_fee_balances',
        'boarding_payments',
        'boarding_fees_payments',
        'boarding_enrollments',
        'fee_payments',
        'student_transactions',
        'student_balances',
        'account_balances',
        'enrollments_gradelevel_classes',
        'enrollments_subject_classes'
      ];

      for (const table of tables) {
        const [result] = await this.connection.execute(`SELECT COUNT(*) as count FROM ${table}`);
        console.log(`${table}: ${result[0].count} records`);
      }

    } catch (error) {
      console.error('❌ Error getting summary:', error);
    } finally {
      await this.disconnect();
    }
  }
}

// Main execution
async function main() {
  const cleaner = new DataCleaner();
  
  try {
    await cleaner.clearData();
    await cleaner.showSummary();
    console.log('\n🎉 All test data has been cleared! You can now start fresh.');
  } catch (error) {
    console.error('❌ Failed to clear data:', error.message);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = DataCleaner;
