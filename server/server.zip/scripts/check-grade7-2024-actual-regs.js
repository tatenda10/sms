const { pool } = require('./config/database');

// All Grade 7 2024 students from the image
const grade72024Students = [
  { name: 'Nicholas', surname: "Chin'ono" },
  { name: 'Anita', surname: 'Chivete' },
  { name: 'Talent', surname: 'Choga' },
  { name: 'Tapiwa', surname: 'Furutuna' },
  { name: 'Tanyaradzwa', surname: 'Kabvura' },
  { name: 'Goodson', surname: 'Kankuni' },
  { name: 'Adience', surname: 'Madzivaidze' },
  { name: 'Tawonga', surname: 'Masango' },
  { name: 'Samantha', surname: 'Munyanyi' },
  { name: 'Leeroy', surname: 'Muzanamombe' },
  { name: 'C Tinotenda', surname: 'Sithole' },
  { name: 'Anesu', surname: 'Mutengu' },
  { name: 'Ruvimbo', surname: 'Jongwe' },
  { name: 'Maseline', surname: 'Gwese' },
  { name: 'Sibongile', surname: 'Nyoni' },
  { name: 'Tinashe', surname: 'Antonio' },
  { name: 'Queen', surname: 'Muswati' },
  { name: 'Chipo', surname: 'Nyambodza' }
];

async function checkGrade72024ActualRegs() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ACTUAL REGISTRATION NUMBERS FOR GRADE 7 2024 STUDENTS\n');
    console.log('='.repeat(70));
    
    // Group by registration number
    const regNumberMap = {};
    
    for (const student of grade72024Students) {
      const [students] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      if (students.length > 0) {
        const regNumber = students[0].RegNumber;
        if (!regNumberMap[regNumber]) {
          regNumberMap[regNumber] = [];
        }
        regNumberMap[regNumber].push({
          name: student.name,
          surname: student.surname,
          regNumber: regNumber
        });
      }
    }
    
    // Find duplicates
    const duplicates = [];
    const unique = [];
    
    for (const [regNumber, studentList] of Object.entries(regNumberMap)) {
      if (studentList.length > 1) {
        duplicates.push({ regNumber, students: studentList });
      } else {
        unique.push(studentList[0]);
      }
    }
    
    console.log(`\n📊 Summary:\n`);
    console.log(`   Total students found: ${grade72024Students.length}`);
    console.log(`   Unique registration numbers: ${unique.length}`);
    console.log(`   Duplicate registration numbers: ${duplicates.length}\n`);
    
    if (duplicates.length > 0) {
      console.log('🔴 DUPLICATE REGISTRATION NUMBERS:\n');
      duplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((s, sIdx) => {
          console.log(`   ${sIdx + 1}. ${s.name} ${s.surname}`);
        });
      });
    }
    
    // Show all students
    console.log(`\n\n📋 ALL GRADE 7 2024 STUDENTS WITH THEIR REGISTRATION NUMBERS:\n`);
    console.log('-'.repeat(70));
    let idx = 1;
    for (const student of grade72024Students) {
      const [students] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      if (students.length > 0) {
        console.log(`${String(idx).padStart(3)}. ${student.name.padEnd(20)} ${student.surname.padEnd(25)} ${students[0].RegNumber}`);
      } else {
        console.log(`${String(idx).padStart(3)}. ${student.name.padEnd(20)} ${student.surname.padEnd(25)} NOT FOUND`);
      }
      idx++;
    }
    
  } catch (error) {
    console.error('Error checking students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkGrade72024ActualRegs();

