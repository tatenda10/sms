const { pool } = require('./config/database');

// All ECD A students from the image
const ecdaStudents = [
  { name: 'Baven', surname: 'Mandizadza', balance: 0.00, totalPayments: 85.00 },
  { name: 'Blessed', surname: 'Masimo', balance: 0.00, totalPayments: 85.00 },
  { name: 'Alex', surname: 'Paza', balance: -45.00, totalPayments: 75.00 },
  { name: 'Elsie', surname: 'Nhara', balance: -5.00, totalPayments: 25.00 },
  { name: 'Keila', surname: 'Divala', balance: -15.00, totalPayments: 115.00 },
  { name: 'Carlton', surname: 'Kanodeweta', balance: 0.00, totalPayments: 0.00 }
];

async function findStudentByName(conn, name, surname) {
  const [students] = await conn.execute(
    'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
    [name, surname]
  );
  return students.length > 0 ? students[0] : null;
}

async function fixECDAComplete() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 COMPLETING ECD A SETUP\n');
    console.log('='.repeat(70));
    
    // Get ECD A class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%ECD A%' OR gc.name LIKE '%ECD%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ ECD A class not found');
      return;
    }
    
    const ecdaClass = classes[0];
    console.log(`✅ Found ECD A class: ${ecdaClass.name} (ID: ${ecdaClass.id})\n`);
    
    await conn.beginTransaction();
    
    let enrolled = 0;
    
    // Process each student
    for (const student of ecdaStudents) {
      const existing = await findStudentByName(conn, student.name, student.surname);
      
      if (!existing) {
        console.log(`⚠️  ${student.name} ${student.surname} not found, skipping...`);
        continue;
      }
      
      console.log(`📝 Processing: ${student.name} ${student.surname} (${existing.RegNumber})`);
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [existing.RegNumber, ecdaClass.id]);
      
      if (enrollment.length === 0) {
        await conn.execute(`
          INSERT INTO enrollments_gradelevel_classes (student_regnumber, gradelevel_class_id, status)
          VALUES (?, ?, 'active')
        `, [existing.RegNumber, ecdaClass.id]);
        enrolled++;
        console.log(`   ✅ Enrolled in ECD A`);
      } else {
        console.log(`   ⏭️  Already enrolled`);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ ECD A setup completed!');
    console.log(`\n📊 Summary:`);
    console.log(`   Students enrolled: ${enrolled}`);
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error completing ECD A setup:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixECDAComplete();

