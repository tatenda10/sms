const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Corrected student data from the Excel (Grade 3)
const studentData = [
  { name: 'Solomon', surname: 'Mutambiranwa', regNumber: 'R00011M', balance: 0.00, totalPayments: 100.00 },
  { name: 'Zerubabbel', surname: 'Chitakatira', regNumber: 'R00011C', balance: 0.00, totalPayments: 50.00 },
  { name: 'Prosper', surname: 'Choga', regNumber: 'R00011P', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tinodaishe', surname: 'Bhudhi', regNumber: 'R00011T', balance: 0.00, totalPayments: 0.00 },
  { name: 'Princess', surname: 'Gowe', regNumber: 'R00011G', balance: 0.00, totalPayments: 100.00 },
  { name: 'Keilla', surname: 'Gwerendende', regNumber: 'R00011K', balance: 0.00, totalPayments: 100.00 },
  { name: 'Nick', surname: 'Mademutsa', regNumber: 'R00011N', balance: 0.00, totalPayments: 100.00 },
  { name: 'Tashinga', surname: 'Mafuwu', regNumber: 'R00011A', balance: 0.00, totalPayments: 80.00 },
  { name: 'Nomilna', surname: 'Makora', regNumber: 'R00011O', balance: -130.00, totalPayments: 0.00 },
  { name: 'Asher', surname: 'Mutadzakupa', regNumber: 'R00011S', balance: -130.00, totalPayments: 0.00 },
  { name: 'Bradley', surname: 'Majinjiwa', regNumber: 'R00011B', balance: 0.00, totalPayments: 100.00 },
  { name: 'Ethan', surname: 'Muchemwenyi', regNumber: 'R00011E', balance: 0.00, totalPayments: 100.00 },
  { name: 'K Mary', surname: 'Mutetwa', regNumber: 'R00011D', balance: -50.00, totalPayments: 100.00 },
  { name: 'Kudzaishe', surname: 'Mutukumira', regNumber: 'R00011U', balance: 0.00, totalPayments: 100.00 },
  { name: 'Nobuhle', surname: 'Nyoni', regNumber: 'R00011H', balance: 0.00, totalPayments: 75.00 },
  { name: 'Tinotenda', surname: 'Ndoro', regNumber: 'R00011I', balance: 0.00, totalPayments: 100.00 },
  { name: 'Mufaro', surname: 'Sanyamandwe', regNumber: 'R00011F', balance: -10.00, totalPayments: 70.00 },
  { name: 'Lilian', surname: 'Nyamatanga', regNumber: 'R00011L', balance: -10.00, totalPayments: 100.00 },
  { name: 'Edmore', surname: 'Muzindi', regNumber: 'R00011J', balance: 0.00, totalPayments: 100.00 },
  { name: 'Kupakwashe', surname: 'Nyava', regNumber: 'R00011V', balance: 0.00, totalPayments: 100.00 },
  { name: 'Ryley', surname: 'Chasakara', regNumber: 'R00011R', balance: 0.00, totalPayments: 80.00 },
  { name: 'Petronella', surname: 'Sithole', regNumber: 'R00011W', balance: -280.00, totalPayments: 25.00 },
  { name: 'Martin', surname: 'Mazuru', regNumber: 'R00011X', balance: 0.00, totalPayments: 100.00 },
  { name: 'Sean', surname: 'Tambudzi', regNumber: 'R00011Y', balance: 0.00, totalPayments: 60.00 },
  { name: 'Alicia', surname: 'Kumire', regNumber: 'R00011Z', balance: -140.00, totalPayments: 44.00 },
  { name: 'Jayden', surname: 'Masiiwa', regNumber: 'R00012A', balance: 0.00, totalPayments: 55.00 },
  { name: 'Anicia', surname: 'Kumire', regNumber: 'R00012B', balance: -170.00, totalPayments: 45.00 },
  { name: 'Soviet', surname: 'Haisa', regNumber: 'R00012C', balance: 0.00, totalPayments: 100.00 },
  { name: 'Sean', surname: 'Kasunungura', regNumber: 'R00012D', balance: -15.00, totalPayments: 80.00 },
  { name: 'Munashe', surname: 'Nyoni', regNumber: 'R00012E', balance: -30.00, totalPayments: 40.00 },
  { name: 'Alma', surname: 'Chakara', regNumber: 'R00012F', balance: 0.00, totalPayments: 50.00 },
  { name: 'Tashinga', surname: 'Mupesi', regNumber: 'R00012G', balance: 0.00, totalPayments: 100.00 },
  { name: 'Anesu', surname: 'Kamuzondi', regNumber: 'R00012H', balance: 0.00, totalPayments: 90.00 },
  { name: 'Benster', surname: 'Gomera', regNumber: 'R00012I', balance: 0.00, totalPayments: 50.00 },
  { name: 'Tinevimbo', surname: 'Chitambo', regNumber: 'R00012J', balance: 0.00, totalPayments: 100.00 },
  { name: 'Bradley', surname: 'Muzanamombe', regNumber: 'R00012K', balance: -10.00, totalPayments: 107.00 },
  { name: 'Daryl', surname: 'Mupedzisi', regNumber: 'R00012L', balance: 0.00, totalPayments: 110.00 },
  { name: 'Devine', surname: 'Magombe', regNumber: 'R00012M', balance: 0.00, totalPayments: 100.00 },
  { name: 'Lloyd', surname: 'Kufakujeri', regNumber: 'R00012N', balance: 0.00, totalPayments: 90.00 },
  { name: 'Grace', surname: 'Mukarati', regNumber: 'R00012O', balance: -110.00, totalPayments: 30.00 }
];

async function processGrade3Students() {
  console.log('\n📚 PROCESSING GRADE 3 STUDENTS\n');
  console.log('='.repeat(60));
  
  try {
    // STEP 1: Register students
    console.log('\n🔄 STEP 1: Registering students...\n');
    const conn1 = await pool.getConnection();
    let registered = 0;
    let skipped = 0;
    
    try {
      await conn1.beginTransaction();
      
      for (const student of studentData) {
        try {
          // Check if student already exists
          const [existing] = await conn1.execute(
            'SELECT RegNumber FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (existing.length > 0) {
            console.log(`⏭️  Student ${student.name} ${student.surname} (${student.regNumber}) already registered`);
            skipped++;
            continue;
          }
          
          // Register student with random details
          // Generate random details for Grade 3 students (around 2013-2014)
          const year = 2013;
          const month = Math.floor(Math.random() * 12) + 1;
          const day = Math.floor(Math.random() * 28) + 1;
          const dateOfBirth = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const gender = Math.random() > 0.5 ? 'Male' : 'Female';
          const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
          const address = 'Address not provided';
          
          // Insert student
          await conn1.execute(`
            INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
          
          // Insert guardian
          const guardianName = `Guardian of ${student.name}`;
          const guardianSurname = student.surname;
          const guardianPhone = `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
          const relationship = 'Parent';
          
          await conn1.execute(`
            INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
            VALUES (?, ?, ?, ?, ?, ?)
          `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, relationship]);
          
          // Create initial balance record
          await conn1.execute(`
            INSERT INTO student_balances (student_reg_number, current_balance)
            VALUES (?, 0)
            ON DUPLICATE KEY UPDATE current_balance = current_balance
          `, [student.regNumber]);
          
          console.log(`✅ Registered: ${student.name} ${student.surname} (${student.regNumber})`);
          registered++;
        } catch (error) {
          console.error(`❌ Error registering ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn1.commit();
      console.log(`\n📊 Registration Summary: ${registered} registered, ${skipped} already existed`);
    } catch (error) {
      await conn1.rollback();
      throw error;
    } finally {
      conn1.release();
    }
    
    // STEP 2: Add outstanding balances for students with negative balances
    console.log('\n🔄 STEP 2: Adding outstanding balances...\n');
    let processed = 0;
    const conn2 = await pool.getConnection();
    
    try {
      await conn2.beginTransaction();
      
      for (const student of studentData) {
        if (student.balance >= 0) continue; // Skip students with no debt
        
        try {
          const debtAmount = Math.abs(student.balance);
          
          // Get or create journal for opening balances
          let journal_id = 1; // Try General Journal (ID: 1) first
          const [journalCheck] = await conn2.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
          if (journalCheck.length === 0) {
            const [journalByName] = await conn2.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
            if (journalByName.length > 0) {
              journal_id = journalByName[0].id;
            } else {
              const [anyJournal] = await conn2.execute('SELECT id FROM journals LIMIT 1');
              if (anyJournal.length > 0) {
                journal_id = anyJournal[0].id;
              } else {
                const [journalResult] = await conn2.execute(
                  'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
                  ['General Journal', 'Journal for general transactions including opening balances', 1]
                );
                journal_id = journalResult.insertId;
              }
            }
          }
          
          // Get student info
          const [studentInfo] = await conn2.execute(
            'SELECT Name, Surname FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (studentInfo.length === 0) {
            console.log(`⚠️  Student ${student.regNumber} not found, skipping`);
            continue;
          }
          
          const reference = `OB-${student.regNumber}-${Date.now()}`;
          const journalDescription = `Opening Balance - Outstanding Debt for ${studentInfo[0].Name} ${studentInfo[0].Surname}`;
          
          // Create journal entry
          const [journalResult] = await conn2.execute(`
            INSERT INTO journal_entries (
              journal_id, entry_date, description, reference,
              created_by, created_at, updated_at
            ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
          `, [journal_id, journalDescription, reference, 1]);
          
          const journalEntryId = journalResult.insertId;
          
          // Get accounts
          const [accountsReceivable] = await conn2.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1100', 'Asset']
          );
          
          const [retainedEarnings] = await conn2.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
            ['3998'] // Retained Earnings (Opening Balance Equity)
          );
          
          if (accountsReceivable.length === 0 || retainedEarnings.length === 0) {
            throw new Error('Required accounts not found in chart of accounts (1100, 3998)');
          }
          
          // Create journal entry lines (use debit/credit columns)
          await conn2.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, accountsReceivable[0].id, debtAmount, 0, `Outstanding debt for ${studentInfo[0].Name} ${studentInfo[0].Surname}`]);
          
          await conn2.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, retainedEarnings[0].id, 0, debtAmount, `Retained Earnings - Opening Balance`]);
          
          // Check if transaction already exists to prevent duplicates
          const [existingTxn] = await conn2.execute(
            'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
            [student.regNumber, `%Opening Balance - Outstanding Debt%`, 'DEBIT']
          );
          
          if (existingTxn.length > 0) {
            console.log(`⏭️  Skipping outstanding balance for ${student.name} ${student.surname} - transaction already exists`);
            continue;
          }
          
          // Create DEBIT transaction (this automatically updates the balance)
          const transactionId = await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'DEBIT',
            debtAmount,
            `Opening Balance - Outstanding Debt: ${reference}`,
            {
              created_by: 1,
              journal_entry_id: journalEntryId
            }
          );
          
          // Get updated balance (transaction already updated it)
          const [updatedBalance] = await conn2.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [student.regNumber]
          );
          const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
          
          // Update account balances from journal entry
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn2, journalEntryId, 1);
          
          console.log(`✅ Added outstanding balance: ${student.name} ${student.surname} - $${debtAmount.toFixed(2)} (New balance: $${newBalance.toFixed(2)})`);
          processed++;
        } catch (error) {
          console.error(`❌ Error adding outstanding balance for ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn2.commit();
      console.log(`\n📊 Outstanding Balances Summary: ${processed} processed`);
    } catch (error) {
      await conn2.rollback();
      throw error;
    } finally {
      conn2.release();
    }
    
    // STEP 3: Enroll students to Grade 3 class for Term 3 2025
    console.log('\n🔄 STEP 3: Enrolling students to Grade 3...\n');
    const conn3 = await pool.getConnection();
    processed = 0;
    skipped = 0;
    
    try {
      await conn3.beginTransaction();
      
      // Find Grade 3 class
      const [grade3Classes] = await conn3.execute(
        'SELECT id, name FROM gradelevel_classes WHERE name LIKE ? LIMIT 1',
        ['%Grade 3%']
      );
      
      if (grade3Classes.length === 0) {
        throw new Error('Grade 3 class not found');
      }
      
      const grade3Class = grade3Classes[0];
      console.log(`📚 Found class: ${grade3Class.name} (ID: ${grade3Class.id})`);
      
      // Find invoice structure for Grade 3, Term 3, 2025
      const [invoiceStructures] = await conn3.execute(`
        SELECT id, total_amount, term, academic_year
        FROM invoice_structures
        WHERE gradelevel_class_id = ? AND term = ? AND academic_year = ?
        LIMIT 1
      `, [grade3Class.id, 'Term 3', '2025']);
      
      if (invoiceStructures.length === 0) {
        throw new Error('Invoice structure for Grade 3 Term 3 2025 not found');
      }
      
      const invoiceStructure = invoiceStructures[0];
      console.log(`💰 Found invoice structure: Term ${invoiceStructure.term} ${invoiceStructure.academic_year} - $${invoiceStructure.total_amount}`);
      
      for (const student of studentData) {
        try {
          // Check if already enrolled
          const [existingEnrollment] = await conn3.execute(
            'SELECT id FROM enrollments_gradelevel_classes WHERE student_regnumber = ? AND gradelevel_class_id = ?',
            [student.regNumber, grade3Class.id]
          );
          
          if (existingEnrollment.length > 0) {
            console.log(`⏭️  ${student.name} ${student.surname} already enrolled`);
            skipped++;
            continue;
          }
          
          // Get or create journal for enrollments
          let journal_id = 6; // Try Fees Journal (ID: 6) first
          const [journalCheck] = await conn3.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
          if (journalCheck.length === 0) {
            const [journalByName] = await conn3.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['Fees Journal']);
            if (journalByName.length > 0) {
              journal_id = journalByName[0].id;
            } else {
              const [anyJournal] = await conn3.execute('SELECT id FROM journals LIMIT 1');
              if (anyJournal.length > 0) {
                journal_id = anyJournal[0].id;
              } else {
                const [journalResult] = await conn3.execute(
                  'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
                  ['Fees Journal', 'Journal for fee payment transactions including class enrollments', 1]
                );
                journal_id = journalResult.insertId;
              }
            }
          }
          
          const reference = `ENROLL-${student.regNumber}-${Date.now()}`;
          const description = `Class Enrollment - Grade 3 Term 3 2025 for ${student.name} ${student.surname}`;
          
          // Create journal entry
          const [journalEntry] = await conn3.execute(
            `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by)
             VALUES (?, CURDATE(), ?, ?, ?)`,
            [
              journal_id,
              description,
              reference,
              1
            ]
          );
          
          const journalEntryId = journalEntry.insertId;
          
          // Get accounts
          const [accountsReceivable] = await conn3.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1100', 'Asset']
          );
          
          const [tuitionRevenue] = await conn3.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['4000', 'Revenue']
          );
          
          if (accountsReceivable.length === 0 || tuitionRevenue.length === 0) {
            throw new Error('Required accounts not found in chart of accounts');
          }
          
          // Create journal entry lines (use debit/credit columns)
          await conn3.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, accountsReceivable[0].id, invoiceStructure.total_amount, 0, description]);
          
          await conn3.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, tuitionRevenue[0].id, 0, invoiceStructure.total_amount, description]);
          
          // Check if enrollment transaction already exists
          const [existingEnrollTxn] = await conn3.execute(
            'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
            [student.regNumber, `%Class Enrollment - Grade 3 Term 3 2025%`, 'DEBIT']
          );
          
          if (existingEnrollTxn.length > 0) {
            console.log(`⏭️  Skipping enrollment transaction for ${student.name} ${student.surname} - already exists`);
            // Still need to update journal entry link if missing
            if (existingEnrollTxn[0].journal_entry_id !== journalEntryId) {
              await conn3.execute(
                'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
                [journalEntryId, existingEnrollTxn[0].id]
              );
            }
            continue;
          }
          
          // Create DEBIT transaction (this automatically updates the balance)
          const transactionId = await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'DEBIT',
            invoiceStructure.total_amount,
            `Class Enrollment - Grade 3 Term 3 2025: ${reference}`,
            {
              created_by: 1,
              journal_entry_id: journalEntryId
            }
          );
          
          // Get updated balance (transaction already updated it)
          const [updatedBalance] = await conn3.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [student.regNumber]
          );
          const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
          
          // Create enrollment (term and academic_year are not in the table, they come from invoice structure)
          const [enrollment] = await conn3.execute(`
            INSERT INTO enrollments_gradelevel_classes (
              student_regnumber, gradelevel_class_id, status
            ) VALUES (?, ?, ?)
          `, [student.regNumber, grade3Class.id, 'active']);
          
          // Update account balances from journal entry
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn3, journalEntryId, 1);
          
          console.log(`✅ Enrolled: ${student.name} ${student.surname} - Balance: $${newBalance.toFixed(2)}`);
          processed++;
        } catch (error) {
          console.error(`❌ Error enrolling ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn3.commit();
      console.log(`\n📊 Enrollment Summary: ${processed} enrolled, ${skipped} already enrolled`);
    } catch (error) {
      await conn3.rollback();
      throw error;
    } finally {
      conn3.release();
    }
    
    // STEP 4: Record payments
    console.log('\n🔄 STEP 4: Recording payments...\n');
    const conn4 = await pool.getConnection();
    processed = 0;
    skipped = 0;
    
    try {
      await conn4.beginTransaction();
      
      // Get currency
      const [currencies] = await conn4.execute(
        'SELECT id FROM currencies WHERE base_currency = TRUE LIMIT 1'
      );
      const currencyId = currencies.length > 0 ? currencies[0].id : 1;
      
      for (const student of studentData) {
        if (student.totalPayments <= 0) {
          skipped++;
          continue;
        }
        
        try {
          // Check if payment transaction already exists (prevent duplicates)
          const [existingPaymentTxn] = await conn4.execute(
            'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
            [student.regNumber, `%Fee Payment - Receipt #%`, 'CREDIT']
          );
          
          if (existingPaymentTxn.length > 0) {
            // Check if we have the right amount
            const [txnDetails] = await conn4.execute(
              'SELECT amount FROM student_transactions WHERE id = ?',
              [existingPaymentTxn[0].id]
            );
            if (txnDetails.length > 0 && Math.abs(parseFloat(txnDetails[0].amount) - student.totalPayments) < 0.01) {
              console.log(`⏭️  Payment already exists for ${student.name} ${student.surname} (${student.totalPayments})`);
              skipped++;
              continue;
            }
          }
          
          // Generate unique receipt number
          const receiptNumber = `PAY-${student.regNumber}-${Date.now()}`;
          
          // Create payment record
          const [paymentResult] = await conn4.execute(`
            INSERT INTO fee_payments (
              student_reg_number, payment_amount, payment_currency, exchange_rate,
              base_currency_amount, payment_method, payment_date, receipt_number,
              reference_number, notes, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            student.regNumber,
            student.totalPayments,
            currencyId,
            1.0,
            student.totalPayments,
            'Cash',
            new Date(),
            receiptNumber,
            receiptNumber,
            'Payment from Grade 3 enrollment batch',
            1
          ]);
          
          const paymentId = paymentResult.insertId;
          
          // Create CREDIT transaction
          const transactionId = await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'CREDIT',
            student.totalPayments,
            `Fee Payment - Receipt #${receiptNumber}`,
            {
              created_by: 1,
              payment_id: paymentId
            }
          );
          
          // Create journal entries for payment
          const [cashAccount] = await conn4.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1000', 'Asset']
          );
          
          const [accountsReceivable] = await conn4.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1100', 'Asset']
          );
          
          if (cashAccount.length === 0 || accountsReceivable.length === 0) {
            throw new Error('Required accounts not found in chart of accounts');
          }
          
          // Get or create journal for payments
          let journal_id = 6; // Try Fees Journal (ID: 6) first
          const [journalCheck] = await conn4.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
          if (journalCheck.length === 0) {
            const [journalByName] = await conn4.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['Fees Journal']);
            if (journalByName.length > 0) {
              journal_id = journalByName[0].id;
            } else {
              const [anyJournal] = await conn4.execute('SELECT id FROM journals LIMIT 1');
              if (anyJournal.length > 0) {
                journal_id = anyJournal[0].id;
              } else {
                const [journalResult] = await conn4.execute(
                  'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
                  ['Fees Journal', 'Journal for fee payment transactions', 1]
                );
                journal_id = journalResult.insertId;
              }
            }
          }
          
          const journalDescription = `Fee Payment - Receipt #${receiptNumber} for ${student.name} ${student.surname}`;
          const [journalEntry] = await conn4.execute(
            `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by)
             VALUES (?, CURDATE(), ?, ?, ?)`,
            [journal_id, journalDescription, receiptNumber, 1]
          );
          
          const journalEntryId = journalEntry.insertId;
          
          // Create journal entry lines (use debit/credit columns)
          await conn4.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, cashAccount[0].id, student.totalPayments, 0, journalDescription]);
          
          await conn4.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, accountsReceivable[0].id, 0, student.totalPayments, journalDescription]);
          
          // Update transaction with journal entry ID
          await conn4.execute(`
            UPDATE student_transactions 
            SET journal_entry_id = ?
            WHERE id = ?
          `, [journalEntryId, transactionId]);
          
          // Get updated balance (transaction already updated it via createTransactionHelper)
          const [updatedBalance] = await conn4.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [student.regNumber]
          );
          const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
          
          // Update account balances from journal entry
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn4, journalEntryId, currencyId);
          
          console.log(`✅ Payment recorded: ${student.name} ${student.surname} - $${student.totalPayments.toFixed(2)} (New balance: $${newBalance.toFixed(2)})`);
          processed++;
        } catch (error) {
          console.error(`❌ Error recording payment for ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn4.commit();
      console.log(`\n📊 Payment Summary: ${processed} payments recorded, ${skipped} skipped (zero payments)`);
    } catch (error) {
      await conn4.rollback();
      throw error;
    } finally {
      conn4.release();
    }
    
    console.log('\n✅ All Grade 3 students processed successfully!\n');
    
  } catch (error) {
    console.error('\n❌ Error processing Grade 3 students:', error);
    throw error;
  } finally {
    process.exit(0);
  }
}

processGrade3Students();

