const { pool } = require('./config/database');

async function checkR96904Duplicates() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING R96904* REGISTRATION NUMBERS IN DATABASE\n');
    console.log('='.repeat(70));
    
    // Check R96904D
    console.log('\n📋 R96904D:\n');
    const [r96904d] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
      ['R96904D']
    );
    r96904d.forEach((s, idx) => {
      console.log(`   ${idx + 1}. ${s.Name} ${s.Surname}`);
    });
    
    // Check R96904N
    console.log('\n📋 R96904N:\n');
    const [r96904n] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
      ['R96904N']
    );
    r96904n.forEach((s, idx) => {
      console.log(`   ${idx + 1}. ${s.Name} ${s.Surname}`);
    });
    
    // Check R96904O
    console.log('\n📋 R96904O:\n');
    const [r96904o] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
      ['R96904O']
    );
    r96904o.forEach((s, idx) => {
      console.log(`   ${idx + 1}. ${s.Name} ${s.Surname}`);
    });
    
  } catch (error) {
    console.error('Error checking duplicates:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkR96904Duplicates();

