const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        console.log('🔍 Checking for duplicate journal entries for boarding payments...\n');
        
        const studentReg = '56-D4353';
        
        // Get boarding payments for this student
        const [payments] = await conn.execute(`
            SELECT 
                bfp.id as payment_id,
                bfp.amount_paid,
                bfp.base_currency_amount,
                bfp.payment_date,
                bfp.receipt_number,
                bfp.journal_entry_id
            FROM boarding_fees_payments bfp
            WHERE bfp.student_reg_number = ?
            ORDER BY bfp.payment_date
        `, [studentReg]);
        
        console.log(`📋 Boarding Payments for ${studentReg}:`);
        payments.forEach(p => {
            console.log(`   Payment ${p.payment_id}: $${p.base_currency_amount || p.amount_paid} on ${p.payment_date}`);
            console.log(`     - Journal Entry ID: ${p.journal_entry_id || 'None'}`);
        });
        
        // Check journal entries linked to payments
        console.log(`\n📋 Journal Entries Linked to Payments:\n`);
        for (const p of payments) {
            if (p.journal_entry_id) {
                const [je] = await conn.execute(`
                    SELECT 
                        je.id,
                        je.entry_date,
                        je.description,
                        je.reference
                    FROM journal_entries je
                    WHERE je.id = ?
                `, [p.journal_entry_id]);
                
                if (je.length > 0) {
                    console.log(`   Payment ${p.payment_id} ($${p.base_currency_amount || p.amount_paid}):`);
                    console.log(`     - Journal Entry ${je[0].id}: ${je[0].description}`);
                    console.log(`     - Date: ${je[0].entry_date}, Reference: ${je[0].reference}`);
                    
                    // Get journal lines
                    const [lines] = await conn.execute(`
                        SELECT 
                            jel.account_id,
                            jel.debit,
                            jel.credit,
                            coa.code,
                            coa.name,
                            coa.type
                        FROM journal_entry_lines jel
                        JOIN chart_of_accounts coa ON jel.account_id = coa.id
                        WHERE jel.journal_entry_id = ?
                    `, [p.journal_entry_id]);
                    
                    lines.forEach(line => {
                        console.log(`       - ${line.code} (${line.name}): Debit=${line.debit}, Credit=${line.credit}`);
                    });
                    console.log('');
                }
            }
        }
        
        // Check for ALL boarding journal entries that might be duplicates
        console.log(`\n📋 All Boarding Journal Entries for amounts $500 and $50:\n`);
        
        // Simpler query - just get all boarding journals and filter in code
        // Get all boarding journal entries
        const [allJournals] = await conn.execute(`
            SELECT 
                je.id,
                je.entry_date,
                je.description,
                je.reference,
                je.created_at
            FROM journal_entries je
            WHERE je.description LIKE '%BOARDING%'
            ORDER BY je.id ASC
        `);
        
        console.log(`   Found ${allJournals.length} boarding journal entries total:\n`);
        
        const journals500 = [];
        const journals50 = [];
        
        for (const je of allJournals) {
            const [lines] = await conn.execute(`
                SELECT 
                    jel.debit,
                    jel.credit,
                    coa.code,
                    coa.name
                FROM journal_entry_lines jel
                JOIN chart_of_accounts coa ON jel.account_id = coa.id
                WHERE jel.journal_entry_id = ?
            `, [je.id]);
            
            const cashLine = lines.find(l => l.code === '1000' || l.code === '1010');
            if (cashLine) {
                const cashAmount = parseFloat(cashLine.debit);
                if (cashAmount === 500) {
                    journals500.push({ je, lines, cashAmount });
                } else if (cashAmount === 50) {
                    journals50.push({ je, lines, cashAmount });
                }
            }
        }
        
        console.log(`   📋 Journal Entries with $500 cash debit (${journals500.length}):\n`);
        journals500.forEach(({ je, lines }) => {
            console.log(`   Journal Entry ${je.id}:`);
            console.log(`     - Date: ${je.entry_date}`);
            console.log(`     - Created: ${je.created_at}`);
            console.log(`     - Description: ${je.description}`);
            console.log(`     - Reference: ${je.reference}`);
            lines.forEach(line => {
                console.log(`       - ${line.code} (${line.name}): Debit=${line.debit}, Credit=${line.credit}`);
            });
            console.log('');
        });
        
        console.log(`   📋 Journal Entries with $50 cash debit (${journals50.length}):\n`);
        journals50.forEach(({ je, lines }) => {
            console.log(`   Journal Entry ${je.id}:`);
            console.log(`     - Date: ${je.entry_date}`);
            console.log(`     - Created: ${je.created_at}`);
            console.log(`     - Description: ${je.description}`);
            console.log(`     - Reference: ${je.reference}`);
            lines.forEach(line => {
                console.log(`       - ${line.code} (${line.name}): Debit=${line.debit}, Credit=${line.credit}`);
            });
            console.log('');
        });
        
        // Check which payments are linked to which journals
        console.log(`\n📋 Payment-Journal Links:\n`);
        for (const p of payments) {
            console.log(`   Payment ${p.payment_id} ($${p.base_currency_amount || p.amount_paid} on ${p.payment_date}):`);
            console.log(`     - Linked to Journal Entry: ${p.journal_entry_id || 'None'}`);
            
            // Check if there are OTHER journals with same amount on same date
            const matchingJournals = (p.base_currency_amount || p.amount_paid) == 500 ? journals500 : journals50;
            const paymentDateStr = p.payment_date instanceof Date ? p.payment_date.toISOString().split('T')[0] : p.payment_date.split('T')[0];
            const sameDateJournals = matchingJournals.filter(({ je }) => {
                const jeDateStr = je.entry_date instanceof Date ? je.entry_date.toISOString().split('T')[0] : je.entry_date.split('T')[0];
                return jeDateStr === paymentDateStr;
            });
            
            if (sameDateJournals.length > 1) {
                console.log(`     ⚠️  WARNING: Found ${sameDateJournals.length} journals with same amount on same date:`);
                sameDateJournals.forEach(({ je }) => {
                    console.log(`       - Journal ${je.id} (${je.entry_date}): ${je.description}`);
                });
            } else if (sameDateJournals.length === 1 && sameDateJournals[0].je.id !== p.journal_entry_id) {
                console.log(`     ⚠️  WARNING: Payment linked to Journal ${p.journal_entry_id}, but Journal ${sameDateJournals[0].je.id} exists with same amount/date`);
            }
            console.log('');
        }
        
        // Check for duplicate amounts on same dates
        console.log(`\n📋 Checking for duplicate journal entries:\n`);
        
        const [duplicateCheck] = await conn.execute(`
            SELECT 
                je.entry_date,
                je.id,
                SUM(CASE WHEN coa.code IN ('1000', '1010') THEN jel.debit ELSE 0 END) as cash_debit
            FROM journal_entries je
            JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
            JOIN chart_of_accounts coa ON jel.account_id = coa.id
            WHERE je.description LIKE '%BOARDING%'
            AND coa.code IN ('1000', '1010')
            GROUP BY je.id, je.entry_date
            HAVING cash_debit IN (500.00, 50.00)
            ORDER BY je.entry_date, cash_debit
        `);
        
        console.log(`   Found ${duplicateCheck.length} journal entries with $500 or $50 cash debits:\n`);
        const amountsByDate = {};
        duplicateCheck.forEach(dup => {
            const key = `${dup.entry_date}_${dup.cash_debit}`;
            if (!amountsByDate[key]) {
                amountsByDate[key] = [];
            }
            amountsByDate[key].push(dup.id);
        });
        
        Object.keys(amountsByDate).forEach(key => {
            const [date, amount] = key.split('_');
            const ids = amountsByDate[key];
            if (ids.length > 1) {
                console.log(`   ⚠️  DUPLICATE: Date ${date}, Amount $${amount}, Journal IDs: ${ids.join(', ')}`);
            } else {
                console.log(`   ✅ Date ${date}, Amount $${amount}, Journal ID: ${ids[0]}`);
            }
        });
        
        // Check student transactions
        console.log(`\n📋 Student Transactions for ${studentReg}:\n`);
        const [transactions] = await conn.execute(`
            SELECT 
                st.id,
                st.transaction_type,
                st.amount,
                st.description,
                st.transaction_date,
                st.journal_entry_id
            FROM student_transactions st
            WHERE st.student_reg_number = ?
            AND (st.description LIKE '%BOARDING%' OR st.description LIKE '%BOARDER%')
            ORDER BY st.transaction_date, st.id
        `, [studentReg]);
        
        transactions.forEach(t => {
            console.log(`   Transaction ${t.id}: ${t.transaction_type} $${t.amount} on ${t.transaction_date}`);
            console.log(`     - Description: ${t.description}`);
            console.log(`     - Journal Entry ID: ${t.journal_entry_id || 'None'}`);
            console.log('');
        });
        
        // Check account balances for Cash and AR
        console.log(`\n📋 Account Balances:\n`);
        const [accountBalances] = await conn.execute(`
            SELECT 
                ab.balance,
                ab.as_of_date,
                coa.code,
                coa.name,
                coa.type
            FROM account_balances ab
            JOIN chart_of_accounts coa ON ab.account_id = coa.id
            WHERE coa.code IN ('1000', '1010', '1100')
            ORDER BY coa.code, ab.as_of_date DESC
        `);
        
        const balancesByAccount = {};
        accountBalances.forEach(acc => {
            if (!balancesByAccount[acc.code]) {
                balancesByAccount[acc.code] = [];
            }
            balancesByAccount[acc.code].push(acc);
        });
        
        Object.keys(balancesByAccount).forEach(code => {
            const accs = balancesByAccount[code];
            const latest = accs[0];
            console.log(`   ${code} (${latest.name}): ${latest.balance} (as of ${latest.as_of_date})`);
        });
        
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        conn.release();
        process.exit();
    }
})();

