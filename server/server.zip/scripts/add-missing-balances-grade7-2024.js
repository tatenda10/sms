const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Students that need their balances added (newly registered)
const studentsNeedingBalances = [
  { name: 'Talent', surname: 'Choga', regNumber: 'R96905C', balance: -10 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96905M', balance: -20 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96906M', balance: -143 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96907M', balance: -150 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96908M', balance: -210 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96905N', balance: -310 }
];

async function addMissingBalances() {
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    console.log('\n💰 ADDING MISSING OUTSTANDING BALANCES\n');
    console.log('='.repeat(70));
    
    // Get or create journal
    let journal_id = 1;
    const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
    if (journalCheck.length === 0) {
      const [journalByName] = await conn.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
      if (journalByName.length > 0) {
        journal_id = journalByName[0].id;
      } else {
        const [journalResult] = await conn.execute(
          'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
          ['General Journal', 'Journal for general transactions including opening balances', 1]
        );
        journal_id = journalResult.insertId;
      }
    }
    
    // Get accounts
    const [accountsReceivable] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
      ['1100', 'Asset']
    );
    
    const [retainedEarnings] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
      ['3998']
    );
    
    let processed = 0;
    
    for (const student of studentsNeedingBalances) {
      const debtAmount = Math.abs(student.balance);
      
      // Check if transaction already exists
      const [existingTxn] = await conn.execute(
        'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ?',
        [student.regNumber, `%Opening Balance - Outstanding Debt%`]
      );
      
      if (existingTxn.length > 0) {
        console.log(`⏭️  ${student.name} ${student.surname} already has outstanding balance transaction`);
        continue;
      }
      
      const reference = `OB-${student.regNumber}-${Date.now()}`;
      const journalDescription = `Opening Balance - Outstanding Debt for ${student.name} ${student.surname}`;
      
      // Create journal entry
      const [journalResult] = await conn.execute(`
        INSERT INTO journal_entries (
          journal_id, entry_date, description, reference,
          created_by, created_at, updated_at
        ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
      `, [journal_id, journalDescription, reference, 1]);
      
      const journalEntryId = journalResult.insertId;
      
      // Create journal entry lines
      await conn.execute(`
        INSERT INTO journal_entry_lines (
          journal_entry_id, account_id, debit, credit, description
        ) VALUES (?, ?, ?, ?, ?)
      `, [journalEntryId, accountsReceivable[0].id, debtAmount, 0, journalDescription]);
      
      await conn.execute(`
        INSERT INTO journal_entry_lines (
          journal_entry_id, account_id, debit, credit, description
        ) VALUES (?, ?, ?, ?, ?)
      `, [journalEntryId, retainedEarnings[0].id, 0, debtAmount, journalDescription]);
      
      // Create DEBIT transaction
      await StudentTransactionController.createTransactionHelper(
        student.regNumber,
        'DEBIT',
        debtAmount,
        `Opening Balance - Outstanding Debt: ${reference}`,
        {
          created_by: 1,
          journal_entry_id: journalEntryId
        }
      );
      
      // Update account balances
      await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
      
      // Get updated balance
      const [updatedBalance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
      
      console.log(`✅ Added balance: ${student.name} ${student.surname} - $${debtAmount.toFixed(2)} (Balance: $${newBalance.toFixed(2)})`);
      processed++;
    }
    
    await conn.commit();
    console.log(`\n✅ Successfully added ${processed} outstanding balances!`);
    
  } catch (error) {
    await conn.rollback();
    console.error('\n❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

addMissingBalances();

