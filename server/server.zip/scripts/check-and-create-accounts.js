const { pool } = require('../config/database');

async function checkAndCreateAccounts() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking required chart of accounts for transport payments...');
    
    const requiredAccounts = [
      { code: '1000', name: 'Cash', type: 'Asset' },
      { code: '1010', name: 'Bank Account', type: 'Asset' },
      { code: '4000', name: 'Transport Revenue', type: 'Revenue' }
    ];
    
    for (const account of requiredAccounts) {
      console.log(`\n⚡ Checking account ${account.code} - ${account.name}...`);
      
      const [existing] = await connection.execute(
        'SELECT id, code, name, type, is_active FROM chart_of_accounts WHERE code = ?',
        [account.code]
      );
      
      if (existing.length > 0) {
        const acc = existing[0];
        console.log(`   ✅ Account exists: ${acc.code} - ${acc.name} (${acc.type}) - ${acc.is_active ? 'Active' : 'Inactive'}`);
        
        if (!acc.is_active) {
          console.log(`   ⚠️  Account is inactive, activating...`);
          await connection.execute(
            'UPDATE chart_of_accounts SET is_active = 1 WHERE code = ?',
            [account.code]
          );
          console.log(`   ✅ Account activated`);
        }
      } else {
        console.log(`   ❌ Account missing, creating...`);
        await connection.execute(
          `INSERT INTO chart_of_accounts (code, name, type, is_active) VALUES (?, ?, ?, 1)`,
          [account.code, account.name, account.type]
        );
        console.log(`   ✅ Account created: ${account.code} - ${account.name}`);
      }
    }
    
    console.log('\n🎉 Chart of accounts check completed!');
    console.log('\n📋 Required accounts for transport payments:');
    console.log('   • 1000 - Cash (Asset)');
    console.log('   • 1010 - Bank Account (Asset)');
    console.log('   • 4000 - Transport Revenue (Revenue)');
    
  } catch (error) {
    console.error('\n❌ Error checking/creating accounts:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkAndCreateAccounts()
    .then(() => {
      console.log('\n✅ Chart of accounts check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Chart of accounts check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkAndCreateAccounts;
