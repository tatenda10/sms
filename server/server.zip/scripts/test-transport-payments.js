const { pool } = require('../config/database');

async function testTransportPayments() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing transport payments system...');
    
    // Check if transport_payments table has any data
    console.log('\n📋 Checking transport_payments table...');
    const [payments] = await connection.execute('SELECT COUNT(*) as count FROM transport_payments');
    console.log(`   • Total payments in database: ${payments[0].count}`);
    
    if (payments[0].count > 0) {
      // Show recent payments
      const [recentPayments] = await connection.execute(`
        SELECT 
          tp.id,
          tp.student_reg_number,
          tp.route_id,
          tp.amount,
          tp.payment_date,
          tp.reference_number,
          tp.transport_fee_id,
          tr.route_name,
          CONCAT(s.Name, ' ', s.Surname) as student_name
        FROM transport_payments tp
        LEFT JOIN transport_routes tr ON tp.route_id = tr.id
        LEFT JOIN students s ON tp.student_reg_number = s.RegNumber
        ORDER BY tp.payment_date DESC
        LIMIT 5
      `);
      
      console.log('\n📊 Recent payments:');
      recentPayments.forEach((payment, index) => {
        console.log(`   ${index + 1}. ${payment.student_name} (${payment.student_reg_number})`);
        console.log(`      Route: ${payment.route_name || 'Unknown'}`);
        console.log(`      Amount: $${payment.amount}`);
        console.log(`      Date: ${payment.payment_date}`);
        console.log(`      Reference: ${payment.reference_number}`);
        console.log(`      Fee ID: ${payment.transport_fee_id || 'NULL (Direct Payment)'}`);
        console.log('');
      });
    }
    
    // Test the getAllPayments query structure
    console.log('\n🔍 Testing getAllPayments query structure...');
    try {
      const [testPayments] = await connection.execute(`
        SELECT 
           tp.*,
           COALESCE(tf.status, 'paid') as status,
           CONCAT(s.Name, ' ', s.Surname) as student_name,
           s.RegNumber as student_number,
           COALESCE(str.student_reg_number, tp.student_reg_number) as student_reg_number,
           tr.route_name,
           tr.route_code,
           COALESCE(str.pickup_point, 'Direct Payment') as pickup_point,
           COALESCE(str.dropoff_point, 'Direct Payment') as dropoff_point
         FROM transport_payments tp
         LEFT JOIN transport_fees tf ON tp.transport_fee_id = tf.id
         LEFT JOIN student_transport_registrations str ON tf.student_registration_id = str.id
         LEFT JOIN students s ON (str.student_reg_number = s.RegNumber OR tp.student_reg_number = s.RegNumber)
         LEFT JOIN transport_routes tr ON (str.route_id = tr.id OR tp.route_id = tr.id)
         ORDER BY tp.payment_date DESC
         LIMIT 5
      `);
      
      console.log(`   ✅ Query executed successfully - found ${testPayments.length} payments`);
      
      if (testPayments.length > 0) {
        console.log('\n📊 Query results:');
        testPayments.forEach((payment, index) => {
          console.log(`   ${index + 1}. ${payment.student_name} - ${payment.route_name} - $${payment.amount}`);
        });
      }
      
    } catch (queryError) {
      console.log(`   ❌ Query failed: ${queryError.message}`);
    }
    
    // Check transport_fee_id column nullability
    console.log('\n🔍 Checking transport_fee_id column...');
    const [columns] = await connection.execute('DESCRIBE transport_payments');
    const transportFeeIdColumn = columns.find(col => col.Field === 'transport_fee_id');
    
    if (transportFeeIdColumn) {
      console.log(`   • transport_fee_id: ${transportFeeIdColumn.Null === 'YES' ? '✅ NULL allowed' : '❌ NULL not allowed'}`);
    }
    
    // Check for direct payments (transport_fee_id IS NULL)
    const [directPayments] = await connection.execute('SELECT COUNT(*) as count FROM transport_payments WHERE transport_fee_id IS NULL');
    console.log(`   • Direct payments (transport_fee_id IS NULL): ${directPayments[0].count}`);
    
    // Check for fee-based payments (transport_fee_id IS NOT NULL)
    const [feeBasedPayments] = await connection.execute('SELECT COUNT(*) as count FROM transport_payments WHERE transport_fee_id IS NOT NULL');
    console.log(`   • Fee-based payments (transport_fee_id IS NOT NULL): ${feeBasedPayments[0].count}`);
    
  } catch (error) {
    console.error('\n❌ Error testing transport payments:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testTransportPayments()
    .then(() => {
      console.log('\n✅ Transport payments test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Transport payments test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testTransportPayments;
