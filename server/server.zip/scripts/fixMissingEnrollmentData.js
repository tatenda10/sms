const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const StudentTransactionController = require('../controllers/students/studentTransactionController');
const StudentBalanceService = require('../services/studentBalanceService');
const AccountBalanceService = require('../services/accountBalanceService');

// Helper function to create journal entries for enrollment (same as in enrollmentController)
async function createEnrollmentJournalEntries(conn, student_regnumber, amount, description, term, academic_year, created_by) {
    try {
        // Get account IDs
        const [accountsReceivable] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['1100', 'Asset'] // Accounts Receivable - Tuition
        );
        
        const [tuitionRevenue] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['4000', 'Revenue'] // Tuition Revenue - Total
        );

        if (accountsReceivable.length === 0 || tuitionRevenue.length === 0) {
            throw new Error('Required accounts not found in chart of accounts');
        }

        const accountsReceivableId = accountsReceivable[0].id;
        const tuitionRevenueId = tuitionRevenue[0].id;

        // Get or create Fees Journal (ID: 6)
        let journalId = 6;
        const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journalId]);
        if (journalCheck.length === 0) {
            // Try to find any existing journal
            const [existingJournal] = await conn.execute('SELECT id FROM journals ORDER BY id LIMIT 1');
            if (existingJournal.length > 0) {
                journalId = existingJournal[0].id;
            } else {
                // Create Fees Journal if no journals exist
                const [journalResult] = await conn.execute(
                    'INSERT INTO journals (id, name, description, is_active) VALUES (?, ?, ?, ?)',
                    [6, 'Fees Journal', 'All student fee-related transactions, including tuition, exam fees, and boarding fees.', 1]
                );
                journalId = journalResult.insertId || 6;
            }
        }

        // Create journal entry (using Fees Journal)
        const [journalEntry] = await conn.execute(
            `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by) 
             VALUES (?, CURDATE(), ?, ?, ?)`,
            [
                journalId,
                description,
                `ENROLL-${student_regnumber}-${Date.now()}`,
                created_by
            ]
        );

        const journalEntryId = journalEntry.insertId;

        // Create journal entry lines
        const journalLines = [
            {
                journal_entry_id: journalEntryId,
                account_id: accountsReceivableId,
                debit_amount: amount,
                credit_amount: 0,
                description: `Accounts Receivable - ${student_regnumber}`
            },
            {
                journal_entry_id: journalEntryId,
                account_id: tuitionRevenueId,
                debit_amount: 0,
                credit_amount: amount,
                description: `Tuition Revenue - ${student_regnumber}`
            }
        ];

        for (const line of journalLines) {
            await conn.execute(
                `INSERT INTO journal_entry_lines 
                 (journal_entry_id, account_id, debit, credit, description) 
                 VALUES (?, ?, ?, ?, ?)`,
                [
                    line.journal_entry_id,
                    line.account_id,
                    line.debit_amount,
                    line.credit_amount,
                    line.description
                ]
            );
        }

        console.log(`   ✅ Created journal entry ${journalEntryId} for enrollment: ${student_regnumber}, Amount: ${amount}`);
        return journalEntryId;

    } catch (error) {
        console.error(`   ❌ Error creating enrollment journal entries for ${student_regnumber}:`, error);
        throw error;
    }
}

async function fixMissingEnrollmentData() {
    const conn = await pool.getConnection();
    
    try {
        await conn.beginTransaction();
        
        console.log('🔧 Starting to fix missing enrollment data...\n');
        
        // Get all active enrollments without transactions OR without journal entries
        const [enrollments] = await conn.execute(`
            SELECT 
                e.id as enrollment_id,
                e.student_regnumber,
                e.gradelevel_class_id,
                e.status,
                e.created_at as enrollment_date,
                s.Name,
                s.Surname,
                gc.name as class_name,
                st.name as stream_name,
                st_t.id as transaction_id,
                st_t.journal_entry_id
            FROM enrollments_gradelevel_classes e
            JOIN students s ON e.student_regnumber = s.RegNumber
            JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
            JOIN stream st ON gc.stream_id = st.id
            LEFT JOIN student_transactions st_t ON st_t.student_reg_number = e.student_regnumber
                AND st_t.enrollment_id = e.id
                AND st_t.transaction_type = 'DEBIT'
                AND st_t.description LIKE '%TUITION INVOICE%'
            WHERE e.status = 'active'
            AND (st_t.id IS NULL OR st_t.journal_entry_id IS NULL)
            ORDER BY e.created_at DESC
        `);
        
        console.log(`📊 Found ${enrollments.length} enrollments missing transactions or journal entries\n`);
        
        const results = {
            fixed: [],
            skipped: [],
            errors: []
        };
        
        // Get default currency (USD - ID 1) or first available
        const [currencies] = await conn.execute('SELECT id FROM currencies ORDER BY id LIMIT 1');
        const defaultCurrencyId = currencies.length > 0 ? currencies[0].id : 1;
        
        // Get default user (system user - ID 1) or first available
        const [users] = await conn.execute('SELECT id FROM users ORDER BY id LIMIT 1');
        const defaultUserId = users.length > 0 ? users[0].id : 1;
        
        for (const enrollment of enrollments) {
            const studentReg = enrollment.student_regnumber;
            const enrollmentId = enrollment.enrollment_id;
            const gradelevelClassId = enrollment.gradelevel_class_id;
            
            try {
                console.log(`\n📝 Processing: ${studentReg} (${enrollment.Name} ${enrollment.Surname}) - ${enrollment.class_name} (${enrollment.stream_name})`);
                
                // Check if transaction already exists but missing journal entry
                let transactionId = enrollment.transaction_id;
                let journalEntryId = enrollment.journal_entry_id || null;
                let needsJournalEntry = !enrollment.journal_entry_id;
                
                if (transactionId && needsJournalEntry) {
                    console.log(`   ℹ️  Transaction ${transactionId} exists but missing journal entry - will create journal entry only`);
                }
                
                // Get current term and academic year from class term year structure
                const [classTermYears] = await conn.execute(
                    'SELECT term, academic_year FROM class_term_year WHERE gradelevel_class_id = ?',
                    [gradelevelClassId]
                );
                
                let enrollmentTerm = null;
                let enrollmentAcademicYear = null;
                
                if (classTermYears.length > 0) {
                    enrollmentTerm = classTermYears[0].term;
                    enrollmentAcademicYear = classTermYears[0].academic_year;
                }
                
                // Get invoice structure for this class and term/year
                let feeAmount = 0;
                let invoiceTerm = null;
                let invoiceAcademicYear = null;
                
                if (enrollmentTerm && enrollmentAcademicYear) {
                    const [invoiceStructures] = await conn.execute(
                        'SELECT total_amount, term, academic_year, currency_id FROM invoice_structures WHERE gradelevel_class_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                        [gradelevelClassId, enrollmentTerm, enrollmentAcademicYear]
                    );
                    
                    if (invoiceStructures.length > 0) {
                        feeAmount = parseFloat(invoiceStructures[0].total_amount);
                        invoiceTerm = invoiceStructures[0].term;
                        invoiceAcademicYear = invoiceStructures[0].academic_year;
                    }
                }
                
                // If no invoice structure found, try to get the most recent one for this class
                if (feeAmount === 0) {
                    const [recentInvoice] = await conn.execute(
                        'SELECT total_amount, term, academic_year, currency_id FROM invoice_structures WHERE gradelevel_class_id = ? AND is_active = TRUE ORDER BY academic_year DESC, term DESC LIMIT 1',
                        [gradelevelClassId]
                    );
                    
                    if (recentInvoice.length > 0) {
                        feeAmount = parseFloat(recentInvoice[0].total_amount);
                        invoiceTerm = recentInvoice[0].term;
                        invoiceAcademicYear = recentInvoice[0].academic_year;
                        console.log(`   ⚠️  Using most recent invoice structure: Term ${invoiceTerm}, Year ${invoiceAcademicYear}`);
                    }
                }
                
                if (feeAmount === 0) {
                    results.skipped.push({
                        ...enrollment,
                        reason: 'No invoice structure found'
                    });
                    console.log(`   ⏭️  Skipped: No invoice structure found for class ${gradelevelClassId}`);
                    continue;
                }
                
                // Format term to just the number (e.g., "Term 1" -> "1")
                let formattedTerm = null;
                if (invoiceTerm) {
                    const termMatch = invoiceTerm.match(/\d+/);
                    formattedTerm = termMatch ? termMatch[0] : invoiceTerm;
                }
                
                const className = enrollment.class_name;
                const streamName = enrollment.stream_name;
                const description = `TUITION INVOICE - ${className} (${streamName})`;
                
                // 1. Ensure student balance record exists
                await StudentBalanceService.ensureBalanceRecord(studentReg, conn);
                console.log(`   ✅ Student balance record ensured`);
                
                // 2. Create DEBIT transaction if it doesn't exist
                if (!transactionId) {
                    const [transactionResult] = await conn.execute(
                        `INSERT INTO student_transactions 
                         (student_reg_number, transaction_type, amount, description, term, academic_year, 
                          class_id, enrollment_id, transaction_date, created_by) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)`,
                        [
                            studentReg,
                            'DEBIT',
                            feeAmount,
                            description,
                            formattedTerm || (invoiceTerm ? invoiceTerm.replace(/Term\s*/i, '') : null),
                            invoiceAcademicYear || enrollmentAcademicYear || null,
                            gradelevelClassId,
                            enrollmentId,
                            defaultUserId
                        ]
                    );
                    
                    transactionId = transactionResult.insertId;
                    console.log(`   ✅ Created DEBIT transaction ${transactionId} for amount ${feeAmount}`);
                    
                    // 3. Update student balance
                    await StudentBalanceService.updateBalanceOnTransaction(
                        studentReg,
                        'DEBIT',
                        feeAmount,
                        conn
                    );
                    console.log(`   ✅ Updated student balance`);
                } else {
                    // Get transaction amount if transaction already exists
                    const [existingTransaction] = await conn.execute(
                        'SELECT amount FROM student_transactions WHERE id = ?',
                        [transactionId]
                    );
                    if (existingTransaction.length > 0) {
                        feeAmount = parseFloat(existingTransaction[0].amount);
                        console.log(`   ℹ️  Using existing transaction ${transactionId} with amount ${feeAmount}`);
                    }
                }
                
                // 4. Create journal entries (only if missing)
                if (needsJournalEntry) {
                    journalEntryId = await createEnrollmentJournalEntries(
                        conn,
                        studentReg,
                        feeAmount,
                        description,
                        invoiceTerm || enrollmentTerm,
                        invoiceAcademicYear || enrollmentAcademicYear,
                        defaultUserId
                    );
                    
                    // 5. Link transaction to journal entry
                    await conn.execute(
                        'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
                        [journalEntryId, transactionId]
                    );
                    
                    // 6. Update account balances
                    await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId);
                    console.log(`   ✅ Updated account balances`);
                } else {
                    console.log(`   ℹ️  Journal entry already exists, skipping`);
                }
                
                results.fixed.push({
                    ...enrollment,
                    transactionId,
                    journalEntryId,
                    amount: feeAmount,
                    term: invoiceTerm || enrollmentTerm,
                    academicYear: invoiceAcademicYear || enrollmentAcademicYear
                });
                
                console.log(`   ✅ Successfully fixed enrollment ${enrollmentId}`);
                
            } catch (error) {
                console.error(`   ❌ Error fixing enrollment ${enrollmentId} for student ${studentReg}:`, error.message);
                results.errors.push({
                    ...enrollment,
                    error: error.message
                });
            }
        }
        
        await conn.commit();
        
        // Print summary
        console.log('\n' + '='.repeat(80));
        console.log('📋 FIX SUMMARY');
        console.log('='.repeat(80));
        console.log(`✅ Fixed: ${results.fixed.length}`);
        console.log(`⏭️  Skipped: ${results.skipped.length}`);
        console.log(`❌ Errors: ${results.errors.length}`);
        console.log('='.repeat(80));
        
        if (results.skipped.length > 0) {
            console.log('\n⏭️  SKIPPED ENROLLMENTS (No invoice structure):');
            results.skipped.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
            });
        }
        
        if (results.errors.length > 0) {
            console.log('\n❌ ERRORS:');
            results.errors.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}): ${e.error}`);
            });
        }
        
        // Save detailed report
        const fs = require('fs');
        const report = {
            timestamp: new Date().toISOString(),
            summary: {
                fixed: results.fixed.length,
                skipped: results.skipped.length,
                errors: results.errors.length
            },
            fixed: results.fixed,
            skipped: results.skipped,
            errors: results.errors
        };
        
        const reportPath = path.join(__dirname, `enrollment_fix_report_${new Date().toISOString().split('T')[0]}.json`);
        fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
        console.log(`\n💾 Detailed report saved to: ${reportPath}`);
        
    } catch (error) {
        await conn.rollback();
        console.error('❌ Fatal error:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the fix
fixMissingEnrollmentData()
    .then(() => {
        console.log('\n✅ Fix completed');
        process.exit(0);
    })
    .catch(error => {
        console.error('❌ Fatal error:', error);
        process.exit(1);
    });

