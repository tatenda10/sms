const { pool } = require('./config/database');

async function checkStudentBalance() {
    const connection = await pool.getConnection();
    const studentRegNumber = 'R79290B';
    
    try {
        console.log(`🔍 Checking balance and transactions for student ${studentRegNumber}...\n`);
        
        // Get student details
        const [students] = await connection.execute(
            'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
            [studentRegNumber]
        );
        
        if (students.length === 0) {
            throw new Error(`Student with registration number ${studentRegNumber} not found`);
        }
        
        const student = students[0];
        console.log(`✅ Student: ${student.Name} ${student.Surname}\n`);
        
        // Get current balance
        const [balanceRows] = await connection.execute(
            'SELECT current_balance, last_updated FROM student_balances WHERE student_reg_number = ?',
            [studentRegNumber]
        );
        
        const currentBalance = balanceRows.length > 0 ? balanceRows[0].current_balance : 0;
        const lastUpdated = balanceRows.length > 0 ? balanceRows[0].last_updated : null;
        console.log(`📊 Current Balance: ${currentBalance}`);
        console.log(`📅 Last Updated: ${lastUpdated || 'Never'}\n`);
        
        // Get all transactions
        const [transactions] = await connection.execute(
            `SELECT 
                id, 
                transaction_type, 
                amount, 
                description, 
                transaction_date,
                journal_entry_id
             FROM student_transactions 
             WHERE student_reg_number = ? 
             ORDER BY transaction_date DESC, id DESC`,
            [studentRegNumber]
        );
        
        console.log(`📝 Transaction History (${transactions.length} transactions):`);
        console.log('─'.repeat(100));
        
        if (transactions.length === 0) {
            console.log('   No transactions found.');
        } else {
            let runningBalance = 0;
            transactions.forEach((tx, index) => {
                const amount = parseFloat(tx.amount);
                if (tx.transaction_type === 'DEBIT') {
                    runningBalance -= amount;
                } else if (tx.transaction_type === 'CREDIT') {
                    runningBalance += amount;
                }
                
                console.log(`${index + 1}. ${tx.transaction_type.padEnd(7)} | ${amount.toFixed(2).padStart(10)} | Balance: ${runningBalance.toFixed(2).padStart(10)}`);
                console.log(`   Description: ${tx.description}`);
                console.log(`   Date: ${tx.transaction_date}`);
                if (tx.journal_entry_id) {
                    console.log(`   Journal Entry ID: ${tx.journal_entry_id}`);
                }
                console.log('');
            });
        }
        
        // Check for opening balance entries
        const [openingBalances] = await connection.execute(
            `SELECT 
                je.id as journal_entry_id,
                je.description,
                je.reference,
                je.entry_date,
                st.id as transaction_id,
                st.transaction_type,
                st.amount
             FROM journal_entries je
             LEFT JOIN student_transactions st ON st.journal_entry_id = je.id
             WHERE je.description LIKE ? 
               AND je.description LIKE ?
             ORDER BY je.entry_date DESC`,
            [`%${studentRegNumber}%`, '%Opening Balance%']
        );
        
        console.log(`\n📚 Opening Balance Journal Entries (${openingBalances.length} entries):`);
        console.log('─'.repeat(100));
        
        if (openingBalances.length === 0) {
            console.log('   No opening balance journal entries found.');
        } else {
            openingBalances.forEach((entry, index) => {
                console.log(`${index + 1}. Journal Entry ID: ${entry.journal_entry_id}`);
                console.log(`   Reference: ${entry.reference}`);
                console.log(`   Description: ${entry.description}`);
                console.log(`   Entry Date: ${entry.entry_date}`);
                if (entry.transaction_id) {
                    console.log(`   Transaction: ${entry.transaction_type} ${entry.amount}`);
                }
                console.log('');
            });
        }
        
    } catch (error) {
        console.error('\n❌ ERROR:', error.message);
        console.error(error);
        process.exit(1);
    } finally {
        connection.release();
        process.exit(0);
    }
}

// Run the check
checkStudentBalance();

