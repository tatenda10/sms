const { pool } = require('./config/database');

async function verifyBalances() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n📊 VERIFYING GRADE 7 2024 STUDENT BALANCES\n');
    console.log('='.repeat(70));
    
    const studentsToCheck = [
      { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', expectedBalance: -340 },
      { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', expectedBalance: -80 },
      { name: 'Talent', surname: 'Choga', regNumber: 'R96904D', expectedBalance: -10 },
      { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96904O', expectedBalance: -310 },
      { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', expectedBalance: -210 }
    ];
    
    for (const student of studentsToCheck) {
      // Get current balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      
      // Get transactions
      const [transactions] = await conn.execute(
        'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY created_at',
        [student.regNumber]
      );
      
      // Calculate balance from transactions
      let calculatedBalance = 0;
      transactions.forEach(txn => {
        if (txn.transaction_type === 'DEBIT') {
          calculatedBalance -= parseFloat(txn.amount);
        } else if (txn.transaction_type === 'CREDIT') {
          calculatedBalance += parseFloat(txn.amount);
        }
      });
      
      const match = Math.abs(currentBalance - student.expectedBalance) < 0.01;
      const calcMatch = Math.abs(calculatedBalance - student.expectedBalance) < 0.01;
      
      console.log(`\n👤 ${student.name} ${student.surname} (${student.regNumber})`);
      console.log(`   Expected Balance: $${student.expectedBalance.toFixed(2)}`);
      console.log(`   Database Balance: $${currentBalance.toFixed(2)} ${match ? '✅' : '❌'}`);
      console.log(`   Calculated Balance: $${calculatedBalance.toFixed(2)} ${calcMatch ? '✅' : '❌'}`);
      console.log(`   Transactions (${transactions.length}):`);
      transactions.forEach((txn, idx) => {
        const sign = txn.transaction_type === 'DEBIT' ? '-' : '+';
        console.log(`      ${idx + 1}. ${txn.transaction_type} ${sign}$${parseFloat(txn.amount).toFixed(2)} - ${txn.description.substring(0, 60)}`);
      });
    }
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error verifying balances:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

verifyBalances();

