const { pool } = require('./config/database');
const StudentBalanceService = require('./services/studentBalanceService');

// Clean up duplicate transactions for Grade 7 students
async function cleanupDuplicates() {
  console.log('\n🧹 Cleaning up duplicate transactions...\n');
  const conn = await pool.getConnection();
  
  try {
    const regNumbers = [
      'R00001N', 'R00001P', 'R00001K', 'R00001M', 'R00002M', 'R00001R', 'R00001J',
      'R00002J', 'R00001A', 'R00001T', 'R00002N', 'R00003N', 'R00003M', 'R00001S',
      'R00002S', 'R00004M', 'R00001B', 'R00003S', 'R00002A', 'R00003J', 'R00004J',
      'R00004K', 'R00002B', 'R00005J'
    ];
    
    await conn.beginTransaction();
    
    for (const regNumber of regNumbers) {
      // Get all transactions for this student
      const [txns] = await conn.execute(
        'SELECT id, transaction_type, amount, description, created_at FROM student_transactions WHERE student_reg_number = ? ORDER BY id',
        [regNumber]
      );
      
      // Find duplicates by description pattern
      const seen = new Map();
      const toDelete = [];
      
      for (const txn of txns) {
        // Create a key based on transaction type, amount, and description pattern
        const key = `${txn.transaction_type}-${txn.amount}-${txn.description.substring(0, 50)}`;
        
        if (seen.has(key)) {
          // This is a duplicate - keep the first one, delete this one
          toDelete.push(txn.id);
          console.log(`  Found duplicate transaction ${txn.id} for ${regNumber}: ${txn.description.substring(0, 40)}`);
        } else {
          seen.set(key, txn.id);
        }
      }
      
      // Delete duplicates (keep the first occurrence)
      if (toDelete.length > 0) {
        for (const id of toDelete) {
          await conn.execute('DELETE FROM student_transactions WHERE id = ?', [id]);
        }
        console.log(`  Deleted ${toDelete.length} duplicate(s) for ${regNumber}`);
      }
    }
    
    await conn.commit();
    console.log('\n✅ Cleanup complete. Recalculating balances...\n');
    
    // Recalculate all balances
    for (const regNumber of regNumbers) {
      await StudentBalanceService.recalculateBalance(regNumber, conn);
    }
    
    console.log('✅ All balances recalculated\n');
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

cleanupDuplicates().then(() => process.exit(0)).catch(err => {
  console.error(err);
  process.exit(1);
});

