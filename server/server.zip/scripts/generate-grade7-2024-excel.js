const ExcelJS = require('exceljs');
const { pool } = require('./config/database');

// Student data extracted from the 2024 Grade 7 sheet - focusing on names and balances only
const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", balance: -260 }, // -20 + -240
  { name: 'Anita', surname: 'Chivete', balance: -30 }, // -20 + -10
  { name: 'Talent', surname: 'Choga', balance: -20 }, // 0 + -20
  { name: 'Tapiwa', surname: 'Furutuna', balance: -60 }, // -20 + -40
  { name: 'Tanyaradzwa', surname: 'Kabvura', balance: -30 }, // -10 + -20
  { name: 'Goodson', surname: 'Kankuni', balance: -55 }, // 0 + -55
  { name: 'Adience', surname: 'Madzivaidze', balance: -10 }, // -10 + 0
  { name: 'Kaine', surname: 'Majoni', balance: 0 }, // 0 + 0
  { name: 'Tawonga', surname: 'Masango', balance: -16 }, // -10 + -6
  { name: 'Donald', surname: 'Mlambo', balance: 0 }, // 0 + 0
  { name: 'Macduff', surname: 'Nyama', balance: 0 }, // -20+20 = 0
  { name: 'Samantha', surname: 'Munyanyi', balance: -20 }, // -20 + 0
  { name: 'Leeroy', surname: 'Muzanamombe', balance: -63 }, // -20 + -43
  { name: 'M Deline', surname: 'Nhandara', balance: -20 }, // -20 + 0
  { name: 'Aisha', surname: 'Singende', balance: -20 }, // -20 + 0
  { name: 'C Tinotenda', surname: 'Sithole', balance: -85 }, // -190 + 105 (50+55)
  { name: 'Anesu', surname: 'Mutengu', balance: -100 }, // -20 + -80
  { name: 'Ruvimbo', surname: 'Jongwe', balance: -40 }, // -20 + -20
  { name: 'Maseline', surname: 'Gwese', balance: -130 }, // -20 + -110
  { name: 'Sibongile', surname: 'Nyoni', balance: -60 }, // -20 + -40
  { name: 'Tinashe', surname: 'Antonio', balance: 0 }, // 0 + 0
  { name: 'Queen', surname: 'Muswati', balance: -130 }, // -10 + -120
  { name: 'Chipo', surname: 'Nyambodza', balance: -230 } // -20 + -210
];

// Function to generate registration number based on existing pattern
async function generateRegNumber(name, surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 0;
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY RegNumber DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  // Generate new number (increment from max)
  const newNumber = maxNumber + 1;
  const numberStr = String(newNumber).padStart(5, '0');
  
  // Generate letter suffix based on surname first letter (or name if no surname)
  const letterSource = surname || name;
  const firstLetter = letterSource.charAt(0).toUpperCase();
  const letter = /[A-Z]/.test(firstLetter) ? firstLetter : 'A';
  
  const regNumber = `R${numberStr}${letter}`;
  
  // Check for duplicates and adjust if needed
  if (existingNumbers.has(regNumber)) {
    // If duplicate, try next letter
    const nextLetter = String.fromCharCode(letter.charCodeAt(0) + 1);
    return `R${numberStr}${nextLetter > 'Z' ? 'A' : nextLetter}`;
  }
  
  existingNumbers.add(regNumber);
  return regNumber;
}

async function generateExcel() {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grade 7 2024 Students');
  
  // Set column headers
  worksheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Surname', key: 'surname', width: 20 },
    { header: 'Registration Number', key: 'regNumber', width: 18 },
    { header: 'Balance', key: 'balance', width: 15 }
  ];
  
  // Style the header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Get existing registration numbers to avoid duplicates
  const existingNumbers = new Set();
  try {
    const [existing] = await pool.execute('SELECT RegNumber FROM students');
    existing.forEach(row => existingNumbers.add(row.RegNumber));
  } catch (error) {
    console.log('Could not fetch existing reg numbers');
  }
  
  // Add student data
  for (const student of studentData) {
    const regNumber = await generateRegNumber(student.name, student.surname, existingNumbers);
    
    worksheet.addRow({
      name: student.name,
      surname: student.surname,
      regNumber: regNumber,
      balance: student.balance
    });
  }
  
  // Format balance column (negative values in red)
  worksheet.getColumn('balance').numFmt = '$#,##0.00';
  
  // Add conditional formatting for negative balances
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) { // Skip header
      const balanceCell = row.getCell('balance');
      if (balanceCell.value < 0) {
        balanceCell.font = { color: { argb: 'FFFF0000' } }; // Red
      }
    }
  });
  
  // Save the file
  const filename = 'Grade7_2024_Students_Data.xlsx';
  await workbook.xlsx.writeFile(filename);
  console.log(`\n✅ Excel file created: ${filename}`);
  console.log(`📊 Total students: ${studentData.length}`);
  console.log(`\n📋 Columns: Name, Surname, Registration Number, Balance`);
  
  // Close database connection
  await pool.end();
}

generateExcel().catch(error => {
  console.error('Error generating Excel file:', error);
  process.exit(1);
});

