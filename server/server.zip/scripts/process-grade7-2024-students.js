const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Final corrected student data from the Excel (Grade 7 2024)
const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96904D', balance: -10 },
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96904N', balance: -20 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96904N', balance: -143 },
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96904N', balance: -150 },
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5 },
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96904N', balance: -210 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96904O', balance: -310 }
];

async function processGrade72024Students() {
  console.log('\n📚 PROCESSING GRADE 7 2024 STUDENTS\n');
  console.log('='.repeat(60));
  console.log('⚠️  NOTE: Students will NOT be enrolled to any class\n');
  
  try {
    // STEP 1: Register students
    console.log('\n🔄 STEP 1: Registering students...\n');
    const conn1 = await pool.getConnection();
    let registered = 0;
    let skipped = 0;
    
    try {
      await conn1.beginTransaction();
      
      for (const student of studentData) {
        try {
          // Check if student already exists
          const [existing] = await conn1.execute(
            'SELECT RegNumber FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (existing.length > 0) {
            console.log(`⏭️  Student ${student.name} ${student.surname} (${student.regNumber}) already registered`);
            skipped++;
            continue;
          }
          
          // Register student with random details for Grade 7 2024 (around 2009-2010)
          const year = 2009;
          const month = Math.floor(Math.random() * 12) + 1;
          const day = Math.floor(Math.random() * 28) + 1;
          const dateOfBirth = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const gender = Math.random() > 0.5 ? 'Male' : 'Female';
          const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
          const address = 'Address not provided';
          
          // Insert student
          await conn1.execute(`
            INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
          
          // Insert guardian
          const guardianName = `Guardian of ${student.name}`;
          const guardianSurname = student.surname;
          const guardianPhone = `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
          const relationship = 'Parent';
          
          await conn1.execute(`
            INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
            VALUES (?, ?, ?, ?, ?, ?)
          `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, relationship]);
          
          // Create initial balance record
          await conn1.execute(`
            INSERT INTO student_balances (student_reg_number, current_balance)
            VALUES (?, 0)
            ON DUPLICATE KEY UPDATE current_balance = current_balance
          `, [student.regNumber]);
          
          console.log(`✅ Registered: ${student.name} ${student.surname} (${student.regNumber})`);
          registered++;
        } catch (error) {
          console.error(`❌ Error registering ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn1.commit();
      console.log(`\n📊 Registration Summary: ${registered} registered, ${skipped} already existed`);
    } catch (error) {
      await conn1.rollback();
      throw error;
    } finally {
      conn1.release();
    }
    
    // STEP 2: Add outstanding balances for students with negative balances
    console.log('\n🔄 STEP 2: Adding outstanding balances...\n');
    let processed = 0;
    const conn2 = await pool.getConnection();
    
    try {
      await conn2.beginTransaction();
      
      for (const student of studentData) {
        if (student.balance >= 0) {
          console.log(`⏭️  Skipping ${student.name} ${student.surname} - no outstanding balance`);
          continue;
        }
        
        try {
          const debtAmount = Math.abs(student.balance);
          
          // Get or create journal for opening balances
          let journal_id = 1; // Try General Journal (ID: 1) first
          const [journalCheck] = await conn2.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
          if (journalCheck.length === 0) {
            const [journalByName] = await conn2.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
            if (journalByName.length > 0) {
              journal_id = journalByName[0].id;
            } else {
              const [anyJournal] = await conn2.execute('SELECT id FROM journals LIMIT 1');
              if (anyJournal.length > 0) {
                journal_id = anyJournal[0].id;
              } else {
                const [journalResult] = await conn2.execute(
                  'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
                  ['General Journal', 'Journal for general transactions including opening balances', 1]
                );
                journal_id = journalResult.insertId;
              }
            }
          }
          
          // Get student info
          const [studentInfo] = await conn2.execute(
            'SELECT Name, Surname FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (studentInfo.length === 0) {
            console.log(`⚠️  Student ${student.regNumber} not found, skipping`);
            continue;
          }
          
          const reference = `OB-${student.regNumber}-${Date.now()}`;
          const journalDescription = `Opening Balance - Outstanding Debt for ${studentInfo[0].Name} ${studentInfo[0].Surname}`;
          
          // Create journal entry
          const [journalResult] = await conn2.execute(`
            INSERT INTO journal_entries (
              journal_id, entry_date, description, reference,
              created_by, created_at, updated_at
            ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
          `, [journal_id, journalDescription, reference, 1]);
          
          const journalEntryId = journalResult.insertId;
          
          // Get accounts
          const [accountsReceivable] = await conn2.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
            ['1100', 'Asset']
          );
          
          const [retainedEarnings] = await conn2.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
            ['3998'] // Retained Earnings (Opening Balance Equity)
          );
          
          if (accountsReceivable.length === 0 || retainedEarnings.length === 0) {
            throw new Error('Required accounts not found in chart of accounts (1100, 3998)');
          }
          
          // Create journal entry lines (use debit/credit columns)
          await conn2.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, accountsReceivable[0].id, debtAmount, 0, `Outstanding debt for ${studentInfo[0].Name} ${studentInfo[0].Surname}`]);
          
          await conn2.execute(`
            INSERT INTO journal_entry_lines (
              journal_entry_id, account_id, debit, credit, description
            ) VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, retainedEarnings[0].id, 0, debtAmount, `Retained Earnings - Opening Balance`]);
          
          // Check if transaction already exists to prevent duplicates
          const [existingTxn] = await conn2.execute(
            'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ? AND transaction_type = ?',
            [student.regNumber, `%Opening Balance - Outstanding Debt%`, 'DEBIT']
          );
          
          if (existingTxn.length > 0) {
            console.log(`⏭️  Skipping outstanding balance for ${student.name} ${student.surname} - transaction already exists`);
            continue;
          }
          
          // Create DEBIT transaction (this automatically updates the balance)
          const transactionId = await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'DEBIT',
            debtAmount,
            `Opening Balance - Outstanding Debt: ${reference}`,
            {
              created_by: 1,
              journal_entry_id: journalEntryId
            }
          );
          
          // Get updated balance (transaction already updated it)
          const [updatedBalance] = await conn2.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [student.regNumber]
          );
          const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
          
          // Update account balances from journal entry
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn2, journalEntryId, 1);
          
          console.log(`✅ Added outstanding balance: ${student.name} ${student.surname} - $${debtAmount.toFixed(2)} (New balance: $${newBalance.toFixed(2)})`);
          processed++;
        } catch (error) {
          console.error(`❌ Error adding outstanding balance for ${student.name} ${student.surname}:`, error.message);
          throw error;
        }
      }
      
      await conn2.commit();
      console.log(`\n📊 Outstanding Balances Summary: ${processed} processed`);
    } catch (error) {
      await conn2.rollback();
      throw error;
    } finally {
      conn2.release();
    }
    
    console.log('\n✅ Grade 7 2024 students processed successfully!');
    console.log('⚠️  NOTE: Students were NOT enrolled to any class (as requested)\n');
    
  } catch (error) {
    console.error('\n❌ Error processing Grade 7 2024 students:', error);
    throw error;
  } finally {
    process.exit(0);
  }
}

processGrade72024Students();

