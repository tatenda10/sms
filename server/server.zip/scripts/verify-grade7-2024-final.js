const { pool } = require('./config/database');

const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96905C', balance: -10 },
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96905M', balance: -20 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96906M', balance: -143 },
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96907M', balance: -150 },
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5 },
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96908M', balance: -210 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96905N', balance: -310 }
];

async function verify() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n📊 VERIFYING GRADE 7 2024 STUDENTS\n');
    console.log('='.repeat(70));
    
    for (const student of studentData) {
      // Check if student exists
      const [studentCheck] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      if (studentCheck.length === 0) {
        console.log(`❌ ${student.name} ${student.surname} (${student.regNumber}) - NOT FOUND IN DATABASE`);
        continue;
      }
      
      // Get balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      const match = Math.abs(currentBalance - student.balance) < 0.01;
      
      // Get transaction count
      const [transactions] = await conn.execute(
        'SELECT COUNT(*) as count FROM student_transactions WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const txnCount = transactions[0].count;
      
      console.log(`${match ? '✅' : '❌'} ${student.name} ${student.surname} (${student.regNumber}): $${currentBalance.toFixed(2)} (expected: $${student.balance.toFixed(2)}) [${txnCount} transactions]`);
    }
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

verify();

