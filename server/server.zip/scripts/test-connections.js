const mysql = require('mysql2/promise');

async function testConnection(config, name) {
    try {
        console.log(`🔄 Testing ${name} connection...`);
        
        const connection = await mysql.createConnection({
            host: config.host,
            user: config.user,
            password: config.password,
            database: config.database,
            port: config.port || 3306,
        });

        // Test basic query
        const [rows] = await connection.execute('SELECT 1 as test');
        console.log(`✅ ${name} connection successful`);

        // Get table count
        const [tables] = await connection.execute('SHOW TABLES');
        console.log(`📊 ${name} has ${tables.length} tables`);

        await connection.end();
        return true;

    } catch (error) {
        console.error(`❌ ${name} connection failed:`, error.message);
        return false;
    }
}

async function main() {
    console.log('🔍 Database Connection Test');
    console.log('============================\n');

    // Test local connection
    const localConfig = {
        host: 'localhost',
        user: 'root',
        password: 'password123',
        database: 'sms',
        port: 3306,
    };

    // Test remote connection
    const remoteConfig = {
        host: 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
        user: 'doadmin',
        password: 'AVNS_O_R4Z5_x8aFOV6Pzy6J',
        database: 'sms',
        port: 25060,
        ssl: { rejectUnauthorized: false }
    };

    console.log('📝 Update the credentials in this script before running!\n');

    const localSuccess = await testConnection(localConfig, 'Local Database');
    const remoteSuccess = await testConnection(remoteConfig, 'Remote Database');

    console.log('\n📊 Test Results:');
    console.log(`  - Local: ${localSuccess ? '✅ Success' : '❌ Failed'}`);
    console.log(`  - Remote: ${remoteSuccess ? '✅ Success' : '❌ Failed'}`);

    if (localSuccess && remoteSuccess) {
        console.log('\n🎉 Both connections successful! You can run the sync tools.');
    } else {
        console.log('\n⚠️  Fix connection issues before running sync tools.');
    }
}

main().catch(console.error);
