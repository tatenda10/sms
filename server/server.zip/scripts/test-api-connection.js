const axios = require('axios');

async function testApiConnection() {
    try {
        console.log('🔍 Testing API connection to server.learningladder.site...');
        
        const apiUrl = 'https://server.learningladder.site/api/sync-full-db.php';
        
        // Test basic connectivity
        console.log('📡 Testing basic connectivity...');
        const response = await axios.get(apiUrl, {
            timeout: 10000,
            headers: {
                'User-Agent': 'SMS-Sync-Test/1.0'
            }
        });
        
        console.log('✅ API endpoint is accessible');
        console.log(`📊 Response status: ${response.status}`);
        console.log(`📋 Response headers:`, Object.keys(response.headers));
        
        if (response.data) {
            console.log('📄 Response data preview:', JSON.stringify(response.data).substring(0, 200) + '...');
        }
        
    } catch (error) {
        if (error.code === 'ECONNREFUSED') {
            console.log('❌ Connection refused - server might be down');
        } else if (error.code === 'ENOTFOUND') {
            console.log('❌ Server not found - check URL');
        } else if (error.response) {
            console.log(`❌ Server responded with status: ${error.response.status}`);
            console.log(`📄 Error message: ${error.response.data}`);
        } else {
            console.log('❌ Connection error:', error.message);
        }
    }
}

testApiConnection();
