const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const AccountBalanceService = require('../services/accountBalanceService');

async function removeDuplicateBoardingJournals() {
    const conn = await pool.getConnection();
    
    try {
        await conn.beginTransaction();
        
        console.log('🔧 Removing duplicate boarding payment journal entries...\n');
        
        const studentReg = '56-D4353';
        
        // Get boarding payments
        const [payments] = await conn.execute(`
            SELECT 
                bfp.id as payment_id,
                bfp.base_currency_amount,
                bfp.payment_date,
                bfp.journal_entry_id
            FROM boarding_fees_payments bfp
            WHERE bfp.student_reg_number = ?
            ORDER BY bfp.payment_date
        `, [studentReg]);
        
        // Duplicate journals to remove (the ones we created)
        const duplicatesToRemove = [609, 610]; // Created on 2025-11-08
        const originalJournals = {
            609: 36, // $500 payment
            610: 37  // $50 payment
        };
        
        console.log(`📋 Processing ${payments.length} payments:\n`);
        
        for (const payment of payments) {
            console.log(`\n📝 Processing Payment ${payment.payment_id} ($${payment.base_currency_amount}):`);
            
            const duplicateJournalId = payment.journal_entry_id;
            if (duplicatesToRemove.includes(duplicateJournalId)) {
                const originalJournalId = originalJournals[duplicateJournalId];
                console.log(`   ⚠️  Found duplicate journal ${duplicateJournalId}, should use original ${originalJournalId}`);
                
                // 1. Reverse account balances from duplicate journal
                console.log(`   🔄 Reversing account balances from duplicate journal ${duplicateJournalId}...`);
                
                const [duplicateLines] = await conn.execute(`
                    SELECT 
                        jel.account_id,
                        jel.debit,
                        jel.credit,
                        coa.code,
                        coa.type
                    FROM journal_entry_lines jel
                    JOIN chart_of_accounts coa ON jel.account_id = coa.id
                    WHERE jel.journal_entry_id = ?
                `, [duplicateJournalId]);
                
                // Reverse each account balance
                for (const line of duplicateLines) {
                    const balanceChange = (line.type === 'Asset' || line.type === 'Expense')
                        ? parseFloat(line.debit || 0) - parseFloat(line.credit || 0)
                        : parseFloat(line.credit || 0) - parseFloat(line.debit || 0);
                    
                    // Get current balance
                    const [currentBalance] = await conn.execute(`
                        SELECT id, balance 
                        FROM account_balances 
                        WHERE account_id = ? 
                        ORDER BY as_of_date DESC 
                        LIMIT 1
                    `, [line.account_id]);
                    
                    if (currentBalance.length > 0) {
                        // Reverse: subtract the change we added
                        const newBalance = parseFloat(currentBalance[0].balance) - balanceChange;
                        await conn.execute(`
                            UPDATE account_balances 
                            SET balance = ?, as_of_date = CURRENT_DATE 
                            WHERE id = ?
                        `, [newBalance, currentBalance[0].id]);
                        console.log(`     ✅ Reversed ${line.code} (${line.type}): ${currentBalance[0].balance} → ${newBalance}`);
                    }
                }
                
                // 2. Update payment to point to original journal
                console.log(`   🔗 Linking payment to original journal ${originalJournalId}...`);
                await conn.execute(
                    'UPDATE boarding_fees_payments SET journal_entry_id = ? WHERE id = ?',
                    [originalJournalId, payment.payment_id]
                );
                console.log(`     ✅ Payment ${payment.payment_id} now linked to journal ${originalJournalId}`);
                
                // 3. Update student transaction to point to original journal
                const [studentTransaction] = await conn.execute(`
                    SELECT id FROM student_transactions 
                    WHERE student_reg_number = ?
                    AND transaction_type = 'CREDIT'
                    AND journal_entry_id = ?
                    AND amount = ?
                `, [studentReg, duplicateJournalId, payment.base_currency_amount]);
                
                if (studentTransaction.length > 0) {
                    await conn.execute(
                        'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
                        [originalJournalId, studentTransaction[0].id]
                    );
                    console.log(`     ✅ Student transaction ${studentTransaction[0].id} now linked to journal ${originalJournalId}`);
                }
                
                // 4. Delete duplicate journal entry lines
                console.log(`   🗑️  Deleting duplicate journal entry lines...`);
                await conn.execute(
                    'DELETE FROM journal_entry_lines WHERE journal_entry_id = ?',
                    [duplicateJournalId]
                );
                console.log(`     ✅ Deleted journal entry lines for journal ${duplicateJournalId}`);
                
                // 5. Delete duplicate journal entry
                console.log(`   🗑️  Deleting duplicate journal entry...`);
                await conn.execute(
                    'DELETE FROM journal_entries WHERE id = ?',
                    [duplicateJournalId]
                );
                console.log(`     ✅ Deleted journal entry ${duplicateJournalId}`);
                
            } else {
                console.log(`   ✅ Journal ${payment.journal_entry_id} is correct (not a duplicate)`);
            }
        }
        
        await conn.commit();
        
        console.log(`\n\n================================================================================`);
        console.log(`✅ Successfully removed duplicate journal entries`);
        console.log(`================================================================================\n`);
        
        // Verify the fix
        console.log(`📋 Verification:\n`);
        const [verifyPayments] = await conn.execute(`
            SELECT 
                bfp.id,
                bfp.base_currency_amount,
                bfp.payment_date,
                bfp.journal_entry_id,
                je.description,
                je.created_at
            FROM boarding_fees_payments bfp
            LEFT JOIN journal_entries je ON bfp.journal_entry_id = je.id
            WHERE bfp.student_reg_number = ?
            ORDER BY bfp.payment_date
        `, [studentReg]);
        
        verifyPayments.forEach(p => {
            console.log(`   Payment ${p.id} ($${p.base_currency_amount}): Journal ${p.journal_entry_id} (${p.description}) - Created: ${p.created_at}`);
        });
        
        // Check if duplicate journals still exist
        const [remainingDuplicates] = await conn.execute(`
            SELECT id FROM journal_entries WHERE id IN (?)
        `, [duplicatesToRemove]);
        
        if (remainingDuplicates.length > 0) {
            console.log(`\n   ⚠️  WARNING: Some duplicate journals still exist: ${remainingDuplicates.map(d => d.id).join(', ')}`);
        } else {
            console.log(`\n   ✅ All duplicate journals successfully removed`);
        }
        
    } catch (error) {
        await conn.rollback();
        console.error('❌ Error removing duplicate journals:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the script
removeDuplicateBoardingJournals()
    .then(() => {
        console.log('\n✅ Script completed');
        process.exit(0);
    })
    .catch(error => {
        console.error('\n❌ Script failed:', error);
        process.exit(1);
    });

