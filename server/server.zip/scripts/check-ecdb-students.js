const { pool } = require('./config/database');

// All ECD B students from the image
const ecdbStudents = [
  { name: 'Meeghan', surname: 'Shoko', regNumber: 'R00007S', balance: 0.00, totalPayments: 115.00 },
  { name: 'Alvin', surname: 'Mpofu', regNumber: 'R00007M', balance: -131.00, totalPayments: 40.00 },
  { name: 'Mukudzei', surname: 'Kamuzonde', regNumber: 'R00007K', balance: -136.00, totalPayments: 100.00 },
  { name: 'Marlon', surname: 'Mafigu', regNumber: 'R00007N', balance: -1.00, totalPayments: 115.00 },
  { name: 'Christian', surname: 'Zulu', regNumber: 'R00007Z', balance: 0.00, totalPayments: 115.00 },
  { name: 'Liam', surname: 'Chawora', regNumber: 'R00007C', balance: 0.00, totalPayments: 115.00 },
  { name: 'Phiri', surname: 'Tawananyasha', regNumber: 'R00007T', balance: 0.00, totalPayments: 115.00 },
  { name: 'Mylar', surname: 'Gwerendende', regNumber: 'R00007G', balance: 0.00, totalPayments: 115.00 },
  { name: 'Rufaro', surname: 'Jekecha', regNumber: 'R00007J', balance: 0.00, totalPayments: 65.00 },
  { name: 'Courtney', surname: 'Pabwe', regNumber: 'R00007P', balance: 0.00, totalPayments: 115.00 },
  { name: 'Blessed', surname: 'Chiza', regNumber: 'R00007D', balance: -15.00, totalPayments: 70.00 },
  { name: 'Fidel', surname: 'Marume', regNumber: 'R00007N', balance: 0.00, totalPayments: 115.00 },
  { name: 'Tally', surname: 'Madzima', regNumber: 'R00007N', balance: 0.00, totalPayments: 110.00 },
  { name: 'Lionel', surname: 'Mashambi', regNumber: 'R00007N', balance: -1.00, totalPayments: 115.00 }
];

async function checkECDBStudents() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ECD B STUDENTS\n');
    console.log('='.repeat(70));
    
    // Get ECD B class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%ECD B%' OR gc.name LIKE '%ECD%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ ECD B class not found');
      return;
    }
    
    const ecdbClass = classes[0];
    console.log(`✅ Found ECD B class: ${ecdbClass.name} (ID: ${ecdbClass.id})\n`);
    
    // Check each student
    const results = [];
    const regNumberMap = {};
    const duplicateRegNumbers = [];
    
    for (const student of ecdbStudents) {
      // Check by registration number
      const [byReg] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      // Check by name
      const [byName] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [student.regNumber, ecdbClass.id]);
      
      // Get balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const foundByReg = byReg.length > 0;
      const foundByName = byName.length > 0;
      const enrolled = enrollment.length > 0;
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : null;
      
      // Check for duplicate reg numbers
      if (foundByReg) {
        if (!regNumberMap[student.regNumber]) {
          regNumberMap[student.regNumber] = [];
        }
        regNumberMap[student.regNumber].push({
          expected: student,
          actual: byReg[0]
        });
        
        // Check if name matches
        if (byReg[0].Name.toLowerCase().trim() !== student.name.toLowerCase().trim() ||
            byReg[0].Surname.toLowerCase().trim() !== student.surname.toLowerCase().trim()) {
          duplicateRegNumbers.push({
            regNumber: student.regNumber,
            expected: student,
            actual: byReg[0]
          });
        }
      }
      
      results.push({
        student,
        foundByReg,
        foundByName,
        enrolled,
        currentBalance,
        dbStudent: foundByReg ? byReg[0] : (foundByName ? byName[0] : null)
      });
    }
    
    // Find all duplicates
    const allDuplicates = [];
    for (const [regNumber, students] of Object.entries(regNumberMap)) {
      if (students.length > 1) {
        allDuplicates.push({
          regNumber,
          students: students.map(s => s.expected)
        });
      }
    }
    
    // Summary
    const found = results.filter(r => r.foundByReg || r.foundByName).length;
    const missing = results.filter(r => !r.foundByReg && !r.foundByName).length;
    const enrolledCount = results.filter(r => r.enrolled).length;
    const notEnrolled = results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).length;
    
    console.log(`📊 SUMMARY:\n`);
    console.log(`   Total students in Excel: ${ecdbStudents.length}`);
    console.log(`   Found in database: ${found}`);
    console.log(`   Missing from database: ${missing}`);
    console.log(`   Enrolled in ECD B: ${enrolledCount}`);
    console.log(`   Not enrolled: ${notEnrolled}`);
    console.log(`   Duplicate reg numbers: ${allDuplicates.length}\n`);
    
    // Show duplicates
    if (allDuplicates.length > 0) {
      console.log(`\n⚠️  DUPLICATE REGISTRATION NUMBERS:\n`);
      allDuplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((s, sIdx) => {
          console.log(`   ${sIdx + 1}. ${s.name} ${s.surname}`);
        });
      });
    }
    
    // Show missing students
    if (missing > 0) {
      console.log(`\n❌ MISSING STUDENTS:\n`);
      results.filter(r => !r.foundByReg && !r.foundByName).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show not enrolled
    if (notEnrolled > 0) {
      console.log(`\n⚠️  NOT ENROLLED IN ECD B:\n`);
      results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show all students with details
    console.log(`\n\n📋 ALL ECD B STUDENTS STATUS:\n`);
    console.log('-'.repeat(70));
    results.forEach((r, idx) => {
      const status = r.foundByReg ? '✅' : (r.foundByName ? '⚠️' : '❌');
      const enrolledStatus = r.enrolled ? '✅' : '❌';
      const balanceStr = r.currentBalance !== null ? 
        (r.currentBalance < 0 ? `-$${Math.abs(r.currentBalance).toFixed(2)}` : `$${r.currentBalance.toFixed(2)}`) : 
        'N/A';
      const expectedBalance = r.student.balance < 0 ? `-$${Math.abs(r.student.balance).toFixed(2)}` : `$${r.student.balance.toFixed(2)}`;
      
      console.log(`${String(idx + 1).padStart(3)}. ${status} ${r.student.name.padEnd(15)} ${r.student.surname.padEnd(20)} ${r.student.regNumber.padEnd(10)} ${enrolledStatus} Enrolled | Balance: ${balanceStr.padEnd(10)} (Expected: ${expectedBalance})`);
    });
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking ECD B students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkECDBStudents();

