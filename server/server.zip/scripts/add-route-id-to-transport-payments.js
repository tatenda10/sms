const { pool } = require('../config/database');

async function addRouteIdToTransportPayments() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🚀 Adding route_id column to transport_payments table...');
    
    // Step 1: Check if route_id column already exists
    console.log('\n⚡ Step 1: Checking if route_id column exists...');
    const [columns] = await connection.execute('DESCRIBE transport_payments');
    const routeIdColumn = columns.find(col => col.Field === 'route_id');
    
    if (routeIdColumn) {
      console.log('   ✅ route_id column already exists');
      console.log(`   • Type: ${routeIdColumn.Type}`);
      console.log(`   • Null allowed: ${routeIdColumn.Null === 'YES' ? 'YES' : 'NO'}`);
    } else {
      console.log('   ❌ route_id column does not exist, adding...');
      
      // Step 2: Add route_id column
      await connection.execute(`
        ALTER TABLE transport_payments 
        ADD COLUMN route_id INT NULL 
        COMMENT 'Foreign key to transport_routes, NULL for fee-based payments'
      `);
      console.log('   ✅ route_id column added');
      
      // Step 3: Add foreign key constraint
      try {
        await connection.execute(`
          ALTER TABLE transport_payments 
          ADD CONSTRAINT fk_transport_payments_route_id 
          FOREIGN KEY (route_id) REFERENCES transport_routes(id)
        `);
        console.log('   ✅ Foreign key constraint added');
      } catch (fkError) {
        if (fkError.code === 'ER_DUP_KEYNAME') {
          console.log('   ⚠️  Foreign key constraint already exists');
        } else {
          console.log('   ⚠️  Could not add foreign key constraint:', fkError.message);
        }
      }
      
      // Step 4: Add index for performance
      try {
        await connection.execute(`
          CREATE INDEX idx_transport_payments_route_id 
          ON transport_payments(route_id)
        `);
        console.log('   ✅ Index added for route_id');
      } catch (indexError) {
        if (indexError.code === 'ER_DUP_KEYNAME') {
          console.log('   ⚠️  Index already exists');
        } else {
          console.log('   ⚠️  Could not add index:', indexError.message);
        }
      }
    }
    
    // Step 5: Verify the change
    console.log('\n⚡ Step 5: Verifying the change...');
    const [finalColumns] = await connection.execute('DESCRIBE transport_payments');
    const finalRouteIdColumn = finalColumns.find(col => col.Field === 'route_id');
    
    if (finalRouteIdColumn) {
      console.log('   ✅ Verification successful: route_id column exists');
      console.log(`   • Type: ${finalRouteIdColumn.Type}`);
      console.log(`   • Null allowed: ${finalRouteIdColumn.Null === 'YES' ? 'YES' : 'NO'}`);
    } else {
      throw new Error('Verification failed: route_id column still does not exist');
    }
    
    console.log('\n🎉 route_id column addition completed successfully!');
    console.log('\n📋 Changes made:');
    console.log('   • Added route_id column to transport_payments table');
    console.log('   • Made column nullable for fee-based payments');
    console.log('   • Added foreign key constraint to transport_routes');
    console.log('   • Added performance index');
    
    console.log('\n✅ Direct transport payments can now properly link to routes!');
    
  } catch (error) {
    console.error('\n❌ Adding route_id column failed:', error.message);
    console.error('Error details:', error);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the migration if this script is executed directly
if (require.main === module) {
  addRouteIdToTransportPayments()
    .then(() => {
      console.log('\n✅ route_id column addition script completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 route_id column addition script failed:', error.message);
      process.exit(1);
    });
}

module.exports = addRouteIdToTransportPayments;
