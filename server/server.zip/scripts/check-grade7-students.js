const { pool } = require('./config/database');

// All Grade 7 students from the image
const grade7Students = [
  { surname: 'Alifasi', name: 'Naison', regNumber: 'R00001N', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Gowe', name: 'Patience', regNumber: 'R00001P', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Chiteve', name: 'Kupakwashe', regNumber: 'R00001K', balance: -60.00, totalPayments: 0.00 },
  { surname: 'Hahisa', name: 'Maudy', regNumber: 'R00001M', balance: 0.00, totalPayments: 50.00 },
  { surname: 'Gomera', name: 'Miguel', regNumber: 'R00002M', balance: 0.00, totalPayments: 50.00 },
  { surname: 'Bhudhi', name: 'Ruvarashe', regNumber: 'R00001R', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Masanganise', name: 'Joseph', regNumber: 'R00001J', balance: -5.00, totalPayments: 0.00 },
  { surname: 'Mudisi', name: 'Juliet', regNumber: 'R00002J', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Mudzviti', name: 'Andrew', regNumber: 'R00001A', balance: -25.00, totalPayments: 0.00 },
  { surname: 'Mushonga', name: 'Thandeka', regNumber: 'R00001T', balance: 0.00, totalPayments: 40.00 },
  { surname: 'Mutonzi', name: 'Nelisha', regNumber: 'R00002N', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Vainet', name: 'Nigel', regNumber: 'R00003N', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Mudewairi', name: 'Tadiwanashe', regNumber: 'R00003M', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Mashati', name: 'Sharon', regNumber: 'R00001S', balance: -5.00, totalPayments: 100.00 },
  { surname: 'Matsheza', name: 'Shanice', regNumber: 'R00002S', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Kasunungura', name: 'Mitchelle', regNumber: 'R00004M', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Majinjiwa', name: 'Brayden', regNumber: 'R00001B', balance: 0.00, totalPayments: 100.00 },
  { surname: 'Chatiza', name: 'Shyleen', regNumber: 'R00003S', balance: 0.00, totalPayments: 70.00 },
  { surname: 'Hlebo', name: 'Anotidaishe', regNumber: 'R00002A', balance: -10.00, totalPayments: 50.00 },
  { surname: 'Nyaude', name: 'Junior', regNumber: 'R00003J', balance: 0.00, totalPayments: 0.00 },
  { surname: 'Nhidza', name: 'Jayden', regNumber: 'R00004J', balance: -70.00, totalPayments: 0.00 },
  { surname: 'Tsiko', name: 'Tadiwa', regNumber: 'R00004K', balance: 0.00, totalPayments: 60.00 },
  { surname: 'Phiri', name: 'Bianga', regNumber: 'R00002B', balance: -272.00, totalPayments: 0.00 },
  { surname: 'Gwaze', name: 'Junior', regNumber: 'R00005J', balance: -80.00, totalPayments: 0.00 }
];

async function checkGrade7Students() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING GRADE 7 STUDENTS\n');
    console.log('='.repeat(70));
    
    // Get Grade 7 class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%Grade 7%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ Grade 7 class not found');
      return;
    }
    
    const grade7Class = classes[0];
    console.log(`✅ Found Grade 7 class: ${grade7Class.name} (ID: ${grade7Class.id})\n`);
    
    // Check each student
    const results = [];
    const regNumberMap = {};
    const duplicateRegNumbers = [];
    
    for (const student of grade7Students) {
      // Check by registration number
      const [byReg] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      // Check by name
      const [byName] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [student.regNumber, grade7Class.id]);
      
      // Get balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const foundByReg = byReg.length > 0;
      const foundByName = byName.length > 0;
      const enrolled = enrollment.length > 0;
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : null;
      
      // Check for duplicate reg numbers
      if (foundByReg) {
        if (!regNumberMap[student.regNumber]) {
          regNumberMap[student.regNumber] = [];
        }
        regNumberMap[student.regNumber].push({
          expected: student,
          actual: byReg[0]
        });
        
        // Check if name matches
        if (byReg[0].Name.toLowerCase().trim() !== student.name.toLowerCase().trim() ||
            byReg[0].Surname.toLowerCase().trim() !== student.surname.toLowerCase().trim()) {
          duplicateRegNumbers.push({
            regNumber: student.regNumber,
            expected: student,
            actual: byReg[0]
          });
        }
      }
      
      results.push({
        student,
        foundByReg,
        foundByName,
        enrolled,
        currentBalance,
        dbStudent: foundByReg ? byReg[0] : (foundByName ? byName[0] : null)
      });
    }
    
    // Summary
    const found = results.filter(r => r.foundByReg || r.foundByName).length;
    const missing = results.filter(r => !r.foundByReg && !r.foundByName).length;
    const enrolledCount = results.filter(r => r.enrolled).length;
    const notEnrolled = results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).length;
    
    console.log(`📊 SUMMARY:\n`);
    console.log(`   Total students in Excel: ${grade7Students.length}`);
    console.log(`   Found in database: ${found}`);
    console.log(`   Missing from database: ${missing}`);
    console.log(`   Enrolled in Grade 7: ${enrolledCount}`);
    console.log(`   Not enrolled: ${notEnrolled}`);
    console.log(`   Duplicate reg numbers: ${duplicateRegNumbers.length}\n`);
    
    // Show duplicates
    if (duplicateRegNumbers.length > 0) {
      console.log(`\n⚠️  DUPLICATE REGISTRATION NUMBERS:\n`);
      duplicateRegNumbers.forEach((dup, idx) => {
        console.log(`${idx + 1}. Reg Number: ${dup.regNumber}`);
        console.log(`   Expected: ${dup.expected.name} ${dup.expected.surname}`);
        console.log(`   Actual in DB: ${dup.actual.Name} ${dup.actual.Surname}`);
      });
    }
    
    // Show missing students
    if (missing > 0) {
      console.log(`\n❌ MISSING STUDENTS:\n`);
      results.filter(r => !r.foundByReg && !r.foundByName).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show not enrolled
    if (notEnrolled > 0) {
      console.log(`\n⚠️  NOT ENROLLED IN GRADE 7:\n`);
      results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show all students with details
    console.log(`\n\n📋 ALL GRADE 7 STUDENTS STATUS:\n`);
    console.log('-'.repeat(70));
    results.forEach((r, idx) => {
      const status = r.foundByReg ? '✅' : (r.foundByName ? '⚠️' : '❌');
      const enrolledStatus = r.enrolled ? '✅' : '❌';
      const balanceStr = r.currentBalance !== null ? 
        (r.currentBalance < 0 ? `-$${Math.abs(r.currentBalance).toFixed(2)}` : `$${r.currentBalance.toFixed(2)}`) : 
        'N/A';
      const expectedBalance = r.student.balance < 0 ? `-$${Math.abs(r.student.balance).toFixed(2)}` : `$${r.student.balance.toFixed(2)}`;
      
      console.log(`${String(idx + 1).padStart(3)}. ${status} ${r.student.name.padEnd(15)} ${r.student.surname.padEnd(20)} ${r.student.regNumber.padEnd(10)} ${enrolledStatus} Enrolled | Balance: ${balanceStr.padEnd(10)} (Expected: ${expectedBalance})`);
    });
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking Grade 7 students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkGrade7Students();

