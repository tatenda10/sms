const { pool } = require('../config/database');

async function checkBoardingInvoiceTrialBalance() {
  const conn = await pool.getConnection();
  
  try {
    console.log('🔍 Checking Boarding Invoice Trial Balance Issue...\n');
    
    // 1. Check for boarding DEBIT transactions (invoices)
    console.log('1️⃣ Checking Boarding DEBIT Transactions (Invoices):');
    const [boardingDebits] = await conn.execute(`
      SELECT 
        st.id,
        st.student_reg_number,
        st.transaction_type,
        st.amount,
        st.transaction_date,
        st.description,
        st.journal_entry_id
      FROM student_transactions st
      WHERE st.transaction_type = 'DEBIT'
        AND st.description LIKE '%BOARDING%'
        AND st.transaction_date >= '2025-11-01'
      ORDER BY st.transaction_date DESC
      LIMIT 10
    `);
    
    console.log(`   Found ${boardingDebits.length} boarding DEBIT transactions:`);
    boardingDebits.forEach(tx => {
      console.log(`   - ID: ${tx.id}, Amount: $${tx.amount}, Date: ${tx.transaction_date}, Journal Entry ID: ${tx.journal_entry_id || 'NULL'}`);
    });
    
    // 2. Check journal entries for boarding enrollments
    console.log('\n2️⃣ Checking Journal Entries for Boarding:');
    const [boardingJournals] = await conn.execute(`
      SELECT 
        je.id,
        je.entry_date,
        je.description,
        je.reference,
        SUM(CASE WHEN coa.code = '1100' THEN jel.debit ELSE 0 END) as ar_debit,
        SUM(CASE WHEN coa.code = '4002' THEN jel.credit ELSE 0 END) as revenue_credit
      FROM journal_entries je
      INNER JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
      INNER JOIN chart_of_accounts coa ON jel.account_id = coa.id
      WHERE je.description LIKE '%BOARDING%'
        AND je.entry_date >= '2025-11-01'
      GROUP BY je.id, je.entry_date, je.description, je.reference
      ORDER BY je.entry_date DESC
      LIMIT 10
    `);
    
    console.log(`   Found ${boardingJournals.length} boarding journal entries:`);
    boardingJournals.forEach(je => {
      console.log(`   - ID: ${je.id}, Date: ${je.entry_date}, AR Debit: $${je.ar_debit}, Revenue Credit: $${je.revenue_credit}`);
    });
    
    // 3. Check account balances for AR (1100) and Boarding Revenue (4002)
    console.log('\n3️⃣ Checking Account Balances:');
    const [accountBalances] = await conn.execute(`
      SELECT 
        coa.code,
        coa.name,
        ab.as_of_date,
        ab.balance,
        ab.currency_id
      FROM account_balances ab
      INNER JOIN chart_of_accounts coa ON ab.account_id = coa.id
      WHERE coa.code IN ('1100', '4002')
        AND ab.as_of_date >= '2025-11-01'
      ORDER BY coa.code, ab.as_of_date DESC
    `);
    
    console.log(`   Found ${accountBalances.length} account balance records:`);
    accountBalances.forEach(ab => {
      console.log(`   - ${ab.code} (${ab.name}): Balance: $${ab.balance}, Date: ${ab.as_of_date}`);
    });
    
    // 4. Get latest balance for each account
    console.log('\n4️⃣ Latest Account Balances (as of today):');
    const [latestBalances] = await conn.execute(`
      SELECT 
        coa.code,
        coa.name,
        coa.type,
        COALESCE(ab.balance, 0) as balance
      FROM chart_of_accounts coa
      LEFT JOIN (
        SELECT 
          ab1.account_id,
          ab1.balance
        FROM account_balances ab1
        INNER JOIN (
          SELECT 
            account_id,
            MAX(as_of_date) as max_date
          FROM account_balances
          WHERE as_of_date <= CURDATE()
          GROUP BY account_id
        ) ab2 ON ab1.account_id = ab2.account_id AND ab1.as_of_date = ab2.max_date
      ) ab ON coa.id = ab.account_id
      WHERE coa.code IN ('1100', '4002')
        AND coa.is_active = TRUE
      ORDER BY coa.code
    `);
    
    latestBalances.forEach(ab => {
      console.log(`   - ${ab.code} (${ab.name} - ${ab.type}): $${ab.balance}`);
    });
    
    // 5. Check if student_transactions are linked to journal_entries
    console.log('\n5️⃣ Checking Transaction-Journal Links:');
    const [unlinkedTransactions] = await conn.execute(`
      SELECT 
        st.id,
        st.student_reg_number,
        st.amount,
        st.transaction_date,
        st.description,
        st.journal_entry_id
      FROM student_transactions st
      WHERE st.transaction_type = 'DEBIT'
        AND st.description LIKE '%BOARDING%'
        AND st.transaction_date >= '2025-11-01'
        AND (st.journal_entry_id IS NULL OR st.journal_entry_id = 0)
      LIMIT 10
    `);
    
    console.log(`   Found ${unlinkedTransactions.length} unlinked transactions:`);
    unlinkedTransactions.forEach(tx => {
      console.log(`   - ID: ${tx.id}, Amount: $${tx.amount}, Date: ${tx.transaction_date}`);
    });
    
    // 6. Summary
    console.log('\n📊 SUMMARY:');
    const totalDebitAmount = boardingDebits.reduce((sum, tx) => sum + parseFloat(tx.amount || 0), 0);
    const totalJournalAmount = boardingJournals.reduce((sum, je) => sum + parseFloat(je.revenue_credit || 0), 0);
    const totalARBalance = latestBalances.find(b => b.code === '1100')?.balance || 0;
    const totalRevenueBalance = latestBalances.find(b => b.code === '4002')?.balance || 0;
    
    console.log(`   Total Boarding DEBIT Transactions: $${totalDebitAmount}`);
    console.log(`   Total Journal Entry Revenue: $${totalJournalAmount}`);
    console.log(`   AR (1100) Balance: $${totalARBalance}`);
    console.log(`   Boarding Revenue (4002) Balance: $${totalRevenueBalance}`);
    
    if (totalDebitAmount > 0 && (totalARBalance === 0 || totalRevenueBalance === 0)) {
      console.log('\n   ⚠️  ISSUE DETECTED: Transactions exist but account balances are zero!');
      console.log('   This means journal entries may not be updating account_balances.');
    }
    
    if (unlinkedTransactions.length > 0) {
      console.log(`\n   ⚠️  ISSUE DETECTED: ${unlinkedTransactions.length} transactions are not linked to journal entries!`);
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkBoardingInvoiceTrialBalance();

