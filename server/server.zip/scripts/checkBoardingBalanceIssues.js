const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        console.log('🔍 Checking boarding enrollment and payment balance issues...\n');
        
        // 1. Check boarding enrollments
        console.log('📋 BOARDING ENROLLMENTS:');
        const [boardingEnrollments] = await conn.execute(`
            SELECT 
                be.id as enrollment_id,
                be.student_reg_number,
                be.hostel_id,
                be.room_id,
                be.status,
                be.term,
                be.academic_year,
                be.created_at,
                s.Name,
                s.Surname
            FROM boarding_enrollments be
            JOIN students s ON be.student_reg_number = s.RegNumber
            WHERE be.status IN ('enrolled', 'checked_in', 'active')
            ORDER BY be.created_at DESC
        `);
        
        console.log(`   Total active boarding enrollments: ${boardingEnrollments.length}`);
        
        // Check which enrollments have transactions
        const [enrollmentsWithTransactions] = await conn.execute(`
            SELECT 
                be.id as enrollment_id,
                be.student_reg_number,
                COUNT(st.id) as transaction_count
            FROM boarding_enrollments be
            LEFT JOIN student_transactions st ON st.enrollment_id = be.id 
                AND st.transaction_type = 'DEBIT'
                AND (st.description LIKE '%BOARDING%' OR st.description LIKE '%BOARDER%')
            WHERE be.status IN ('enrolled', 'checked_in', 'active')
            GROUP BY be.id, be.student_reg_number
            HAVING transaction_count = 0
        `);
        
        console.log(`   Enrollments missing transactions: ${enrollmentsWithTransactions.length}`);
        
        // Check which enrollments have student balance records
        const [enrollmentsWithBalances] = await conn.execute(`
            SELECT 
                be.id as enrollment_id,
                be.student_reg_number
            FROM boarding_enrollments be
            LEFT JOIN student_balances sb ON sb.student_reg_number = be.student_reg_number
            WHERE be.status IN ('enrolled', 'checked_in', 'active')
            AND sb.student_reg_number IS NULL
        `);
        
        console.log(`   Enrollments for students without balance records: ${enrollmentsWithBalances.length}`);
        
        // 2. Check boarding payments
        console.log('\n📋 BOARDING PAYMENTS:');
        const [boardingPayments] = await conn.execute(`
            SELECT 
                bfp.id as payment_id,
                bfp.student_reg_number,
                bfp.amount_paid,
                bfp.base_currency_amount,
                bfp.payment_date,
                bfp.status,
                bfp.receipt_number,
                s.Name,
                s.Surname
            FROM boarding_fees_payments bfp
            JOIN students s ON bfp.student_reg_number = s.RegNumber
            WHERE bfp.status = 'completed'
            ORDER BY bfp.payment_date DESC
        `);
        
        console.log(`   Total completed boarding payments: ${boardingPayments.length}`);
        
        // Check which payments have student transactions
        const [paymentsWithTransactions] = await conn.execute(`
            SELECT 
                bfp.id as payment_id,
                bfp.student_reg_number,
                bfp.amount_paid,
                bfp.base_currency_amount,
                bfp.payment_date,
                bfp.receipt_number,
                COUNT(st.id) as transaction_count
            FROM boarding_fees_payments bfp
            LEFT JOIN student_transactions st ON st.student_reg_number = bfp.student_reg_number
                AND st.transaction_type = 'CREDIT'
                AND (st.description LIKE '%BOARDING%' OR st.description LIKE '%BOARDER%')
                AND ABS(st.amount - bfp.base_currency_amount) < 0.01
            WHERE bfp.status = 'completed'
            GROUP BY bfp.id, bfp.student_reg_number, bfp.amount_paid, bfp.base_currency_amount, bfp.payment_date, bfp.receipt_number
            HAVING transaction_count = 0
        `);
        
        console.log(`   Payments missing transactions: ${paymentsWithTransactions.length}`);
        
        console.log(`\n📊 Detailed Analysis:\n`);
        
        // Show enrollments missing transactions
        if (enrollmentsWithTransactions.length > 0) {
            console.log(`❌ Enrollments missing transactions (${enrollmentsWithTransactions.length}):`);
            enrollmentsWithTransactions.slice(0, 10).forEach(e => {
                console.log(`   - Enrollment ${e.enrollment_id}: ${e.student_reg_number}`);
            });
            if (enrollmentsWithTransactions.length > 10) {
                console.log(`   ... and ${enrollmentsWithTransactions.length - 10} more`);
            }
        } else {
            console.log(`✅ All enrollments have transactions`);
        }
        
        // Show payments missing transactions
        if (paymentsWithTransactions.length > 0) {
            console.log(`\n❌ Payments missing transactions (${paymentsWithTransactions.length}):`);
            paymentsWithTransactions.slice(0, 10).forEach(p => {
                console.log(`   - Payment ${p.payment_id} (${p.receipt_number}): ${p.student_reg_number} - $${p.base_currency_amount || p.amount_paid} on ${p.payment_date}`);
            });
            if (paymentsWithTransactions.length > 10) {
                console.log(`   ... and ${paymentsWithTransactions.length - 10} more`);
            }
        } else {
            console.log(`✅ All payments have transactions`);
        }
        
        // Check if students have balance records but balances might be incorrect
        const [studentsWithIncorrectBalances] = await conn.execute(`
            SELECT 
                bfp.student_reg_number,
                COALESCE(sb.current_balance, 0) as current_balance,
                (SELECT COALESCE(SUM(CASE 
                    WHEN st.transaction_type = 'DEBIT' THEN -st.amount
                    WHEN st.transaction_type = 'CREDIT' THEN st.amount
                    ELSE 0
                END), 0)
                FROM student_transactions st
                WHERE st.student_reg_number = bfp.student_reg_number
                ) as calculated_balance
            FROM boarding_fees_payments bfp
            LEFT JOIN student_balances sb ON sb.student_reg_number = bfp.student_reg_number
            WHERE bfp.status = 'completed'
            GROUP BY bfp.student_reg_number, sb.current_balance
            HAVING ABS(COALESCE(sb.current_balance, 0) - calculated_balance) > 0.01
            LIMIT 10
        `);
        
        if (studentsWithIncorrectBalances.length > 0) {
            console.log(`\n⚠️  Students with potential balance discrepancies (sample):`);
            studentsWithIncorrectBalances.forEach(s => {
                console.log(`   - ${s.student_reg_number}: Stored=${s.current_balance}, Calculated=${s.calculated_balance}`);
            });
        }
        
        // Summary
        console.log(`\n📋 SUMMARY:`);
        console.log(`   Boarding enrollments missing transactions: ${enrollmentsWithTransactions.length}`);
        console.log(`   Boarding payments missing transactions: ${paymentsWithTransactions.length}`);
        console.log(`   Students without balance records: ${enrollmentsWithBalances.length}`);
        console.log(`   Students with balance discrepancies: ${studentsWithIncorrectBalances.length > 0 ? 'Some found (see above)' : 'None found'}`);
        
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        conn.release();
        process.exit();
    }
})();

