const { pool } = require('./config/database');

async function checkR00007NStudents() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ALL STUDENTS WITH REGISTRATION NUMBER R00007N\n');
    console.log('='.repeat(70));
    
    // Get all students with R00007N
    const [students] = await conn.execute(
      'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
      ['R00007N']
    );
    
    console.log(`\n📊 Total students with R00007N: ${students.length}\n`);
    
    if (students.length > 0) {
      console.log('Students with R00007N:');
      students.forEach((student, idx) => {
        console.log(`${idx + 1}. ${student.Name} ${student.Surname}`);
      });
    }
    
  } catch (error) {
    console.error('Error checking students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkR00007NStudents();

