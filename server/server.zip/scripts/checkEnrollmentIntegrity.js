const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function checkEnrollmentIntegrity() {
    const conn = await pool.getConnection();
    
    try {
        console.log('🔍 Checking enrollment integrity...\n');
        
        // Get all active grade-level enrollments
        const [enrollments] = await conn.execute(`
            SELECT 
                e.id as enrollment_id,
                e.student_regnumber,
                e.gradelevel_class_id,
                e.status,
                e.created_at as enrollment_date,
                s.Name,
                s.Surname,
                gc.name as class_name,
                st.name as stream_name
            FROM enrollments_gradelevel_classes e
            JOIN students s ON e.student_regnumber = s.RegNumber
            JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
            JOIN stream st ON gc.stream_id = st.id
            WHERE e.status = 'active'
            ORDER BY e.created_at DESC
        `);
        
        console.log(`📊 Found ${enrollments.length} active enrollments\n`);
        
        const issues = {
            noStudentBalance: [],
            noTransactions: [],
            noJournalEntries: [],
            noAccountBalances: [],
            missingInvoiceStructure: []
        };
        
        // Get AR and Revenue account IDs
        const [arAccount] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['1100', 'Asset']
        );
        const [revenueAccount] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['4000', 'Revenue']
        );
        
        const arAccountId = arAccount.length > 0 ? arAccount[0].id : null;
        const revenueAccountId = revenueAccount.length > 0 ? revenueAccount[0].id : null;
        
        console.log(`📋 Accounts: AR (${arAccountId}), Revenue (${revenueAccountId})\n`);
        
        for (const enrollment of enrollments) {
            const studentReg = enrollment.student_regnumber;
            const enrollmentId = enrollment.enrollment_id;
            
            // Check 1: Student balance record
            const [studentBalance] = await conn.execute(
                'SELECT * FROM student_balances WHERE student_reg_number = ?',
                [studentReg]
            );
            
            if (studentBalance.length === 0) {
                issues.noStudentBalance.push({
                    ...enrollment,
                    issue: 'No student_balances record'
                });
            }
            
            // Check 2: Enrollment transaction
            const [transactions] = await conn.execute(
                `SELECT * FROM student_transactions 
                 WHERE student_reg_number = ? 
                 AND enrollment_id = ? 
                 AND transaction_type = 'DEBIT'
                 AND description LIKE '%TUITION INVOICE%'`,
                [studentReg, enrollmentId]
            );
            
            if (transactions.length === 0) {
                issues.noTransactions.push({
                    ...enrollment,
                    issue: 'No enrollment DEBIT transaction found'
                });
            }
            
            // Check 3: Journal entries for enrollment
            const [journalEntries] = await conn.execute(
                `SELECT je.id, je.description, je.reference
                 FROM journal_entries je
                 WHERE je.reference LIKE ?
                 AND je.description LIKE ?`,
                [`%ENROLL-${studentReg}-%`, `%TUITION INVOICE%`]
            );
            
            if (journalEntries.length === 0) {
                issues.noJournalEntries.push({
                    ...enrollment,
                    issue: 'No journal entries found for enrollment'
                });
            }
            
            // Check 4: Account balances (AR and Revenue)
            if (arAccountId && revenueAccountId) {
                // Get most recent account balances
                const [arBalance] = await conn.execute(
                    `SELECT balance, as_of_date 
                     FROM account_balances 
                     WHERE account_id = ? 
                     ORDER BY as_of_date DESC 
                     LIMIT 1`,
                    [arAccountId]
                );
                
                const [revenueBalance] = await conn.execute(
                    `SELECT balance, as_of_date 
                     FROM account_balances 
                     WHERE account_id = ? 
                     ORDER BY as_of_date DESC 
                     LIMIT 1`,
                    [revenueAccountId]
                );
                
                // Check if there are journal entries that should have updated balances
                if (journalEntries.length > 0 && (arBalance.length === 0 || revenueBalance.length === 0)) {
                    issues.noAccountBalances.push({
                        ...enrollment,
                        issue: 'Journal entries exist but account_balances not updated',
                        hasJournalEntries: true
                    });
                }
            }
            
            // Check 5: Invoice structure exists for this enrollment
            // Get class term year to find expected term/year
            const [classTermYear] = await conn.execute(
                'SELECT term, academic_year FROM class_term_year WHERE gradelevel_class_id = ?',
                [enrollment.gradelevel_class_id]
            );
            
            if (classTermYear.length > 0) {
                const expectedTerm = classTermYear[0].term;
                const expectedYear = classTermYear[0].academic_year;
                
                const [invoiceStructure] = await conn.execute(
                    'SELECT id, total_amount FROM invoice_structures WHERE gradelevel_class_id = ? AND term = ? AND academic_year = ?',
                    [enrollment.gradelevel_class_id, expectedTerm, expectedYear]
                );
                
                if (invoiceStructure.length === 0 && transactions.length === 0) {
                    issues.missingInvoiceStructure.push({
                        ...enrollment,
                        issue: 'No invoice structure found for expected term/year',
                        expectedTerm,
                        expectedYear
                    });
                }
            }
        }
        
        // Print summary
        console.log('='.repeat(80));
        console.log('📋 ENROLLMENT INTEGRITY REPORT');
        console.log('='.repeat(80));
        console.log(`\n✅ Total active enrollments: ${enrollments.length}`);
        console.log(`\n❌ Issues found:\n`);
        
        if (issues.noStudentBalance.length > 0) {
            console.log(`\n🔴 ${issues.noStudentBalance.length} Enrollments with NO STUDENT BALANCE:`);
            issues.noStudentBalance.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
            });
        }
        
        if (issues.noTransactions.length > 0) {
            console.log(`\n🔴 ${issues.noTransactions.length} Enrollments with NO TRANSACTIONS:`);
            issues.noTransactions.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
                console.log(`     Enrollment ID: ${e.enrollment_id}, Date: ${e.enrollment_date}`);
            });
        }
        
        if (issues.noJournalEntries.length > 0) {
            console.log(`\n🔴 ${issues.noJournalEntries.length} Enrollments with NO JOURNAL ENTRIES:`);
            issues.noJournalEntries.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
                console.log(`     Enrollment ID: ${e.enrollment_id}, Date: ${e.enrollment_date}`);
            });
        }
        
        if (issues.noAccountBalances.length > 0) {
            console.log(`\n🔴 ${issues.noAccountBalances.length} Enrollments with JOURNAL ENTRIES but NO ACCOUNT BALANCES:`);
            issues.noAccountBalances.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
            });
        }
        
        if (issues.missingInvoiceStructure.length > 0) {
            console.log(`\n🔴 ${issues.missingInvoiceStructure.length} Enrollments with MISSING INVOICE STRUCTURE:`);
            issues.missingInvoiceStructure.forEach(e => {
                console.log(`   - ${e.student_regnumber} (${e.Name} ${e.Surname}) - ${e.class_name} (${e.stream_name})`);
                console.log(`     Expected: Term ${e.expectedTerm}, Year ${e.expectedYear}`);
            });
        }
        
        // Summary counts
        const totalIssues = Object.values(issues).reduce((sum, arr) => sum + arr.length, 0);
        const uniqueStudentsWithIssues = new Set([
            ...issues.noStudentBalance.map(e => e.student_regnumber),
            ...issues.noTransactions.map(e => e.student_regnumber),
            ...issues.noJournalEntries.map(e => e.student_regnumber),
            ...issues.noAccountBalances.map(e => e.student_regnumber),
            ...issues.missingInvoiceStructure.map(e => e.student_regnumber)
        ]).size;
        
        console.log(`\n${'='.repeat(80)}`);
        console.log(`📊 SUMMARY:`);
        console.log(`   Total Issues: ${totalIssues}`);
        console.log(`   Unique Students Affected: ${uniqueStudentsWithIssues}`);
        console.log(`   Enrollments Without Issues: ${enrollments.length - uniqueStudentsWithIssues}`);
        console.log('='.repeat(80));
        
        // Export detailed report
        const report = {
            timestamp: new Date().toISOString(),
            totalEnrollments: enrollments.length,
            issues,
            summary: {
                totalIssues,
                uniqueStudentsAffected: uniqueStudentsWithIssues,
                enrollmentsWithoutIssues: enrollments.length - uniqueStudentsWithIssues
            }
        };
        
        const fs = require('fs');
        const reportPath = path.join(__dirname, `enrollment_integrity_report_${new Date().toISOString().split('T')[0]}.json`);
        fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
        console.log(`\n💾 Detailed report saved to: ${reportPath}`);
        
    } catch (error) {
        console.error('❌ Error checking enrollment integrity:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the check
checkEnrollmentIntegrity()
    .then(() => {
        console.log('\n✅ Check completed');
        process.exit(0);
    })
    .catch(error => {
        console.error('❌ Fatal error:', error);
        process.exit(1);
    });

