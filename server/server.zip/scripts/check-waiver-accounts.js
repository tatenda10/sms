const { pool } = require('./config/database');

async function checkWaiverAccounts() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n📊 CHECKING WAIVER ACCOUNTS IN CHART OF ACCOUNTS\n');
    console.log('='.repeat(70));
    
    // Check for waiver expense accounts
    const waiverCodes = ['5500', '5510', '5520', '5530', '5540'];
    
    console.log('\n🔍 Checking Waiver Expense Accounts:\n');
    for (const code of waiverCodes) {
      const [accounts] = await conn.execute(
        'SELECT id, code, name, type FROM chart_of_accounts WHERE code = ?',
        [code]
      );
      
      if (accounts.length > 0) {
        const account = accounts[0];
        console.log(`   ${account.code}: ${account.name} (${account.type}) - ID: ${account.id}`);
      } else {
        console.log(`   ${code}: ❌ NOT FOUND`);
      }
    }
    
    // Check for receivable accounts
    const receivableCodes = ['1100', '1110', '1120', '1130'];
    
    console.log('\n🔍 Checking Accounts Receivable:\n');
    for (const code of receivableCodes) {
      const [accounts] = await conn.execute(
        'SELECT id, code, name, type FROM chart_of_accounts WHERE code = ?',
        [code]
      );
      
      if (accounts.length > 0) {
        const account = accounts[0];
        console.log(`   ${account.code}: ${account.name} (${account.type}) - ID: ${account.id}`);
      } else {
        console.log(`   ${code}: ❌ NOT FOUND`);
      }
    }
    
    // Check for any account with "Waiver" in the name
    console.log('\n🔍 Checking for any accounts with "Waiver" in name:\n');
    const [waiverAccounts] = await conn.execute(
      "SELECT id, code, name, type FROM chart_of_accounts WHERE name LIKE '%Waiver%' OR name LIKE '%waiver%'"
    );
    
    if (waiverAccounts.length > 0) {
      waiverAccounts.forEach(account => {
        console.log(`   ${account.code}: ${account.name} (${account.type}) - ID: ${account.id}`);
      });
    } else {
      console.log('   No accounts found with "Waiver" in the name');
    }
    
    // Check for any account with "Marketing" in the name (conflict check)
    console.log('\n🔍 Checking for Marketing accounts (potential conflict):\n');
    const [marketingAccounts] = await conn.execute(
      "SELECT id, code, name, type FROM chart_of_accounts WHERE name LIKE '%Marketing%' OR name LIKE '%marketing%'"
    );
    
    if (marketingAccounts.length > 0) {
      marketingAccounts.forEach(account => {
        console.log(`   ${account.code}: ${account.name} (${account.type}) - ID: ${account.id}`);
      });
    } else {
      console.log('   No accounts found with "Marketing" in the name');
    }
    
  } catch (error) {
    console.error('Error checking accounts:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkWaiverAccounts();

