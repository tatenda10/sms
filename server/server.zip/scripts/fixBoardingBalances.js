const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');
const AccountBalanceService = require('../services/accountBalanceService');
const StudentTransactionController = require('../controllers/students/studentTransactionController');

// Helper function to create boarding enrollment journal entries (same as in enrollmentController.js)
async function createBoardingEnrollmentJournalEntries(conn, student_reg_number, amount, description, term, academic_year, created_by) {
    try {
        // Get account IDs
        const [accountsReceivable] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['1100', 'Asset'] // Accounts Receivable - Tuition
        );
        
        // Use Tuition Revenue - Boarders account (4002)
        const [boardingRevenue] = await conn.execute(
            'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ?',
            ['4002', 'Revenue'] // Tuition Revenue - Boarders
        );

        if (accountsReceivable.length === 0 || boardingRevenue.length === 0) {
            throw new Error('Required accounts not found in chart of accounts (1100 or 4002)');
        }

        const accountsReceivableId = accountsReceivable[0].id;
        const boardingRevenueId = boardingRevenue[0].id;

        // Get or create Fees Journal (ID: 6)
        let journalId = 6;
        const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journalId]);
        if (journalCheck.length === 0) {
            // Try to find any existing journal
            const [existingJournal] = await conn.execute('SELECT id FROM journals ORDER BY id LIMIT 1');
            if (existingJournal.length > 0) {
                journalId = existingJournal[0].id;
            } else {
                // Create Fees Journal if no journals exist
                const [journalResult] = await conn.execute(
                    'INSERT INTO journals (id, name, description, is_active) VALUES (?, ?, ?, ?)',
                    [6, 'Fees Journal', 'All student fee-related transactions, including tuition, exam fees, and boarding fees.', 1]
                );
                journalId = journalResult.insertId || 6;
            }
        }

        // Create journal entry (using Fees Journal)
        const [journalEntry] = await conn.execute(
            `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by) 
             VALUES (?, CURDATE(), ?, ?, ?)`,
            [
                journalId,
                description,
                `BOARDING-${student_reg_number}-${Date.now()}`,
                created_by
            ]
        );

        const journalEntryId = journalEntry.insertId;

        // Create journal entry lines
        const journalLines = [
            {
                journal_entry_id: journalEntryId,
                account_id: accountsReceivableId,
                debit: amount,
                credit: 0,
                description: `Boarding Enrollment - ${student_reg_number}`
            },
            {
                journal_entry_id: journalEntryId,
                account_id: boardingRevenueId,
                debit: 0,
                credit: amount,
                description: `Boarding Revenue - ${student_reg_number}`
            }
        ];

        for (const line of journalLines) {
            await conn.execute(
                `INSERT INTO journal_entry_lines 
                 (journal_entry_id, account_id, debit, credit, description) 
                 VALUES (?, ?, ?, ?, ?)`,
                [line.journal_entry_id, line.account_id, line.debit, line.credit, line.description]
            );
        }

        return journalEntryId;
    } catch (error) {
        console.error('Error creating boarding enrollment journal entries:', error);
        throw error;
    }
}

async function fixBoardingBalances() {
    const conn = await pool.getConnection();
    
    try {
        await conn.beginTransaction();
        
        console.log('🔧 Starting to fix boarding enrollment and payment balances...\n');
        
        // Get default user ID (or use 1 as fallback)
        const [users] = await conn.execute('SELECT id FROM users ORDER BY id LIMIT 1');
        const defaultUserId = users.length > 0 ? users[0].id : 1;
        
        // Get default currency
        const [currencies] = await conn.execute('SELECT id FROM currencies WHERE base_currency = TRUE LIMIT 1');
        const defaultCurrencyId = currencies.length > 0 ? currencies[0].id : 1;
        
        const results = {
            enrollmentsFixed: [],
            paymentsFixed: [],
            errors: []
        };
        
        // 1. Fix boarding enrollments missing transactions
        console.log('📋 Fixing boarding enrollments...\n');
        
        const [enrollmentsMissingTransactions] = await conn.execute(`
            SELECT 
                be.id as enrollment_id,
                be.student_reg_number,
                be.hostel_id,
                be.room_id,
                be.term,
                be.academic_year,
                be.status,
                be.created_at,
                s.Name,
                s.Surname,
                bf.amount as boarding_fee_amount,
                bf.currency_id
            FROM boarding_enrollments be
            JOIN students s ON be.student_reg_number = s.RegNumber
            LEFT JOIN boarding_fees bf ON bf.hostel_id = be.hostel_id 
                AND bf.term = be.term 
                AND bf.academic_year = be.academic_year
                AND bf.is_active = TRUE
            WHERE be.status IN ('enrolled', 'checked_in', 'active')
            AND NOT EXISTS (
                SELECT 1 FROM student_transactions st
                WHERE st.enrollment_id = be.id
                AND st.transaction_type = 'DEBIT'
                AND (st.description LIKE '%BOARDING%' OR st.description LIKE '%BOARDER%')
            )
            ORDER BY be.created_at DESC
        `);
        
        console.log(`Found ${enrollmentsMissingTransactions.length} enrollments missing transactions\n`);
        
        for (const enrollment of enrollmentsMissingTransactions) {
            try {
                console.log(`\n📝 Processing enrollment ${enrollment.enrollment_id} for student ${enrollment.student_reg_number} (${enrollment.Name} ${enrollment.Surname})`);
                
                // Get boarding fee amount
                let feeAmount = parseFloat(enrollment.boarding_fee_amount || 0);
                
                if (feeAmount === 0) {
                    // Try to get fee from boarding_fee_balances
                    const [feeBalance] = await conn.execute(
                        'SELECT total_fee FROM boarding_fee_balances WHERE enrollment_id = ?',
                        [enrollment.enrollment_id]
                    );
                    if (feeBalance.length > 0) {
                        feeAmount = parseFloat(feeBalance[0].total_fee);
                    }
                }
                
                if (feeAmount === 0) {
                    console.log(`   ⚠️  No boarding fee found, skipping...`);
                    results.errors.push({
                        type: 'enrollment',
                        enrollment_id: enrollment.enrollment_id,
                        student_reg_number: enrollment.student_reg_number,
                        error: 'No boarding fee amount found'
                    });
                    continue;
                }
                
                console.log(`   💰 Boarding fee amount: ${feeAmount}`);
                
                // 1. Ensure student balance record exists
                await StudentBalanceService.ensureBalanceRecord(enrollment.student_reg_number, conn);
                console.log(`   ✅ Student balance record ensured`);
                
                // 2. Create DEBIT transaction
                const [transactionResult] = await conn.execute(
                    `INSERT INTO student_transactions 
                     (student_reg_number, transaction_type, amount, description, term, academic_year, 
                      hostel_id, enrollment_id, transaction_date, created_by) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)`,
                    [
                        enrollment.student_reg_number,
                        'DEBIT',
                        feeAmount,
                        `BOARDING ENROLLMENT - Hostel ID: ${enrollment.hostel_id}`,
                        enrollment.term,
                        enrollment.academic_year,
                        enrollment.hostel_id,
                        enrollment.enrollment_id,
                        defaultUserId
                    ]
                );
                
                const transactionId = transactionResult.insertId;
                console.log(`   ✅ Created DEBIT transaction ${transactionId} for amount ${feeAmount}`);
                
                // 3. Update student balance
                await StudentBalanceService.updateBalanceOnTransaction(
                    enrollment.student_reg_number,
                    'DEBIT',
                    feeAmount,
                    conn
                );
                console.log(`   ✅ Updated student balance`);
                
                // 4. Create journal entries
                const description = `BOARDING ENROLLMENT - ${enrollment.student_reg_number} - Term ${enrollment.term} ${enrollment.academic_year}`;
                const journalEntryId = await createBoardingEnrollmentJournalEntries(
                    conn,
                    enrollment.student_reg_number,
                    feeAmount,
                    description,
                    enrollment.term,
                    enrollment.academic_year,
                    defaultUserId
                );
                
                // 5. Link transaction to journal entry
                await conn.execute(
                    'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
                    [journalEntryId, transactionId]
                );
                
                // 6. Update account balances
                await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId);
                console.log(`   ✅ Updated account balances`);
                
                results.enrollmentsFixed.push({
                    enrollment_id: enrollment.enrollment_id,
                    student_reg_number: enrollment.student_reg_number,
                    transaction_id: transactionId,
                    journal_entry_id: journalEntryId,
                    amount: feeAmount
                });
                
            } catch (error) {
                console.error(`   ❌ Error fixing enrollment ${enrollment.enrollment_id}:`, error.message);
                results.errors.push({
                    type: 'enrollment',
                    enrollment_id: enrollment.enrollment_id,
                    student_reg_number: enrollment.student_reg_number,
                    error: error.message
                });
            }
        }
        
        // 2. Fix boarding payments missing transactions
        console.log(`\n\n📋 Fixing boarding payments...\n`);
        
        const [paymentsMissingTransactions] = await conn.execute(`
            SELECT 
                bfp.id as payment_id,
                bfp.student_reg_number,
                bfp.amount_paid,
                bfp.base_currency_amount,
                bfp.currency_id,
                bfp.base_currency_id,
                bfp.payment_method,
                bfp.payment_date,
                bfp.receipt_number,
                bfp.reference_number,
                bfp.term,
                bfp.academic_year,
                bfp.hostel_id,
                bfp.journal_entry_id,
                s.Name,
                s.Surname
            FROM boarding_fees_payments bfp
            JOIN students s ON bfp.student_reg_number = s.RegNumber
            WHERE bfp.status = 'completed'
            AND NOT EXISTS (
                SELECT 1 FROM student_transactions st
                WHERE st.student_reg_number = bfp.student_reg_number
                AND st.transaction_type = 'CREDIT'
                AND (st.description LIKE '%BOARDING%' OR st.description LIKE '%BOARDER%')
                AND ABS(st.amount - bfp.base_currency_amount) < 0.01
                AND DATE(st.transaction_date) = DATE(bfp.payment_date)
            )
            ORDER BY bfp.payment_date DESC
        `);
        
        console.log(`Found ${paymentsMissingTransactions.length} payments missing transactions\n`);
        
        for (const payment of paymentsMissingTransactions) {
            try {
                console.log(`\n📝 Processing payment ${payment.payment_id} for student ${payment.student_reg_number} (${payment.Name} ${payment.Surname})`);
                console.log(`   💰 Payment amount: ${payment.base_currency_amount || payment.amount_paid}`);
                console.log(`   📅 Payment date: ${payment.payment_date}`);
                console.log(`   🧾 Receipt: ${payment.receipt_number || 'N/A'}`);
                
                // 1. Ensure student balance record exists
                await StudentBalanceService.ensureBalanceRecord(payment.student_reg_number, conn);
                console.log(`   ✅ Student balance record ensured`);
                
                // 2. Create CREDIT transaction
                const paymentAmount = parseFloat(payment.base_currency_amount || payment.amount_paid);
                const description = `BOARDING PAYMENT - ${payment.payment_method} - Receipt #${payment.receipt_number || payment.reference_number || payment.payment_id}`;
                
                const [transactionResult] = await conn.execute(
                    `INSERT INTO student_transactions 
                     (student_reg_number, transaction_type, amount, description, term, academic_year, 
                      hostel_id, transaction_date, created_by) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        payment.student_reg_number,
                        'CREDIT',
                        paymentAmount,
                        description,
                        payment.term,
                        payment.academic_year,
                        payment.hostel_id,
                        payment.payment_date,
                        defaultUserId
                    ]
                );
                
                const transactionId = transactionResult.insertId;
                console.log(`   ✅ Created CREDIT transaction ${transactionId} for amount ${paymentAmount}`);
                
                // 3. Update student balance
                await StudentBalanceService.updateBalanceOnTransaction(
                    payment.student_reg_number,
                    'CREDIT',
                    paymentAmount,
                    conn
                );
                console.log(`   ✅ Updated student balance`);
                
                // 4. Check if journal entry already exists for this payment
                let journalEntryId = payment.journal_entry_id || null;
                
                // Check if there's an existing journal entry for this payment (by amount, date, and student)
                if (!journalEntryId) {
                    const [existingJournal] = await conn.execute(`
                        SELECT je.id
                        FROM journal_entries je
                        JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
                        JOIN chart_of_accounts coa ON jel.account_id = coa.id
                        WHERE je.description LIKE '%BOARDING%'
                        AND je.description LIKE ?
                        AND DATE(je.entry_date) = DATE(?)
                        AND coa.code IN ('1000', '1010')
                        AND jel.debit = ?
                        GROUP BY je.id
                        HAVING COUNT(DISTINCT jel.account_id) >= 1
                        LIMIT 1
                    `, [
                        `%${payment.student_reg_number}%`,
                        payment.payment_date,
                        paymentAmount
                    ]);
                    
                    if (existingJournal.length > 0) {
                        journalEntryId = existingJournal[0].id;
                        console.log(`   ℹ️  Found existing journal entry ${journalEntryId} for this payment`);
                    }
                }
                
                // 5. Create journal entries only if they don't exist
                if (!journalEntryId) {
                    const student_name = `${payment.Name} ${payment.Surname}`;
                    
                    // Get account IDs
                    const [cashAccount] = await conn.execute(
                        'SELECT id FROM chart_of_accounts WHERE code = ? AND is_active = TRUE',
                        ['1000'] // Cash on Hand
                    );
                    
                    const [bankAccount] = await conn.execute(
                        'SELECT id FROM chart_of_accounts WHERE code = ? AND is_active = TRUE',
                        ['1010'] // Bank Account
                    );
                    
                    const [arAccount] = await conn.execute(
                        'SELECT id FROM chart_of_accounts WHERE code = ? AND is_active = TRUE',
                        ['1100'] // Accounts Receivable - Tuition
                    );
                    
                    if (!cashAccount.length || !bankAccount.length || !arAccount.length) {
                        throw new Error('Required chart of accounts not found (1000, 1010, or 1100)');
                    }
                    
                    // Determine debit account based on payment method
                    let debitAccountId;
                    if (payment.payment_method === 'Cash' || payment.payment_method === 'Mobile Money') {
                        debitAccountId = cashAccount[0].id;
                    } else {
                        debitAccountId = bankAccount[0].id;
                    }
                    
                    // Get or create journal
                    let journalId = 1;
                    const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journalId]);
                    if (journalCheck.length === 0) {
                        const [existingJournal] = await conn.execute('SELECT id FROM journals ORDER BY id LIMIT 1');
                        if (existingJournal.length > 0) {
                            journalId = existingJournal[0].id;
                        }
                    }
                    
                    // Create journal entry
                    const [journalResult] = await conn.execute(
                        `INSERT INTO journal_entries (journal_id, entry_date, description, reference, created_by) 
                         VALUES (?, ?, ?, ?, ?)`,
                        [
                            journalId,
                            payment.payment_date,
                            `Boarding Fee Payment - ${student_name} (${payment.student_reg_number})`,
                            payment.receipt_number || payment.reference_number || `BF-${payment.payment_id}`,
                            defaultUserId
                        ]
                    );
                    
                    journalEntryId = journalResult.insertId;
                    console.log(`   ✅ Created new journal entry ${journalEntryId}`);
                    
                    // Create journal entry lines
                    // Debit: Cash/Bank
                    await conn.execute(
                        `INSERT INTO journal_entry_lines 
                         (journal_entry_id, account_id, debit, credit, description) 
                         VALUES (?, ?, ?, ?, ?)`,
                        [
                            journalEntryId,
                            debitAccountId,
                            paymentAmount,
                            0,
                            `Boarding Payment - ${student_name}`
                        ]
                    );
                    
                    // Credit: Accounts Receivable
                    await conn.execute(
                        `INSERT INTO journal_entry_lines 
                         (journal_entry_id, account_id, debit, credit, description) 
                         VALUES (?, ?, ?, ?, ?)`,
                        [
                            journalEntryId,
                            arAccount[0].id,
                            0,
                            paymentAmount,
                            `Boarding Payment - ${student_name}`
                        ]
                    );
                    
                    // Update account balances
                    await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId);
                    console.log(`   ✅ Updated account balances`);
                } else {
                    console.log(`   ℹ️  Using existing journal entry, skipping account balance update`);
                }
                
                // 6. Link transaction to journal entry
                await conn.execute(
                    'UPDATE student_transactions SET journal_entry_id = ? WHERE id = ?',
                    [journalEntryId, transactionId]
                );
                
                // 7. Link payment to journal entry
                await conn.execute(
                    'UPDATE boarding_fees_payments SET journal_entry_id = ? WHERE id = ?',
                    [journalEntryId, payment.payment_id]
                );
                
                results.paymentsFixed.push({
                    payment_id: payment.payment_id,
                    student_reg_number: payment.student_reg_number,
                    transaction_id: transactionId,
                    journal_entry_id: journalEntryId,
                    amount: paymentAmount
                });
                
            } catch (error) {
                console.error(`   ❌ Error fixing payment ${payment.payment_id}:`, error.message);
                results.errors.push({
                    type: 'payment',
                    payment_id: payment.payment_id,
                    student_reg_number: payment.student_reg_number,
                    error: error.message
                });
            }
        }
        
        await conn.commit();
        
        console.log(`\n\n================================================================================`);
        console.log(`📋 FIX SUMMARY`);
        console.log(`================================================================================`);
        console.log(`✅ Enrollments fixed: ${results.enrollmentsFixed.length}`);
        console.log(`✅ Payments fixed: ${results.paymentsFixed.length}`);
        console.log(`❌ Errors: ${results.errors.length}`);
        console.log(`================================================================================\n`);
        
        if (results.errors.length > 0) {
            console.log(`❌ ERRORS:\n`);
            results.errors.forEach(err => {
                console.log(`   - ${err.type === 'enrollment' ? `Enrollment ${err.enrollment_id}` : `Payment ${err.payment_id}`} (${err.student_reg_number}): ${err.error}`);
            });
        }
        
        // Save detailed report
        const fs = require('fs');
        const reportPath = path.join(__dirname, `boarding_balance_fix_report_${new Date().toISOString().split('T')[0]}.json`);
        fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
        console.log(`\n💾 Detailed report saved to: ${reportPath}`);
        
        console.log(`\n✅ Fix completed`);
        
    } catch (error) {
        await conn.rollback();
        console.error('❌ Error fixing boarding balances:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the script
fixBoardingBalances()
    .then(() => {
        console.log('\n✅ Script completed');
        process.exit(0);
    })
    .catch(error => {
        console.error('\n❌ Script failed:', error);
        process.exit(1);
    });

