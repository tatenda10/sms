const { pool } = require('../config/database');

async function testMonthlyIncomeStatementAPI() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing Monthly Income Statement API endpoint...');
    
    // Test September 2025 (month 9, year 2025)
    const month = 9;
    const year = 2025;
    
    console.log(`\n📅 Testing: Month ${month}, Year ${year}`);
    
    // Calculate start and end dates for the month (same logic as the API)
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0); // Last day of the month
    
    const startDateStr = startDate.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];
    
    console.log(`📅 Date Range: ${startDateStr} to ${endDateStr}`);
    
    // Test the exact same query that generateIncomeStatementData uses
    console.log('\n💰 Testing Revenue Query...');
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [revenue] = await connection.execute(revenueQuery, [startDateStr, endDateStr]);
    
    console.log(`   ✅ Found ${revenue.length} revenue accounts:`);
    revenue.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💰' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Test expense query
    console.log('\n💸 Testing Expense Query...');
    const expenseQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.debit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Expense' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [expenses] = await connection.execute(expenseQuery, [startDateStr, endDateStr]);
    
    console.log(`   ✅ Found ${expenses.length} expense accounts:`);
    expenses.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💸' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Calculate totals
    const totalRevenue = revenue.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const netIncome = totalRevenue - totalExpenses;
    
    console.log(`\n📊 Summary:`);
    console.log(`   • Total Revenue: $${totalRevenue.toFixed(2)}`);
    console.log(`   • Total Expenses: $${totalExpenses.toFixed(2)}`);
    console.log(`   • Net Income: $${netIncome.toFixed(2)}`);
    
    // Simulate the API response structure
    const apiResponse = {
      period: {
        period_name: `${startDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}`,
        start_date: startDateStr,
        end_date: endDateStr
      },
      revenue: revenue,
      expenses: expenses,
      totals: {
        total_revenue: totalRevenue,
        total_expenses: totalExpenses,
        net_income: netIncome
      }
    };
    
    console.log(`\n🔍 API Response Structure:`);
    console.log(`   • period.period_name: ${apiResponse.period.period_name}`);
    console.log(`   • revenue.length: ${apiResponse.revenue.length}`);
    console.log(`   • expenses.length: ${apiResponse.expenses.length}`);
    console.log(`   • totals.total_revenue: $${apiResponse.totals.total_revenue.toFixed(2)}`);
    console.log(`   • totals.total_expenses: $${apiResponse.totals.total_expenses.toFixed(2)}`);
    console.log(`   • totals.net_income: $${apiResponse.totals.net_income.toFixed(2)}`);
    
    if (expenses.length === 0) {
      console.log('\n❌ PROBLEM: No expense accounts returned by the query!');
      console.log('   This explains why the frontend shows "No expense accounts configured"');
    } else {
      console.log('\n✅ SUCCESS: Expense accounts are being returned by the backend!');
      console.log('   The frontend should display all expense accounts with zero values.');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing monthly income statement API:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testMonthlyIncomeStatementAPI()
    .then(() => {
      console.log('\n✅ Monthly income statement API test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Monthly income statement API test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testMonthlyIncomeStatementAPI;
