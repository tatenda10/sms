const { pool } = require('../config/database');

async function checkBoardingFees() {
  try {
    const conn = await pool.getConnection();
    
    // Get all boarding fees
    const [boardingFees] = await conn.execute('SELECT id, hostel_id, amount, term, academic_year, is_active FROM boarding_fees');
    console.log('=== ALL BOARDING FEES ===');
    console.log(boardingFees);
    
    // Get all hostels
    const [hostels] = await conn.execute('SELECT id, name FROM hostels');
    console.log('\n=== ALL HOSTELS ===');
    console.log(hostels);
    
    // Get the specific enrollment that's failing
    const [enrollment] = await conn.execute('SELECT * FROM boarding_enrollments WHERE id = 16');
    console.log('\n=== ENROLLMENT 16 ===');
    console.log(enrollment);
    
    // Check if there are any boarding fees for hostel_id 1 (assuming that's the hostel)
    if (enrollment.length > 0) {
      const hostelId = enrollment[0].hostel_id;
      const term = enrollment[0].term;
      const academicYear = enrollment[0].academic_year;
      
      console.log(`\n=== CHECKING FOR HOSTEL ${hostelId}, TERM ${term}, YEAR ${academicYear} ===`);
      
      const [matchingFees] = await conn.execute(
        'SELECT * FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
        [hostelId, term, academicYear]
      );
      console.log('Matching fees:', matchingFees);
      
      // Also check with different term formats
      console.log('\n=== CHECKING WITH DIFFERENT TERM FORMATS ===');
      const [allFeesForHostel] = await conn.execute(
        'SELECT * FROM boarding_fees WHERE hostel_id = ? AND academic_year = ? AND is_active = TRUE',
        [hostelId, academicYear]
      );
      console.log('All fees for this hostel and year:', allFeesForHostel);
    }
    
    conn.release();
  } catch (error) {
    console.error('Error:', error);
  }
}

checkBoardingFees();
