const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');

async function testBalanceUpdate() {
    const conn = await pool.getConnection();
    try {
        console.log('=== TESTING STUDENT BALANCE UPDATE ===\n');
        
        // Get a student with transactions
        const [students] = await conn.execute(
            `SELECT DISTINCT st.student_reg_number, s.Name, s.Surname
             FROM student_transactions st
             JOIN students s ON st.student_reg_number = s.RegNumber
             WHERE st.transaction_type = 'DEBIT'
             LIMIT 1`
        );
        
        if (students.length === 0) {
            console.log('No students with DEBIT transactions found');
            return;
        }
        
        const studentReg = students[0].student_reg_number;
        const studentName = `${students[0].Name} ${students[0].Surname}`;
        
        console.log(`Testing with student: ${studentName} (${studentReg})`);
        
        // Get current balance
        const [currentBalance] = await conn.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [studentReg]
        );
        
        console.log(`Current balance: ${currentBalance[0]?.current_balance || 0}`);
        
        // Get all transactions for this student
        const [transactions] = await conn.execute(
            'SELECT id, transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY transaction_date DESC',
            [studentReg]
        );
        
        console.log(`\nCurrent transactions (${transactions.length}):`);
        transactions.forEach(t => {
            console.log(`  ${t.id}: ${t.transaction_type} ${t.amount} - ${t.description}`);
        });
        
        // Get a DEBIT transaction to delete
        const debitTransactions = transactions.filter(t => t.transaction_type === 'DEBIT');
        
        if (debitTransactions.length === 0) {
            console.log('\nNo DEBIT transactions to test with');
            return;
        }
        
        const transactionToDelete = debitTransactions[0];
        console.log(`\nWill delete transaction: ${transactionToDelete.id} (${transactionToDelete.amount})`);
        
        // Delete the transaction
        await conn.execute(
            'DELETE FROM student_transactions WHERE id = ?',
            [transactionToDelete.id]
        );
        
        console.log('Transaction deleted from database');
        
        // Update the balance
        await StudentBalanceService.updateBalanceOnTransactionDelete(
            studentReg,
            'DEBIT',
            transactionToDelete.amount,
            conn
        );
        
        console.log('Balance updated using StudentBalanceService');
        
        // Check the new balance
        const [newBalance] = await conn.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [studentReg]
        );
        
        console.log(`New balance: ${newBalance[0]?.current_balance || 0}`);
        
        // Verify the calculation
        const expectedBalance = (currentBalance[0]?.current_balance || 0) + transactionToDelete.amount;
        console.log(`Expected balance: ${expectedBalance}`);
        
        if (Math.abs((newBalance[0]?.current_balance || 0) - expectedBalance) < 0.01) {
            console.log('✅ Balance update successful!');
        } else {
            console.log('❌ Balance update failed!');
        }
        
        // Recreate the transaction to restore the original state
        await conn.execute(
            `INSERT INTO student_transactions 
             (student_reg_number, transaction_type, amount, description, transaction_date, created_by)
             VALUES (?, 'DEBIT', ?, ?, NOW(), 1)`,
            [studentReg, transactionToDelete.amount, transactionToDelete.description]
        );
        
        // Update balance back
        await StudentBalanceService.updateBalanceOnTransaction(
            studentReg,
            'DEBIT',
            transactionToDelete.amount,
            conn
        );
        
        console.log('\nTransaction restored for testing');
        
    } catch (error) {
        console.error('Error in test:', error);
    } finally {
        conn.release();
        await pool.end();
    }
}

testBalanceUpdate().catch(console.error);
