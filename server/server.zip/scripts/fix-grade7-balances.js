const { pool } = require('./config/database');
const StudentBalanceService = require('./services/studentBalanceService');

// First, recalculate all balances from transactions to fix any issues
async function recalculateAllBalances() {
  console.log('\n🔄 STEP 0: Recalculating all student balances from transactions...\n');
  const conn = await pool.getConnection();
  
  try {
    // Get all Grade 7 students
    const regNumbers = [
      'R00001N', 'R00001P', 'R00001K', 'R00001M', 'R00002M', 'R00001R', 'R00001J',
      'R00002J', 'R00001A', 'R00001T', 'R00002N', 'R00003N', 'R00003M', 'R00001S',
      'R00002S', 'R00004M', 'R00001B', 'R00003S', 'R00002A', 'R00003J', 'R00004J',
      'R00004K', 'R00002B', 'R00005J'
    ];
    
    for (const regNumber of regNumbers) {
      await StudentBalanceService.recalculateBalance(regNumber, conn);
    }
    
    console.log('✅ All balances recalculated\n');
  } finally {
    conn.release();
  }
}

recalculateAllBalances().then(() => process.exit(0)).catch(err => {
  console.error(err);
  process.exit(1);
});

