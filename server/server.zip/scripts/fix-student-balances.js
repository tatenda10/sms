const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');

async function fixStudentBalances() {
    const conn = await pool.getConnection();
    try {
        console.log('Starting student balance recalculation...');
        
        // Get all students
        const [students] = await conn.execute(
            'SELECT DISTINCT student_reg_number FROM students WHERE student_reg_number IS NOT NULL'
        );
        
        console.log(`Found ${students.length} students to process`);
        
        let processed = 0;
        let errors = 0;
        
        for (const student of students) {
            try {
                console.log(`Processing student: ${student.student_reg_number}`);
                
                // Recalculate balance for this student
                const newBalance = await StudentBalanceService.recalculateBalance(student.student_reg_number, conn);
                
                console.log(`Student ${student.student_reg_number}: Balance recalculated to ${newBalance}`);
                processed++;
                
            } catch (error) {
                console.error(`Error processing student ${student.student_reg_number}:`, error);
                errors++;
            }
        }
        
        console.log(`\n=== SUMMARY ===`);
        console.log(`Total students processed: ${processed}`);
        console.log(`Errors: ${errors}`);
        console.log(`Success: ${processed - errors}`);
        
        // Show some sample balances
        const [sampleBalances] = await conn.execute(
            `SELECT student_reg_number, current_balance, last_updated 
             FROM student_balances 
             ORDER BY last_updated DESC 
             LIMIT 10`
        );
        
        console.log(`\n=== SAMPLE BALANCES ===`);
        sampleBalances.forEach(balance => {
            console.log(`${balance.student_reg_number}: ${balance.current_balance} (updated: ${balance.last_updated})`);
        });
        
    } catch (error) {
        console.error('Error in fixStudentBalances:', error);
    } finally {
        conn.release();
        await pool.end();
    }
}

// Run the script
fixStudentBalances().catch(console.error);
