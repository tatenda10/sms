const { pool } = require('../config/database');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

class DataReconciliation {
    constructor() {
        this.config = {
            // API endpoint for cPanel
            apiEndpoint: process.env.CPANEL_API_URL || 'https://your-domain.com/api/reconcile-data.php',
            apiKey: process.env.CPANEL_API_KEY || 'your_secure_api_key',
            
            // Reconciliation settings
            exportPath: './reconciliation-exports',
            conflictResolution: 'timestamp', // 'timestamp', 'local', 'remote', 'manual'
            backupBeforeReconcile: true
        };
    }

    // Main reconciliation method
    async reconcileData() {
        try {
            console.log('🔄 Starting data reconciliation...');
            
            // Create export directory
            if (!fs.existsSync(this.config.exportPath)) {
                fs.mkdirSync(this.config.exportPath, { recursive: true });
            }
            
            // Get all tables
            const tables = await this.getAllTables();
            console.log(`📊 Found ${tables.length} tables to reconcile`);
            
            const reconciliationReport = {
                timestamp: new Date().toISOString(),
                tables_processed: 0,
                conflicts_found: 0,
                records_updated: 0,
                records_created: 0,
                records_deleted: 0,
                conflicts: []
            };
            
            // Process each table
            for (const table of tables) {
                console.log(`🔍 Analyzing table: ${table}`);
                
                const tableReconciliation = await this.reconcileTable(table);
                reconciliationReport.tables_processed++;
                reconciliationReport.conflicts_found += tableReconciliation.conflicts.length;
                reconciliationReport.records_updated += tableReconciliation.updated;
                reconciliationReport.records_created += tableReconciliation.created;
                reconciliationReport.records_deleted += tableReconciliation.deleted;
                reconciliationReport.conflicts.push(...tableReconciliation.conflicts);
                
                console.log(`✅ Table ${table}: ${tableReconciliation.conflicts.length} conflicts, ${tableReconciliation.updated} updated, ${tableReconciliation.created} created`);
            }
            
            // Save reconciliation report
            const reportFile = path.join(this.config.exportPath, `reconciliation_report_${new Date().toISOString().split('T')[0]}.json`);
            fs.writeFileSync(reportFile, JSON.stringify(reconciliationReport, null, 2));
            
            console.log('🎉 Data reconciliation completed!');
            console.log(`📊 Summary: ${reconciliationReport.conflicts_found} conflicts found, ${reconciliationReport.records_updated} records updated`);
            
            return reconciliationReport;
            
        } catch (error) {
            console.error('❌ Data reconciliation failed:', error.message);
            throw error;
        }
    }

    // Reconcile a single table
    async reconcileTable(tableName) {
        try {
            // Get local data
            const localData = await this.getLocalTableData(tableName);
            
            // Get remote data
            const remoteData = await this.getRemoteTableData(tableName);
            
            // Find conflicts and differences
            const conflicts = this.findConflicts(localData, remoteData, tableName);
            
            // Resolve conflicts based on strategy
            const resolution = await this.resolveConflicts(conflicts, tableName);
            
            return {
                table: tableName,
                conflicts: conflicts,
                updated: resolution.updated,
                created: resolution.created,
                deleted: resolution.deleted
            };
            
        } catch (error) {
            console.error(`❌ Error reconciling table ${tableName}:`, error.message);
            return {
                table: tableName,
                conflicts: [],
                updated: 0,
                created: 0,
                deleted: 0,
                error: error.message
            };
        }
    }

    // Get local table data
    async getLocalTableData(tableName) {
        const [rows] = await pool.execute(`SELECT * FROM \`${tableName}\``);
        return rows;
    }

    // Get remote table data via API
    async getRemoteTableData(tableName) {
        try {
            const response = await axios.post(this.config.apiEndpoint, {
                action: 'get_table_data',
                table_name: tableName
            }, {
                headers: {
                    'Authorization': `Bearer ${this.config.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            });
            
            return response.data.data || [];
            
        } catch (error) {
            console.error(`❌ Failed to get remote data for ${tableName}:`, error.message);
            return [];
        }
    }

    // Find conflicts between local and remote data
    findConflicts(localData, remoteData, tableName) {
        const conflicts = [];
        
        // Create maps for easier lookup
        const localMap = new Map();
        const remoteMap = new Map();
        
        localData.forEach(row => {
            const key = this.generateRowKey(row, tableName);
            localMap.set(key, row);
        });
        
        remoteData.forEach(row => {
            const key = this.generateRowKey(row, tableName);
            remoteMap.set(key, row);
        });
        
        // Find conflicts (same key, different data)
        for (const [key, localRow] of localMap) {
            if (remoteMap.has(key)) {
                const remoteRow = remoteMap.get(key);
                if (!this.rowsEqual(localRow, remoteRow)) {
                    conflicts.push({
                        type: 'conflict',
                        table: tableName,
                        key: key,
                        local: localRow,
                        remote: remoteRow,
                        differences: this.findRowDifferences(localRow, remoteRow)
                    });
                }
            }
        }
        
        // Find local-only records
        for (const [key, localRow] of localMap) {
            if (!remoteMap.has(key)) {
                conflicts.push({
                    type: 'local_only',
                    table: tableName,
                    key: key,
                    local: localRow,
                    remote: null
                });
            }
        }
        
        // Find remote-only records
        for (const [key, remoteRow] of remoteMap) {
            if (!localMap.has(key)) {
                conflicts.push({
                    type: 'remote_only',
                    table: tableName,
                    key: key,
                    local: null,
                    remote: remoteRow
                });
            }
        }
        
        return conflicts;
    }

    // Generate a unique key for a row
    generateRowKey(row, tableName) {
        // Use primary key or first few columns as key
        const keyColumns = this.getKeyColumns(tableName);
        return keyColumns.map(col => row[col]).join('|');
    }

    // Get key columns for a table
    getKeyColumns(tableName) {
        // This would typically query INFORMATION_SCHEMA to get primary key columns
        // For now, using common patterns
        const commonKeys = ['id', 'ID', 'reg_number', 'RegNumber', 'student_id', 'item_id'];
        
        // You could enhance this to query the actual primary key
        return commonKeys;
    }

    // Check if two rows are equal
    rowsEqual(row1, row2) {
        const keys1 = Object.keys(row1);
        const keys2 = Object.keys(row2);
        
        if (keys1.length !== keys2.length) return false;
        
        for (const key of keys1) {
            if (row1[key] !== row2[key]) return false;
        }
        
        return true;
    }

    // Find differences between two rows
    findRowDifferences(row1, row2) {
        const differences = [];
        const allKeys = new Set([...Object.keys(row1), ...Object.keys(row2)]);
        
        for (const key of allKeys) {
            if (row1[key] !== row2[key]) {
                differences.push({
                    column: key,
                    local_value: row1[key],
                    remote_value: row2[key]
                });
            }
        }
        
        return differences;
    }

    // Resolve conflicts based on strategy
    async resolveConflicts(conflicts, tableName) {
        const resolution = {
            updated: 0,
            created: 0,
            deleted: 0
        };
        
        for (const conflict of conflicts) {
            switch (conflict.type) {
                case 'conflict':
                    await this.resolveDataConflict(conflict, tableName);
                    resolution.updated++;
                    break;
                    
                case 'local_only':
                    await this.handleLocalOnlyRecord(conflict, tableName);
                    resolution.created++;
                    break;
                    
                case 'remote_only':
                    await this.handleRemoteOnlyRecord(conflict, tableName);
                    resolution.deleted++;
                    break;
            }
        }
        
        return resolution;
    }

    // Resolve data conflicts
    async resolveDataConflict(conflict, tableName) {
        switch (this.config.conflictResolution) {
            case 'timestamp':
                await this.resolveByTimestamp(conflict, tableName);
                break;
                
            case 'local':
                await this.resolveByLocal(conflict, tableName);
                break;
                
            case 'remote':
                await this.resolveByRemote(conflict, tableName);
                break;
                
            case 'manual':
                await this.flagForManualResolution(conflict, tableName);
                break;
        }
    }

    // Resolve by timestamp (newer wins)
    async resolveByTimestamp(conflict, tableName) {
        const localTimestamp = this.getRowTimestamp(conflict.local);
        const remoteTimestamp = this.getRowTimestamp(conflict.remote);
        
        if (localTimestamp > remoteTimestamp) {
            await this.updateRemoteRecord(conflict, tableName);
        } else {
            await this.updateLocalRecord(conflict, tableName);
        }
    }

    // Resolve by local data
    async resolveByLocal(conflict, tableName) {
        await this.updateRemoteRecord(conflict, tableName);
    }

    // Resolve by remote data
    async resolveByRemote(conflict, tableName) {
        await this.updateLocalRecord(conflict, tableName);
    }

    // Flag for manual resolution
    async flagForManualResolution(conflict, tableName) {
        const flagFile = path.join(this.config.exportPath, `manual_resolution_${tableName}.json`);
        let manualFlags = [];
        
        if (fs.existsSync(flagFile)) {
            manualFlags = JSON.parse(fs.readFileSync(flagFile, 'utf8'));
        }
        
        manualFlags.push({
            timestamp: new Date().toISOString(),
            conflict: conflict
        });
        
        fs.writeFileSync(flagFile, JSON.stringify(manualFlags, null, 2));
    }

    // Handle local-only records
    async handleLocalOnlyRecord(conflict, tableName) {
        // Create record on remote
        await this.createRemoteRecord(conflict.local, tableName);
    }

    // Handle remote-only records
    async handleRemoteOnlyRecord(conflict, tableName) {
        // Create record locally
        await this.createLocalRecord(conflict.remote, tableName);
    }

    // Update remote record
    async updateRemoteRecord(conflict, tableName) {
        try {
            await axios.post(this.config.apiEndpoint, {
                action: 'update_record',
                table_name: tableName,
                data: conflict.local,
                key: conflict.key
            }, {
                headers: {
                    'Authorization': `Bearer ${this.config.apiKey}`,
                    'Content-Type': 'application/json'
                }
            });
        } catch (error) {
            console.error(`❌ Failed to update remote record:`, error.message);
        }
    }

    // Update local record
    async updateLocalRecord(conflict, tableName) {
        try {
            const keyColumns = this.getKeyColumns(tableName);
            const whereClause = keyColumns.map(col => `\`${col}\` = ?`).join(' AND ');
            const whereValues = keyColumns.map(col => conflict.remote[col]);
            
            const setClause = Object.keys(conflict.remote)
                .filter(key => !keyColumns.includes(key))
                .map(key => `\`${key}\` = ?`)
                .join(', ');
            const setValues = Object.keys(conflict.remote)
                .filter(key => !keyColumns.includes(key))
                .map(key => conflict.remote[key]);
            
            const query = `UPDATE \`${tableName}\` SET ${setClause} WHERE ${whereClause}`;
            await pool.execute(query, [...setValues, ...whereValues]);
            
        } catch (error) {
            console.error(`❌ Failed to update local record:`, error.message);
        }
    }

    // Create remote record
    async createRemoteRecord(data, tableName) {
        try {
            await axios.post(this.config.apiEndpoint, {
                action: 'create_record',
                table_name: tableName,
                data: data
            }, {
                headers: {
                    'Authorization': `Bearer ${this.config.apiKey}`,
                    'Content-Type': 'application/json'
                }
            });
        } catch (error) {
            console.error(`❌ Failed to create remote record:`, error.message);
        }
    }

    // Create local record
    async createLocalRecord(data, tableName) {
        try {
            const columns = Object.keys(data);
            const values = Object.values(data);
            const placeholders = columns.map(() => '?').join(', ');
            
            const query = `INSERT INTO \`${tableName}\` (\`${columns.join('`, `')}\`) VALUES (${placeholders})`;
            await pool.execute(query, values);
            
        } catch (error) {
            console.error(`❌ Failed to create local record:`, error.message);
        }
    }

    // Get timestamp from row (assuming updated_at or similar column)
    getRowTimestamp(row) {
        const timestampColumns = ['updated_at', 'modified_at', 'last_updated', 'created_at'];
        
        for (const col of timestampColumns) {
            if (row[col]) {
                return new Date(row[col]).getTime();
            }
        }
        
        return 0; // Default to 0 if no timestamp found
    }

    // Get all table names
    async getAllTables() {
        const [tables] = await pool.execute(`
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        `);
        
        return tables.map(row => row.TABLE_NAME);
    }

    // Generate reconciliation report
    async generateReport() {
        try {
            console.log('📊 Generating reconciliation report...');
            
            const tables = await this.getAllTables();
            const report = {
                timestamp: new Date().toISOString(),
                summary: {
                    total_tables: tables.length,
                    tables_with_conflicts: 0,
                    total_conflicts: 0
                },
                table_details: {}
            };
            
            for (const table of tables) {
                const localData = await this.getLocalTableData(table);
                const remoteData = await this.getRemoteTableData(table);
                const conflicts = this.findConflicts(localData, remoteData, table);
                
                report.table_details[table] = {
                    local_records: localData.length,
                    remote_records: remoteData.length,
                    conflicts: conflicts.length,
                    conflict_types: {
                        data_conflicts: conflicts.filter(c => c.type === 'conflict').length,
                        local_only: conflicts.filter(c => c.type === 'local_only').length,
                        remote_only: conflicts.filter(c => c.type === 'remote_only').length
                    }
                };
                
                if (conflicts.length > 0) {
                    report.summary.tables_with_conflicts++;
                    report.summary.total_conflicts += conflicts.length;
                }
            }
            
            // Save report
            const reportFile = path.join(this.config.exportPath, `reconciliation_analysis_${new Date().toISOString().split('T')[0]}.json`);
            fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
            
            console.log('✅ Reconciliation report generated');
            console.log(`📊 Found ${report.summary.total_conflicts} conflicts across ${report.summary.tables_with_conflicts} tables`);
            
            return report;
            
        } catch (error) {
            console.error('❌ Failed to generate report:', error.message);
            throw error;
        }
    }
}

// CLI usage
if (require.main === module) {
    const reconciliation = new DataReconciliation();
    
    const command = process.argv[2] || 'reconcile';
    
    switch (command) {
        case 'reconcile':
            reconciliation.reconcileData().catch(console.error);
            break;
            
        case 'report':
            reconciliation.generateReport().catch(console.error);
            break;
            
        default:
            console.log('Usage: node data-reconciliation.js [reconcile|report]');
            console.log('  reconcile - Perform data reconciliation');
            console.log('  report    - Generate reconciliation analysis report');
            break;
    }
}

module.exports = DataReconciliation;
