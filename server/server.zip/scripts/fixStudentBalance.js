const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');

async function fixStudentBalance() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔧 Fixing balance for student: ${studentRegNumber}\n`);
    
    // Recalculate balance from all transactions
    console.log('1️⃣ Recalculating balance from transactions...');
    const newBalance = await StudentBalanceService.recalculateBalance(studentRegNumber, conn);
    console.log(`   ✅ New balance: $${newBalance.toFixed(2)}\n`);
    
    // Verify the fix
    const [balanceRecord] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    if (balanceRecord.length > 0) {
      console.log('2️⃣ Verification:');
      console.log(`   Current Balance: $${parseFloat(balanceRecord[0].current_balance).toFixed(2)}`);
      
      if (Math.abs(parseFloat(balanceRecord[0].current_balance)) < 0.01) {
        console.log('   ✅ Balance fixed! Balance is now $0.00');
      } else {
        console.log(`   ⚠️  Balance is still not zero: $${parseFloat(balanceRecord[0].current_balance).toFixed(2)}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixStudentBalance();

