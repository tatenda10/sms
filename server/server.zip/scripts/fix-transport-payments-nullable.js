const { pool } = require('../config/database');

async function fixTransportPaymentsNullable() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🚀 Starting transport payments nullable fix...');
    
    // Step 1: Make transport_fee_id nullable
    console.log('\n⚡ Step 1: Making transport_fee_id column nullable...');
    await connection.execute(`
      ALTER TABLE transport_payments 
      MODIFY COLUMN transport_fee_id INT NULL
    `);
    console.log('   ✅ transport_fee_id is now nullable');
    
    // Step 2: Add comment to clarify usage
    console.log('\n⚡ Step 2: Adding column comment...');
    await connection.execute(`
      ALTER TABLE transport_payments 
      MODIFY COLUMN transport_fee_id INT NULL 
      COMMENT 'NULL for direct payments, references transport_fees.id for fee-based payments'
    `);
    console.log('   ✅ Column comment added');
    
    // Step 3: Verify the change
    console.log('\n⚡ Step 3: Verifying the change...');
    const [columns] = await connection.execute('DESCRIBE transport_payments');
    const transportFeeIdColumn = columns.find(col => col.Field === 'transport_fee_id');
    
    if (transportFeeIdColumn && transportFeeIdColumn.Null === 'YES') {
      console.log('   ✅ Verification successful: transport_fee_id now allows NULL');
    } else {
      throw new Error('Verification failed: transport_fee_id still does not allow NULL');
    }
    
    console.log('\n🎉 Transport payments nullable fix completed successfully!');
    console.log('\n📋 Changes made:');
    console.log('   • Made transport_fee_id column nullable');
    console.log('   • Added descriptive comment to the column');
    console.log('   • Verified the change was applied correctly');
    
    console.log('\n✅ Direct transport payments should now work!');
    
  } catch (error) {
    console.error('\n❌ Fix failed:', error.message);
    console.error('Error details:', error);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the fix if this script is executed directly
if (require.main === module) {
  fixTransportPaymentsNullable()
    .then(() => {
      console.log('\n✅ Fix script completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Fix script failed:', error.message);
      process.exit(1);
    });
}

module.exports = fixTransportPaymentsNullable;
