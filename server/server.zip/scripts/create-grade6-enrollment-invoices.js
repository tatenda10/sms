const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

const students = [
  { name: 'Shantel', surname: 'Chiteve', regNumber: 'R96909C' },
  { name: 'Rumbidzai', surname: 'Chiputura', regNumber: 'R96911C' }
];

async function createGrade6EnrollmentInvoices() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 CREATING ENROLLMENT INVOICES FOR GRADE 6 STUDENTS\n');
    console.log('='.repeat(70));
    
    const classId = 27; // Grade 6
    
    // Get invoice structure
    const [invoiceStructures] = await conn.execute(`
      SELECT id, total_amount, term, academic_year
      FROM invoice_structures
      WHERE gradelevel_class_id = ? AND is_active = 1
      ORDER BY academic_year DESC, term DESC
      LIMIT 1
    `, [classId]);
    
    if (invoiceStructures.length === 0) {
      console.log('⚠️  No invoice structure found for Grade 6');
      return;
    }
    
    const invoiceStructure = invoiceStructures[0];
    const feeAmount = parseFloat(invoiceStructure.total_amount);
    const term = invoiceStructure.term || '3';
    const academicYear = invoiceStructure.academic_year || '2025';
    
    console.log(`Invoice Structure: Term ${term} ${academicYear}, Amount: $${feeAmount.toFixed(2)}\n`);
    
    // Get class name
    const [classes] = await conn.execute(
      'SELECT name FROM gradelevel_classes WHERE id = ?',
      [classId]
    );
    const classNameFull = classes.length > 0 ? classes[0].name : 'Grade 6';
    
    // Get or create journal ID
    let journalId = 1;
    try {
      const [journals] = await conn.execute(
        'SELECT id FROM journals WHERE name = ? OR id = ? LIMIT 1',
        ['Fees Journal', 1]
      );
      if (journals.length > 0) {
        journalId = journals[0].id;
      }
    } catch (error) {
      console.log('Using default journal ID 1');
    }
    
    // Get Accounts Receivable and Tuition Revenue accounts
    const [arAccounts] = await conn.execute(
      "SELECT id FROM chart_of_accounts WHERE code = '1100' AND type = 'Asset' LIMIT 1"
    );
    const [revenueAccounts] = await conn.execute(
      "SELECT id FROM chart_of_accounts WHERE code = '4000' AND type = 'Revenue' LIMIT 1"
    );
    
    if (arAccounts.length === 0 || revenueAccounts.length === 0) {
      console.log('⚠️  Required accounts not found');
      return;
    }
    
    const arAccountId = arAccounts[0].id;
    const revenueAccountId = revenueAccounts[0].id;
    
    await conn.beginTransaction();
    
    for (const student of students) {
      try {
        // Check if enrollment exists
        const [enrollments] = await conn.execute(`
          SELECT id FROM enrollments_gradelevel_classes
          WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
        `, [student.regNumber, classId]);
        
        if (enrollments.length === 0) {
          console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Not enrolled`);
          continue;
        }
        
        const enrollmentId = enrollments[0].id;
        
        // Check if enrollment invoice transaction already exists
        const [existingTxns] = await conn.execute(`
          SELECT id FROM student_transactions
          WHERE student_reg_number = ? 
            AND class_id = ?
            AND transaction_type = 'DEBIT'
            AND (description LIKE ? OR description LIKE ?)
        `, [student.regNumber, classId, `%TUITION INVOICE%`, `%${classNameFull}%`]);
        
        if (existingTxns.length > 0) {
          console.log(`⏭️  ${student.name} ${student.surname} (${student.regNumber}) - Enrollment invoice already exists`);
          continue;
        }
        
        // Get student name
        const [studentInfo] = await conn.execute(
          'SELECT Name, Surname FROM students WHERE RegNumber = ?',
          [student.regNumber]
        );
        
        if (studentInfo.length === 0) {
          console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Student not found`);
          continue;
        }
        
        const studentName = `${studentInfo[0].Name} ${studentInfo[0].Surname}`;
        
        // Create journal entry
        const description = `TUITION INVOICE - ${classNameFull} - ${studentName} (${student.regNumber}) - Term ${term} ${academicYear}`;
        const reference = `INV-${student.regNumber}-${Date.now()}`;
        
        const [journalEntry] = await conn.execute(`
          INSERT INTO journal_entries (journal_id, entry_date, reference, description, created_by, created_at, updated_at)
          VALUES (?, CURDATE(), ?, ?, ?, NOW(), NOW())
        `, [journalId, reference, description, 1]);
        
        const journalEntryId = journalEntry.insertId;
        
        // Create journal entry lines
        await conn.execute(`
          INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
          VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, arAccountId, feeAmount, 0, `Accounts Receivable - ${studentName}`]);
        
        await conn.execute(`
          INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
          VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, revenueAccountId, 0, feeAmount, `Tuition Revenue - ${classNameFull}`]);
        
        // Create DEBIT transaction
        const formattedTerm = term.replace(/Term\s*/i, '');
        await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'DEBIT',
          feeAmount,
          `TUITION INVOICE - ${classNameFull}`,
          {
            term: formattedTerm,
            academic_year: academicYear,
            class_id: classId,
            enrollment_id: enrollmentId,
            created_by: 1,
            journal_entry_id: journalEntryId
          }
        );
        
        // Update account balances
        await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
        
        console.log(`✅ Created enrollment invoice for: ${student.name} ${student.surname} (${student.regNumber})`);
        
      } catch (error) {
        console.error(`❌ Error processing ${student.name} ${student.surname}:`, error.message);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ Process complete!');
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

createGrade6EnrollmentInvoices();

