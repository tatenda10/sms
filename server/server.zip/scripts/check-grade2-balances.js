const { pool } = require('./config/database');

async function checkBalances() {
  const students = [
    'R47689L', // Lazarus Adel - should have -191 (opening -91, enrollment -100, payment +70)
    'R96741Z', // Golden Charuma - should have -136 (opening -36, enrollment -100, payment +80)
    'R73191M', // Tinashe Muchabaiwa - should have -116 (opening -16, enrollment -100, payment +100)
    'R57153A', // Princess Muwamka - should have -121 (opening -21, enrollment -100, payment +65)
    'R61079K', // Advance Paza - should have -101 (opening -1, enrollment -100, payment +75)
    'R84339Y', // Dhinala Delan - should have -100 (enrollment -100, payment +120)
    'R94343W', // Praise Mupedzisi - should have -100 (enrollment -100, payment +110)
    'R86634G'  // Wishby Chiza - should have -100 (enrollment -100, payment 0)
  ];
  
  console.log('\n📊 Checking Grade 2 Student Balances\n');
  console.log('='.repeat(60));
  
  for (const regNumber of students) {
    const [balance] = await pool.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [regNumber]
    );
    
    const [student] = await pool.execute(
      'SELECT Name, Surname FROM students WHERE RegNumber = ?',
      [regNumber]
    );
    
    const [transactions] = await pool.execute(
      'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY created_at',
      [regNumber]
    );
    
    const studentName = student.length > 0 ? `${student[0].Name} ${student[0].Surname}` : regNumber;
    const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
    
    console.log(`\n👤 ${studentName} (${regNumber})`);
    console.log(`   Current Balance: $${currentBalance.toFixed(2)}`);
    console.log(`   Transactions (${transactions.length}):`);
    
    let calculatedBalance = 0;
    transactions.forEach((txn, idx) => {
      const amount = parseFloat(txn.amount);
      if (txn.transaction_type === 'DEBIT') {
        calculatedBalance -= amount;
        console.log(`   ${idx + 1}. DEBIT  $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      } else {
        calculatedBalance += amount;
        console.log(`   ${idx + 1}. CREDIT $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      }
    });
    
    console.log(`   Calculated Balance: $${calculatedBalance.toFixed(2)}`);
    
    if (Math.abs(currentBalance - calculatedBalance) > 0.01) {
      console.log(`   ⚠️  WARNING: Balance mismatch!`);
    } else {
      console.log(`   ✅ Balance matches`);
    }
  }
  
  await pool.end();
  process.exit(0);
}

checkBalances().catch(error => {
  console.error('Error:', error);
  process.exit(1);
});

