const { pool } = require('./config/database');

async function checkBalances() {
  const conn = await pool.getConnection();
  
  try {
    // Check specific students
    const studentsToCheck = [
      'R96903J', // Memory Jambwa
      'R96903C', // Judith Chirenje (should have -245)
      'R96903N', // Makanakaishe Muchabaiwa (should have -20)
      'R96903R', // Anesu Runhuka
      'R96903T'  // Junior Tavawona
    ];
    
    console.log('\n📊 CHECKING GRADE 4 STUDENT BALANCES\n');
    console.log('='.repeat(70));
    
    for (const regNumber of studentsToCheck) {
      // Get current balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [regNumber]
      );
      
      // Get student info
      const [student] = await conn.execute(
        'SELECT Name, Surname FROM students WHERE RegNumber = ?',
        [regNumber]
      );
      
      const studentName = student.length > 0 ? `${student[0].Name} ${student[0].Surname}` : regNumber;
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      
      // Get transactions
      const [transactions] = await conn.execute(
        'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY created_at',
        [regNumber]
      );
      
      // Calculate balance from transactions
      let calculatedBalance = 0;
      transactions.forEach(txn => {
        if (txn.transaction_type === 'DEBIT') {
          calculatedBalance -= parseFloat(txn.amount);
        } else if (txn.transaction_type === 'CREDIT') {
          calculatedBalance += parseFloat(txn.amount);
        }
      });
      
      console.log(`\n👤 ${studentName} (${regNumber})`);
      console.log(`   Database Balance: $${currentBalance.toFixed(2)}`);
      console.log(`   Calculated Balance: $${calculatedBalance.toFixed(2)}`);
      console.log(`   Match: ${Math.abs(currentBalance - calculatedBalance) < 0.01 ? '✅' : '❌'}`);
      console.log(`   Transactions (${transactions.length}):`);
      transactions.forEach((txn, idx) => {
        const sign = txn.transaction_type === 'DEBIT' ? '-' : '+';
        console.log(`      ${idx + 1}. ${txn.transaction_type} ${sign}$${parseFloat(txn.amount).toFixed(2)} - ${txn.description.substring(0, 50)}`);
      });
    }
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking balances:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkBalances();

