const { pool } = require('./config/database');

// Student data with their expected balances
const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96904D', balance: -10 }, // DUPLICATE - needs new reg number
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66 }, // DUPLICATE - needs new reg number
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96904N', balance: -20 }, // DUPLICATE - needs new reg number
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96904N', balance: -143 }, // DUPLICATE - needs new reg number
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96904N', balance: -150 }, // DUPLICATE - needs new reg number
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5 }, // DUPLICATE - needs new reg number
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96904N', balance: -210 }, // DUPLICATE - needs new reg number
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96904O', balance: -310 } // DUPLICATE - needs new reg number
];

// Function to generate unique registration number
async function generateUniqueRegNumber(surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 96904; // Start from 96904 since we're using that series
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY RegNumber DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      if (numberPart > maxNumber) {
        maxNumber = numberPart;
      }
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers');
  }
  
  // Generate new number (increment from max)
  let newNumber = maxNumber + 1;
  let attempts = 0;
  let regNumber;
  
  do {
    const numberStr = String(newNumber).padStart(5, '0');
    
    // Generate letter suffix based on surname first letter
    const firstLetter = surname.charAt(0).toUpperCase();
    const letter = /[A-Z]/.test(firstLetter) ? firstLetter : 'A';
    
    regNumber = `R${numberStr}${letter}`;
    
    // Check if this reg number is already in use
    const [check] = await pool.execute(
      'SELECT RegNumber FROM students WHERE RegNumber = ?',
      [regNumber]
    );
    
    if (check.length === 0 && !existingNumbers.has(regNumber)) {
      existingNumbers.add(regNumber);
      return regNumber;
    }
    
    newNumber++;
    attempts++;
    
    // If letter conflicts, try next letter
    if (attempts > 10) {
      const nextLetter = String.fromCharCode(letter.charCodeAt(0) + 1);
      const altLetter = nextLetter > 'Z' ? 'A' : nextLetter;
      regNumber = `R${numberStr}${altLetter}`;
      if (!existingNumbers.has(regNumber)) {
        existingNumbers.add(regNumber);
        return regNumber;
      }
    }
  } while (attempts < 100);
  
  throw new Error(`Could not generate unique reg number for ${surname}`);
}

async function fixDuplicateRegNumbers() {
  const conn = await pool.getConnection();
  const existingNumbers = new Set();
  
  try {
    await conn.beginTransaction();
    
    console.log('\n🔧 FIXING DUPLICATE REGISTRATION NUMBERS\n');
    console.log('='.repeat(70));
    
    // First, get all existing reg numbers
    const [allStudents] = await conn.execute('SELECT RegNumber FROM students');
    allStudents.forEach(row => existingNumbers.add(row.RegNumber));
    
    // Identify duplicates and assign new reg numbers
    const regNumberGroups = {};
    const studentsToUpdate = [];
    
    for (const student of studentData) {
      if (!regNumberGroups[student.regNumber]) {
        regNumberGroups[student.regNumber] = [];
      }
      regNumberGroups[student.regNumber].push(student);
    }
    
    // Find duplicates (reg numbers used by more than one student)
    for (const [regNumber, students] of Object.entries(regNumberGroups)) {
      if (students.length > 1) {
        console.log(`\n⚠️  Found duplicate reg number: ${regNumber} (used by ${students.length} students)`);
        
        // Keep first student with original reg number, assign new ones to others
        for (let i = 1; i < students.length; i++) {
          const student = students[i];
          const newRegNumber = await generateUniqueRegNumber(student.surname, existingNumbers);
          
          console.log(`   → Assigning ${student.name} ${student.surname} new reg number: ${newRegNumber}`);
          
          studentsToUpdate.push({
            oldRegNumber: regNumber,
            newRegNumber: newRegNumber,
            student: student
          });
        }
      }
    }
    
    // Update students with new reg numbers
    console.log(`\n🔄 Updating ${studentsToUpdate.length} student records...\n`);
    
    for (const update of studentsToUpdate) {
      const { oldRegNumber, newRegNumber, student } = update;
      
      // First, check if student exists with old reg number and matching name
      const [studentCheck] = await conn.execute(
        'SELECT RegNumber FROM students WHERE RegNumber = ? AND Name = ? AND Surname = ?',
        [oldRegNumber, student.name, student.surname]
      );
      
      if (studentCheck.length === 0) {
        console.log(`⚠️  Student ${student.name} ${student.surname} not found with reg number ${oldRegNumber}, skipping`);
        continue;
      }
      
      // Update students table FIRST (this will cascade to guardians due to foreign key)
      await conn.execute(
        'UPDATE students SET RegNumber = ? WHERE RegNumber = ? AND Name = ? AND Surname = ?',
        [newRegNumber, oldRegNumber, student.name, student.surname]
      );
      
      // Update student_balances table
      await conn.execute(
        'UPDATE student_balances SET student_reg_number = ? WHERE student_reg_number = ?',
        [newRegNumber, oldRegNumber]
      );
      
      // Update student_transactions table
      await conn.execute(
        'UPDATE student_transactions SET student_reg_number = ? WHERE student_reg_number = ?',
        [newRegNumber, oldRegNumber]
      );
      
      // Update enrollments_gradelevel_classes table (if any)
      await conn.execute(
        'UPDATE enrollments_gradelevel_classes SET student_regnumber = ? WHERE student_regnumber = ?',
        [newRegNumber, oldRegNumber]
      );
      
      // Update fee_payments table (if any)
      await conn.execute(
        'UPDATE fee_payments SET student_reg_number = ? WHERE student_reg_number = ?',
        [newRegNumber, oldRegNumber]
      );
      
      console.log(`✅ Updated ${student.name} ${student.surname}: ${oldRegNumber} → ${newRegNumber}`);
    }
    
    await conn.commit();
    
    console.log(`\n✅ Successfully fixed ${studentsToUpdate.length} duplicate registration numbers!`);
    console.log('\n📊 Verification:\n');
    
    // Verify all students now have unique reg numbers
    for (const student of studentData) {
      const finalRegNumber = studentsToUpdate.find(u => 
        u.student.name === student.name && u.student.surname === student.surname
      )?.newRegNumber || student.regNumber;
      
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [finalRegNumber]
      );
      
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      const match = Math.abs(currentBalance - student.balance) < 0.01;
      
      console.log(`   ${student.name} ${student.surname} (${finalRegNumber}): $${currentBalance.toFixed(2)} ${match ? '✅' : '❌'} (expected: $${student.balance.toFixed(2)})`);
    }
    
  } catch (error) {
    await conn.rollback();
    console.error('\n❌ Error fixing duplicate reg numbers:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixDuplicateRegNumbers();

