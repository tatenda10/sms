const { pool } = require('./config/database');

// All ECD A students from the image
const ecdaStudents = [
  { name: 'Baven', surname: 'Mandizadza', regNumber: 'R00010M', balance: 0.00, totalPayments: 85.00 },
  { name: 'Blessed', surname: 'Masimo', regNumber: 'R00010N', balance: 0.00, totalPayments: 85.00 },
  { name: 'Alex', surname: 'Paza', regNumber: 'R00010P', balance: -45.00, totalPayments: 75.00 },
  { name: 'Elsie', surname: 'Nhara', regNumber: 'R00010N', balance: -5.00, totalPayments: 25.00 },
  { name: 'Keila', surname: 'Divala', regNumber: 'R00010D', balance: -15.00, totalPayments: 115.00 },
  { name: 'Carlton', surname: 'Kanodeweta', regNumber: 'R00010K', balance: 0.00, totalPayments: 0.00 }
];

async function checkECDAStudents() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING ECD A STUDENTS\n');
    console.log('='.repeat(70));
    
    // Get ECD A class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.name LIKE '%ECD A%' OR gc.name LIKE '%ECD%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ ECD A class not found');
      return;
    }
    
    const ecdaClass = classes[0];
    console.log(`✅ Found ECD A class: ${ecdaClass.name} (ID: ${ecdaClass.id})\n`);
    
    // Check each student
    const results = [];
    const regNumberMap = {};
    const duplicateRegNumbers = [];
    
    for (const student of ecdaStudents) {
      // Check by registration number
      const [byReg] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      // Check by name
      const [byName] = await conn.execute(
        'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
        [student.name, student.surname]
      );
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [student.regNumber, ecdaClass.id]);
      
      // Get balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const foundByReg = byReg.length > 0;
      const foundByName = byName.length > 0;
      const enrolled = enrollment.length > 0;
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : null;
      
      // Check for duplicate reg numbers
      if (foundByReg) {
        if (!regNumberMap[student.regNumber]) {
          regNumberMap[student.regNumber] = [];
        }
        regNumberMap[student.regNumber].push({
          expected: student,
          actual: byReg[0]
        });
        
        // Check if name matches
        if (byReg[0].Name.toLowerCase().trim() !== student.name.toLowerCase().trim() ||
            byReg[0].Surname.toLowerCase().trim() !== student.surname.toLowerCase().trim()) {
          duplicateRegNumbers.push({
            regNumber: student.regNumber,
            expected: student,
            actual: byReg[0]
          });
        }
      }
      
      results.push({
        student,
        foundByReg,
        foundByName,
        enrolled,
        currentBalance,
        dbStudent: foundByReg ? byReg[0] : (foundByName ? byName[0] : null)
      });
    }
    
    // Find all duplicates
    const allDuplicates = [];
    for (const [regNumber, students] of Object.entries(regNumberMap)) {
      if (students.length > 1) {
        allDuplicates.push({
          regNumber,
          students: students.map(s => s.expected)
        });
      }
    }
    
    // Summary
    const found = results.filter(r => r.foundByReg || r.foundByName).length;
    const missing = results.filter(r => !r.foundByReg && !r.foundByName).length;
    const enrolledCount = results.filter(r => r.enrolled).length;
    const notEnrolled = results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).length;
    
    console.log(`📊 SUMMARY:\n`);
    console.log(`   Total students in Excel: ${ecdaStudents.length}`);
    console.log(`   Found in database: ${found}`);
    console.log(`   Missing from database: ${missing}`);
    console.log(`   Enrolled in ECD A: ${enrolledCount}`);
    console.log(`   Not enrolled: ${notEnrolled}`);
    console.log(`   Duplicate reg numbers: ${allDuplicates.length}\n`);
    
    // Show duplicates
    if (allDuplicates.length > 0) {
      console.log(`\n⚠️  DUPLICATE REGISTRATION NUMBERS:\n`);
      allDuplicates.forEach((dup, idx) => {
        console.log(`\n${idx + 1}. Registration Number: ${dup.regNumber} (used by ${dup.students.length} students)`);
        dup.students.forEach((s, sIdx) => {
          console.log(`   ${sIdx + 1}. ${s.name} ${s.surname}`);
        });
      });
    }
    
    // Show missing students
    if (missing > 0) {
      console.log(`\n❌ MISSING STUDENTS:\n`);
      results.filter(r => !r.foundByReg && !r.foundByName).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show not enrolled
    if (notEnrolled > 0) {
      console.log(`\n⚠️  NOT ENROLLED IN ECD A:\n`);
      results.filter(r => (r.foundByReg || r.foundByName) && !r.enrolled).forEach((r, idx) => {
        console.log(`${idx + 1}. ${r.student.name} ${r.student.surname} (${r.student.regNumber})`);
      });
    }
    
    // Show all students with details
    console.log(`\n\n📋 ALL ECD A STUDENTS STATUS:\n`);
    console.log('-'.repeat(70));
    results.forEach((r, idx) => {
      const status = r.foundByReg ? '✅' : (r.foundByName ? '⚠️' : '❌');
      const enrolledStatus = r.enrolled ? '✅' : '❌';
      const balanceStr = r.currentBalance !== null ? 
        (r.currentBalance < 0 ? `-$${Math.abs(r.currentBalance).toFixed(2)}` : `$${r.currentBalance.toFixed(2)}`) : 
        'N/A';
      const expectedBalance = r.student.balance < 0 ? `-$${Math.abs(r.student.balance).toFixed(2)}` : `$${r.student.balance.toFixed(2)}`;
      
      console.log(`${String(idx + 1).padStart(3)}. ${status} ${r.student.name.padEnd(15)} ${r.student.surname.padEnd(20)} ${r.student.regNumber.padEnd(10)} ${enrolledStatus} Enrolled | Balance: ${balanceStr.padEnd(10)} (Expected: ${expectedBalance})`);
    });
    
    console.log('\n' + '='.repeat(70));
    
  } catch (error) {
    console.error('Error checking ECD A students:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkECDAStudents();

