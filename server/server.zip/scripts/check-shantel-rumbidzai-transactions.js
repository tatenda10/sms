const { pool } = require('./config/database');

async function checkTransactions() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 CHECKING TRANSACTIONS FOR SHANTEL AND RUMBIDZAI\n');
    console.log('='.repeat(70));
    
    const students = [
      { name: 'Shantel', surname: 'Chiteve', regNumber: 'R96909C' },
      { name: 'Rumbidzai', surname: 'Chiputura', regNumber: 'R96911C' }
    ];
    
    for (const student of students) {
      console.log(`\n📋 ${student.name} ${student.surname} (${student.regNumber})\n`);
      
      // Check transactions
      const [transactions] = await conn.execute(`
        SELECT id, transaction_type, amount, description, class_id
        FROM student_transactions
        WHERE student_reg_number = ?
        ORDER BY transaction_date DESC
      `, [student.regNumber]);
      
      console.log(`Total transactions: ${transactions.length}`);
      transactions.forEach((txn, idx) => {
        console.log(`   ${idx + 1}. ${txn.transaction_type} - $${parseFloat(txn.amount).toFixed(2)} - ${txn.description} (Class ID: ${txn.class_id})`);
      });
      
      // Check balance
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      console.log(`Current balance: $${currentBalance.toFixed(2)}`);
    }
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkTransactions();

