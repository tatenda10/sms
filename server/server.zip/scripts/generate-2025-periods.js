require('dotenv').config();
const { pool } = require('../config/database');

async function generate2025Periods() {
  const conn = await pool.getConnection();
  
  try {
    console.log('🗓️  Generating accounting periods for 2025...\n');
    
    await conn.beginTransaction();
    
    const year = 2025;
    const months = [
      { num: 1, name: 'January', days: 31 },
      { num: 2, name: 'February', days: 28 }, // 2025 is not a leap year
      { num: 3, name: 'March', days: 31 },
      { num: 4, name: 'April', days: 30 },
      { num: 5, name: 'May', days: 31 },
      { num: 6, name: 'June', days: 30 },
      { num: 7, name: 'July', days: 31 },
      { num: 8, name: 'August', days: 31 },
      { num: 9, name: 'September', days: 30 },
      { num: 10, name: 'October', days: 31 },
      { num: 11, name: 'November', days: 30 },
      { num: 12, name: 'December', days: 31 }
    ];
    
    let created = 0;
    let skipped = 0;
    
    for (const month of months) {
      const periodName = `${month.name} ${year}`;
      const startDate = `${year}-${String(month.num).padStart(2, '0')}-01`;
      const endDate = `${year}-${String(month.num).padStart(2, '0')}-${month.days}`;
      
      // Check if period already exists
      const [existing] = await conn.execute(
        'SELECT id FROM accounting_periods WHERE period_name = ? OR (start_date = ? AND end_date = ?)',
        [periodName, startDate, endDate]
      );
      
      if (existing.length > 0) {
        console.log(`⏭️  Skipped: ${periodName} (already exists)`);
        skipped++;
        continue;
      }
      
      // Insert the period
      await conn.execute(
        `INSERT INTO accounting_periods (period_name, period_type, start_date, end_date, status, created_at)
         VALUES (?, 'monthly', ?, ?, 'open', NOW())`,
        [periodName, startDate, endDate]
      );
      
      console.log(`✅ Created: ${periodName} (${startDate} to ${endDate})`);
      created++;
    }
    
    await conn.commit();
    
    console.log('\n📊 Summary:');
    console.log(`   ✅ Created: ${created} periods`);
    console.log(`   ⏭️  Skipped: ${skipped} periods (already existed)`);
    console.log('\n🎉 Done! All 2025 accounting periods are ready.\n');
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error generating periods:', error);
    throw error;
  } finally {
    conn.release();
    await pool.end();
  }
}

// Run the script
generate2025Periods()
  .then(() => {
    console.log('✅ Script completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Script failed:', error);
    process.exit(1);
  });

