const { pool } = require('../config/database');

async function discoverTables() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Discovering tables in the database...\n');
    
    // Get all tables
    const [tables] = await connection.execute(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = 'sms' 
      ORDER BY TABLE_NAME
    `);
    
    console.log('📋 All tables in the database:');
    console.log('================================');
    tables.forEach((table, index) => {
      console.log(`${index + 1}. ${table.TABLE_NAME}`);
    });
    
    // Get foreign key relationships
    console.log('\n🔗 Foreign key relationships:');
    console.log('==============================');
    const [foreignKeys] = await connection.execute(`
      SELECT 
        TABLE_NAME,
        COLUMN_NAME,
        REFERENCED_TABLE_NAME,
        REFERENCED_COLUMN_NAME
      FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
      WHERE TABLE_SCHEMA = 'sms' 
        AND REFERENCED_TABLE_NAME IS NOT NULL
      ORDER BY TABLE_NAME, COLUMN_NAME
    `);
    
    foreignKeys.forEach(fk => {
      console.log(`${fk.TABLE_NAME}.${fk.COLUMN_NAME} -> ${fk.REFERENCED_TABLE_NAME}.${fk.REFERENCED_COLUMN_NAME}`);
    });
    
  } catch (error) {
    console.error('❌ Error discovering tables:', error);
  } finally {
    connection.release();
  }
}

discoverTables();
