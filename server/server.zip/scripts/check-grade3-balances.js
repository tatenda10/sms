const { pool } = require('./config/database');

async function checkBalances() {
  const students = [
    'R00011O', // Nomilna - should have -130 (opening -130, enrollment -100, payment 0)
    'R00011W', // Petronella - should have -380 (opening -280, enrollment -100, payment +25)
    'R00011Z', // Alicia - should have -240 (opening -140, enrollment -100, payment +44)
    'R00012B', // Anicia - should have -270 (opening -170, enrollment -100, payment +45)
    'R00012O', // Grace - should have -210 (opening -110, enrollment -100, payment +30)
    'R00011M', // Solomon - should have -100 (enrollment -100, payment +100)
    'R00012L'  // Daryl - should have -100 (enrollment -100, payment +110)
  ];
  
  console.log('\n📊 Checking Grade 3 Student Balances\n');
  console.log('='.repeat(60));
  
  for (const regNumber of students) {
    const [balance] = await pool.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [regNumber]
    );
    
    const [student] = await pool.execute(
      'SELECT Name, Surname FROM students WHERE RegNumber = ?',
      [regNumber]
    );
    
    const [transactions] = await pool.execute(
      'SELECT transaction_type, amount, description FROM student_transactions WHERE student_reg_number = ? ORDER BY created_at',
      [regNumber]
    );
    
    const studentName = student.length > 0 ? `${student[0].Name} ${student[0].Surname}` : regNumber;
    const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
    
    console.log(`\n👤 ${studentName} (${regNumber})`);
    console.log(`   Current Balance: $${currentBalance.toFixed(2)}`);
    console.log(`   Transactions (${transactions.length}):`);
    
    let calculatedBalance = 0;
    transactions.forEach((txn, idx) => {
      const amount = parseFloat(txn.amount);
      if (txn.transaction_type === 'DEBIT') {
        calculatedBalance -= amount;
        console.log(`   ${idx + 1}. DEBIT  $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      } else {
        calculatedBalance += amount;
        console.log(`   ${idx + 1}. CREDIT $${amount.toFixed(2)} - ${txn.description.substring(0, 50)}...`);
      }
    });
    
    console.log(`   Calculated Balance: $${calculatedBalance.toFixed(2)}`);
    
    if (Math.abs(currentBalance - calculatedBalance) > 0.01) {
      console.log(`   ⚠️  WARNING: Balance mismatch!`);
    } else {
      console.log(`   ✅ Balance matches`);
    }
  }
  
  await pool.end();
  process.exit(0);
}

checkBalances().catch(error => {
  console.error('Error:', error);
  process.exit(1);
});

