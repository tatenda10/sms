const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Missing students that need to be registered with their new unique reg numbers
const missingStudents = [
  { name: 'Talent', surname: 'Choga', regNumber: 'R96905C', balance: -10 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96905M', balance: -20 },
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96906M', balance: -143 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96907M', balance: -150 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96908M', balance: -210 },
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96905N', balance: -310 }
];

// Students with combined balances that need to be fixed
const studentsWithWrongBalances = [
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', currentBalance: -589, expectedBalance: -66 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', currentBalance: -315, expectedBalance: -5 }
];

async function completeFix() {
  console.log('\n🔧 COMPLETING GRADE 7 2024 FIX\n');
  console.log('='.repeat(70));
  
  // STEP 1: Register missing students
  console.log('\n📝 STEP 1: Registering missing students...\n');
  const conn1 = await pool.getConnection();
  let registered = 0;
  
  try {
    await conn1.beginTransaction();
    
    for (const student of missingStudents) {
      // Check if already exists
      const [existing] = await conn1.execute(
        'SELECT RegNumber FROM students WHERE RegNumber = ?',
        [student.regNumber]
      );
      
      if (existing.length > 0) {
        console.log(`⏭️  ${student.name} ${student.surname} (${student.regNumber}) already exists`);
        continue;
      }
      
      // Register student
      const year = 2009;
      const month = Math.floor(Math.random() * 12) + 1;
      const day = Math.floor(Math.random() * 28) + 1;
      const dateOfBirth = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const gender = Math.random() > 0.5 ? 'Male' : 'Female';
      const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
      const address = 'Address not provided';
      
      await conn1.execute(`
        INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
      
      // Insert guardian
      const guardianName = `Guardian of ${student.name}`;
      const guardianSurname = student.surname;
      const guardianPhone = `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
      
      await conn1.execute(`
        INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, 'Parent']);
      
      // Create initial balance record
      await conn1.execute(`
        INSERT INTO student_balances (student_reg_number, current_balance)
        VALUES (?, 0)
      `, [student.regNumber]);
      
      console.log(`✅ Registered: ${student.name} ${student.surname} (${student.regNumber})`);
      registered++;
    }
    
    await conn1.commit();
    console.log(`\n📊 Registered ${registered} new students`);
  } catch (error) {
    await conn1.rollback();
    console.error('❌ Error registering students:', error);
    throw error;
  } finally {
    conn1.release();
  }
  
  // STEP 2: Add outstanding balances for newly registered students
  console.log('\n💰 STEP 2: Adding outstanding balances for new students...\n');
  const conn2 = await pool.getConnection();
  
  try {
    await conn2.beginTransaction();
    
    // Get or create journal
    let journal_id = 1;
    const [journalCheck] = await conn2.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
    if (journalCheck.length === 0) {
      const [journalByName] = await conn2.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
      if (journalByName.length > 0) {
        journal_id = journalByName[0].id;
      } else {
        const [journalResult] = await conn2.execute(
          'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
          ['General Journal', 'Journal for general transactions including opening balances', 1]
        );
        journal_id = journalResult.insertId;
      }
    }
    
    // Get accounts
    const [accountsReceivable] = await conn2.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
      ['1100', 'Asset']
    );
    
    const [retainedEarnings] = await conn2.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
      ['3998']
    );
    
    let processed = 0;
    
    for (const student of missingStudents) {
      const debtAmount = Math.abs(student.balance);
      
      // Check if transaction already exists
      const [existingTxn] = await conn2.execute(
        'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ?',
        [student.regNumber, `%Opening Balance - Outstanding Debt%`]
      );
      
      if (existingTxn.length > 0) {
        console.log(`⏭️  ${student.name} ${student.surname} already has outstanding balance`);
        continue;
      }
      
      const reference = `OB-${student.regNumber}-${Date.now()}`;
      const journalDescription = `Opening Balance - Outstanding Debt for ${student.name} ${student.surname}`;
      
      // Create journal entry
      const [journalResult] = await conn2.execute(`
        INSERT INTO journal_entries (
          journal_id, entry_date, description, reference,
          created_by, created_at, updated_at
        ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
      `, [journal_id, journalDescription, reference, 1]);
      
      const journalEntryId = journalResult.insertId;
      
      // Create journal entry lines
      await conn2.execute(`
        INSERT INTO journal_entry_lines (
          journal_entry_id, account_id, debit, credit, description
        ) VALUES (?, ?, ?, ?, ?)
      `, [journalEntryId, accountsReceivable[0].id, debtAmount, 0, journalDescription]);
      
      await conn2.execute(`
        INSERT INTO journal_entry_lines (
          journal_entry_id, account_id, debit, credit, description
        ) VALUES (?, ?, ?, ?, ?)
      `, [journalEntryId, retainedEarnings[0].id, 0, debtAmount, journalDescription]);
      
      // Create DEBIT transaction
      await StudentTransactionController.createTransactionHelper(
        student.regNumber,
        'DEBIT',
        debtAmount,
        `Opening Balance - Outstanding Debt: ${reference}`,
        {
          created_by: 1,
          journal_entry_id: journalEntryId
        }
      );
      
      // Update account balances
      await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn2, journalEntryId, 1);
      
      console.log(`✅ Added balance: ${student.name} ${student.surname} - $${debtAmount.toFixed(2)}`);
      processed++;
    }
    
    await conn2.commit();
    console.log(`\n📊 Added ${processed} outstanding balances`);
  } catch (error) {
    await conn2.rollback();
    console.error('❌ Error adding balances:', error);
    throw error;
  } finally {
    conn2.release();
  }
  
  // STEP 3: Fix combined balances
  console.log('\n🔧 STEP 3: Fixing combined balances...\n');
  const conn3 = await pool.getConnection();
  
  try {
    await conn3.beginTransaction();
    
    // Get or create journal
    let journal_id = 1;
    const [journalCheck] = await conn3.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
    if (journalCheck.length === 0) {
      const [journalByName] = await conn3.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
      if (journalByName.length > 0) {
        journal_id = journalByName[0].id;
      }
    }
    
    // Get accounts
    const [accountsReceivable] = await conn3.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
      ['1100', 'Asset']
    );
    
    const [retainedEarnings] = await conn3.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
      ['3998']
    );
    
    for (const student of studentsWithWrongBalances) {
      // Get actual current balance from database
      const [currentBalanceRow] = await conn3.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const currentBalance = currentBalanceRow.length > 0 ? parseFloat(currentBalanceRow[0].current_balance) : 0;
      const difference = student.expectedBalance - currentBalance;
      const adjustmentAmount = Math.abs(difference);
      
      if (Math.abs(difference) < 0.01) {
        console.log(`⏭️  ${student.name} ${student.surname} balance is already correct`);
        continue;
      }
      
      const reference = `ADJ-${student.regNumber}-${Date.now()}`;
      const journalDescription = `Balance Correction for ${student.name} ${student.surname}`;
      
      // Create journal entry
      const [journalResult] = await conn3.execute(`
        INSERT INTO journal_entries (
          journal_id, entry_date, description, reference,
          created_by, created_at, updated_at
        ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
      `, [journal_id, journalDescription, reference, 1]);
      
      const journalEntryId = journalResult.insertId;
      
      if (difference > 0) {
        // Current balance is more negative than expected - need to reduce debt (CREDIT)
        // Example: current = -589, expected = -66, difference = 523, so CREDIT 523
        await conn3.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, retainedEarnings[0].id, adjustmentAmount, 0, journalDescription]);
        
        await conn3.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, accountsReceivable[0].id, 0, adjustmentAmount, journalDescription]);
        
        // Create CREDIT transaction
        await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'CREDIT',
          adjustmentAmount,
          `Balance Correction: ${reference}`,
          {
            created_by: 1,
            journal_entry_id: journalEntryId
          }
        );
      } else {
        // Current balance is less negative than expected - need to add more debt (DEBIT)
        // Example: current = -5, expected = -10, difference = -5, so DEBIT 5
        await conn3.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, accountsReceivable[0].id, adjustmentAmount, 0, journalDescription]);
        
        await conn3.execute(`
          INSERT INTO journal_entry_lines (
            journal_entry_id, account_id, debit, credit, description
          ) VALUES (?, ?, ?, ?, ?)
        `, [journalEntryId, retainedEarnings[0].id, 0, adjustmentAmount, journalDescription]);
        
        // Create DEBIT transaction
        await StudentTransactionController.createTransactionHelper(
          student.regNumber,
          'DEBIT',
          adjustmentAmount,
          `Balance Correction: ${reference}`,
          {
            created_by: 1,
            journal_entry_id: journalEntryId
          }
        );
      }
      
      // Update account balances
      await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn3, journalEntryId, 1);
      
      // Get updated balance
      const [updatedBalance] = await conn3.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
      
      console.log(`✅ Fixed ${student.name} ${student.surname}: $${currentBalance.toFixed(2)} → $${newBalance.toFixed(2)} (expected: $${student.expectedBalance.toFixed(2)})`);
    }
    
    await conn3.commit();
    console.log(`\n✅ Fixed combined balances`);
  } catch (error) {
    await conn3.rollback();
    console.error('❌ Error fixing balances:', error);
    throw error;
  } finally {
    conn3.release();
  }
  
  console.log('\n✅ All fixes completed!\n');
  process.exit(0);
}

completeFix();

