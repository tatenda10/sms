const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function removeDuplicateEnrollments() {
    const conn = await pool.getConnection();
    
    try {
        await conn.beginTransaction();
        
        console.log('🔍 Finding duplicate enrollments...\n');
        
        // Find students with multiple active enrollments
        const [duplicates] = await conn.execute(`
            SELECT 
                e.student_regnumber,
                e.id as enrollment_id,
                e.gradelevel_class_id,
                e.status,
                e.created_at,
                gc.name as class_name,
                st.name as stream_name,
                (SELECT COUNT(*) FROM student_transactions st_t 
                 WHERE st_t.enrollment_id = e.id 
                 AND st_t.transaction_type = 'DEBIT') as transaction_count
            FROM enrollments_gradelevel_classes e
            JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
            JOIN stream st ON gc.stream_id = st.id
            WHERE e.status = 'active'
            AND e.student_regnumber IN (
                SELECT student_regnumber
                FROM enrollments_gradelevel_classes
                WHERE status = 'active'
                GROUP BY student_regnumber
                HAVING COUNT(*) > 1
            )
            ORDER BY e.student_regnumber, e.created_at DESC
        `);
        
        console.log(`Found ${duplicates.length} enrollments for students with duplicates\n`);
        
        // Group by student
        const studentsWithDuplicates = {};
        duplicates.forEach(enrollment => {
            if (!studentsWithDuplicates[enrollment.student_regnumber]) {
                studentsWithDuplicates[enrollment.student_regnumber] = [];
            }
            studentsWithDuplicates[enrollment.student_regnumber].push(enrollment);
        });
        
        const toDelete = [];
        const toKeep = [];
        
        // For each student, keep the most recent enrollment (or one with transactions)
        for (const [studentReg, enrollments] of Object.entries(studentsWithDuplicates)) {
            // Sort by transaction count (desc) then by created_at (desc)
            enrollments.sort((a, b) => {
                if (b.transaction_count !== a.transaction_count) {
                    return b.transaction_count - a.transaction_count;
                }
                return new Date(b.created_at) - new Date(a.created_at);
            });
            
            // Keep the first one (most transactions or most recent)
            const keep = enrollments[0];
            const deleteList = enrollments.slice(1);
            
            toKeep.push(keep);
            toDelete.push(...deleteList);
            
            console.log(`\n📝 Student: ${studentReg}`);
            console.log(`   ✅ Keeping enrollment ${keep.enrollment_id} (${keep.class_name} - ${keep.stream_name}) - ${keep.transaction_count} transactions, created: ${keep.created_at}`);
            deleteList.forEach(del => {
                console.log(`   ❌ Deleting enrollment ${del.enrollment_id} (${del.class_name} - ${del.stream_name}) - ${del.transaction_count} transactions, created: ${del.created_at}`);
            });
        }
        
        console.log(`\n\n📊 Summary:`);
        console.log(`   Total duplicate enrollments to delete: ${toDelete.length}`);
        console.log(`   Enrollments to keep: ${toKeep.length}`);
        
        if (toDelete.length === 0) {
            console.log('\n✅ No duplicate enrollments to remove');
            await conn.rollback();
            return;
        }
        
        // Delete duplicate enrollments
        console.log(`\n🗑️  Deleting duplicate enrollments...\n`);
        
        for (const enrollment of toDelete) {
            try {
                // Get transactions for this enrollment
                const [transactions] = await conn.execute(
                    'SELECT id, amount, transaction_type, journal_entry_id FROM student_transactions WHERE enrollment_id = ?',
                    [enrollment.enrollment_id]
                );
                
                console.log(`\n   Processing enrollment ${enrollment.enrollment_id} (${enrollment.student_regnumber})...`);
                
                // For each transaction, we need to:
                // 1. Reverse the student balance
                // 2. Reverse the account balances (via journal entries)
                // 3. Delete journal entries
                // 4. Delete transactions
                // 5. Delete enrollment
                
                for (const transaction of transactions) {
                    // Reverse student balance
                    const StudentBalanceService = require('../services/studentBalanceService');
                    if (transaction.transaction_type === 'DEBIT') {
                        // Reverse: add a CREDIT to cancel the DEBIT
                        await StudentBalanceService.updateBalanceOnTransaction(
                            enrollment.student_regnumber,
                            'CREDIT',
                            transaction.amount,
                            conn
                        );
                        console.log(`     ✅ Reversed student balance: -${transaction.amount}`);
                    }
                    
                    // If there's a journal entry, reverse account balances
                    if (transaction.journal_entry_id) {
                        const AccountBalanceService = require('../services/accountBalanceService');
                        
                        // Get journal entry lines to reverse
                        const [journalLines] = await conn.execute(`
                            SELECT jel.account_id, jel.debit, jel.credit, coa.code, coa.type, coa.id
                            FROM journal_entry_lines jel
                            JOIN chart_of_accounts coa ON jel.account_id = coa.id
                            WHERE jel.journal_entry_id = ?
                        `, [transaction.journal_entry_id]);
                        
                        // Reverse each journal line by negating the balance change
                        for (const line of journalLines) {
                            // Calculate original balance change
                            const balanceChange = (line.type === 'Asset' || line.type === 'Expense')
                                ? parseFloat(line.debit || 0) - parseFloat(line.credit || 0)
                                : parseFloat(line.credit || 0) - parseFloat(line.debit || 0);
                            
                            // Get current balance
                            const [currentBalance] = await conn.execute(`
                                SELECT id, balance 
                                FROM account_balances 
                                WHERE account_id = ? 
                                ORDER BY as_of_date DESC 
                                LIMIT 1
                            `, [line.account_id]);
                            
                            if (currentBalance.length > 0) {
                                // Reverse: subtract the original change
                                const newBalance = parseFloat(currentBalance[0].balance) - balanceChange;
                                await conn.execute(`
                                    UPDATE account_balances 
                                    SET balance = ?, as_of_date = CURRENT_DATE 
                                    WHERE id = ?
                                `, [newBalance, currentBalance[0].id]);
                                console.log(`     ✅ Reversed account balance for ${line.code} (${line.type}): ${currentBalance[0].balance} → ${newBalance}`);
                            }
                        }
                        
                        // Delete journal entry lines
                        await conn.execute('DELETE FROM journal_entry_lines WHERE journal_entry_id = ?', [transaction.journal_entry_id]);
                        console.log(`     ✅ Deleted journal entry lines for journal ${transaction.journal_entry_id}`);
                    }
                    
                    // Delete transaction
                    await conn.execute('DELETE FROM student_transactions WHERE id = ?', [transaction.id]);
                    console.log(`     ✅ Deleted transaction ${transaction.id}`);
                }
                
                // Delete journal entries (if any remain)
                if (transactions.some(t => t.journal_entry_id)) {
                    const journalEntryIds = [...new Set(transactions.map(t => t.journal_entry_id).filter(Boolean))];
                    for (const jeId of journalEntryIds) {
                        await conn.execute('DELETE FROM journal_entries WHERE id = ?', [jeId]);
                        console.log(`     ✅ Deleted journal entry ${jeId}`);
                    }
                }
                
                // Delete subject enrollments first (if any) - use gradelevel_class_id and student_regnumber
                await conn.execute(
                    'DELETE FROM enrollments_subject_classes WHERE student_regnumber = ? AND gradelevel_class_id = ?', 
                    [enrollment.student_regnumber, enrollment.gradelevel_class_id]
                );
                
                // Delete enrollment
                await conn.execute('DELETE FROM enrollments_gradelevel_classes WHERE id = ?', [enrollment.enrollment_id]);
                console.log(`     ✅ Deleted enrollment ${enrollment.enrollment_id}`);
                
            } catch (error) {
                console.error(`     ❌ Error deleting enrollment ${enrollment.enrollment_id}:`, error.message);
                throw error;
            }
        }
        
        await conn.commit();
        console.log(`\n✅ Successfully removed ${toDelete.length} duplicate enrollments`);
        
    } catch (error) {
        await conn.rollback();
        console.error('❌ Error removing duplicate enrollments:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the script
removeDuplicateEnrollments()
    .then(() => {
        console.log('\n✅ Script completed');
        process.exit(0);
    })
    .catch(error => {
        console.error('\n❌ Script failed:', error);
        process.exit(1);
    });

