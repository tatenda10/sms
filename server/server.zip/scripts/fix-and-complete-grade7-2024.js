const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Student data with their expected balances
const studentData = [
  { name: 'Nicholas', surname: "Chin'ono", regNumber: 'R96904C', balance: -340 },
  { name: 'Anita', surname: 'Chivete', regNumber: 'R96904D', balance: -80 },
  { name: 'Talent', surname: 'Choga', regNumber: 'R96905C', balance: -10 }, // New reg number
  { name: 'Tapiwa', surname: 'Furutuna', regNumber: 'R96904F', balance: -10 },
  { name: 'Tanyaradzwa', surname: 'Kabvura', regNumber: 'R96904K', balance: -10 },
  { name: 'Goodson', surname: 'Kankuni', regNumber: 'R96904L', balance: -135 },
  { name: 'Adience', surname: 'Madzivaidze', regNumber: 'R96904M', balance: -10 },
  { name: 'Tawonga', surname: 'Masango', regNumber: 'R96904N', balance: -66 },
  { name: 'Samantha', surname: 'Munyanyi', regNumber: 'R96905M', balance: -20 }, // New reg number
  { name: 'Leeroy', surname: 'Muzanamombe', regNumber: 'R96906M', balance: -143 }, // New reg number
  { name: 'C Tinotenda', surname: 'Sithole', regNumber: 'R96904T', balance: -35 },
  { name: 'Anesu', surname: 'Mutengu', regNumber: 'R96907M', balance: -150 }, // New reg number
  { name: 'Ruvimbo', surname: 'Jongwe', regNumber: 'R96904J', balance: -120 },
  { name: 'Maseline', surname: 'Gwese', regNumber: 'R96904G', balance: -210 },
  { name: 'Sibongile', surname: 'Nyoni', regNumber: 'R96904O', balance: -5 },
  { name: 'Tinashe', surname: 'Antonio', regNumber: 'R96904A', balance: -80 },
  { name: 'Queen', surname: 'Muswati', regNumber: 'R96908M', balance: -210 }, // New reg number
  { name: 'Chipo', surname: 'Nyambodza', regNumber: 'R96905N', balance: -310 } // New reg number
];

async function fixAndComplete() {
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    console.log('\n🔧 FIXING AND COMPLETING GRADE 7 2024 STUDENTS\n');
    console.log('='.repeat(70));
    
    // Step 1: Register missing students
    console.log('\n📝 STEP 1: Registering missing students...\n');
    
    const newRegNumbers = ['R96905C', 'R96905M', 'R96906M', 'R96907M', 'R96908M', 'R96905N'];
    let registered = 0;
    
    for (const student of studentData) {
      if (newRegNumbers.includes(student.regNumber)) {
        // Check if student already exists
        const [existing] = await conn.execute(
          'SELECT RegNumber FROM students WHERE RegNumber = ?',
          [student.regNumber]
        );
        
        if (existing.length === 0) {
          // Register student
          const year = 2009;
          const month = Math.floor(Math.random() * 12) + 1;
          const day = Math.floor(Math.random() * 28) + 1;
          const dateOfBirth = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const gender = Math.random() > 0.5 ? 'Male' : 'Female';
          const nationalID = `ID${Math.floor(Math.random() * 1000000000)}`;
          const address = 'Address not provided';
          
          await conn.execute(`
            INSERT INTO students (RegNumber, Name, Surname, DateOfBirth, NationalIDNumber, Address, Gender, Active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [student.regNumber, student.name, student.surname, dateOfBirth, nationalID, address, gender, 'Yes']);
          
          // Insert guardian
          const guardianName = `Guardian of ${student.name}`;
          const guardianSurname = student.surname;
          const guardianPhone = `+263${Math.floor(Math.random() * 9000000) + 1000000}`;
          
          await conn.execute(`
            INSERT INTO guardians (StudentRegNumber, Name, Surname, NationalIDNumber, PhoneNumber, RelationshipToStudent)
            VALUES (?, ?, ?, ?, ?, ?)
          `, [student.regNumber, guardianName, guardianSurname, null, guardianPhone, 'Parent']);
          
          // Create initial balance record
          await conn.execute(`
            INSERT INTO student_balances (student_reg_number, current_balance)
            VALUES (?, 0)
            ON DUPLICATE KEY UPDATE current_balance = current_balance
          `, [student.regNumber]);
          
          console.log(`✅ Registered: ${student.name} ${student.surname} (${student.regNumber})`);
          registered++;
        } else {
          console.log(`⏭️  ${student.name} ${student.surname} (${student.regNumber}) already exists`);
        }
      }
    }
    
    console.log(`\n📊 Registered ${registered} new students`);
    
    // Step 2: Fix balances for students with wrong balances
    console.log('\n💰 STEP 2: Fixing student balances...\n');
    
    // Get or create journal
    let journal_id = 1;
    const [journalCheck] = await conn.execute('SELECT id FROM journals WHERE id = ?', [journal_id]);
    if (journalCheck.length === 0) {
      const [journalByName] = await conn.execute('SELECT id FROM journals WHERE name = ? LIMIT 1', ['General Journal']);
      if (journalByName.length > 0) {
        journal_id = journalByName[0].id;
      } else {
        const [journalResult] = await conn.execute(
          'INSERT INTO journals (name, description, is_active) VALUES (?, ?, ?)',
          ['General Journal', 'Journal for general transactions including opening balances', 1]
        );
        journal_id = journalResult.insertId;
      }
    }
    
    // Get accounts
    const [accountsReceivable] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? AND type = ? LIMIT 1',
      ['1100', 'Asset']
    );
    
    const [retainedEarnings] = await conn.execute(
      'SELECT id FROM chart_of_accounts WHERE code = ? LIMIT 1',
      ['3998']
    );
    
    let fixed = 0;
    
    for (const student of studentData) {
      // Get current balance
      const [currentBalance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const current = currentBalance.length > 0 ? parseFloat(currentBalance[0].current_balance) : 0;
      const expected = student.balance;
      
      // If balance is wrong, fix it
      if (Math.abs(current - expected) > 0.01) {
        const difference = expected - current;
        const adjustmentAmount = Math.abs(difference);
        
        // Check if adjustment transaction already exists
        const [existingTxn] = await conn.execute(
          'SELECT id FROM student_transactions WHERE student_reg_number = ? AND description LIKE ?',
          [student.regNumber, `%Balance Adjustment for ${student.name}%`]
        );
        
        if (existingTxn.length === 0) {
          const reference = `ADJ-${student.regNumber}-${Date.now()}`;
          const journalDescription = `Balance Adjustment for ${student.name} ${student.surname}`;
          
          // Create journal entry
          const [journalResult] = await conn.execute(`
            INSERT INTO journal_entries (
              journal_id, entry_date, description, reference,
              created_by, created_at, updated_at
            ) VALUES (?, NOW(), ?, ?, ?, NOW(), NOW())
          `, [journal_id, journalDescription, reference, 1]);
          
          const journalEntryId = journalResult.insertId;
          
          // Create journal entry lines
          if (difference < 0) {
            // Need to add more debt (DEBIT)
            await conn.execute(`
              INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
              ) VALUES (?, ?, ?, ?, ?)
            `, [journalEntryId, accountsReceivable[0].id, adjustmentAmount, 0, journalDescription]);
            
            await conn.execute(`
              INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
              ) VALUES (?, ?, ?, ?, ?)
            `, [journalEntryId, retainedEarnings[0].id, 0, adjustmentAmount, journalDescription]);
            
            // Create DEBIT transaction
            await StudentTransactionController.createTransactionHelper(
              student.regNumber,
              'DEBIT',
              adjustmentAmount,
              `Balance Adjustment for ${student.name} ${student.surname}: ${reference}`,
              {
                created_by: 1,
                journal_entry_id: journalEntryId
              }
            );
          } else {
            // Need to reduce debt (CREDIT)
            await conn.execute(`
              INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
              ) VALUES (?, ?, ?, ?, ?)
            `, [journalEntryId, retainedEarnings[0].id, adjustmentAmount, 0, journalDescription]);
            
            await conn.execute(`
              INSERT INTO journal_entry_lines (
                journal_entry_id, account_id, debit, credit, description
              ) VALUES (?, ?, ?, ?, ?)
            `, [journalEntryId, accountsReceivable[0].id, 0, adjustmentAmount, journalDescription]);
            
            // Create CREDIT transaction
            await StudentTransactionController.createTransactionHelper(
              student.regNumber,
              'CREDIT',
              adjustmentAmount,
              `Balance Adjustment for ${student.name} ${student.surname}: ${reference}`,
              {
                created_by: 1,
                journal_entry_id: journalEntryId
              }
            );
          }
          
          // Update account balances
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
          
          // Get updated balance
          const [updatedBalance] = await conn.execute(
            'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
            [student.regNumber]
          );
          const newBalance = updatedBalance.length > 0 ? parseFloat(updatedBalance[0].current_balance) : 0;
          
          console.log(`✅ Fixed ${student.name} ${student.surname}: $${current.toFixed(2)} → $${newBalance.toFixed(2)} (expected: $${expected.toFixed(2)})`);
          fixed++;
        }
      }
    }
    
    await conn.commit();
    
    console.log(`\n✅ Successfully fixed ${fixed} student balances!`);
    console.log('\n📊 Final Verification:\n');
    
    // Verify all balances
    for (const student of studentData) {
      const [balance] = await conn.execute(
        'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
        [student.regNumber]
      );
      
      const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
      const match = Math.abs(currentBalance - student.balance) < 0.01;
      
      console.log(`   ${student.name} ${student.surname} (${student.regNumber}): $${currentBalance.toFixed(2)} ${match ? '✅' : '❌'} (expected: $${student.balance.toFixed(2)})`);
    }
    
  } catch (error) {
    await conn.rollback();
    console.error('\n❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixAndComplete();

