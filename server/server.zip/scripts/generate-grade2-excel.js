const ExcelJS = require('exceljs');
const { pool } = require('./config/database');

// Student data extracted from the Grade 2 sheet - carefully extracted from image description
const studentData = [
  { name: 'J Golden', surname: 'Charuma', balReg: -36, payment1: 50, payment2: 50, payment3: 10, total: 120 },
  { name: 'Tinashe', surname: 'Dube', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Lazarus', surname: 'Adel', balReg: -91, payment1: 50, payment2: 40, payment3: 0, total: 90 },
  { name: 'Tinashe', surname: 'Muchabaiwa', balReg: -16, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Advance', surname: 'Paza', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Delma', surname: 'Nhandara', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Mufaro', surname: 'Magombe', balReg: -2, payment1: 50, payment2: 50, payment3: 10, total: 100 },
  { name: 'Dhinala', surname: 'Delan', balReg: -2, payment1: 50, payment2: 50, payment3: 20, total: 120 },
  { name: 'Munyaradzi', surname: 'Unknown1', balReg: -2, payment1: 40, payment2: 50, payment3: 20, total: 100 },
  { name: 'Tafadzwa', surname: 'Mudzviti', balReg: -6, payment1: 25, payment2: 23, payment3: 15, total: 63 },
  { name: 'Mickeilla', surname: 'Musungo', balReg: -2, payment1: 40, payment2: 50, payment3: 0, total: 90 },
  { name: 'T Shamah', surname: 'Kativhu', balReg: -2, payment1: 50, payment2: 30, payment3: 30, total: 100 },
  { name: 'Paul', surname: 'Prince', balReg: -2, payment1: 50, payment2: 50, payment3: 100, total: 200 },
  { name: 'Kelly', surname: 'Chitando', balReg: -2, payment1: 50, payment2: 10, payment3: 0, total: 60 },
  { name: 'Anashe', surname: 'Ndongwe', balReg: -2, payment1: 10, payment2: 50, payment3: 0, total: 60 },
  // For students 16-38, the description doesn't provide specific names, but mentions they exist
  // Most have Bal/REG: -2, and typical payments of 50+50=100
  // I'll create placeholder entries that need to be filled in
  { name: 'Student16', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student17', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student18', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student19', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student20', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student21', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student22', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student23', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student24', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student25', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student26', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student27', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student28', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student29', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student30', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student31', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student32', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student33', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student34', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student35', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student36', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student37', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 },
  { name: 'Student38', surname: 'Unknown', balReg: -2, payment1: 50, payment2: 50, payment3: 0, total: 100 }
];

// Function to generate registration number based on existing pattern
// Pattern: R + 5 digits + letter (e.g., R05688P, R79290B)
async function generateRegNumber(name, surname, existingNumbers) {
  // Get the highest number from existing registration numbers
  let maxNumber = 0;
  
  try {
    const [existing] = await pool.execute(
      "SELECT RegNumber FROM students WHERE RegNumber REGEXP '^R[0-9]{5}[A-Z]$' ORDER BY RegNumber DESC LIMIT 1"
    );
    
    if (existing.length > 0) {
      const lastReg = existing[0].RegNumber;
      const numberPart = parseInt(lastReg.substring(1, 6));
      maxNumber = numberPart;
    }
  } catch (error) {
    console.log('Could not fetch existing reg numbers, starting from 0');
  }
  
  // Generate new number (increment from max)
  const newNumber = maxNumber + 1;
  const numberStr = String(newNumber).padStart(5, '0');
  
  // Generate letter suffix based on surname first letter (or name if no surname)
  const letterSource = surname || name;
  const firstLetter = letterSource.charAt(0).toUpperCase();
  const letter = /[A-Z]/.test(firstLetter) ? firstLetter : 'A';
  
  const regNumber = `R${numberStr}${letter}`;
  
  // Check for duplicates and adjust if needed
  if (existingNumbers.has(regNumber)) {
    // If duplicate, try next letter
    const nextLetter = String.fromCharCode(letter.charCodeAt(0) + 1);
    return `R${numberStr}${nextLetter > 'Z' ? 'A' : nextLetter}`;
  }
  
  existingNumbers.add(regNumber);
  return regNumber;
}

async function generateExcel() {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grade 2 Students');
  
  // Set column headers
  worksheet.columns = [
    { header: 'Name', key: 'name', width: 20 },
    { header: 'Surname', key: 'surname', width: 20 },
    { header: 'Registration Number', key: 'regNumber', width: 18 },
    { header: 'Class', key: 'class', width: 15 },
    { header: 'Balance', key: 'balance', width: 12 },
    { header: 'Total Payments', key: 'totalPayments', width: 15 }
  ];
  
  // Style the header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Get existing registration numbers to avoid duplicates
  const existingNumbers = new Set();
  try {
    const [existing] = await pool.execute('SELECT RegNumber FROM students');
    existing.forEach(row => existingNumbers.add(row.RegNumber));
  } catch (error) {
    console.log('Could not fetch existing reg numbers');
  }
  
  // Add student data
  for (const student of studentData) {
    const regNumber = await generateRegNumber(student.name, student.surname, existingNumbers);
    
    // Calculate total payments (use total column if provided, otherwise sum payments)
    const totalPayments = student.total || (student.payment1 || 0) + (student.payment2 || 0) + (student.payment3 || 0);
    
    worksheet.addRow({
      name: student.name,
      surname: student.surname,
      regNumber: regNumber,
      class: 'Grade 2',
      balance: student.balReg || 0,
      totalPayments: totalPayments
    });
  }
  
  // Format balance column (negative values in red)
  worksheet.getColumn('balance').numFmt = '$#,##0.00';
  worksheet.getColumn('totalPayments').numFmt = '$#,##0.00';
  
  // Add conditional formatting for negative balances
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) { // Skip header
      const balanceCell = row.getCell('balance');
      if (balanceCell.value < 0) {
        balanceCell.font = { color: { argb: 'FFFF0000' } }; // Red
      }
    }
  });
  
  // Save the file
  const filename = 'Grade2_Students_Data.xlsx';
  await workbook.xlsx.writeFile(filename);
  console.log(`\n✅ Excel file created: ${filename}`);
  console.log(`📊 Total students: ${studentData.length}`);
  console.log(`\n⚠️  IMPORTANT: The image description only provided clear details for the first 15 students.`);
  console.log(`   Students 16-38 are marked as "Student16", "Student17", etc. with placeholder data.`);
  console.log(`   Please review the original document and update ALL student names, balances, and payments in the Excel file.`);
  console.log(`   Pay special attention to:`);
  console.log(`   - All student names (first name and surname)`);
  console.log(`   - Bal/REG values (many show -2, but some have different values like -36, -91, -16, -6)`);
  console.log(`   - Payment amounts (1st, 2nd, 3rd payments)`);
  console.log(`   - Total payments (some may differ from the sum of individual payments)`);
  
  // Close database connection
  await pool.end();
}

generateExcel().catch(error => {
  console.error('Error generating Excel file:', error);
  process.exit(1);
});
