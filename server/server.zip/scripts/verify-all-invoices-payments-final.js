const { pool } = require('./config/database');

async function verifyAllInvoicesPaymentsFinal() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n✅ FINAL VERIFICATION: INVOICES AND PAYMENTS\n');
    console.log('='.repeat(70));
    console.log('Checking: Grade 1-7, ECD A, ECD B (excluding Grade 7 2024)\n');
    
    const classes = [
      { name: 'Grade 1', id: 22 },
      { name: 'Grade 2', id: 23 },
      { name: 'Grade 3', id: 24 },
      { name: 'Grade 4', id: 25 },
      { name: 'Grade 5', id: 26 },
      { name: 'Grade 6', id: 27 },
      { name: 'Grade 7', id: 28 },
      { name: 'ECD A', id: 20 },
      { name: 'ECD B', id: 21 }
    ];
    
    let totalStudents = 0;
    let totalWithInvoices = 0;
    let totalWithPayments = 0;
    let totalWithoutPayments = 0;
    
    for (const classInfo of classes) {
      console.log(`\n📚 ${classInfo.name} (Class ID: ${classInfo.id})\n`);
      console.log('-'.repeat(70));
      
      // Get all enrolled students
      const [students] = await conn.execute(`
        SELECT DISTINCT s.RegNumber, s.Name, s.Surname,
               (SELECT current_balance FROM student_balances WHERE student_reg_number = s.RegNumber) as balance
        FROM students s
        INNER JOIN enrollments_gradelevel_classes e ON s.RegNumber = e.student_regnumber
        WHERE e.gradelevel_class_id = ? AND e.status = 'active'
        ORDER BY s.RegNumber
      `, [classInfo.id]);
      
      totalStudents += students.length;
      
      let withInvoices = 0;
      let withPayments = 0;
      let withoutPayments = 0;
      
      for (const student of students) {
        // Check for invoices - any DEBIT transaction (enrollment creates DEBIT)
        const [invoices] = await conn.execute(`
          SELECT COUNT(*) as count
          FROM student_transactions
          WHERE student_reg_number = ? 
            AND transaction_type = 'DEBIT'
        `, [student.RegNumber]);
        
        const hasInvoice = parseInt(invoices[0].count) > 0;
        
        // Get total payments
        const [feePayments] = await conn.execute(`
          SELECT COALESCE(SUM(payment_amount), 0) as total_payments
          FROM fee_payments
          WHERE student_reg_number = ?
        `, [student.RegNumber]);
        
        const [creditTransactions] = await conn.execute(`
          SELECT COALESCE(SUM(amount), 0) as total_credits
          FROM student_transactions
          WHERE student_reg_number = ? AND transaction_type = 'CREDIT'
        `, [student.RegNumber]);
        
        const totalPayments = parseFloat(feePayments[0].total_payments || 0) + parseFloat(creditTransactions[0].total_credits || 0);
        const balance = parseFloat(student.balance || 0);
        
        if (hasInvoice) {
          withInvoices++;
          totalWithInvoices++;
        }
        
        if (totalPayments > 0) {
          withPayments++;
          totalWithPayments++;
        } else {
          withoutPayments++;
          totalWithoutPayments++;
        }
      }
      
      console.log(`Total students: ${students.length}`);
      console.log(`Students with invoices: ${withInvoices}/${students.length} (${((withInvoices/students.length)*100).toFixed(1)}%)`);
      console.log(`Students with payments: ${withPayments}/${students.length} (${((withPayments/students.length)*100).toFixed(1)}%)`);
      console.log(`Students without payments: ${withoutPayments}/${students.length} (${((withoutPayments/students.length)*100).toFixed(1)}%)`);
    }
    
    console.log('\n\n' + '='.repeat(70));
    console.log('📊 OVERALL SUMMARY:\n');
    console.log(`   Total students checked: ${totalStudents}`);
    console.log(`   Students with invoices: ${totalWithInvoices}/${totalStudents} (${((totalWithInvoices/totalStudents)*100).toFixed(1)}%)`);
    console.log(`   Students with payments: ${totalWithPayments}/${totalStudents} (${((totalWithPayments/totalStudents)*100).toFixed(1)}%)`);
    console.log(`   Students without payments: ${totalWithoutPayments}/${totalStudents} (${((totalWithoutPayments/totalStudents)*100).toFixed(1)}%)`);
    
    if (totalWithInvoices === totalStudents) {
      console.log(`\n   ✅ ALL STUDENTS HAVE INVOICES!`);
    } else {
      console.log(`\n   ⚠️  ${totalStudents - totalWithInvoices} students missing invoices`);
    }
    
    if (totalWithPayments === totalStudents) {
      console.log(`   ✅ ALL STUDENTS HAVE PAYMENTS RECORDED!`);
    } else {
      console.log(`   ⚠️  ${totalWithoutPayments} students have no payments recorded`);
    }
    
    console.log('\n' + '='.repeat(70));
    console.log('✅ Verification complete!');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

verifyAllInvoicesPaymentsFinal();

