const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

async function checkDuplicateFeePayments() {
  const conn = await pool.getConnection();
  
  try {
    const studentRegNumber = 'R97077M';
    
    console.log(`🔍 Checking fee payments and transactions for student: ${studentRegNumber}\n`);
    
    // Check fee_payments
    const [feePayments] = await conn.execute(
      `SELECT id, receipt_number, payment_amount, base_currency_amount, payment_date, created_at
       FROM fee_payments 
       WHERE student_reg_number = ?
       ORDER BY created_at DESC`,
      [studentRegNumber]
    );
    
    console.log(`📊 Fee Payments (${feePayments.length} total):`);
    feePayments.forEach((fp, index) => {
      console.log(`   ${index + 1}. ID: ${fp.id}, Receipt: ${fp.receipt_number}, Amount: $${fp.base_currency_amount}, Date: ${fp.payment_date}`);
    });
    
    // Check student_transactions
    const [transactions] = await conn.execute(
      `SELECT id, transaction_type, amount, description, transaction_date, created_at
       FROM student_transactions 
       WHERE student_reg_number = ?
       ORDER BY created_at DESC`,
      [studentRegNumber]
    );
    
    console.log(`\n📋 Student Transactions (${transactions.length} total):`);
    transactions.forEach((tx, index) => {
      console.log(`   ${index + 1}. ID: ${tx.id}, Type: ${tx.transaction_type}, Amount: $${tx.amount}, Description: ${tx.description}`);
      console.log(`      Date: ${tx.transaction_date}, Created: ${tx.created_at}`);
    });
    
    // Check for duplicates by matching receipt numbers
    console.log(`\n🔍 Checking for duplicates...\n`);
    const duplicates = [];
    
    feePayments.forEach(fp => {
      const matchingTxs = transactions.filter(tx => 
        tx.description && tx.description.includes(fp.receipt_number)
      );
      
      if (matchingTxs.length > 1) {
        duplicates.push({
          receipt: fp.receipt_number,
          payment: fp,
          transactions: matchingTxs
        });
      }
    });
    
    if (duplicates.length > 0) {
      console.log(`⚠️  Found ${duplicates.length} duplicate transaction(s):\n`);
      duplicates.forEach((dup, index) => {
        console.log(`Duplicate ${index + 1}:`);
        console.log(`   Receipt: ${dup.receipt}`);
        console.log(`   Payment ID: ${dup.payment.id}, Amount: $${dup.payment.base_currency_amount}`);
        console.log(`   Transaction IDs: ${dup.transactions.map(t => t.id).join(', ')}`);
        console.log('');
      });
    } else {
      console.log('✅ No duplicates found');
    }
    
    // Check balance
    const [balance] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      [studentRegNumber]
    );
    
    console.log(`\n💰 Current Balance: $${balance.length > 0 ? balance[0].current_balance : '0.00'}`);
    
    // Calculate expected balance
    let calculatedBalance = 0;
    transactions.forEach(tx => {
      const amount = parseFloat(tx.amount);
      if (tx.transaction_type === 'CREDIT') {
        calculatedBalance += amount;
      } else {
        calculatedBalance -= amount;
      }
    });
    
    console.log(`📊 Calculated Balance (from transactions): $${calculatedBalance.toFixed(2)}`);
    
    if (balance.length > 0) {
      const currentBalance = parseFloat(balance[0].current_balance);
      const diff = Math.abs(currentBalance - calculatedBalance);
      if (diff > 0.01) {
        console.log(`⚠️  Balance mismatch: $${diff.toFixed(2)}`);
      } else {
        console.log(`✅ Balance matches`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkDuplicateFeePayments();

