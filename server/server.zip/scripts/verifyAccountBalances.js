const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        // Check AR account balance
        const [arAccount] = await conn.execute('SELECT id, code, name FROM chart_of_accounts WHERE code = "1100" AND type = "Asset"');
        if (arAccount.length > 0) {
            const [arBalance] = await conn.execute(`
                SELECT balance, as_of_date 
                FROM account_balances 
                WHERE account_id = ? 
                ORDER BY as_of_date DESC 
                LIMIT 1
            `, [arAccount[0].id]);
            console.log(`AR Account (${arAccount[0].code} - ${arAccount[0].name}):`);
            console.log(`  Balance: ${arBalance.length > 0 ? arBalance[0].balance : 'No balance record'}`);
            console.log(`  As of: ${arBalance.length > 0 ? arBalance[0].as_of_date : 'N/A'}`);
        }
        
        // Check Revenue account balance
        const [revenueAccount] = await conn.execute('SELECT id, code, name FROM chart_of_accounts WHERE code = "4000" AND type = "Revenue"');
        if (revenueAccount.length > 0) {
            const [revenueBalance] = await conn.execute(`
                SELECT balance, as_of_date 
                FROM account_balances 
                WHERE account_id = ? 
                ORDER BY as_of_date DESC 
                LIMIT 1
            `, [revenueAccount[0].id]);
            console.log(`\nRevenue Account (${revenueAccount[0].code} - ${revenueAccount[0].name}):`);
            console.log(`  Balance: ${revenueBalance.length > 0 ? revenueBalance[0].balance : 'No balance record'}`);
            console.log(`  As of: ${revenueBalance.length > 0 ? revenueBalance[0].as_of_date : 'N/A'}`);
        }
        
        // Count journal entries for enrollments
        const [journalCount] = await conn.execute(`
            SELECT COUNT(DISTINCT je.id) as count
            FROM journal_entries je
            WHERE je.reference LIKE 'ENROLL-%'
            AND je.description LIKE '%TUITION INVOICE%'
        `);
        console.log(`\nJournal entries for enrollments: ${journalCount[0].count}`);
        
    } catch(e) {
        console.error(e);
    } finally {
        conn.release();
        process.exit();
    }
})();

