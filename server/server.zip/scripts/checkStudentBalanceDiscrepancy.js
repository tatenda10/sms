const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        // Total active enrollments
        const [totalEnrollments] = await conn.execute('SELECT COUNT(*) as count FROM enrollments_gradelevel_classes WHERE status = "active"');
        console.log(`Total active enrollments: ${totalEnrollments[0].count}`);
        
        // Unique students in enrollments
        const [uniqueStudents] = await conn.execute(`
            SELECT COUNT(DISTINCT student_regnumber) as count 
            FROM enrollments_gradelevel_classes 
            WHERE status = 'active'
        `);
        console.log(`Unique students in enrollments: ${uniqueStudents[0].count}`);
        
        // Students with balance records
        const [withBalances] = await conn.execute('SELECT COUNT(*) as count FROM student_balances');
        console.log(`Students with balance records: ${withBalances[0].count}`);
        
        // Students in enrollments but missing balance records
        const [missingBalances] = await conn.execute(`
            SELECT DISTINCT e.student_regnumber, s.Name, s.Surname
            FROM enrollments_gradelevel_classes e
            JOIN students s ON e.student_regnumber = s.RegNumber
            WHERE e.status = 'active'
            AND NOT EXISTS (
                SELECT 1 FROM student_balances sb
                WHERE sb.student_reg_number = e.student_regnumber
            )
            ORDER BY e.student_regnumber
        `);
        console.log(`\nStudents in enrollments but missing balance records: ${missingBalances.length}`);
        if (missingBalances.length > 0) {
            console.log('\nMissing balance records:');
            missingBalances.forEach((student, idx) => {
                if (idx < 10) { // Show first 10
                    console.log(`  - ${student.student_regnumber}: ${student.Name} ${student.Surname}`);
                }
            });
            if (missingBalances.length > 10) {
                console.log(`  ... and ${missingBalances.length - 10} more`);
            }
        }
        
        // Students with multiple enrollments
        const [multipleEnrollments] = await conn.execute(`
            SELECT student_regnumber, COUNT(*) as enrollment_count
            FROM enrollments_gradelevel_classes
            WHERE status = 'active'
            GROUP BY student_regnumber
            HAVING COUNT(*) > 1
            ORDER BY enrollment_count DESC
        `);
        console.log(`\nStudents with multiple enrollments: ${multipleEnrollments.length}`);
        if (multipleEnrollments.length > 0) {
            console.log('\nTop students with multiple enrollments:');
            multipleEnrollments.slice(0, 10).forEach(student => {
                console.log(`  - ${student.student_regnumber}: ${student.enrollment_count} enrollments`);
            });
        }
        
        // Students with balance records but no active enrollments
        const [orphanBalances] = await conn.execute(`
            SELECT COUNT(*) as count
            FROM student_balances sb
            WHERE NOT EXISTS (
                SELECT 1 FROM enrollments_gradelevel_classes e
                WHERE e.student_regnumber = sb.student_reg_number
                AND e.status = 'active'
            )
        `);
        console.log(`\nStudents with balance records but no active enrollments: ${orphanBalances[0].count}`);
        
    } catch(e) {
        console.error(e);
    } finally {
        conn.release();
        process.exit();
    }
})();

