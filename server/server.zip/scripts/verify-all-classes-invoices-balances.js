const { pool } = require('./config/database');

// Define all classes and their students with expected balances
const classesToCheck = {
  'Grade 1': { classId: null, students: [] },
  'Grade 2': { classId: null, students: [] },
  'Grade 3': { classId: null, students: [] },
  'Grade 4': { classId: 25, students: [] },
  'Grade 5': { classId: null, students: [] },
  'Grade 6': { classId: null, students: [] },
  'Grade 7': { classId: null, students: [] },
  'ECD A': { classId: 20, students: [] },
  'ECD B': { classId: 21, students: [] }
};

async function verifyAllClassesInvoicesBalances() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔍 VERIFYING INVOICES AND BALANCES FOR ALL CLASSES\n');
    console.log('='.repeat(70));
    console.log('Checking: Grade 1-7, ECD A, ECD B (excluding Grade 7 2024)\n');
    
    // First, get class IDs for all classes
    console.log('📋 STEP 1: Finding class IDs...\n');
    for (const [className, classData] of Object.entries(classesToCheck)) {
      if (!classData.classId) {
        const [classes] = await conn.execute(`
          SELECT gc.id, gc.name 
          FROM gradelevel_classes gc
          WHERE gc.name LIKE ? OR gc.name = ?
          LIMIT 1
        `, [`%${className}%`, className]);
        
        if (classes.length > 0) {
          classesToCheck[className].classId = classes[0].id;
          console.log(`✅ ${className}: ID ${classes[0].id}`);
        } else {
          console.log(`❌ ${className}: Not found`);
        }
      } else {
        console.log(`✅ ${className}: ID ${classData.classId}`);
      }
    }
    
    // Now check each class
    console.log('\n\n📊 STEP 2: Checking students in each class...\n');
    console.log('='.repeat(70));
    
    let totalStudents = 0;
    let totalWithInvoices = 0;
    let totalWithoutInvoices = 0;
    let totalBalanceIssues = 0;
    
    for (const [className, classData] of Object.entries(classesToCheck)) {
      if (!classData.classId) {
        console.log(`\n⚠️  Skipping ${className} - class not found\n`);
        continue;
      }
      
      console.log(`\n📚 ${className} (Class ID: ${classData.classId})\n`);
      console.log('-'.repeat(70));
      
      // Get all enrolled students
      const [students] = await conn.execute(`
        SELECT DISTINCT s.RegNumber, s.Name, s.Surname,
               (SELECT current_balance FROM student_balances WHERE student_reg_number = s.RegNumber) as balance
        FROM students s
        INNER JOIN enrollments_gradelevel_classes e ON s.RegNumber = e.student_regnumber
        WHERE e.gradelevel_class_id = ? AND e.status = 'active'
        ORDER BY s.RegNumber
      `, [classData.classId]);
      
      console.log(`Total enrolled students: ${students.length}\n`);
      totalStudents += students.length;
      
      // Check if there are invoice structures for this class
      const [invoiceStructures] = await conn.execute(`
        SELECT COUNT(*) as count
        FROM invoice_structures
        WHERE gradelevel_class_id = ? AND is_active = 1
      `, [classData.classId]);
      
      const hasInvoiceStructures = parseInt(invoiceStructures[0].count) > 0;
      
      let studentsWithInvoices = 0;
      let studentsWithoutInvoices = 0;
      let studentsWithBalanceIssues = [];
      
      for (const student of students) {
        // Check if student has enrollment-related transactions (DEBIT transactions indicating fees charged)
        const [enrollmentTransactions] = await conn.execute(`
          SELECT COUNT(*) as count
          FROM student_transactions
          WHERE student_reg_number = ? 
            AND transaction_type = 'DEBIT'
            AND class_id = ?
        `, [student.RegNumber, classData.classId]);
        
        const hasTransactions = parseInt(enrollmentTransactions[0].count) > 0;
        
        // Check if student has journal entries related to enrollment
        const [journalEntries] = await conn.execute(`
          SELECT COUNT(*) as count
          FROM journal_entries je
          INNER JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
          WHERE je.description LIKE ? 
            AND je.reference LIKE ?
        `, [`%${student.Name}%${student.Surname}%`, `%${student.RegNumber}%`]);
        
        const hasJournalEntries = parseInt(journalEntries[0].count) > 0;
        
        const balance = parseFloat(student.balance || 0);
        const balanceStr = balance < 0 ? `-$${Math.abs(balance).toFixed(2)}` : `$${balance.toFixed(2)}`;
        
        // Student has invoices if there are invoice structures for the class AND (transactions OR journal entries)
        const hasInvoices = hasInvoiceStructures && (hasTransactions || hasJournalEntries);
        
        if (hasInvoices) {
          studentsWithInvoices++;
          totalWithInvoices++;
          console.log(`✅ ${student.Name.padEnd(20)} ${student.Surname.padEnd(25)} ${student.RegNumber.padEnd(12)} | Balance: ${balanceStr.padEnd(10)} | Has invoices`);
        } else {
          studentsWithoutInvoices++;
          totalWithoutInvoices++;
          studentsWithBalanceIssues.push(student);
          console.log(`⚠️  ${student.Name.padEnd(20)} ${student.Surname.padEnd(25)} ${student.RegNumber.padEnd(12)} | Balance: ${balanceStr.padEnd(10)} | NO INVOICES/TRANSACTIONS`);
        }
      }
      
      console.log(`\n📊 ${className} Summary:`);
      console.log(`   Total students: ${students.length}`);
      console.log(`   Invoice structures exist: ${hasInvoiceStructures ? 'Yes' : 'No'}`);
      console.log(`   Students with invoices/transactions: ${studentsWithInvoices}`);
      console.log(`   Students without invoices/transactions: ${studentsWithoutInvoices}`);
      if (studentsWithoutInvoices > 0) {
        console.log(`   ⚠️  WARNING: ${studentsWithoutInvoices} students missing invoices/transactions!`);
        totalBalanceIssues += studentsWithoutInvoices;
      }
    }
    
    console.log('\n\n' + '='.repeat(70));
    console.log('📊 OVERALL SUMMARY:\n');
    console.log(`   Total students checked: ${totalStudents}`);
    console.log(`   Students with invoices/transactions: ${totalWithInvoices}`);
    console.log(`   Students without invoices/transactions: ${totalWithoutInvoices}`);
    if (totalWithoutInvoices > 0) {
      console.log(`   ⚠️  WARNING: ${totalWithoutInvoices} students missing invoices/transactions!`);
    } else {
      console.log(`   ✅ All students have invoices/transactions!`);
    }
    console.log('\n' + '='.repeat(70));
    console.log('✅ Verification complete!');
    
  } catch (error) {
    console.error('Error verifying classes:', error);
  } finally {
    conn.release();
    process.exit(0);
  }
}

verifyAllClassesInvoicesBalances();
