const { pool } = require('./config/database');
const StudentTransactionController = require('./controllers/students/studentTransactionController');
const AccountBalanceService = require('./services/accountBalanceService');

// Students missing invoices/transactions
const missingStudents = {
  'Grade 4': [
    { name: 'Jacob', surname: 'Chimambo', regNumber: 'R96923C', expectedBalance: 0.00, totalPayments: 0.00 },
    { name: 'Munyaradzi', surname: 'Mudewairi', regNumber: 'R96923M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Malcom', surname: 'Mashamba', regNumber: 'R96924M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Comfort', surname: 'Mafigu', regNumber: 'R96925M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Ashleen', surname: 'Mberi', regNumber: 'R96926M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Tanatswa', surname: 'Mupumela', regNumber: 'R96927M', expectedBalance: 0.00, totalPayments: 20.00 },
    { name: 'B Tanisha', surname: 'Mushonga', regNumber: 'R96928M', expectedBalance: 0.00, totalPayments: 40.00 },
    { name: 'Brilliant', surname: 'Mabwinya', regNumber: 'R96929M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Makanakaishe', surname: 'Muchabaiwa', regNumber: 'R96930M', expectedBalance: -20.00, totalPayments: 82.00 },
    { name: 'Sharnia', surname: 'Mukwazi', regNumber: 'R96931M', expectedBalance: 0.00, totalPayments: 100.00 }
  ],
  'Grade 6': [
    { name: 'Shantel', surname: 'Chiteve', regNumber: 'R96909C', expectedBalance: 0.00, totalPayments: 50.00 },
    { name: 'Livetti', surname: 'Divala', regNumber: 'R96909D', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Nokutenda', surname: 'Manyanga', regNumber: 'R96909M', expectedBalance: 0.00, totalPayments: 90.00 },
    { name: 'Tadiwanashe', surname: 'Nguruve', regNumber: 'R96909N', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Isaac', surname: 'Chimambo', regNumber: 'R96910C', expectedBalance: 0.00, totalPayments: 0.00 },
    { name: 'Vanessa', surname: 'Machingauta', regNumber: 'R96910M', expectedBalance: 0.00, totalPayments: 75.00 },
    { name: 'Rumbidzai', surname: 'Chiputura', regNumber: 'R96911C', expectedBalance: 0.00, totalPayments: 0.00 },
    { name: 'Michele', surname: 'Munyanyi', regNumber: 'R96911M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Z Aaron', surname: 'Mutetwa', regNumber: 'R96912M', expectedBalance: 0.00, totalPayments: 50.00 },
    { name: 'Savania', surname: 'Matekenya', regNumber: 'R96913M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Mikel', surname: 'Mazuru', regNumber: 'R96914M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'clint', surname: 'Muchengwa', regNumber: 'R96915M', expectedBalance: 0.00, totalPayments: 140.00 },
    { name: 'Blessed', surname: 'Munjeri', regNumber: 'R96916M', expectedBalance: 0.00, totalPayments: 100.00 },
    { name: 'Tinotenda', surname: 'Madiya', regNumber: 'R96917M', expectedBalance: 0.00, totalPayments: 80.00 }
  ],
  'ECD A': [
    { name: 'Elsie', surname: 'Nhara', regNumber: 'R96919N', expectedBalance: -5.00, totalPayments: 25.00 }
  ],
  'ECD B': [
    { name: 'Fidel', surname: 'Marume', regNumber: 'R96920M', expectedBalance: 0.00, totalPayments: 115.00 },
    { name: 'Tally', surname: 'Madzima', regNumber: 'R96921M', expectedBalance: 0.00, totalPayments: 110.00 },
    { name: 'Lionel', surname: 'Mashambi', regNumber: 'R96922M', expectedBalance: -1.00, totalPayments: 115.00 }
  ]
};

async function createMissingInvoicesAndCheckPayments() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 CREATING MISSING INVOICES AND CHECKING PAYMENTS\n');
    console.log('='.repeat(70));
    
    // Get class IDs
    const classIds = {
      'Grade 4': 25,
      'Grade 6': 27,
      'ECD A': 20,
      'ECD B': 21
    };
    
    let totalProcessed = 0;
    let totalPaymentsChecked = 0;
    let totalPaymentsMissing = 0;
    
    for (const [className, students] of Object.entries(missingStudents)) {
      const classId = classIds[className];
      
      console.log(`\n📚 ${className} (Class ID: ${classId})\n`);
      console.log('-'.repeat(70));
      
      // Get invoice structure for this class (Term 3 2025)
      const [invoiceStructures] = await conn.execute(`
        SELECT id, total_amount, term, academic_year, gradelevel_class_id
        FROM invoice_structures
        WHERE gradelevel_class_id = ? AND is_active = 1
        ORDER BY academic_year DESC, term DESC
        LIMIT 1
      `, [classId]);
      
      if (invoiceStructures.length === 0) {
        console.log(`⚠️  No invoice structure found for ${className}, skipping...`);
        continue;
      }
      
      const invoiceStructure = invoiceStructures[0];
      const feeAmount = parseFloat(invoiceStructure.total_amount);
      const term = invoiceStructure.term || '3';
      const academicYear = invoiceStructure.academic_year || '2025';
      
      console.log(`Invoice Structure: Term ${term} ${academicYear}, Amount: $${feeAmount.toFixed(2)}\n`);
      
      // Get class name
      const [classes] = await conn.execute(
        'SELECT name FROM gradelevel_classes WHERE id = ?',
        [classId]
      );
      const classNameFull = classes.length > 0 ? classes[0].name : className;
      
      // Get or create journal ID
      let journalId = 1;
      try {
        const [journals] = await conn.execute(
          'SELECT id FROM journals WHERE name = ? OR id = ? LIMIT 1',
          ['Fees Journal', 1]
        );
        if (journals.length > 0) {
          journalId = journals[0].id;
        } else {
          const [newJournal] = await conn.execute(
            'INSERT INTO journals (name, description) VALUES (?, ?)',
            ['Fees Journal', 'Journal for fee transactions']
          );
          journalId = newJournal.insertId;
        }
      } catch (error) {
        console.log('Using default journal ID 1');
      }
      
      // Get Accounts Receivable and Tuition Revenue accounts
      const [arAccounts] = await conn.execute(
        "SELECT id FROM chart_of_accounts WHERE code = '1100' AND type = 'Asset' LIMIT 1"
      );
      const [revenueAccounts] = await conn.execute(
        "SELECT id FROM chart_of_accounts WHERE code = '4000' AND type = 'Revenue' LIMIT 1"
      );
      
      if (arAccounts.length === 0 || revenueAccounts.length === 0) {
        console.log(`⚠️  Required accounts not found for ${className}, skipping...`);
        continue;
      }
      
      const arAccountId = arAccounts[0].id;
      const revenueAccountId = revenueAccounts[0].id;
      
      await conn.beginTransaction();
      
      for (const student of students) {
        try {
          // Check if enrollment exists
          const [enrollments] = await conn.execute(`
            SELECT id FROM enrollments_gradelevel_classes
            WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
          `, [student.regNumber, classId]);
          
          if (enrollments.length === 0) {
            console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Not enrolled, skipping...`);
            continue;
          }
          
          const enrollmentId = enrollments[0].id;
          
          // Check if transaction already exists
          const [existingTxns] = await conn.execute(`
            SELECT id FROM student_transactions
            WHERE student_reg_number = ? 
              AND class_id = ?
              AND transaction_type = 'DEBIT'
              AND description LIKE ?
          `, [student.regNumber, classId, `%${classNameFull}%`]);
          
          if (existingTxns.length > 0) {
            console.log(`⏭️  ${student.name} ${student.surname} (${student.regNumber}) - Invoice already exists`);
            continue;
          }
          
          // Get student name
          const [studentInfo] = await conn.execute(
            'SELECT Name, Surname FROM students WHERE RegNumber = ?',
            [student.regNumber]
          );
          
          if (studentInfo.length === 0) {
            console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Student not found`);
            continue;
          }
          
          const studentName = `${studentInfo[0].Name} ${studentInfo[0].Surname}`;
          
          // Create journal entry
          const description = `TUITION INVOICE - ${classNameFull} - ${studentName} (${student.regNumber}) - Term ${term} ${academicYear}`;
          const reference = `INV-${student.regNumber}-${Date.now()}`;
          
          const [journalEntry] = await conn.execute(`
            INSERT INTO journal_entries (journal_id, entry_date, reference, description, created_by, created_at, updated_at)
            VALUES (?, CURDATE(), ?, ?, ?, NOW(), NOW())
          `, [journalId, reference, description, 1]);
          
          const journalEntryId = journalEntry.insertId;
          
          // Create journal entry lines
          await conn.execute(`
            INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, arAccountId, feeAmount, 0, `Accounts Receivable - ${studentName}`]);
          
          await conn.execute(`
            INSERT INTO journal_entry_lines (journal_entry_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, ?, ?)
          `, [journalEntryId, revenueAccountId, 0, feeAmount, `Tuition Revenue - ${classNameFull}`]);
          
          // Create DEBIT transaction
          const formattedTerm = term.replace(/Term\s*/i, '');
          await StudentTransactionController.createTransactionHelper(
            student.regNumber,
            'DEBIT',
            feeAmount,
            `TUITION INVOICE - ${classNameFull}`,
            {
              term: formattedTerm,
              academic_year: academicYear,
              class_id: classId,
              enrollment_id: enrollmentId,
              created_by: 1,
              journal_entry_id: journalEntryId
            }
          );
          
          // Update account balances
          await AccountBalanceService.updateAccountBalancesFromJournalEntry(conn, journalEntryId, 1);
          
          console.log(`✅ Created invoice for: ${student.name} ${student.surname} (${student.regNumber})`);
          totalProcessed++;
          
        } catch (error) {
          console.error(`❌ Error processing ${student.name} ${student.surname}:`, error.message);
        }
      }
      
      await conn.commit();
      
      // Now check payments for this class
      console.log(`\n💰 Checking payments for ${className}...\n`);
      
      for (const student of students) {
        // Get total payments from fee_payments table
        const [feePayments] = await conn.execute(`
          SELECT COALESCE(SUM(payment_amount), 0) as total_payments
          FROM fee_payments
          WHERE student_reg_number = ?
        `, [student.regNumber]);
        
        // Also get CREDIT transactions (payments)
        const [creditTransactions] = await conn.execute(`
          SELECT COALESCE(SUM(amount), 0) as total_credits
          FROM student_transactions
          WHERE student_reg_number = ? AND transaction_type = 'CREDIT'
        `, [student.regNumber]);
        
        const totalFeePayments = parseFloat(feePayments[0].total_payments || 0);
        const totalCredits = parseFloat(creditTransactions[0].total_credits || 0);
        const totalPayments = totalFeePayments + totalCredits;
        const expectedPayments = student.totalPayments || 0;
        
        // Get current balance
        const [balance] = await conn.execute(
          'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
          [student.regNumber]
        );
        const currentBalance = balance.length > 0 ? parseFloat(balance[0].current_balance) : 0;
        
        if (totalPayments < expectedPayments) {
          totalPaymentsMissing++;
          console.log(`⚠️  ${student.name} ${student.surname} (${student.regNumber}) - Payments: $${totalPayments.toFixed(2)} (Expected: $${expectedPayments.toFixed(2)}) | Balance: $${currentBalance.toFixed(2)}`);
        } else {
          totalPaymentsChecked++;
          console.log(`✅ ${student.name} ${student.surname} (${student.regNumber}) - Payments: $${totalPayments.toFixed(2)} (Expected: $${expectedPayments.toFixed(2)}) | Balance: $${currentBalance.toFixed(2)}`);
        }
      }
    }
    
    console.log('\n\n' + '='.repeat(70));
    console.log('📊 SUMMARY:\n');
    console.log(`   Invoices created: ${totalProcessed}`);
    console.log(`   Payments verified: ${totalPaymentsChecked}`);
    console.log(`   Payments missing: ${totalPaymentsMissing}`);
    console.log('\n' + '='.repeat(70));
    console.log('✅ Process complete!');
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

createMissingInvoicesAndCheckPayments();

