const { pool } = require('./config/database');

async function fixWaiverAccounts() {
  const conn = await pool.getConnection();
  
  try {
    await conn.beginTransaction();
    
    console.log('\n🔧 FIXING WAIVER ACCOUNTS\n');
    console.log('='.repeat(70));
    
    // Create waiver expense accounts using codes 5600-5640 to avoid conflict with Marketing (5500)
    const waiverAccounts = [
      { code: '5600', name: 'Waiver Expense - Tuition', type: 'Expense' },
      { code: '5610', name: 'Waiver Expense - Boarding', type: 'Expense' },
      { code: '5620', name: 'Waiver Expense - Transport', type: 'Expense' },
      { code: '5630', name: 'Waiver Expense - Uniform', type: 'Expense' },
      { code: '5640', name: 'Waiver Expense - Other Fees', type: 'Expense' }
    ];
    
    console.log('\n📝 Creating/Updating Waiver Expense Accounts:\n');
    
    for (const account of waiverAccounts) {
      // Check if account exists
      const [existing] = await conn.execute(
        'SELECT id, code, name FROM chart_of_accounts WHERE code = ?',
        [account.code]
      );
      
      if (existing.length > 0) {
        // Update existing account
        await conn.execute(
          'UPDATE chart_of_accounts SET name = ?, type = ?, is_active = TRUE WHERE code = ?',
          [account.name, account.type, account.code]
        );
        console.log(`   ✅ Updated: ${account.code} - ${account.name}`);
      } else {
        // Create new account
        await conn.execute(
          'INSERT INTO chart_of_accounts (code, name, type, is_active) VALUES (?, ?, ?, TRUE)',
          [account.code, account.name, account.type]
        );
        console.log(`   ✅ Created: ${account.code} - ${account.name}`);
      }
    }
    
    // Verify receivable accounts exist
    console.log('\n📝 Verifying Accounts Receivable:\n');
    
    const receivableAccounts = [
      { code: '1100', name: 'Accounts Receivable - Tuition', type: 'Asset' },
      { code: '1110', name: 'Accounts Receivable - Other', type: 'Asset' }
    ];
    
    for (const account of receivableAccounts) {
      const [existing] = await conn.execute(
        'SELECT id, code, name FROM chart_of_accounts WHERE code = ?',
        [account.code]
      );
      
      if (existing.length > 0) {
        console.log(`   ✅ Exists: ${account.code} - ${existing[0].name}`);
      } else {
        // Create if missing
        await conn.execute(
          'INSERT INTO chart_of_accounts (code, name, type, is_active) VALUES (?, ?, ?, TRUE)',
          [account.code, account.name, account.type]
        );
        console.log(`   ✅ Created: ${account.code} - ${account.name}`);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ Waiver accounts fixed successfully!');
    console.log('\n📊 New Account Mapping:');
    console.log('   Tuition:  Expense 5600 → Receivable 1100');
    console.log('   Boarding: Expense 5610 → Receivable 1110');
    console.log('   Transport: Expense 5620 → Receivable 1110');
    console.log('   Uniform:  Expense 5630 → Receivable 1110');
    console.log('   Other:    Expense 5640 → Receivable 1100');
    
  } catch (error) {
    await conn.rollback();
    console.error('\n❌ Error fixing waiver accounts:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

fixWaiverAccounts();

