const { pool } = require('./config/database');

// Newly registered Grade 4 students that need enrollment
const newStudents = [
  { name: 'Jacob', surname: 'Chimambo' },
  { name: 'Munyaradzi', surname: 'Mudewairi' },
  { name: 'Malcom', surname: 'Mashamba' },
  { name: 'Comfort', surname: 'Mafigu' },
  { name: 'Ashleen', surname: 'Mberi' },
  { name: 'Tanatswa', surname: 'Mupumela' },
  { name: 'B Tanisha', surname: 'Mushonga' },
  { name: 'Brilliant', surname: 'Mabwinya' },
  { name: 'Makanakaishe', surname: 'Muchabaiwa' },
  { name: 'Sharnia', surname: 'Mukwazi' }
];

async function findStudentByName(conn, name, surname) {
  const [students] = await conn.execute(
    'SELECT RegNumber, Name, Surname FROM students WHERE LOWER(TRIM(Name)) = LOWER(TRIM(?)) AND LOWER(TRIM(Surname)) = LOWER(TRIM(?))',
    [name, surname]
  );
  return students.length > 0 ? students[0] : null;
}

async function enrollGrade4Missing() {
  const conn = await pool.getConnection();
  
  try {
    console.log('\n🔧 ENROLLING MISSING GRADE 4 STUDENTS\n');
    console.log('='.repeat(70));
    
    // Get Grade 4 class
    const [classes] = await conn.execute(`
      SELECT gc.id, gc.name 
      FROM gradelevel_classes gc
      WHERE gc.id = 25 OR gc.name LIKE '%Grade 4%'
      LIMIT 1
    `);
    
    if (classes.length === 0) {
      console.log('❌ Grade 4 class not found');
      return;
    }
    
    const grade4Class = classes[0];
    console.log(`✅ Found Grade 4 class: ${grade4Class.name} (ID: ${grade4Class.id})\n`);
    
    await conn.beginTransaction();
    
    let enrolled = 0;
    
    // Process each student
    for (const student of newStudents) {
      const existing = await findStudentByName(conn, student.name, student.surname);
      
      if (!existing) {
        console.log(`⚠️  ${student.name} ${student.surname} not found, skipping...`);
        continue;
      }
      
      console.log(`📝 Processing: ${student.name} ${student.surname} (${existing.RegNumber})`);
      
      // Check enrollment
      const [enrollment] = await conn.execute(`
        SELECT id FROM enrollments_gradelevel_classes 
        WHERE student_regnumber = ? AND gradelevel_class_id = ? AND status = 'active'
      `, [existing.RegNumber, grade4Class.id]);
      
      if (enrollment.length === 0) {
        await conn.execute(`
          INSERT INTO enrollments_gradelevel_classes (student_regnumber, gradelevel_class_id, status)
          VALUES (?, ?, 'active')
        `, [existing.RegNumber, grade4Class.id]);
        enrolled++;
        console.log(`   ✅ Enrolled in Grade 4`);
      } else {
        console.log(`   ⏭️  Already enrolled`);
      }
    }
    
    await conn.commit();
    
    console.log('\n✅ Grade 4 enrollment completed!');
    console.log(`\n📊 Summary:`);
    console.log(`   Students enrolled: ${enrolled}`);
    
  } catch (error) {
    await conn.rollback();
    console.error('❌ Error enrolling students:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
}

enrollGrade4Missing();

