const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { pool } = require('../config/database');

(async () => {
    const conn = await pool.getConnection();
    try {
        console.log('🔍 Verifying unique constraint on enrollments_gradelevel_classes...\n');
        
        // Check if constraint exists
        const [indexes] = await conn.execute(
            `SHOW INDEX FROM enrollments_gradelevel_classes WHERE Key_name = 'unique_student_enrollment'`
        );
        
        if (indexes.length > 0) {
            console.log('✅ Unique constraint EXISTS');
            console.log(`   Constraint name: ${indexes[0].Key_name}`);
            console.log(`   Column: ${indexes[0].Column_name}`);
            console.log(`   Unique: ${indexes[0].Non_unique === 0 ? 'YES' : 'NO'}`);
        } else {
            console.log('❌ Unique constraint DOES NOT EXIST');
            console.log('   Run applyUniqueEnrollmentConstraint.js to add it.');
            process.exit(1);
        }
        
        // Test the constraint by trying to find any duplicates (should be 0)
        const [duplicates] = await conn.execute(`
            SELECT student_regnumber, COUNT(*) as count
            FROM enrollments_gradelevel_classes
            GROUP BY student_regnumber
            HAVING COUNT(*) > 1
        `);
        
        if (duplicates.length > 0) {
            console.log(`\n⚠️  WARNING: Found ${duplicates.length} students with duplicate enrollments!`);
            console.log('   This should not happen with the constraint in place.');
            duplicates.forEach(dup => {
                console.log(`   - ${dup.student_regnumber}: ${dup.count} enrollments`);
            });
        } else {
            console.log('\n✅ No duplicate enrollments found - constraint is working correctly.');
        }
        
        // Show total enrollments
        const [total] = await conn.execute(
            'SELECT COUNT(*) as count FROM enrollments_gradelevel_classes'
        );
        console.log(`\n📊 Total enrollments: ${total[0].count}`);
        
        // Show unique students
        const [unique] = await conn.execute(
            'SELECT COUNT(DISTINCT student_regnumber) as count FROM enrollments_gradelevel_classes'
        );
        console.log(`📊 Unique students: ${unique[0].count}`);
        
        if (total[0].count === unique[0].count) {
            console.log('✅ Perfect: Total enrollments = Unique students (one enrollment per student)');
        } else {
            console.log(`⚠️  Mismatch: Total enrollments (${total[0].count}) != Unique students (${unique[0].count})`);
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    } finally {
        conn.release();
        process.exit(0);
    }
})();

