const { pool } = require('./config/database');

async function checkStudent() {
  const conn = await pool.getConnection();
  try {
    const [balance] = await conn.execute(
      'SELECT current_balance FROM student_balances WHERE student_reg_number = ?',
      ['R00002B']
    );
    
    console.log('Current balance:', balance[0]?.current_balance);
    
    const [txns] = await conn.execute(
      'SELECT id, transaction_type, amount, description, created_at FROM student_transactions WHERE student_reg_number = ? ORDER BY id',
      ['R00002B']
    );
    
    console.log('\nTransactions:');
    let calculated = 0;
    txns.forEach(t => {
      const amt = parseFloat(t.amount);
      if (t.transaction_type === 'DEBIT') {
        calculated -= amt;
      } else {
        calculated += amt;
      }
      console.log(`  ${t.id}: ${t.transaction_type} ${amt} - ${t.description.substring(0, 50)}`);
    });
    
    console.log(`\nCalculated balance from transactions: ${calculated}`);
    console.log(`Actual balance in DB: ${balance[0]?.current_balance}`);
    
  } finally {
    conn.release();
    process.exit(0);
  }
}

checkStudent();

