const { pool } = require('../config/database');

async function testIncomeStatementAllAccounts() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing Income Statement with all accounts (including zero values)...');
    
    // Test with a date range that might have some transactions
    const startDate = '2025-01-01';
    const endDate = '2025-12-31';
    
    console.log(`\n📅 Testing period: ${startDate} to ${endDate}`);
    
    // Test the revenue query (same as in the updated controller)
    console.log('\n💰 Testing Revenue Query...');
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [revenue] = await connection.execute(revenueQuery, [startDate, endDate]);
    
    console.log(`   ✅ Found ${revenue.length} revenue accounts:`);
    revenue.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💰' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Test the expense query (same as in the updated controller)
    console.log('\n💸 Testing Expense Query...');
    const expenseQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.debit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN ? AND ?
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Expense' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [expenses] = await connection.execute(expenseQuery, [startDate, endDate]);
    
    console.log(`   ✅ Found ${expenses.length} expense accounts:`);
    expenses.forEach((account, index) => {
      const amount = parseFloat(account.amount || 0);
      const status = amount > 0 ? '💸' : '⚪';
      console.log(`   ${index + 1}. ${status} ${account.code} - ${account.name}: $${amount.toFixed(2)}`);
    });
    
    // Calculate totals
    const totalRevenue = revenue.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const netIncome = totalRevenue - totalExpenses;
    
    console.log(`\n📊 Summary:`);
    console.log(`   • Total Revenue: $${totalRevenue.toFixed(2)}`);
    console.log(`   • Total Expenses: $${totalExpenses.toFixed(2)}`);
    console.log(`   • Net Income: $${netIncome.toFixed(2)}`);
    
    // Count accounts with and without transactions
    const revenueWithTransactions = revenue.filter(r => parseFloat(r.amount || 0) > 0).length;
    const revenueWithoutTransactions = revenue.length - revenueWithTransactions;
    const expensesWithTransactions = expenses.filter(e => parseFloat(e.amount || 0) > 0).length;
    const expensesWithoutTransactions = expenses.length - expensesWithTransactions;
    
    console.log(`\n📈 Account Breakdown:`);
    console.log(`   • Revenue accounts with transactions: ${revenueWithTransactions}`);
    console.log(`   • Revenue accounts with zero values: ${revenueWithoutTransactions}`);
    console.log(`   • Expense accounts with transactions: ${expensesWithTransactions}`);
    console.log(`   • Expense accounts with zero values: ${expensesWithoutTransactions}`);
    
    if (revenueWithoutTransactions > 0 || expensesWithoutTransactions > 0) {
      console.log('\n🎉 SUCCESS! Income statement now shows all accounts including those with zero values!');
    } else {
      console.log('\n⚠️  All accounts have transactions - this might be expected for this period.');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing income statement:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testIncomeStatementAllAccounts()
    .then(() => {
      console.log('\n✅ Income statement test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Income statement test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testIncomeStatementAllAccounts;
