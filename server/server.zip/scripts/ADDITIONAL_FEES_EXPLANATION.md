# Additional Fees System - How It Works

## Overview
The Additional Fees system allows you to create and assign fees to students that are NOT part of the regular invoice structure (tuition, boarding, etc.). Examples include:
- Textbook Fees
- Registration Fees
- Uniform Fees
- Sports Fees
- Library Fees
- etc.

## System Architecture

### 1. **Fee Structures** (`additional_fee_structures` table)
- Templates for fees that can be assigned to students
- Fields:
  - `fee_name`: Name of the fee (e.g., "Textbook Fees")
  - `description`: Optional description
  - `amount`: Default amount for this fee
  - `currency_id`: Currency for the fee
  - `fee_type`: Either `'annual'` (charged once per year) or `'one_time'` (charged once per student)
  - `academic_year`: Optional - can be tied to specific academic year
  - `is_active`: Whether the fee structure is active

### 2. **Student Fee Assignments** (`student_fee_assignments` table)
- Links specific students to fee structures
- Created when you assign a fee to a student
- Fields:
  - `student_reg_number`: Student receiving the fee
  - `fee_structure_id`: Which fee structure
  - `academic_year`: Academic year for the assignment
  - `term`: Optional term (for one-time fees)
  - `amount`: Amount assigned (can differ from structure default)
  - `due_date`: When payment is due
  - `status`: 'pending', 'paid', 'partial', 'overdue', 'waived'
  - `paid_amount`: How much has been paid
  - `balance`: Calculated as `amount - paid_amount`

### 3. **Fee Payments** (`additional_fee_payments` table)
- Records payments made for additional fees
- Links to fee assignments
- Tracks payment method, date, receipt number, etc.

## How It Works

### Step 1: Create Fee Structure
1. Admin creates a fee structure (e.g., "Textbook Fees - $35")
2. Sets fee type (annual or one-time)
3. Sets default amount and currency

### Step 2: Assign Fee to Students
Two methods:

**A. Manual Assignment** (`assignFeeToStudents`)
- Select specific students
- Assign fee structure to them
- Can set custom amount, term, due date
- **What happens:**
  - Creates `student_fee_assignments` record
  - Creates DEBIT `student_transactions` (increases student debt)
  - Updates `student_balances` (increases balance owed)
  - ⚠️ **ISSUE**: Does NOT create journal entries for accounting

**B. Bulk Generation** (`generateAnnualFeesForAllStudents`)
- For annual fees only
- Automatically assigns to ALL active students
- Same process as manual assignment

### Step 3: Record Payments
Two methods:

**A. Payment Against Assignment** (`processPayment`)
- Student pays against a specific fee assignment
- Updates assignment status (pending → partial → paid)
- Updates `paid_amount` and `balance`
- Creates CREDIT `student_transactions` (reduces debt)
- Updates `student_balances` (reduces balance owed)
- ✅ Creates journal entries:
  - DEBIT: Cash/Bank (increases asset)
  - CREDIT: Additional Fees Revenue (increases revenue)

**B. Direct Payment** (`processFeePayment`)
- Payment without a specific assignment
- Creates payment record directly
- Creates CREDIT `student_transactions`
- Updates `student_balances`
- ✅ Creates journal entries

## Current Issues

### Issue 1: Missing Journal Entries on Fee Assignment
**Problem:** When fees are assigned to students, journal entries are NOT created.

**What should happen:**
```
When assigning $35 Textbook Fee to Student:
DEBIT:  Accounts Receivable - Tuition (1100)    $35
CREDIT: Additional Fees Revenue (4XXX)         $35
```

**Current behavior:**
- ✅ Student transaction created (DEBIT)
- ✅ Student balance updated
- ❌ No journal entry created
- ❌ Accounts Receivable not updated
- ❌ Revenue not recorded

### Issue 2: Journal Entry Account Selection
**Problem:** The `createJournalEntries` function uses a fallback to find revenue accounts, which may not be correct.

**Current logic:**
1. Tries to find account with code starting with '4' and name containing 'additional' or 'fee'
2. Falls back to ANY revenue account
3. This could use the wrong account (e.g., Tuition Revenue instead of Additional Fees Revenue)

## Recommendations

1. **Fix Fee Assignment Journal Entries**
   - Add journal entry creation when assigning fees
   - DEBIT Accounts Receivable
   - CREDIT Additional Fees Revenue account

2. **Create Dedicated Additional Fees Revenue Account**
   - Add account code (e.g., 4100) for "Additional Fees Revenue"
   - Update `createJournalEntries` to use this account

3. **Fix Payment Method Mapping**
   - Currently: 'Bank' or 'Mobile Money' → 1010
   - Should check for 'Bank Transfer' (not 'Bank')
   - Should handle all payment methods properly

