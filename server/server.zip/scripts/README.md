# Class Term Year Records Fix Script

This script fixes the class term year records to ensure each class has exactly one record indicating the current term and academic year.

## What This Script Does

1. **Updates Database Constraint**: Changes the unique constraint to allow only one record per class
2. **Cleans Up Duplicates**: Removes duplicate records, keeping only the most recent one per class
3. **Verifies Results**: Shows which classes need term/year assignment

## How to Run

### Option 1: Using npm script (Recommended)
```bash
cd server
npm run fix-class-term-year
```

### Option 2: Using batch file (Windows)
```bash
# Double-click the file or run from command prompt
server/scripts/fix_class_term_year.bat
```

### Option 3: Direct node execution
```bash
cd server
node scripts/fix_class_term_year_records.js
```

## Environment Variables

Make sure your database connection is configured. The script uses these environment variables:

- `DB_HOST` (default: localhost)
- `DB_USER` (default: root)
- `DB_PASSWORD` (default: empty)
- `DB_NAME` (default: sms_db)
- `DB_PORT` (default: 3306)

## What Happens During Execution

1. **Connects to Database**: Uses your existing database configuration
2. **Checks Current State**: Shows how many records exist and which classes have duplicates
3. **Updates Constraint**: Removes old constraint, adds new one for one record per class
4. **Cleans Duplicates**: For each class with multiple records, keeps the most recent one
5. **Verifies Results**: Shows final state and any classes that need term/year assignment

## Expected Output

```
🔧 Starting Class Term Year Records Fix...

📡 Connecting to database...
✅ Connected to database successfully

📊 Checking current state...
📈 Total class term year records: 15
⚠️  Classes with duplicate records: 3
🔍 Duplicate classes found:
   - Class ID 1: 3 records
   - Class ID 2: 2 records
   - Class ID 3: 2 records

🔧 Step 1: Updating database constraint...
✅ Dropped old unique constraint
✅ Added new unique constraint (one record per class)

🧹 Step 2: Cleaning up duplicate records...
🗑️  Removing duplicate records...
   📝 Class 1: Found 3 records
      🎯 Keeping record 15 (Term 1 2025)
      🗑️  Deleting records: 12, 8
   📝 Class 2: Found 2 records
      🎯 Keeping record 14 (Term 1 2025)
      🗑️  Deleting records: 10
   📝 Class 3: Found 2 records
      🎯 Keeping record 13 (Term 1 2025)
      🗑️  Deleting records: 9
✅ Duplicate records cleaned up

🔍 Step 3: Verifying final state...
📊 Final Results:
   📈 Total class term year records: 8
   ✅ Classes with duplicate records: 0
   ⚠️  Classes without term/year records: 2

📋 Classes that need term/year assignment:
   - Form 4 A (Science)
   - Grade 1 B (Primary)

💡 Use the bulk populate feature in the frontend to assign term/year to these classes

✅ Success: All classes now have exactly one record each!

🎉 Class Term Year Records Fix completed successfully!
```

## After Running the Script

1. **Check the Results**: The script will show which classes need term/year assignment
2. **Use Bulk Populate**: Go to the Class Term Year management page in the frontend
3. **Assign Current Term/Year**: Use bulk populate to assign all classes to the current term and academic year
4. **Test Enrollment**: Try enrolling a student - it should now work without "undefined" errors

## Troubleshooting

### Database Connection Issues
- Make sure your database is running
- Check your environment variables
- Verify database credentials

### Permission Issues
- Make sure the database user has ALTER TABLE permissions
- Check that the user can DELETE records

### Script Fails
- Check the error message for specific issues
- Make sure you're running from the correct directory
- Verify all dependencies are installed (`npm install`)

## Safety Notes

- **Backup First**: Always backup your database before running this script
- **Test Environment**: Run on a test database first if possible
- **Read Output**: The script shows exactly what it's doing - read the output carefully

## Support

If you encounter issues:
1. Check the error messages in the console
2. Verify your database connection settings
3. Make sure you have the necessary database permissions
4. Check that the class_term_year table exists and has data