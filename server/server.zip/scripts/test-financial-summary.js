const { pool } = require('../config/database');

async function testFinancialSummary() {
    try {
        console.log('=== TESTING FINANCIAL SUMMARY CALCULATION ===\n');
        
        // Get a student with a balance
        const [students] = await pool.execute(
            `SELECT sb.student_reg_number, s.Name, s.Surname, sb.current_balance
             FROM student_balances sb
             JOIN students s ON sb.student_reg_number = s.RegNumber
             WHERE sb.current_balance != 0
             LIMIT 1`
        );
        
        if (students.length === 0) {
            console.log('No students with non-zero balance found');
            return;
        }
        
        const studentReg = students[0].student_reg_number;
        const studentName = `${students[0].Name} ${students[0].Surname}`;
        const currentBalance = students[0].current_balance;
        
        console.log(`Testing with student: ${studentName} (${studentReg})`);
        console.log(`Current balance from student_balances: ${currentBalance}\n`);
        
        // Get fee payments (CREDIT)
        const [feePaymentsSummary] = await pool.execute(
            `SELECT 
                COUNT(*) as total_payments,
                COALESCE(SUM(base_currency_amount), 0) as total_paid_amount,
                COUNT(CASE WHEN LOWER(status) = 'completed' THEN 1 END) as completed_payments,
                COUNT(CASE WHEN LOWER(status) = 'pending' THEN 1 END) as pending_payments
             FROM fee_payments 
             WHERE student_reg_number = ?`,
            [studentReg]
        );
        
        console.log('Fee payments summary:', feePaymentsSummary[0]);
        
        // Get boarding payments (CREDIT)
        const [boardingPaymentsSummary] = await pool.execute(
            `SELECT 
                COUNT(*) as total_payments,
                COALESCE(SUM(base_currency_amount), 0) as total_paid_amount,
                COUNT(CASE WHEN LOWER(status) = 'completed' THEN 1 END) as completed_payments,
                COUNT(CASE WHEN LOWER(status) = 'pending' THEN 1 END) as pending_payments
             FROM boarding_fees_payments 
             WHERE student_reg_number = ?`,
            [studentReg]
        );
        
        console.log('Boarding payments summary:', boardingPaymentsSummary[0]);
        
        // Get student transactions for DEBIT amounts
        const [debitTransactions] = await pool.execute(
            `SELECT 
                COUNT(*) as total_debits,
                COALESCE(SUM(amount), 0) as total_debit_amount
             FROM student_transactions 
             WHERE student_reg_number = ? AND transaction_type = 'DEBIT'`,
            [studentReg]
        );
        
        console.log('DEBIT transactions summary:', debitTransactions[0]);
        
        // Calculate totals
        const totalDebit = parseFloat(debitTransactions[0].total_debit_amount || 0);
        const totalCredit = parseFloat(feePaymentsSummary[0].total_paid_amount || 0) + 
                           parseFloat(boardingPaymentsSummary[0].total_paid_amount || 0);
        
        console.log('\n=== CALCULATIONS ===');
        console.log(`Total DEBIT (from transactions): ${totalDebit}`);
        console.log(`Total CREDIT (from payments): ${totalCredit}`);
        console.log(`Calculated balance (DEBIT - CREDIT): ${totalDebit - totalCredit}`);
        console.log(`Actual balance (from student_balances): ${currentBalance}`);
        
        // Check if they match
        const calculatedBalance = totalDebit - totalCredit;
        const difference = Math.abs(calculatedBalance - currentBalance);
        
        if (difference < 0.01) {
            console.log('\n✅ Balances match!');
        } else {
            console.log('\n❌ Balances do not match!');
            console.log(`Difference: ${difference}`);
            
            // Show all transactions for debugging
            console.log('\n=== ALL TRANSACTIONS ===');
            const [allTransactions] = await pool.execute(
                'SELECT id, transaction_type, amount, description, transaction_date FROM student_transactions WHERE student_reg_number = ? ORDER BY transaction_date DESC',
                [studentReg]
            );
            
            allTransactions.forEach(t => {
                console.log(`  ${t.id}: ${t.transaction_type} ${t.amount} - ${t.description} (${t.transaction_date})`);
            });
        }
        
    } catch (error) {
        console.error('Error in test:', error);
    } finally {
        await pool.end();
    }
}

testFinancialSummary().catch(console.error);
