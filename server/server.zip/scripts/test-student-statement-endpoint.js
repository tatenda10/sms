const { pool } = require('../config/database');

async function testStudentStatementEndpoint() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing student statement endpoint logic...');
    
    const studentRegNumber = 'R22121C'; // The student we know has transport payments
    
    console.log(`\n📋 Testing for student: ${studentRegNumber}`);
    
    // Simulate the exact query from getStudentStatement
    const [transactions] = await connection.execute(
      `SELECT st.*, 
              gc.name as class_name,
              h.name as hostel_name
       FROM student_transactions st
       LEFT JOIN gradelevel_classes gc ON st.class_id = gc.id
       LEFT JOIN hostels h ON st.hostel_id = h.id
       WHERE student_reg_number = ?
       ORDER BY st.transaction_date DESC, st.id DESC
       LIMIT 50`,
      [studentRegNumber]
    );
    
    console.log(`\n✅ Found ${transactions.length} transactions:`);
    
    transactions.forEach((transaction, index) => {
      console.log(`\n${index + 1}. Transaction ID: ${transaction.id}`);
      console.log(`   Type: ${transaction.transaction_type}`);
      console.log(`   Amount: $${transaction.amount}`);
      console.log(`   Description: ${transaction.description}`);
      console.log(`   Date: ${transaction.transaction_date}`);
      console.log(`   Created: ${transaction.created_at}`);
      
      // Check if this is a transport payment
      if (transaction.description && transaction.description.includes('Transport Payment')) {
        console.log(`   🚌 TRANSPORT PAYMENT DETECTED!`);
      }
    });
    
    // Check specifically for transport payments
    const transportPayments = transactions.filter(t => 
      t.description && t.description.includes('Transport Payment')
    );
    
    console.log(`\n🚌 Transport payments found: ${transportPayments.length}`);
    transportPayments.forEach((payment, index) => {
      console.log(`   ${index + 1}. ${payment.transaction_type}: $${payment.amount} - ${payment.description}`);
    });
    
    // Check if there are any transactions that might be filtered out
    console.log(`\n🔍 Checking for any filtering issues...`);
    
    // Get all transactions without any joins
    const [allTransactions] = await connection.execute(
      `SELECT * FROM student_transactions 
       WHERE student_reg_number = ?
       ORDER BY transaction_date DESC, id DESC`,
      [studentRegNumber]
    );
    
    console.log(`   Total transactions in database: ${allTransactions.length}`);
    console.log(`   Transactions returned by statement query: ${transactions.length}`);
    
    if (allTransactions.length !== transactions.length) {
      console.log(`   ⚠️  DISCREPANCY FOUND! Some transactions are being filtered out.`);
      
      // Find missing transactions
      const returnedIds = new Set(transactions.map(t => t.id));
      const missingTransactions = allTransactions.filter(t => !returnedIds.has(t.id));
      
      console.log(`   Missing transactions:`);
      missingTransactions.forEach(t => {
        console.log(`     - ID: ${t.id}, Type: ${t.transaction_type}, Amount: $${t.amount}, Description: ${t.description}`);
      });
    } else {
      console.log(`   ✅ All transactions are being returned correctly.`);
    }
    
  } catch (error) {
    console.error('\n❌ Error testing student statement endpoint:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testStudentStatementEndpoint()
    .then(() => {
      console.log('\n✅ Student statement endpoint test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Student statement endpoint test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testStudentStatementEndpoint;
