const { pool } = require('../config/database');
const fs = require('fs');
const path = require('path');

class TimestampColumnAdder {
    constructor() {
        this.config = {
            exportPath: './timestamp-reports',
            backupBeforeChanges: true
        };
    }

    // Add timestamp columns to all tables that need them
    async addTimestampColumns() {
        try {
            console.log('🔧 Adding timestamp columns to tables...');
            
            // Create export directory
            if (!fs.existsSync(this.config.exportPath)) {
                fs.mkdirSync(this.config.exportPath, { recursive: true });
            }
            
            // Get tables that need timestamp columns
            const tablesNeedingTimestamps = await this.getTablesNeedingTimestamps();
            console.log(`📊 Found ${tablesNeedingTimestamps.length} tables that need timestamp columns`);
            
            if (tablesNeedingTimestamps.length === 0) {
                console.log('✅ All tables already have timestamp columns!');
                return;
            }
            
            const results = {
                timestamp: new Date().toISOString(),
                tables_processed: 0,
                tables_updated: 0,
                errors: [],
                changes: []
            };
            
            // Process each table
            for (const table of tablesNeedingTimestamps) {
                console.log(`🔧 Processing table: ${table.name}`);
                
                try {
                    const changes = await this.addTimestampsToTable(table);
                    results.tables_processed++;
                    results.tables_updated++;
                    results.changes.push(...changes);
                    
                    console.log(`✅ Table ${table.name}: Added ${changes.length} timestamp columns`);
                    
                } catch (error) {
                    console.error(`❌ Error processing table ${table.name}:`, error.message);
                    results.errors.push({
                        table: table.name,
                        error: error.message
                    });
                }
            }
            
            // Save results
            const resultsFile = path.join(this.config.exportPath, `timestamp_addition_results_${new Date().toISOString().split('T')[0]}.json`);
            fs.writeFileSync(resultsFile, JSON.stringify(results, null, 2));
            
            // Display summary
            this.displaySummary(results);
            
            return results;
            
        } catch (error) {
            console.error('❌ Failed to add timestamp columns:', error.message);
            throw error;
        }
    }

    // Get tables that need timestamp columns
    async getTablesNeedingTimestamps() {
        const [tables] = await pool.execute(`
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        `);
        
        const tablesNeedingTimestamps = [];
        
        for (const table of tables) {
            const tableName = table.TABLE_NAME;
            
            // Get existing columns
            const [columns] = await pool.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = ?
            `, [tableName]);
            
            const existingColumns = columns.map(col => col.COLUMN_NAME);
            
            // Check what's missing
            const missingColumns = [];
            if (!existingColumns.includes('created_at')) {
                missingColumns.push('created_at');
            }
            if (!existingColumns.includes('updated_at')) {
                missingColumns.push('updated_at');
            }
            
            if (missingColumns.length > 0) {
                tablesNeedingTimestamps.push({
                    name: tableName,
                    missing_columns: missingColumns
                });
            }
        }
        
        return tablesNeedingTimestamps;
    }

    // Add timestamp columns to a specific table
    async addTimestampsToTable(table) {
        const changes = [];
        
        for (const column of table.missing_columns) {
            try {
                let sql;
                if (column === 'created_at') {
                    sql = `ALTER TABLE \`${table.name}\` ADD COLUMN \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`;
                } else if (column === 'updated_at') {
                    sql = `ALTER TABLE \`${table.name}\` ADD COLUMN \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`;
                }
                
                await pool.execute(sql);
                
                changes.push({
                    table: table.name,
                    column: column,
                    action: 'added',
                    sql: sql
                });
                
                console.log(`  ✅ Added ${column} column to ${table.name}`);
                
            } catch (error) {
                console.error(`  ❌ Failed to add ${column} to ${table.name}:`, error.message);
                throw error;
            }
        }
        
        return changes;
    }

    // Add timestamp columns to specific table
    async addTimestampsToSpecificTable(tableName) {
        try {
            console.log(`🔧 Adding timestamp columns to table: ${tableName}`);
            
            // Check if table exists
            const [tables] = await pool.execute(`
                SELECT TABLE_NAME 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = ?
            `, [tableName]);
            
            if (tables.length === 0) {
                throw new Error(`Table ${tableName} does not exist`);
            }
            
            // Get existing columns
            const [columns] = await pool.execute(`
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = ?
            `, [tableName]);
            
            const existingColumns = columns.map(col => col.COLUMN_NAME);
            
            const changes = [];
            
            // Add created_at if missing
            if (!existingColumns.includes('created_at')) {
                const sql = `ALTER TABLE \`${tableName}\` ADD COLUMN \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`;
                await pool.execute(sql);
                changes.push({
                    table: tableName,
                    column: 'created_at',
                    action: 'added',
                    sql: sql
                });
                console.log(`  ✅ Added created_at column`);
            } else {
                console.log(`  ℹ️  created_at column already exists`);
            }
            
            // Add updated_at if missing
            if (!existingColumns.includes('updated_at')) {
                const sql = `ALTER TABLE \`${tableName}\` ADD COLUMN \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`;
                await pool.execute(sql);
                changes.push({
                    table: tableName,
                    column: 'updated_at',
                    action: 'added',
                    sql: sql
                });
                console.log(`  ✅ Added updated_at column`);
            } else {
                console.log(`  ℹ️  updated_at column already exists`);
            }
            
            if (changes.length === 0) {
                console.log(`✅ Table ${tableName} already has all required timestamp columns`);
            } else {
                console.log(`✅ Successfully added ${changes.length} timestamp columns to ${tableName}`);
            }
            
            return changes;
            
        } catch (error) {
            console.error(`❌ Error adding timestamp columns to ${tableName}:`, error.message);
            throw error;
        }
    }

    // Display summary
    displaySummary(results) {
        console.log('\n📊 TIMESTAMP COLUMNS ADDITION SUMMARY');
        console.log('='.repeat(50));
        console.log(`Tables Processed: ${results.tables_processed}`);
        console.log(`Tables Updated: ${results.tables_updated}`);
        console.log(`Total Changes: ${results.changes.length}`);
        console.log(`Errors: ${results.errors.length}`);
        
        if (results.changes.length > 0) {
            console.log('\n✅ CHANGES MADE:');
            console.log('-'.repeat(40));
            results.changes.forEach(change => {
                console.log(`✅ ${change.table}: Added ${change.column} column`);
            });
        }
        
        if (results.errors.length > 0) {
            console.log('\n❌ ERRORS:');
            console.log('-'.repeat(40));
            results.errors.forEach(error => {
                console.log(`❌ ${error.table}: ${error.error}`);
            });
        }
        
        console.log('\n✅ Timestamp columns addition complete!');
    }

    // Verify timestamp columns
    async verifyTimestampColumns() {
        try {
            console.log('🔍 Verifying timestamp columns...');
            
            const [tables] = await pool.execute(`
                SELECT TABLE_NAME 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_TYPE = 'BASE TABLE'
                ORDER BY TABLE_NAME
            `);
            
            const verification = {
                timestamp: new Date().toISOString(),
                total_tables: tables.length,
                tables_with_created_at: 0,
                tables_with_updated_at: 0,
                tables_with_both: 0,
                table_details: {}
            };
            
            for (const table of tables) {
                const tableName = table.TABLE_NAME;
                
                const [columns] = await pool.execute(`
                    SELECT COLUMN_NAME, DATA_TYPE, COLUMN_DEFAULT, EXTRA
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_SCHEMA = DATABASE() 
                    AND TABLE_NAME = ?
                    AND COLUMN_NAME IN ('created_at', 'updated_at')
                `, [tableName]);
                
                const hasCreatedAt = columns.some(col => col.COLUMN_NAME === 'created_at');
                const hasUpdatedAt = columns.some(col => col.COLUMN_NAME === 'updated_at');
                
                verification.table_details[tableName] = {
                    has_created_at: hasCreatedAt,
                    has_updated_at: hasUpdatedAt,
                    has_both: hasCreatedAt && hasUpdatedAt,
                    columns: columns
                };
                
                if (hasCreatedAt) verification.tables_with_created_at++;
                if (hasUpdatedAt) verification.tables_with_updated_at++;
                if (hasCreatedAt && hasUpdatedAt) verification.tables_with_both++;
            }
            
            console.log('\n📊 VERIFICATION RESULTS:');
            console.log('='.repeat(50));
            console.log(`Total Tables: ${verification.total_tables}`);
            console.log(`Tables with created_at: ${verification.tables_with_created_at}`);
            console.log(`Tables with updated_at: ${verification.tables_with_updated_at}`);
            console.log(`Tables with both: ${verification.tables_with_both}`);
            
            return verification;
            
        } catch (error) {
            console.error('❌ Verification failed:', error.message);
            throw error;
        }
    }
}

// CLI usage
if (require.main === module) {
    const adder = new TimestampColumnAdder();
    
    const command = process.argv[2] || 'add';
    const tableName = process.argv[3];
    
    switch (command) {
        case 'add':
            if (tableName) {
                adder.addTimestampsToSpecificTable(tableName).catch(console.error);
            } else {
                adder.addTimestampColumns().catch(console.error);
            }
            break;
            
        case 'verify':
            adder.verifyTimestampColumns().catch(console.error);
            break;
            
        default:
            console.log('Usage: node add-timestamp-columns.js [add|verify] [table_name]');
            console.log('  add [table_name] - Add timestamp columns (all tables or specific table)');
            console.log('  verify           - Verify timestamp columns in all tables');
            break;
    }
}

module.exports = TimestampColumnAdder;
