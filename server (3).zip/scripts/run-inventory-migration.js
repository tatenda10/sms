const mysql = require('mysql2/promise');
require('dotenv').config();

const runInventoryMigration = async () => {
  let connection;
  
  try {
    console.log('🔄 Starting inventory module migration...');
    
    // Create database connection
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'sms',
      multipleStatements: true
    });
    
    console.log('✅ Database connected successfully');
    
    // Read and execute the migration SQL
    const fs = require('fs');
    const path = require('path');
    
    const migrationPath = path.join(__dirname, '../migrations/inventory_tables.sql');
    const migrationSQL = fs.readFileSync(migrationPath, 'utf8');
    
    console.log('📖 Executing inventory migration SQL...');
    
    // Execute the migration
    await connection.execute(migrationSQL);
    
    console.log('✅ Inventory migration completed successfully!');
    console.log('\n📊 Created tables:');
    console.log('   - inventory_categories');
    console.log('   - inventory_items');
    console.log('   - uniform_issues');
    console.log('   - uniform_payments');
    console.log('\n🎯 Sample data inserted:');
    console.log('   - 9 default categories');
    console.log('   - 20 sample inventory items');
    
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log('🔌 Database connection closed');
    }
  }
};

// Run the migration
runInventoryMigration()
  .then(() => {
    console.log('🎉 Inventory module setup complete!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Fatal error:', error);
    process.exit(1);
  });
