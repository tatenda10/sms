# School Management System - Testing Scripts

This directory contains comprehensive testing scripts for the School Management System.

## Quick Start

### Run Quick Test (Recommended for daily use)
```bash
node scripts/quick-test.js
```
This runs a fast check of all core systems and is perfect for daily verification.

### Run Complete Test Suite
```bash
node scripts/run-all-tests.js
```
This runs all tests including comprehensive system tests and generates an HTML report.

### Run Individual Tests
```bash
# Test specific functionality
node scripts/comprehensive-system-test.js
node scripts/test-income-statement-all-accounts.js
node scripts/test-transport-payments.js
node scripts/test-student-financial-record-fix.js
```

## Test Scripts Overview

### Core Testing Scripts

#### `quick-test.js`
- **Purpose**: Fast system health check
- **Duration**: ~5 seconds
- **Use Case**: Daily verification, pre-deployment checks
- **Tests**: Database connection, core tables, basic queries

#### `comprehensive-system-test.js`
- **Purpose**: Complete system validation
- **Duration**: ~30 seconds
- **Use Case**: Full system testing, troubleshooting
- **Tests**: All modules, integrations, data integrity

#### `run-all-tests.js`
- **Purpose**: Complete test suite with reporting
- **Duration**: ~60 seconds
- **Use Case**: Release testing, comprehensive validation
- **Output**: Console report + HTML report

### Module-Specific Tests

#### `test-income-statement-all-accounts.js`
- **Purpose**: Verify income statement shows all accounts
- **Tests**: Revenue and expense queries with zero values
- **Expected**: All 12 revenue + 17 expense accounts visible

#### `test-transport-payments.js`
- **Purpose**: Test transport payment functionality
- **Tests**: Payment creation, student transactions, accounting integration
- **Expected**: Payments create proper journal entries

#### `test-student-financial-record-fix.js`
- **Purpose**: Verify student transactions include all types
- **Tests**: DEBIT and CREDIT transactions visibility
- **Expected**: Transport payments visible in student records

#### `test-monthly-income-statement-api.js`
- **Purpose**: Test monthly income statement API
- **Tests**: September 2025 income statement generation
- **Expected**: All accounts returned with proper totals

### Database Testing Scripts

#### `check-chart-of-accounts.js`
- **Purpose**: Verify chart of accounts structure
- **Tests**: Revenue and expense account counts
- **Expected**: 12+ revenue accounts, 10+ expense accounts

#### `check-transport-payments-structure.js`
- **Purpose**: Verify transport payments table structure
- **Tests**: Column existence, nullability
- **Expected**: route_id column exists, transport_fee_id is nullable

#### `test-student-statement-endpoint.js`
- **Purpose**: Test student statement API endpoint
- **Tests**: Student transaction retrieval
- **Expected**: All transaction types returned

## Test Results Interpretation

### Success Indicators
- ✅ All tests pass
- 📊 High success rate (>95%)
- 🎯 System status: "ALL SYSTEMS OPERATIONAL"

### Warning Signs
- ⚠️ Some tests fail
- 📉 Success rate <95%
- 🎯 System status: "ISSUES DETECTED"

### Common Issues and Solutions

#### Issue: "No expense accounts returned"
**Cause**: Server not restarted after controller changes
**Solution**: Restart the server and re-run tests

#### Issue: "Transport payments not creating student transactions"
**Cause**: createTransactionHelper not static
**Solution**: Check controller method is static

#### Issue: "Database connection failed"
**Cause**: Database server not running
**Solution**: Start MySQL server

#### Issue: "Required table missing"
**Cause**: Database migration not run
**Solution**: Run database setup scripts

## Test Data Requirements

### Minimum Test Data
- **Students**: 5+ students with registration numbers
- **Transport Routes**: 3+ active routes
- **Chart of Accounts**: 12+ revenue, 10+ expense accounts
- **Journal Entries**: Sample transactions for testing
- **Accounting Periods**: At least 1 period (September 2025)

### Sample Data Setup
```sql
-- Ensure you have test students
INSERT INTO students (RegNumber, FirstName, LastName, ClassID) VALUES 
('R22121C', 'Test', 'Student', 1);

-- Ensure you have transport routes
INSERT INTO transport_routes (route_name, pickup_point, dropoff_point, weekly_fee, is_active) VALUES 
('Test Route', 'Test Pickup', 'Test Dropoff', 50.00, 1);

-- Ensure you have chart of accounts
INSERT INTO chart_of_accounts (code, name, type, is_active) VALUES 
('4000', 'Tuition Revenue', 'Revenue', 1),
('5000', 'Salaries', 'Expense', 1);
```

## Continuous Integration

### Pre-commit Testing
```bash
# Run quick test before committing
node scripts/quick-test.js
```

### Pre-deployment Testing
```bash
# Run complete test suite before deployment
node scripts/run-all-tests.js
```

### Automated Testing
```bash
# Add to CI/CD pipeline
npm test  # If package.json has test script
node scripts/run-all-tests.js
```

## Troubleshooting

### Test Scripts Not Running
1. Check Node.js version: `node --version`
2. Install dependencies: `npm install`
3. Check file permissions: `chmod +x scripts/*.js`

### Database Connection Issues
1. Verify MySQL is running
2. Check connection string in `.env`
3. Test connection: `mysql -u username -p database_name`

### Permission Issues
1. Check database user permissions
2. Verify table access rights
3. Test with database admin user

## Best Practices

### Testing Frequency
- **Daily**: Run `quick-test.js`
- **Weekly**: Run `comprehensive-system-test.js`
- **Pre-release**: Run `run-all-tests.js`

### Test Maintenance
- Update tests when adding new features
- Review test results regularly
- Keep test data current

### Documentation
- Document new test cases
- Update this README when adding tests
- Maintain test result history

## Support

For issues with testing scripts:
1. Check this README first
2. Review test output for specific errors
3. Check system logs for additional context
4. Contact development team with test results

## Test Report Locations

- **Console Output**: Real-time test results
- **HTML Reports**: `server/test-reports/test-report-[timestamp].html`
- **Log Files**: Check server logs for detailed error information
