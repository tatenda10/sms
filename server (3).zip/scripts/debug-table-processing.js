const axios = require('axios');

async function debugTableProcessing() {
  try {
    console.log('🔍 Testing sync with a few specific tables to debug processing...');
    
    // Test with tables that have data
    const testData = {
      database_export: {
        students: {
          schema: 'CREATE TABLE `students` (`RegNumber` varchar(10) NOT NULL, `Name` varchar(200) NOT NULL, `Surname` varchar(50) NOT NULL, `DateOfBirth` date NOT NULL, `NationalIDNumber` varchar(20) DEFAULT NULL, `Address` varchar(100) DEFAULT NULL, `Gender` varchar(10) DEFAULT NULL, `Active` varchar(255) DEFAULT \'Yes\', `ImagePath` varchar(255) DEFAULT NULL, `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP, `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP, `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`RegNumber`), UNIQUE KEY `NationalIDNumber` (`NationalIDNumber`), KEY `idx_students_name` (`Name`,`Surname`), KEY `idx_students_regnumber` (`RegNumber`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
          structure: [
            { COLUMN_NAME: 'RegNumber', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'Name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'Surname', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { RegNumber: 'ST001', Name: 'John', Surname: 'Doe' },
            { RegNumber: 'ST002', Name: 'Jane', Surname: 'Smith' }
          ],
          record_count: 2
        },
        roles: {
          schema: 'CREATE TABLE `roles` (`id` int NOT NULL AUTO_INCREMENT, `name` varchar(50) NOT NULL, `description` text, `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP, `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `name` (`name`)) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'description', DATA_TYPE: 'text', IS_NULLABLE: 'YES', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Admin', description: 'Administrator' },
            { id: 2, name: 'Teacher', description: 'Teacher' },
            { id: 3, name: 'Student', description: 'Student' }
          ],
          record_count: 3
        },
        chart_of_accounts: {
          schema: 'CREATE TABLE `chart_of_accounts` (`id` int NOT NULL AUTO_INCREMENT, `code` varchar(20) NOT NULL, `name` varchar(255) NOT NULL, `type` enum(\'Asset\',\'Liability\',\'Equity\',\'Revenue\',\'Expense\') NOT NULL, `parent_id` int DEFAULT NULL, `is_active` tinyint(1) DEFAULT \'1\', `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP, `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `code` (`code`), KEY `parent_id` (`parent_id`)) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'code', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'type', DATA_TYPE: 'enum', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, code: '1000', name: 'Cash', type: 'Asset' },
            { id: 2, code: '2000', name: 'Accounts Payable', type: 'Liability' }
          ],
          record_count: 2
        }
      },
      timestamp: new Date().toISOString(),
      source: 'debug_table_processing'
    };
    
    console.log('📤 Sending test data to server...');
    console.log('📊 Test data summary:', {
      tables: Object.keys(testData.database_export).length,
      totalRecords: Object.values(testData.database_export).reduce((sum, table) => sum + (table.record_count || 0), 0)
    });
    
    const syncResponse = await axios.post('https://server.learningladder.site/api/sync-full-db.php', testData, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 60000
    });
    
    console.log('✅ Server response:', JSON.stringify(syncResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

debugTableProcessing();
