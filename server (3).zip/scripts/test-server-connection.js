const axios = require('axios');

async function testServerConnection() {
  try {
    console.log('🔍 Testing server connection...');
    
    // Test the health endpoint first
    const healthResponse = await axios.get('https://server.learningladder.site/health');
    console.log('✅ Health check passed:', healthResponse.data);
    
    // Test a simple sync with minimal data
    const testData = {
      database_export: {
        test_table: {
          schema: 'CREATE TABLE `test_table` (`id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Test Record 1' },
            { id: 2, name: 'Test Record 2' }
          ],
          record_count: 2
        }
      },
      timestamp: new Date().toISOString(),
      source: 'test_connection'
    };
    
    console.log('📤 Sending test data to server...');
    const syncResponse = await axios.post('https://server.learningladder.site/api/sync-full-db.php', testData, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    console.log('✅ Server response:', syncResponse.data);
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testServerConnection();
