const { pool } = require('../config/database');

async function testBoardingDelete() {
    const conn = await pool.getConnection();
    try {
        console.log('Testing boarding enrollment delete functionality...\n');
        
        // Check current boarding enrollments
        const [enrollments] = await conn.execute(
            'SELECT id, student_reg_number, status, hostel_id, term, academic_year FROM boarding_enrollments ORDER BY id DESC LIMIT 5'
        );
        
        console.log('Current boarding enrollments:', enrollments.length);
        if (enrollments.length > 0) {
            console.log('Sample enrollments:');
            enrollments.forEach(enrollment => {
                console.log(`  - ID: ${enrollment.id}, Student: ${enrollment.student_reg_number}, Status: ${enrollment.status}, Term: ${enrollment.term}, Year: ${enrollment.academic_year}`);
            });
        }
        
        // Check boarding fee balances
        const [feeBalances] = await conn.execute(
            'SELECT * FROM boarding_fee_balances LIMIT 5'
        );
        
        console.log('\nBoarding fee balances:', feeBalances.length);
        if (feeBalances.length > 0) {
            console.log('Sample fee balances:');
            feeBalances.forEach(balance => {
                console.log(`  - Enrollment ID: ${balance.enrollment_id}, Total Fee: ${balance.total_fee}, Outstanding: ${balance.outstanding_balance}`);
            });
        }
        
        // Check student transactions related to boarding
        const [boardingTransactions] = await conn.execute(
            `SELECT * FROM student_transactions 
             WHERE description LIKE '%Boarding Enrollment%' 
             ORDER BY transaction_date DESC LIMIT 5`
        );
        
        console.log('\nBoarding-related transactions:', boardingTransactions.length);
        if (boardingTransactions.length > 0) {
            console.log('Sample transactions:');
            boardingTransactions.forEach(transaction => {
                console.log(`  - Student: ${transaction.student_reg_number}, Type: ${transaction.transaction_type}, Amount: ${transaction.amount}, Description: ${transaction.description}`);
            });
        }
        
        // Test the delete logic for a specific enrollment
        if (enrollments.length > 0) {
            const testEnrollment = enrollments[0];
            console.log(`\nTesting delete logic for enrollment ID: ${testEnrollment.id}`);
            
            // Check if enrollment can be deleted
            if (testEnrollment.status === 'checked_in' || testEnrollment.status === 'checked_out') {
                console.log(`✗ Cannot delete enrollment with status '${testEnrollment.status}'`);
            } else {
                console.log(`✓ Enrollment can be deleted (status: ${testEnrollment.status})`);
                
                // Check for associated fee transactions
                const [feeTransactions] = await conn.execute(
                    `SELECT id, amount FROM student_transactions 
                     WHERE student_reg_number = ? AND hostel_id = ? AND transaction_type = 'DEBIT' 
                     AND description LIKE '%Boarding Enrollment%'
                     ORDER BY transaction_date DESC LIMIT 1`,
                    [testEnrollment.student_reg_number, testEnrollment.hostel_id]
                );
                
                if (feeTransactions.length > 0) {
                    console.log(`✓ Found associated fee transaction: ${feeTransactions[0].amount}`);
                } else {
                    console.log('ℹ No associated fee transactions found');
                }
                
                // Check for boarding fee balance
                const [feeBalance] = await conn.execute(
                    'SELECT * FROM boarding_fee_balances WHERE enrollment_id = ?',
                    [testEnrollment.id]
                );
                
                if (feeBalance.length > 0) {
                    console.log(`✓ Found boarding fee balance: ${feeBalance[0].total_fee}`);
                } else {
                    console.log('ℹ No boarding fee balance found');
                }
            }
        }
        
    } catch (error) {
        console.error('Error testing boarding delete:', error);
    } finally {
        conn.release();
    }
}

// Run the test if called directly
if (require.main === module) {
    testBoardingDelete()
        .then(() => {
            console.log('\nTest completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testBoardingDelete };
