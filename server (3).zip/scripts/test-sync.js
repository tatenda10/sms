const { pool } = require('../config/database');

async function testDatabaseConnection() {
    try {
        console.log('🔍 Testing database connection...');
        
        // Test basic connection
        await pool.execute('SELECT 1');
        console.log('✅ Database connection successful');
        
        // Get table count
        const [tables] = await pool.execute(`
            SELECT COUNT(*) as table_count
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
        `);
        
        console.log(`📊 Found ${tables[0].table_count} tables in database`);
        
        // Get some key table counts
        const keyTables = [
            'students', 'student_balances', 'student_transactions',
            'uniform_issues', 'transport_payments', 'journal_entries',
            'chart_of_accounts', 'gradelevel_classes'
        ];
        
        console.log('\n📋 Key table record counts:');
        for (const table of keyTables) {
            try {
                const [count] = await pool.execute(`SELECT COUNT(*) as count FROM \`${table}\``);
                console.log(`  ${table}: ${count[0].count} records`);
            } catch (error) {
                console.log(`  ${table}: Table not found`);
            }
        }
        
        console.log('\n✅ Database is ready for sync!');
        
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        process.exit(1);
    } finally {
        process.exit(0);
    }
}

testDatabaseConnection();
