const { pool } = require('../config/database');

async function checkAccountingTablesStructure() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking accounting tables structure...');
    
    const tablesToCheck = ['transactions', 'journal_entry_lines', 'chart_of_accounts'];
    
    for (const tableName of tablesToCheck) {
      console.log(`\n📋 Checking ${tableName} table structure:`);
      
      try {
        const [columns] = await connection.execute(`DESCRIBE ${tableName}`);
        
        console.log('┌─────────────────────┬─────────────┬──────┬─────┬─────────┬─────┐');
        console.log('│ Field               │ Type        │ Null │ Key │ Default │ Extra│');
        console.log('├─────────────────────┼─────────────┼──────┼─────┼─────────┼─────┤');
        
        columns.forEach(col => {
          const field = col.Field.padEnd(19);
          const type = col.Type.padEnd(11);
          const nullAllowed = col.Null.padEnd(4);
          const key = (col.Key || '').padEnd(3);
          const defaultVal = (col.Default || '').padEnd(7);
          const extra = col.Extra || '';
          
          console.log(`│ ${field} │ ${type} │ ${nullAllowed} │ ${key} │ ${defaultVal} │ ${extra} │`);
        });
        
        console.log('└─────────────────────┴─────────────┴──────┴─────┴─────────┴─────┘');
        
        // Check for indexes
        const [indexes] = await connection.execute(`SHOW INDEX FROM ${tableName}`);
        if (indexes.length > 0) {
          console.log('\n📊 Indexes:');
          indexes.forEach(index => {
            console.log(`   • ${index.Key_name}: ${index.Column_name} (${index.Non_unique ? 'Non-unique' : 'Unique'})`);
          });
        }
        
      } catch (error) {
        console.log(`❌ Table ${tableName} does not exist or error: ${error.message}`);
      }
    }
    
    // Check if we can create journal entry lines
    console.log('\n🔍 Testing journal_entry_lines structure for transport payments...');
    try {
      const [columns] = await connection.execute('DESCRIBE journal_entry_lines');
      const requiredColumns = ['journal_entry_id', 'account_code', 'debit_amount', 'credit_amount', 'description'];
      
      console.log('\n🎯 Required columns for journal_entry_lines:');
      requiredColumns.forEach(reqCol => {
        const found = columns.find(col => col.Field === reqCol);
        if (found) {
          console.log(`   ✅ ${reqCol}: ${found.Type} (${found.Null === 'YES' ? 'NULL allowed' : 'NOT NULL'})`);
        } else {
          console.log(`   ❌ ${reqCol}: Missing`);
        }
      });
      
    } catch (error) {
      console.log(`❌ journal_entry_lines table error: ${error.message}`);
    }
    
  } catch (error) {
    console.error('\n❌ Error checking accounting tables:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkAccountingTablesStructure()
    .then(() => {
      console.log('\n✅ Accounting tables structure check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Accounting tables structure check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkAccountingTablesStructure;
