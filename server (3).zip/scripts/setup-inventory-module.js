const mysql = require('mysql2/promise');
require('dotenv').config();

const setupInventoryModule = async () => {
  let connection;
  
  try {
    console.log('🚀 Setting up Inventory Module...\n');
    
    // Create database connection
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'sms',
      multipleStatements: true
    });
    
    console.log('✅ Database connected successfully');
    
    // Step 1: Create INVENTORY_MANAGER role
    console.log('\n📋 Step 1: Creating INVENTORY_MANAGER role...');
    
    const roleSQL = `
      INSERT INTO roles (name, description, created_at) 
      VALUES ('INVENTORY_MANAGER', 'Can manage inventory items, categories, and uniform issues', NOW())
      ON DUPLICATE KEY UPDATE 
          description = VALUES(description),
          updated_at = NOW();
    `;
    
    await connection.execute(roleSQL);
    console.log('✅ INVENTORY_MANAGER role created/updated');
    
    // Step 2: Run inventory migration
    console.log('\n📋 Step 2: Running inventory database migration...');
    
    const fs = require('fs');
    const path = require('path');
    
    const migrationPath = path.join(__dirname, '../migrations/inventory_tables.sql');
    const migrationSQL = fs.readFileSync(migrationPath, 'utf8');
    
    await connection.execute(migrationSQL);
    console.log('✅ Inventory tables created successfully');
    
    // Step 3: Verify setup
    console.log('\n📋 Step 3: Verifying setup...');
    
    // Check if tables exist
    const [tables] = await connection.execute(`
      SELECT TABLE_NAME 
      FROM information_schema.TABLES 
      WHERE TABLE_SCHEMA = ? 
      AND TABLE_NAME IN ('inventory_categories', 'inventory_items', 'uniform_issues', 'uniform_payments')
    `, [process.env.DB_NAME || 'sms']);
    
    console.log(`✅ Found ${tables.length} inventory tables`);
    
    // Check if role exists
    const [roles] = await connection.execute(`
      SELECT name, description 
      FROM roles 
      WHERE name = 'INVENTORY_MANAGER'
    `);
    
    if (roles.length > 0) {
      console.log(`✅ Role '${roles[0].name}' exists: ${roles[0].description}`);
    }
    
    // Check sample data
    const [categories] = await connection.execute('SELECT COUNT(*) as count FROM inventory_categories');
    const [items] = await connection.execute('SELECT COUNT(*) as count FROM inventory_items');
    
    console.log(`✅ Sample data: ${categories[0].count} categories, ${items[0].count} items`);
    
    console.log('\n🎉 Inventory Module Setup Complete!');
    console.log('\n📊 What was created:');
    console.log('   • INVENTORY_MANAGER role');
    console.log('   • 4 database tables');
    console.log('   • 9 default categories');
    console.log('   • 20 sample inventory items');
    console.log('\n🔗 API Endpoints available at:');
    console.log('   • /api/inventory/categories');
    console.log('   • /api/inventory/items');
    console.log('   • /api/inventory/issues');
    console.log('   • /api/inventory/summary');
    console.log('\n⚠️  Note: Make sure to assign the INVENTORY_MANAGER role to users who need access');
    
  } catch (error) {
    console.error('\n❌ Setup failed:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log('\n🔌 Database connection closed');
    }
  }
};

// Run the setup
setupInventoryModule()
  .then(() => {
    console.log('\n✨ Setup completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n💥 Fatal error:', error);
    process.exit(1);
  });
