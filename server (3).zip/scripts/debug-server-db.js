const mysql = require('mysql2/promise');
require('dotenv').config();

async function debugServerDatabase() {
  console.log('🔍 Debugging Server Database Configuration...\n');
  
  // Show environment variables
  console.log('📋 Environment Variables:');
  console.log('  DB_HOST:', process.env.DB_HOST || 'NOT SET');
  console.log('  DB_USER:', process.env.DB_USER || 'NOT SET');
  console.log('  DB_PASSWORD:', process.env.DB_PASSWORD ? '***hidden***' : 'NOT SET');
  console.log('  DB_NAME:', process.env.DB_NAME || 'NOT SET');
  
  // Show final configuration
  const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'learpvop',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'learpvop_learningladder',
    charset: 'utf8mb4'
  };
  
  console.log('\n🔧 Final Database Configuration:');
  console.log('  Host:', dbConfig.host);
  console.log('  User:', dbConfig.user);
  console.log('  Database:', dbConfig.database);
  console.log('  Password:', dbConfig.password ? '***hidden***' : 'empty');
  
  // Try to connect
  try {
    console.log('\n🔗 Attempting to connect...');
    const connection = await mysql.createConnection(dbConfig);
    console.log('✅ Connected successfully!');
    
    // Test query
    const [rows] = await connection.execute('SELECT DATABASE() as current_db');
    console.log('📊 Current database:', rows[0].current_db);
    
    // List tables
    const [tables] = await connection.execute('SHOW TABLES');
    console.log(`📋 Found ${tables.length} tables:`);
    tables.forEach((table, index) => {
      console.log(`  ${index + 1}. ${Object.values(table)[0]}`);
    });
    
    await connection.end();
    console.log('\n🎉 Database connection test completed successfully!');
    
  } catch (error) {
    console.error('\n❌ Database connection failed:');
    console.error('  Error:', error.message);
    console.error('  Code:', error.code);
    console.error('  Errno:', error.errno);
    console.error('  SQL State:', error.sqlState);
  }
}

debugServerDatabase();
