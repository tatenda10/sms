const { pool } = require('../config/database');
const axios = require('axios');

class ComprehensiveSystemTest {
  constructor() {
    this.baseUrl = 'http://localhost:5000/api';
    this.testResults = {
      passed: 0,
      failed: 0,
      tests: []
    };
  }

  async runTest(testName, testFunction) {
    try {
      console.log(`\n🧪 Testing: ${testName}`);
      await testFunction();
      this.testResults.passed++;
      this.testResults.tests.push({ name: testName, status: 'PASSED' });
      console.log(`✅ ${testName} - PASSED`);
    } catch (error) {
      this.testResults.failed++;
      this.testResults.tests.push({ name: testName, status: 'FAILED', error: error.message });
      console.log(`❌ ${testName} - FAILED: ${error.message}`);
    }
  }

  // Database Connection Test
  async testDatabaseConnection() {
    const connection = await pool.getConnection();
    const [rows] = await connection.execute('SELECT 1 as test');
    connection.release();
    if (rows[0].test !== 1) throw new Error('Database connection failed');
  }

  // Chart of Accounts Tests
  async testChartOfAccounts() {
    const connection = await pool.getConnection();
    
    // Test revenue accounts
    const [revenueAccounts] = await connection.execute(
      'SELECT COUNT(*) as count FROM chart_of_accounts WHERE type = "Revenue" AND is_active = 1'
    );
    if (revenueAccounts[0].count < 10) throw new Error('Insufficient revenue accounts');
    
    // Test expense accounts
    const [expenseAccounts] = await connection.execute(
      'SELECT COUNT(*) as count FROM chart_of_accounts WHERE type = "Expense" AND is_active = 1'
    );
    if (expenseAccounts[0].count < 10) throw new Error('Insufficient expense accounts');
    
    connection.release();
  }

  // Student Management Tests
  async testStudentManagement() {
    const connection = await pool.getConnection();
    
    // Test students table
    const [students] = await connection.execute('SELECT COUNT(*) as count FROM students');
    if (students[0].count === 0) throw new Error('No students found');
    
    // Test student transactions
    const [transactions] = await connection.execute('SELECT COUNT(*) as count FROM student_transactions');
    if (transactions[0].count === 0) throw new Error('No student transactions found');
    
    connection.release();
  }

  // Transport System Tests
  async testTransportSystem() {
    const connection = await pool.getConnection();
    
    // Test transport routes
    const [routes] = await connection.execute('SELECT COUNT(*) as count FROM transport_routes WHERE is_active = 1');
    if (routes[0].count === 0) throw new Error('No active transport routes found');
    
    // Test transport payments
    const [payments] = await connection.execute('SELECT COUNT(*) as count FROM transport_payments');
    
    // Test transport registrations
    const [registrations] = await connection.execute('SELECT COUNT(*) as count FROM student_transport_registrations');
    
    connection.release();
  }

  // Inventory System Tests
  async testInventorySystem() {
    const connection = await pool.getConnection();
    
    // Test inventory categories
    const [categories] = await connection.execute('SELECT COUNT(*) as count FROM inventory_categories');
    if (categories[0].count === 0) throw new Error('No inventory categories found');
    
    // Test inventory items
    const [items] = await connection.execute('SELECT COUNT(*) as count FROM inventory_items');
    
    // Test uniform issues
    const [issues] = await connection.execute('SELECT COUNT(*) as count FROM uniform_issues');
    
    connection.release();
  }

  // Accounting System Tests
  async testAccountingSystem() {
    const connection = await pool.getConnection();
    
    // Test journal entries
    const [journalEntries] = await connection.execute('SELECT COUNT(*) as count FROM journal_entries');
    if (journalEntries[0].count === 0) throw new Error('No journal entries found');
    
    // Test journal entry lines
    const [journalLines] = await connection.execute('SELECT COUNT(*) as count FROM journal_entry_lines');
    if (journalLines[0].count === 0) throw new Error('No journal entry lines found');
    
    // Test accounting periods
    const [periods] = await connection.execute('SELECT COUNT(*) as count FROM accounting_periods');
    
    connection.release();
  }

  // Income Statement Tests
  async testIncomeStatement() {
    const connection = await pool.getConnection();
    
    // Test revenue query
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN '2025-01-01' AND '2025-12-31'
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [revenue] = await connection.execute(revenueQuery);
    if (revenue.length === 0) throw new Error('No revenue accounts returned');
    
    // Test expense query
    const expenseQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.debit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN '2025-01-01' AND '2025-12-31'
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Expense' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [expenses] = await connection.execute(expenseQuery);
    if (expenses.length === 0) throw new Error('No expense accounts returned');
    
    connection.release();
  }

  // Student Financial Record Tests
  async testStudentFinancialRecord() {
    const connection = await pool.getConnection();
    
    // Test student transactions with both DEBIT and CREDIT
    const [debitTransactions] = await connection.execute(
      'SELECT COUNT(*) as count FROM student_transactions WHERE transaction_type = "DEBIT"'
    );
    
    const [creditTransactions] = await connection.execute(
      'SELECT COUNT(*) as count FROM student_transactions WHERE transaction_type = "CREDIT"'
    );
    
    if (debitTransactions[0].count === 0) throw new Error('No DEBIT transactions found');
    if (creditTransactions[0].count === 0) throw new Error('No CREDIT transactions found');
    
    connection.release();
  }

  // Transport Payment Integration Tests
  async testTransportPaymentIntegration() {
    const connection = await pool.getConnection();
    
    // Test that transport payments create student transactions
    const [transportPayments] = await connection.execute(
      'SELECT COUNT(*) as count FROM transport_payments'
    );
    
    const [transportStudentTransactions] = await connection.execute(
      'SELECT COUNT(*) as count FROM student_transactions WHERE description LIKE "%Transport Payment%"'
    );
    
    if (transportPayments[0].count > 0 && transportStudentTransactions[0].count === 0) {
      throw new Error('Transport payments not creating student transactions');
    }
    
    connection.release();
  }

  // Database Schema Tests
  async testDatabaseSchema() {
    const connection = await pool.getConnection();
    
    // Test required tables exist
    const requiredTables = [
      'students', 'student_transactions', 'student_balances',
      'transport_routes', 'transport_payments', 'student_transport_registrations',
      'inventory_categories', 'inventory_items', 'uniform_issues', 'uniform_payments',
      'chart_of_accounts', 'journal_entries', 'journal_entry_lines', 'accounting_periods'
    ];
    
    for (const table of requiredTables) {
      const [result] = await connection.execute(`SHOW TABLES LIKE '${table}'`);
      if (result.length === 0) throw new Error(`Required table '${table}' does not exist`);
    }
    
    // Test transport_payments has route_id column
    const [columns] = await connection.execute(
      "SHOW COLUMNS FROM transport_payments LIKE 'route_id'"
    );
    if (columns.length === 0) throw new Error('transport_payments table missing route_id column');
    
    // Test transport_fee_id is nullable
    const [nullableCheck] = await connection.execute(
      "SELECT IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'transport_payments' AND COLUMN_NAME = 'transport_fee_id'"
    );
    if (nullableCheck.length === 0 || nullableCheck[0].IS_NULLABLE !== 'YES') {
      throw new Error('transport_fee_id column is not nullable');
    }
    
    connection.release();
  }

  // Data Integrity Tests
  async testDataIntegrity() {
    const connection = await pool.getConnection();
    
    // Test that all student transactions have valid student_reg_number
    const [invalidStudentTransactions] = await connection.execute(
      'SELECT COUNT(*) as count FROM student_transactions st LEFT JOIN students s ON st.student_reg_number = s.RegNumber WHERE s.RegNumber IS NULL'
    );
    if (invalidStudentTransactions[0].count > 0) {
      throw new Error('Found student transactions with invalid student_reg_number');
    }
    
    // Test that all journal entry lines have valid account_id
    const [invalidJournalLines] = await connection.execute(
      'SELECT COUNT(*) as count FROM journal_entry_lines jel LEFT JOIN chart_of_accounts coa ON jel.account_id = coa.id WHERE coa.id IS NULL'
    );
    if (invalidJournalLines[0].count > 0) {
      throw new Error('Found journal entry lines with invalid account_id');
    }
    
    connection.release();
  }

  // Run all tests
  async runAllTests() {
    console.log('🚀 Starting Comprehensive System Test...');
    console.log('=' * 60);
    
    // Core System Tests
    await this.runTest('Database Connection', () => this.testDatabaseConnection());
    await this.runTest('Database Schema', () => this.testDatabaseSchema());
    await this.runTest('Data Integrity', () => this.testDataIntegrity());
    
    // Module Tests
    await this.runTest('Chart of Accounts', () => this.testChartOfAccounts());
    await this.runTest('Student Management', () => this.testStudentManagement());
    await this.runTest('Transport System', () => this.testTransportSystem());
    await this.runTest('Inventory System', () => this.testInventorySystem());
    await this.runTest('Accounting System', () => this.testAccountingSystem());
    
    // Feature Tests
    await this.runTest('Income Statement', () => this.testIncomeStatement());
    await this.runTest('Student Financial Record', () => this.testStudentFinancialRecord());
    await this.runTest('Transport Payment Integration', () => this.testTransportPaymentIntegration());
    
    // Print Results
    this.printResults();
  }

  printResults() {
    console.log('\n' + '=' * 60);
    console.log('📊 TEST RESULTS SUMMARY');
    console.log('=' * 60);
    console.log(`✅ Passed: ${this.testResults.passed}`);
    console.log(`❌ Failed: ${this.testResults.failed}`);
    console.log(`📈 Success Rate: ${((this.testResults.passed / (this.testResults.passed + this.testResults.failed)) * 100).toFixed(1)}%`);
    
    if (this.testResults.failed > 0) {
      console.log('\n❌ FAILED TESTS:');
      this.testResults.tests
        .filter(test => test.status === 'FAILED')
        .forEach(test => {
          console.log(`   • ${test.name}: ${test.error}`);
        });
    }
    
    console.log('\n🎯 SYSTEM STATUS:', this.testResults.failed === 0 ? 'ALL SYSTEMS OPERATIONAL' : 'ISSUES DETECTED');
  }
}

// Run the comprehensive test if this script is executed directly
if (require.main === module) {
  const tester = new ComprehensiveSystemTest();
  tester.runAllTests()
    .then(() => {
      console.log('\n✅ Comprehensive system test completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Comprehensive system test failed:', error.message);
      process.exit(1);
    });
}

module.exports = ComprehensiveSystemTest;
