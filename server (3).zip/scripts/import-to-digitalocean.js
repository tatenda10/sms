const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

class DigitalOceanImporter {
    constructor() {
        this.config = {
            exportPath: './database-exports'
        };
        
        // DigitalOcean database configuration
        this.dbConfig = {
            host: process.env.DB_HOST || 'oxfordstudycenter-do-user-16839730-0.l.db.ondigitalocean.com',
            user: process.env.DB_USER || 'doadmin',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME || 'sms',
            port: process.env.DB_PORT || 25060,
            ssl: process.env.SSL_MODE === 'REQUIRED' ? { rejectUnauthorized: false } : false,
            charset: 'utf8mb4'
        };
    }
    
    // Create database connection
    async createConnection() {
        console.log('🔌 Connecting to DigitalOcean database...');
        console.log('Host:', this.dbConfig.host);
        console.log('User:', this.dbConfig.user);
        console.log('Database:', this.dbConfig.database);
        console.log('Port:', this.dbConfig.port);
        
        return await mysql.createConnection(this.dbConfig);
    }

    // Import data from the latest export file
    async importFromExport() {
        let connection;
        try {
            console.log('🚀 Starting import to DigitalOcean database...');
            
            // Create database connection
            connection = await this.createConnection();
            console.log('✅ Connected to DigitalOcean database');
            
            // Find the latest export file
            const exportFile = this.findLatestExportFile();
            if (!exportFile) {
                throw new Error('No export file found. Please run sync-full-database.js first.');
            }
            
            console.log(`📁 Using export file: ${exportFile}`);
            
            // Load the export data
            const exportData = JSON.parse(fs.readFileSync(exportFile, 'utf8'));
            console.log(`📊 Found ${Object.keys(exportData).length - 1} tables to import`);
            
            let processedTables = 0;
            let processedRecords = 0;
            const errors = [];
            
            // Process each table
            for (const [tableName, tableData] of Object.entries(exportData)) {
                if (tableName === '_metadata') {
                    console.log(`⏭️ Skipping metadata table`);
                    continue;
                }
                
                try {
                    console.log(`📦 Processing table: ${tableName}`);
                    
                    // Check if table exists
                    const [tables] = await connection.execute(`SHOW TABLES LIKE ?`, [tableName]);
                    const tableExists = tables.length > 0;
                    
                    if (!tableExists) {
                        console.log(`⚠️ Table ${tableName} does not exist, creating...`);
                        
                        if (tableData.schema) {
                            await connection.execute(tableData.schema);
                            console.log(`✅ Created table ${tableName} from schema`);
                        } else {
                            console.log(`⚠️ No schema available for table ${tableName}, skipping`);
                            continue;
                        }
                    } else {
                        console.log(`✅ Table ${tableName} already exists`);
                    }
                    
                    // Clear existing data
                    console.log(`🗑️ Clearing existing data from ${tableName}...`);
                    await connection.execute(`TRUNCATE TABLE \`${tableName}\``);
                    console.log(`✅ Cleared existing data from ${tableName}`);
                    
                    // Insert new data
                    if (tableData.data && tableData.data.length > 0) {
                        console.log(`📥 Inserting ${tableData.data.length} records into ${tableName}...`);
                        const columns = Object.keys(tableData.data[0]);
                        const placeholders = columns.map(() => '?').join(', ');
                        const sql = `INSERT INTO \`${tableName}\` (\`${columns.join('`, `')}\`) VALUES (${placeholders})`;
                        
                        const stmt = await connection.prepare(sql);
                        
                        for (const row of tableData.data) {
                            await stmt.execute(Object.values(row));
                            processedRecords++;
                        }
                        
                        console.log(`✅ Inserted ${tableData.data.length} records into ${tableName}`);
                    } else {
                        console.log(`⚠️ No data to insert for table ${tableName}`);
                    }
                    
                    processedTables++;
                    console.log(`✅ Successfully processed table ${tableName}. Total: ${processedTables} tables, ${processedRecords} records`);
                    
                } catch (error) {
                    const errorMsg = `Error processing table ${tableName}: ${error.message}`;
                    console.error(`❌ ${errorMsg}`);
                    errors.push(errorMsg);
                }
            }
            
            console.log('\n🎉 Import completed!');
            console.log(`📊 Processed: ${processedTables} tables, ${processedRecords} records`);
            if (errors.length > 0) {
                console.log(`⚠️ Errors: ${errors.length}`);
                errors.forEach(error => console.log(`  - ${error}`));
            }
            
        } catch (error) {
            console.error('❌ Import failed:', error.message);
            throw error;
        } finally {
            if (connection) {
                await connection.end();
                console.log('🔌 Database connection closed');
            }
        }
    }
    
    // Find the latest export file
    findLatestExportFile() {
        const files = fs.readdirSync(this.config.exportPath)
            .filter(file => file.startsWith('full_database_') && file.endsWith('.json'))
            .sort()
            .reverse();
            
        if (files.length === 0) {
            return null;
        }
        
        return path.join(this.config.exportPath, files[0]);
    }
}

// Run the import
async function runImport() {
    const importer = new DigitalOceanImporter();
    await importer.importFromExport();
}

// Check if this script is being run directly
if (require.main === module) {
    runImport().catch(console.error);
}

module.exports = DigitalOceanImporter;
