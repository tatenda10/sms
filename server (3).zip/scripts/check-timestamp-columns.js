const { pool } = require('../config/database');
const fs = require('fs');
const path = require('path');

class TimestampColumnChecker {
    constructor() {
        this.config = {
            exportPath: './timestamp-reports',
            requiredColumns: [
                'created_at',
                'updated_at',
                'modified_at',
                'last_updated'
            ],
            recommendedColumns: [
                'created_at',
                'updated_at'
            ]
        };
    }

    // Main method to check all tables
    async checkAllTables() {
        try {
            console.log('🔍 Checking timestamp columns in all tables...');
            
            // Create export directory
            if (!fs.existsSync(this.config.exportPath)) {
                fs.mkdirSync(this.config.exportPath, { recursive: true });
            }
            
            // Get all tables
            const tables = await this.getAllTables();
            console.log(`📊 Found ${tables.length} tables to check`);
            
            const report = {
                timestamp: new Date().toISOString(),
                total_tables: tables.length,
                tables_with_timestamps: 0,
                tables_missing_timestamps: 0,
                tables_with_recommended: 0,
                table_details: {},
                recommendations: [],
                sql_commands: []
            };
            
            // Check each table
            for (const table of tables) {
                console.log(`🔍 Checking table: ${table}`);
                
                const tableInfo = await this.checkTable(table);
                report.table_details[table] = tableInfo;
                
                if (tableInfo.has_timestamps) {
                    report.tables_with_timestamps++;
                } else {
                    report.tables_missing_timestamps++;
                }
                
                if (tableInfo.has_recommended) {
                    report.tables_with_recommended++;
                }
                
                // Add recommendations
                if (tableInfo.recommendations.length > 0) {
                    report.recommendations.push(...tableInfo.recommendations);
                }
                
                // Add SQL commands
                if (tableInfo.sql_commands.length > 0) {
                    report.sql_commands.push(...tableInfo.sql_commands);
                }
                
                console.log(`✅ Table ${table}: ${tableInfo.timestamp_columns.length} timestamp columns found`);
            }
            
            // Save report
            const reportFile = path.join(this.config.exportPath, `timestamp_check_${new Date().toISOString().split('T')[0]}.json`);
            fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
            
            // Save SQL commands file
            if (report.sql_commands.length > 0) {
                const sqlFile = path.join(this.config.exportPath, `add_timestamp_columns_${new Date().toISOString().split('T')[0]}.sql`);
                fs.writeFileSync(sqlFile, report.sql_commands.join('\n\n'));
                console.log(`💾 SQL commands saved to: ${sqlFile}`);
            }
            
            // Display summary
            this.displaySummary(report);
            
            return report;
            
        } catch (error) {
            console.error('❌ Timestamp check failed:', error.message);
            throw error;
        }
    }

    // Check a single table
    async checkTable(tableName) {
        try {
            // Get table structure
            const [columns] = await pool.execute(`
                SELECT 
                    COLUMN_NAME,
                    DATA_TYPE,
                    IS_NULLABLE,
                    COLUMN_DEFAULT,
                    EXTRA
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = ?
                ORDER BY ORDINAL_POSITION
            `, [tableName]);
            
            // Check for timestamp columns
            const timestampColumns = columns.filter(col => 
                this.config.requiredColumns.includes(col.COLUMN_NAME) ||
                col.DATA_TYPE === 'timestamp' ||
                col.DATA_TYPE === 'datetime'
            );
            
            // Check for recommended columns
            const hasRecommended = this.config.recommendedColumns.every(col => 
                columns.some(c => c.COLUMN_NAME === col)
            );
            
            // Check if has any timestamp columns
            const hasTimestamps = timestampColumns.length > 0;
            
            // Generate recommendations
            const recommendations = this.generateRecommendations(tableName, columns, timestampColumns);
            
            // Generate SQL commands
            const sqlCommands = this.generateSQLCommands(tableName, columns, timestampColumns);
            
            return {
                table_name: tableName,
                total_columns: columns.length,
                timestamp_columns: timestampColumns.map(col => ({
                    name: col.COLUMN_NAME,
                    type: col.DATA_TYPE,
                    nullable: col.IS_NULLABLE,
                    default: col.COLUMN_DEFAULT,
                    extra: col.EXTRA
                })),
                has_timestamps: hasTimestamps,
                has_recommended: hasRecommended,
                recommendations: recommendations,
                sql_commands: sqlCommands,
                all_columns: columns.map(col => col.COLUMN_NAME)
            };
            
        } catch (error) {
            console.error(`❌ Error checking table ${tableName}:`, error.message);
            return {
                table_name: tableName,
                error: error.message,
                timestamp_columns: [],
                has_timestamps: false,
                has_recommended: false,
                recommendations: [],
                sql_commands: []
            };
        }
    }

    // Generate recommendations for a table
    generateRecommendations(tableName, columns, timestampColumns) {
        const recommendations = [];
        const existingColumns = columns.map(col => col.COLUMN_NAME);
        
        // Check for created_at
        if (!existingColumns.includes('created_at')) {
            recommendations.push({
                type: 'missing_column',
                column: 'created_at',
                priority: 'high',
                description: `Table ${tableName} is missing 'created_at' column for tracking when records are created`
            });
        }
        
        // Check for updated_at
        if (!existingColumns.includes('updated_at')) {
            recommendations.push({
                type: 'missing_column',
                column: 'updated_at',
                priority: 'high',
                description: `Table ${tableName} is missing 'updated_at' column for tracking when records are modified`
            });
        }
        
        // Check for proper data types
        timestampColumns.forEach(col => {
            if (col.DATA_TYPE !== 'timestamp' && col.DATA_TYPE !== 'datetime') {
                recommendations.push({
                    type: 'wrong_data_type',
                    column: col.COLUMN_NAME,
                    priority: 'medium',
                    description: `Column ${col.COLUMN_NAME} in table ${tableName} should be TIMESTAMP or DATETIME type`
                });
            }
        });
        
        // Check for proper defaults
        timestampColumns.forEach(col => {
            if (col.COLUMN_NAME === 'created_at' && !col.COLUMN_DEFAULT) {
                recommendations.push({
                    type: 'missing_default',
                    column: col.COLUMN_NAME,
                    priority: 'medium',
                    description: `Column ${col.COLUMN_NAME} in table ${tableName} should have DEFAULT CURRENT_TIMESTAMP`
                });
            }
            
            if (col.COLUMN_NAME === 'updated_at' && !col.EXTRA.includes('on update CURRENT_TIMESTAMP')) {
                recommendations.push({
                    type: 'missing_auto_update',
                    column: col.COLUMN_NAME,
                    priority: 'medium',
                    description: `Column ${col.COLUMN_NAME} in table ${tableName} should have ON UPDATE CURRENT_TIMESTAMP`
                });
            }
        });
        
        return recommendations;
    }

    // Generate SQL commands to add missing columns
    generateSQLCommands(tableName, columns, timestampColumns) {
        const commands = [];
        const existingColumns = columns.map(col => col.COLUMN_NAME);
        
        // Add created_at if missing
        if (!existingColumns.includes('created_at')) {
            commands.push(`-- Add created_at column to ${tableName}
ALTER TABLE \`${tableName}\` 
ADD COLUMN \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;`);
        }
        
        // Add updated_at if missing
        if (!existingColumns.includes('updated_at')) {
            commands.push(`-- Add updated_at column to ${tableName}
ALTER TABLE \`${tableName}\` 
ADD COLUMN \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;`);
        }
        
        // Fix existing timestamp columns
        timestampColumns.forEach(col => {
            if (col.COLUMN_NAME === 'created_at' && col.DATA_TYPE !== 'timestamp') {
                commands.push(`-- Fix created_at column type in ${tableName}
ALTER TABLE \`${tableName}\` 
MODIFY COLUMN \`${col.COLUMN_NAME}\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;`);
            }
            
            if (col.COLUMN_NAME === 'updated_at' && col.DATA_TYPE !== 'timestamp') {
                commands.push(`-- Fix updated_at column type in ${tableName}
ALTER TABLE \`${tableName}\` 
MODIFY COLUMN \`${col.COLUMN_NAME}\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;`);
            }
            
            if (col.COLUMN_NAME === 'updated_at' && !col.EXTRA.includes('on update CURRENT_TIMESTAMP')) {
                commands.push(`-- Add auto-update to updated_at column in ${tableName}
ALTER TABLE \`${tableName}\` 
MODIFY COLUMN \`${col.COLUMN_NAME}\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;`);
            }
        });
        
        return commands;
    }

    // Get all table names
    async getAllTables() {
        const [tables] = await pool.execute(`
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        `);
        
        return tables.map(row => row.TABLE_NAME);
    }

    // Display summary
    displaySummary(report) {
        console.log('\n📊 TIMESTAMP COLUMNS SUMMARY');
        console.log('='.repeat(50));
        console.log(`Total Tables: ${report.total_tables}`);
        console.log(`Tables with Timestamps: ${report.tables_with_timestamps}`);
        console.log(`Tables Missing Timestamps: ${report.tables_missing_timestamps}`);
        console.log(`Tables with Recommended Columns: ${report.tables_with_recommended}`);
        console.log(`Total Recommendations: ${report.recommendations.length}`);
        console.log(`SQL Commands Generated: ${report.sql_commands.length}`);
        
        if (report.tables_missing_timestamps > 0) {
            console.log('\n⚠️  TABLES MISSING TIMESTAMP COLUMNS:');
            console.log('-'.repeat(40));
            Object.entries(report.table_details).forEach(([table, info]) => {
                if (!info.has_timestamps) {
                    console.log(`❌ ${table} - No timestamp columns found`);
                }
            });
        }
        
        if (report.recommendations.length > 0) {
            console.log('\n💡 TOP RECOMMENDATIONS:');
            console.log('-'.repeat(40));
            const highPriority = report.recommendations.filter(r => r.priority === 'high');
            highPriority.slice(0, 5).forEach(rec => {
                console.log(`🔴 ${rec.description}`);
            });
        }
        
        console.log('\n✅ Check complete! Reports saved to ./timestamp-reports/');
    }

    // Check specific table
    async checkSpecificTable(tableName) {
        try {
            console.log(`🔍 Checking specific table: ${tableName}`);
            
            const tableInfo = await this.checkTable(tableName);
            
            console.log('\n📊 TABLE DETAILS:');
            console.log('='.repeat(50));
            console.log(`Table: ${tableInfo.table_name}`);
            console.log(`Total Columns: ${tableInfo.total_columns}`);
            console.log(`Timestamp Columns: ${tableInfo.timestamp_columns.length}`);
            console.log(`Has Recommended Columns: ${tableInfo.has_recommended ? '✅' : '❌'}`);
            
            if (tableInfo.timestamp_columns.length > 0) {
                console.log('\n🕒 TIMESTAMP COLUMNS:');
                tableInfo.timestamp_columns.forEach(col => {
                    console.log(`  • ${col.name} (${col.type}) - ${col.nullable === 'YES' ? 'Nullable' : 'Not Null'}`);
                });
            }
            
            if (tableInfo.recommendations.length > 0) {
                console.log('\n💡 RECOMMENDATIONS:');
                tableInfo.recommendations.forEach(rec => {
                    const priority = rec.priority === 'high' ? '🔴' : rec.priority === 'medium' ? '🟡' : '🟢';
                    console.log(`  ${priority} ${rec.description}`);
                });
            }
            
            if (tableInfo.sql_commands.length > 0) {
                console.log('\n🔧 SQL COMMANDS:');
                tableInfo.sql_commands.forEach(cmd => {
                    console.log(cmd);
                });
            }
            
            return tableInfo;
            
        } catch (error) {
            console.error(`❌ Error checking table ${tableName}:`, error.message);
            throw error;
        }
    }

    // Generate migration script
    async generateMigrationScript() {
        try {
            console.log('📝 Generating migration script...');
            
            const report = await this.checkAllTables();
            
            const migrationScript = `-- Timestamp Columns Migration Script
-- Generated: ${new Date().toISOString()}
-- This script adds missing timestamp columns to all tables

SET FOREIGN_KEY_CHECKS = 0;

${report.sql_commands.join('\n\n')}

SET FOREIGN_KEY_CHECKS = 1;

-- Verify the changes
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    COLUMN_DEFAULT,
    EXTRA
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE()
AND COLUMN_NAME IN ('created_at', 'updated_at')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
`;
            
            const migrationFile = path.join(this.config.exportPath, `migration_add_timestamps_${new Date().toISOString().split('T')[0]}.sql`);
            fs.writeFileSync(migrationFile, migrationScript);
            
            console.log(`💾 Migration script saved to: ${migrationFile}`);
            return migrationFile;
            
        } catch (error) {
            console.error('❌ Failed to generate migration script:', error.message);
            throw error;
        }
    }
}

// CLI usage
if (require.main === module) {
    const checker = new TimestampColumnChecker();
    
    const command = process.argv[2] || 'check';
    const tableName = process.argv[3];
    
    switch (command) {
        case 'check':
            if (tableName) {
                checker.checkSpecificTable(tableName).catch(console.error);
            } else {
                checker.checkAllTables().catch(console.error);
            }
            break;
            
        case 'migration':
            checker.generateMigrationScript().catch(console.error);
            break;
            
        default:
            console.log('Usage: node check-timestamp-columns.js [check|migration] [table_name]');
            console.log('  check [table_name] - Check timestamp columns (all tables or specific table)');
            console.log('  migration          - Generate migration script to add missing columns');
            break;
    }
}

module.exports = TimestampColumnChecker;
