const axios = require('axios');

async function testActualAPIResponse() {
  try {
    console.log('🔍 Testing actual API response...');
    
    // Test the actual API endpoint that the frontend calls
    const response = await axios.get('http://localhost:5000/api/accounting/income-statement/month/9/year/2025');
    
    console.log('✅ API Response received!');
    console.log('\n📊 Response Structure:');
    console.log(`   • Status: ${response.status}`);
    console.log(`   • Revenue accounts: ${response.data.revenue?.length || 0}`);
    console.log(`   • Expense accounts: ${response.data.expenses?.length || 0}`);
    console.log(`   • Total Revenue: $${response.data.totals?.total_revenue || 0}`);
    console.log(`   • Total Expenses: $${response.data.totals?.total_expenses || 0}`);
    console.log(`   • Net Income: $${response.data.totals?.net_income || 0}`);
    
    if (response.data.revenue && response.data.revenue.length > 0) {
      console.log('\n💰 Sample Revenue Account:');
      console.log(`   • Code: ${response.data.revenue[0].account_code}`);
      console.log(`   • Name: ${response.data.revenue[0].account_name}`);
      console.log(`   • Amount: $${response.data.revenue[0].amount}`);
    }
    
    if (response.data.expenses && response.data.expenses.length > 0) {
      console.log('\n💸 Sample Expense Account:');
      console.log(`   • Code: ${response.data.expenses[0].account_code}`);
      console.log(`   • Name: ${response.data.expenses[0].account_name}`);
      console.log(`   • Amount: $${response.data.expenses[0].amount}`);
    }
    
    if (response.data.expenses && response.data.expenses.length > 0) {
      console.log('\n🎉 SUCCESS! The API is returning expense accounts correctly!');
      console.log('   The frontend should display all expense accounts with zero values.');
    } else {
      console.log('\n❌ PROBLEM: No expense accounts in API response!');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing API:', error.message);
    if (error.response) {
      console.error(`   Status: ${error.response.status}`);
      console.error(`   Data: ${JSON.stringify(error.response.data, null, 2)}`);
    }
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testActualAPIResponse()
    .then(() => {
      console.log('\n✅ API test completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 API test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testActualAPIResponse;
