const { pool } = require('../config/database');
const fs = require('fs');
const path = require('path');

async function testExportOnly() {
    try {
        console.log('🔍 Testing database export (no API sync)...');
        
        // Create export directory
        const exportPath = './database-exports';
        if (!fs.existsSync(exportPath)) {
            fs.mkdirSync(exportPath, { recursive: true });
        }
        
        // Get all table names
        const [tables] = await pool.execute(`
            SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        `);
        
        console.log(`📊 Found ${tables.length} tables to export`);
        
        // Export first 3 tables as test
        const testTables = tables.slice(0, 3).map(row => row.TABLE_NAME);
        const exportData = {};
        let totalRecords = 0;
        
        for (const table of testTables) {
            console.log(`📦 Exporting table: ${table}`);
            
            // Get table data
            const [rows] = await pool.execute(`SELECT * FROM \`${table}\` LIMIT 10`);
            
            exportData[table] = {
                data: rows,
                record_count: rows.length
            };
            
            totalRecords += rows.length;
            console.log(`✅ Exported ${rows.length} records from ${table}`);
        }
        
        // Add metadata
        exportData._metadata = {
            export_timestamp: new Date().toISOString(),
            total_tables: testTables.length,
            total_records: totalRecords,
            source: 'local_sms_test_export'
        };
        
        // Save to file
        const filename = `test_export_${new Date().toISOString().split('T')[0]}.json`;
        const filepath = path.join(exportPath, filename);
        
        fs.writeFileSync(filepath, JSON.stringify(exportData, null, 2));
        console.log(`💾 Test export saved to ${filename}`);
        
        console.log('🎉 Test export completed successfully!');
        console.log(`📊 Total: ${totalRecords} records across ${testTables.length} tables`);
        console.log(`📁 File location: ${filepath}`);
        
    } catch (error) {
        console.error('❌ Test export failed:', error.message);
        throw error;
    }
}

testExportOnly();
