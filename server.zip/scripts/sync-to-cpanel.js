const { pool } = require('../config/database');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

class CpanelDataSync {
    constructor() {
        // Configuration for cPanel database sync
        this.config = {
            // Option 1: Direct MySQL connection (if cPanel allows remote connections)
            directConnection: {
                host: process.env.CPANEL_DB_HOST || 'your-cpanel-domain.com',
                port: process.env.CPANEL_DB_PORT || 3306,
                user: process.env.CPANEL_DB_USER || 'your_cpanel_db_user',
                password: process.env.CPANEL_DB_PASSWORD || 'your_cpanel_db_password',
                database: process.env.CPANEL_DB_NAME || 'your_cpanel_db_name',
                ssl: { rejectUnauthorized: false } // For cPanel SSL
            },
            
            // Option 2: API endpoint for data sync
            apiEndpoint: process.env.CPANEL_API_URL || 'https://your-domain.com/api/sync',
            apiKey: process.env.CPANEL_API_KEY || 'your_api_key',
            
            // Option 3: File-based sync
            exportPath: './exports',
            ftpConfig: {
                host: process.env.FTP_HOST || 'your-domain.com',
                user: process.env.FTP_USER || 'your_ftp_user',
                password: process.env.FTP_PASSWORD || 'your_ftp_password',
                remotePath: '/public_html/data-sync/'
            }
        };
    }

    // Method 1: Direct Database Connection (if cPanel allows remote MySQL)
    async syncDirectConnection() {
        try {
            console.log('🔄 Starting direct database sync...');
            
            const mysql = require('mysql2/promise');
            const remotePool = mysql.createPool(this.config.directConnection);
            
            // Test connection
            await remotePool.execute('SELECT 1');
            console.log('✅ Connected to cPanel database');
            
            // Sync student balances
            await this.syncStudentBalances(remotePool);
            
            // Sync other critical data
            await this.syncStudentTransactions(remotePool);
            await this.syncUniformIssues(remotePool);
            
            await remotePool.end();
            console.log('✅ Direct sync completed successfully');
            
        } catch (error) {
            console.error('❌ Direct sync failed:', error.message);
            throw error;
        }
    }

    // Method 2: API-based sync (recommended for cPanel)
    async syncViaAPI() {
        try {
            console.log('🔄 Starting API-based sync...');
            
            // Prepare sync data
            const syncData = await this.prepareSyncData();
            
            // Send to cPanel API
            const response = await axios.post(this.config.apiEndpoint, {
                data: syncData,
                timestamp: new Date().toISOString(),
                source: 'local_sms'
            }, {
                headers: {
                    'Authorization': `Bearer ${this.config.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000 // 30 seconds timeout
            });
            
            if (response.data.success) {
                console.log('✅ API sync completed successfully');
                console.log(`📊 Synced: ${response.data.syncedRecords} records`);
            } else {
                throw new Error(response.data.message || 'API sync failed');
            }
            
        } catch (error) {
            console.error('❌ API sync failed:', error.message);
            throw error;
        }
    }

    // Method 3: File-based sync (export to files, upload via FTP)
    async syncViaFiles() {
        try {
            console.log('🔄 Starting file-based sync...');
            
            // Create export directory
            if (!fs.existsSync(this.config.exportPath)) {
                fs.mkdirSync(this.config.exportPath, { recursive: true });
            }
            
            // Export data to files
            await this.exportStudentBalances();
            await this.exportStudentTransactions();
            await this.exportUniformIssues();
            
            // Upload files via FTP
            await this.uploadFilesToCpanel();
            
            console.log('✅ File-based sync completed successfully');
            
        } catch (error) {
            console.error('❌ File-based sync failed:', error.message);
            throw error;
        }
    }

    // Prepare data for API sync
    async prepareSyncData() {
        console.log('📦 Preparing sync data...');
        
        const [studentBalances] = await pool.execute(`
            SELECT sb.*, s.Name, s.Surname, s.RegNumber
            FROM student_balances sb
            JOIN students s ON sb.student_reg_number = s.RegNumber
            WHERE sb.last_updated >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        `);
        
        const [studentTransactions] = await pool.execute(`
            SELECT * FROM student_transactions 
            WHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        `);
        
        const [uniformIssues] = await pool.execute(`
            SELECT ui.*, s.Name, s.Surname, s.RegNumber
            FROM uniform_issues ui
            JOIN students s ON ui.student_reg_number = s.RegNumber
            WHERE ui.issue_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        `);
        
        return {
            student_balances: studentBalances,
            student_transactions: studentTransactions,
            uniform_issues: uniformIssues,
            sync_timestamp: new Date().toISOString()
        };
    }

    // Export student balances to JSON file
    async exportStudentBalances() {
        const [balances] = await pool.execute(`
            SELECT sb.*, s.Name, s.Surname, s.RegNumber
            FROM student_balances sb
            JOIN students s ON sb.student_reg_number = s.RegNumber
        `);
        
        const filename = `student_balances_${new Date().toISOString().split('T')[0]}.json`;
        const filepath = path.join(this.config.exportPath, filename);
        
        fs.writeFileSync(filepath, JSON.stringify(balances, null, 2));
        console.log(`📄 Exported ${balances.length} student balances to ${filename}`);
    }

    // Export student transactions to JSON file
    async exportStudentTransactions() {
        const [transactions] = await pool.execute(`
            SELECT * FROM student_transactions 
            ORDER BY transaction_date DESC
        `);
        
        const filename = `student_transactions_${new Date().toISOString().split('T')[0]}.json`;
        const filepath = path.join(this.config.exportPath, filename);
        
        fs.writeFileSync(filepath, JSON.stringify(transactions, null, 2));
        console.log(`📄 Exported ${transactions.length} student transactions to ${filename}`);
    }

    // Export uniform issues to JSON file
    async exportUniformIssues() {
        const [issues] = await pool.execute(`
            SELECT ui.*, s.Name, s.Surname, s.RegNumber
            FROM uniform_issues ui
            JOIN students s ON ui.student_reg_number = s.RegNumber
            ORDER BY ui.issue_date DESC
        `);
        
        const filename = `uniform_issues_${new Date().toISOString().split('T')[0]}.json`;
        const filepath = path.join(this.config.exportPath, filename);
        
        fs.writeFileSync(filepath, JSON.stringify(issues, null, 2));
        console.log(`📄 Exported ${issues.length} uniform issues to ${filename}`);
    }

    // Upload files to cPanel via FTP
    async uploadFilesToCpanel() {
        const ftp = require('basic-ftp');
        const client = new ftp.Client();
        
        try {
            await client.access({
                host: this.config.ftpConfig.host,
                user: this.config.ftpConfig.user,
                password: this.config.ftpConfig.password,
                secure: true // Use FTPS
            });
            
            await client.ensureDir(this.config.ftpConfig.remotePath);
            
            const files = fs.readdirSync(this.config.exportPath);
            for (const file of files) {
                if (file.endsWith('.json')) {
                    await client.uploadFrom(
                        path.join(this.config.exportPath, file),
                        this.config.ftpConfig.remotePath + file
                    );
                    console.log(`📤 Uploaded ${file} to cPanel`);
                }
            }
            
        } finally {
            client.close();
        }
    }

    // Sync specific data to remote database
    async syncStudentBalances(remotePool) {
        const [balances] = await pool.execute(`
            SELECT sb.*, s.Name, s.Surname, s.RegNumber
            FROM student_balances sb
            JOIN students s ON sb.student_reg_number = s.RegNumber
        `);
        
        for (const balance of balances) {
            await remotePool.execute(`
                INSERT INTO student_balances 
                (student_reg_number, current_balance, last_updated, created_at)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                current_balance = VALUES(current_balance),
                last_updated = VALUES(last_updated)
            `, [balance.student_reg_number, balance.current_balance, balance.last_updated, balance.created_at]);
        }
        
        console.log(`✅ Synced ${balances.length} student balances`);
    }

    async syncStudentTransactions(remotePool) {
        const [transactions] = await pool.execute(`
            SELECT * FROM student_transactions 
            ORDER BY transaction_date DESC
        `);
        
        for (const transaction of transactions) {
            await remotePool.execute(`
                INSERT INTO student_transactions 
                (student_reg_number, transaction_type, amount, description, transaction_date, created_by)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                amount = VALUES(amount),
                description = VALUES(description)
            `, [
                transaction.student_reg_number,
                transaction.transaction_type,
                transaction.amount,
                transaction.description,
                transaction.transaction_date,
                transaction.created_by
            ]);
        }
        
        console.log(`✅ Synced ${transactions.length} student transactions`);
    }

    async syncUniformIssues(remotePool) {
        const [issues] = await pool.execute(`
            SELECT ui.*, s.Name, s.Surname, s.RegNumber
            FROM uniform_issues ui
            JOIN students s ON ui.student_reg_number = s.RegNumber
        `);
        
        for (const issue of issues) {
            await remotePool.execute(`
                INSERT INTO uniform_issues 
                (student_reg_number, item_id, quantity, amount, issue_date, payment_status, reference)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                quantity = VALUES(quantity),
                amount = VALUES(amount),
                payment_status = VALUES(payment_status)
            `, [
                issue.student_reg_number,
                issue.item_id,
                issue.quantity,
                issue.amount,
                issue.issue_date,
                issue.payment_status,
                issue.reference
            ]);
        }
        
        console.log(`✅ Synced ${issues.length} uniform issues`);
    }

    // Main sync method - tries different approaches
    async sync() {
        console.log('🚀 Starting data sync to cPanel...');
        
        try {
            // Try API sync first (recommended)
            await this.syncViaAPI();
        } catch (apiError) {
            console.log('⚠️ API sync failed, trying file-based sync...');
            
            try {
                // Fallback to file-based sync
                await this.syncViaFiles();
            } catch (fileError) {
                console.log('⚠️ File sync failed, trying direct connection...');
                
                try {
                    // Last resort: direct connection
                    await this.syncDirectConnection();
                } catch (directError) {
                    console.error('❌ All sync methods failed');
                    throw new Error(`Sync failed: API(${apiError.message}), Files(${fileError.message}), Direct(${directError.message})`);
                }
            }
        }
        
        console.log('🎉 Data sync completed successfully!');
    }
}

// CLI usage
if (require.main === module) {
    const sync = new CpanelDataSync();
    
    const method = process.argv[2] || 'auto';
    
    switch (method) {
        case 'api':
            sync.syncViaAPI().catch(console.error);
            break;
        case 'files':
            sync.syncViaFiles().catch(console.error);
            break;
        case 'direct':
            sync.syncDirectConnection().catch(console.error);
            break;
        case 'auto':
        default:
            sync.sync().catch(console.error);
            break;
    }
}

module.exports = CpanelDataSync;
