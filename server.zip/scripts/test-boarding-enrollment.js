const { pool } = require('../config/database');

async function testBoardingEnrollment() {
    const conn = await pool.getConnection();
    try {
        console.log('Testing boarding enrollment process...\n');
        
        // Check if boarding_fees table has data
        const [boardingFees] = await conn.execute(
            'SELECT * FROM boarding_fees LIMIT 5'
        );
        
        console.log('Boarding fees found:', boardingFees.length);
        if (boardingFees.length > 0) {
            console.log('Sample boarding fee:', boardingFees[0]);
        }
        
        // Check if hostels table has data
        const [hostels] = await conn.execute(
            'SELECT * FROM hostels LIMIT 5'
        );
        
        console.log('\nHostels found:', hostels.length);
        if (hostels.length > 0) {
            console.log('Sample hostel:', hostels[0]);
        }
        
        // Check if rooms table has data
        const [rooms] = await conn.execute(
            'SELECT * FROM rooms LIMIT 5'
        );
        
        console.log('\nRooms found:', rooms.length);
        if (rooms.length > 0) {
            console.log('Sample room:', rooms[0]);
        }
        
        // Check if students table has data
        const [students] = await conn.execute(
            'SELECT RegNumber, Name, Surname FROM students WHERE Active = "Yes" LIMIT 5'
        );
        
        console.log('\nActive students found:', students.length);
        if (students.length > 0) {
            console.log('Sample student:', students[0]);
        }
        
        // Test boarding fee lookup for a specific hostel/term/year
        if (boardingFees.length > 0 && hostels.length > 0) {
            const fee = boardingFees[0];
            console.log(`\nTesting boarding fee lookup for hostel ${fee.hostel_id}, term ${fee.term}, year ${fee.academic_year}`);
            
            const [testFee] = await conn.execute(
                'SELECT id, amount, currency_id FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                [fee.hostel_id, fee.term, fee.academic_year]
            );
            
            if (testFee.length > 0) {
                console.log('✓ Found boarding fee:', testFee[0]);
            } else {
                console.log('✗ No boarding fee found for this combination');
            }
        }
        
        // Check student_balances table
        const [studentBalances] = await conn.execute(
            'SELECT * FROM student_balances LIMIT 5'
        );
        
        console.log('\nStudent balances found:', studentBalances.length);
        if (studentBalances.length > 0) {
            console.log('Sample student balance:', studentBalances[0]);
        }
        
        // Check student_transactions table
        const [studentTransactions] = await conn.execute(
            'SELECT * FROM student_transactions LIMIT 5'
        );
        
        console.log('\nStudent transactions found:', studentTransactions.length);
        if (studentTransactions.length > 0) {
            console.log('Sample student transaction:', studentTransactions[0]);
        }
        
    } catch (error) {
        console.error('Error testing boarding enrollment:', error);
    } finally {
        conn.release();
    }
}

// Run the test if called directly
if (require.main === module) {
    testBoardingEnrollment()
        .then(() => {
            console.log('\nTest completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testBoardingEnrollment };
