const { pool } = require('../config/database');

async function testDigitalOceanConnection() {
  try {
    console.log('🔍 Testing DigitalOcean MySQL connection...');
    
    // Test basic connection
    const connection = await pool.getConnection();
    console.log('✅ Successfully connected to DigitalOcean MySQL');
    
    // Test database name
    const [dbResult] = await connection.execute('SELECT DATABASE() as current_db');
    console.log('📊 Current database:', dbResult[0].current_db);
    
    // Test table listing
    const [tables] = await connection.execute('SHOW TABLES');
    console.log('📋 Tables in database:', tables.length);
    
    if (tables.length > 0) {
      console.log('📝 First few tables:');
      tables.slice(0, 5).forEach(table => {
        console.log(`  - ${Object.values(table)[0]}`);
      });
    } else {
      console.log('⚠️ No tables found in database');
    }
    
    connection.release();
    console.log('✅ Connection test completed successfully');
    
  } catch (error) {
    console.error('❌ Connection test failed:', error.message);
    console.error('Full error:', error);
  } finally {
    await pool.end();
  }
}

testDigitalOceanConnection();
