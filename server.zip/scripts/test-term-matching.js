const { pool } = require('../config/database');

async function testTermMatching() {
    const conn = await pool.getConnection();
    try {
        console.log('Testing term matching between billing and enrollment...\n');
        
        // Check boarding fees
        const [boardingFees] = await conn.execute(
            'SELECT * FROM boarding_fees LIMIT 5'
        );
        
        console.log('Boarding fees found:', boardingFees.length);
        if (boardingFees.length > 0) {
            console.log('Sample boarding fees:');
            boardingFees.forEach(fee => {
                console.log(`  - Hostel ID: ${fee.hostel_id}, Term: "${fee.term}", Year: ${fee.academic_year}, Amount: ${fee.amount}`);
            });
        }
        
        // Test term formatting logic
        console.log('\nTesting term formatting logic:');
        const testTerms = ['Term 1', 'Term 2', 'Term 3', '1', '2', '3'];
        
        testTerms.forEach(originalTerm => {
            let formattedTerm = originalTerm;
            if (originalTerm) {
                const termMatch = originalTerm.match(/\d+/);
                formattedTerm = termMatch ? termMatch[0] : originalTerm;
            }
            console.log(`  "${originalTerm}" -> "${formattedTerm}"`);
        });
        
        // Test boarding fee lookup for a specific hostel
        if (boardingFees.length > 0) {
            const testFee = boardingFees[0];
            console.log(`\nTesting boarding fee lookup for hostel ${testFee.hostel_id}, term "${testFee.term}", year ${testFee.academic_year}`);
            
            // Test with original term
            const [originalTermResult] = await conn.execute(
                'SELECT id, amount, currency_id, term FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                [testFee.hostel_id, testFee.term, testFee.academic_year]
            );
            
            console.log(`✓ Found ${originalTermResult.length} fee(s) with original term "${testFee.term}"`);
            
            // Test with formatted term
            let formattedTerm = testFee.term;
            if (testFee.term) {
                const termMatch = testFee.term.match(/\d+/);
                formattedTerm = termMatch ? termMatch[0] : testFee.term;
            }
            
            const [formattedTermResult] = await conn.execute(
                'SELECT id, amount, currency_id, term FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                [testFee.hostel_id, formattedTerm, testFee.academic_year]
            );
            
            console.log(`✓ Found ${formattedTermResult.length} fee(s) with formatted term "${formattedTerm}"`);
            
            // Test the combined lookup logic
            let [combinedResult] = await conn.execute(
                'SELECT id, amount, currency_id, term FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                [testFee.hostel_id, formattedTerm, testFee.academic_year]
            );
            
            if (combinedResult.length === 0 && testFee.term !== formattedTerm) {
                [combinedResult] = await conn.execute(
                    'SELECT id, amount, currency_id, term FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
                    [testFee.hostel_id, testFee.term, testFee.academic_year]
                );
            }
            
            console.log(`✓ Combined lookup found ${combinedResult.length} fee(s)`);
            
            if (combinedResult.length > 0) {
                console.log(`  - Using term: "${combinedResult[0].term}"`);
                console.log(`  - Amount: ${combinedResult[0].amount}`);
            }
        }
        
        // Check enrollments to see what term format they're using
        const [enrollments] = await conn.execute(
            'SELECT id, student_reg_number, hostel_id, term, academic_year FROM boarding_enrollments LIMIT 5'
        );
        
        console.log('\nEnrollments found:', enrollments.length);
        if (enrollments.length > 0) {
            console.log('Sample enrollments:');
            enrollments.forEach(enrollment => {
                console.log(`  - Student: ${enrollment.student_reg_number}, Hostel: ${enrollment.hostel_id}, Term: "${enrollment.term}", Year: ${enrollment.academic_year}`);
            });
        }
        
    } catch (error) {
        console.error('Error testing term matching:', error);
    } finally {
        conn.release();
    }
}

// Run the test if called directly
if (require.main === module) {
    testTermMatching()
        .then(() => {
            console.log('\nTest completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testTermMatching };
