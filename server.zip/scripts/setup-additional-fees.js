const mysql = require('mysql2/promise');
require('dotenv').config();

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'sms',
  port: process.env.DB_PORT || 3306,
  charset: 'utf8mb4'
};

async function setupAdditionalFees() {
  const connection = await mysql.createConnection(dbConfig);
  
  try {
    console.log('🚀 Setting up additional fee structures...');
    
    // 1. Check if fee structures already exist
    const [existing] = await connection.execute(
      'SELECT COUNT(*) as count FROM additional_fee_structures'
    );
    
    if (existing[0].count > 0) {
      console.log('✅ Additional fee structures already exist, skipping setup');
      return;
    }
    
    // 2. Get currency ID (assuming USD is currency ID 1)
    const [currencies] = await connection.execute('SELECT id FROM currencies LIMIT 1');
    if (currencies.length === 0) {
      console.log('⚠️ No currencies found. Please create a currency first.');
      return;
    }
    const currencyId = currencies[0].id;
    console.log(`💰 Using currency ID: ${currencyId}`);
    
    // 3. Create the 3 default fee structures
    console.log('📋 Creating default fee structures...');
    
    const feeStructures = [
      {
        fee_name: 'Textbook Fees',
        description: 'Annual textbook and learning materials fee',
        amount: 35.00,
        fee_type: 'annual'
      },
      {
        fee_name: 'Registration Fees',
        description: 'One-time registration fee for new students',
        amount: 30.00,
        fee_type: 'one_time'
      },
      {
        fee_name: 'Report Book Fees',
        description: 'One-time report book fee',
        amount: 10.00,
        fee_type: 'one_time'
      }
    ];
    
    for (const fee of feeStructures) {
      await connection.execute(`
        INSERT INTO additional_fee_structures (fee_name, description, amount, currency_id, fee_type)
        VALUES (?, ?, ?, ?, ?)
      `, [fee.fee_name, fee.description, fee.amount, currencyId, fee.fee_type]);
      
      console.log(`✅ Created: ${fee.fee_name} - $${fee.amount} (${fee.fee_type})`);
    }
    
    console.log('\n🎉 Additional fee structures setup completed!');
    console.log('\n📊 Summary:');
    console.log('- Textbook Fees: $35.00 (Annual)');
    console.log('- Registration Fees: $30.00 (One-time)');
    console.log('- Report Book Fees: $10.00 (One-time)');
    console.log('\n💡 Next steps:');
    console.log('1. Run the database migration: mysql -u username -p database_name < server/migrations/additional_fee_structures.sql');
    console.log('2. Use the API endpoints to manage fee assignments');
    console.log('3. Generate annual textbook fees for all students');
    console.log('4. Manually assign registration and report book fees as needed');
    
  } catch (error) {
    console.error('❌ Error setting up additional fees:', error);
  } finally {
    await connection.end();
  }
}

// Run the setup
setupAdditionalFees();
