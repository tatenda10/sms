const { pool } = require('../config/database');

async function testEnrollmentPrevention() {
    const conn = await pool.getConnection();
    try {
        console.log('Testing enrollment prevention logic...\n');
        
        // Check boarding fees
        const [boardingFees] = await conn.execute(
            'SELECT * FROM boarding_fees LIMIT 3'
        );
        
        console.log('Boarding fees available:', boardingFees.length);
        if (boardingFees.length > 0) {
            console.log('Sample boarding fees:');
            boardingFees.forEach(fee => {
                console.log(`  - Hostel ID: ${fee.hostel_id}, Term: ${fee.term}, Year: ${fee.academic_year}, Amount: ${fee.amount}`);
            });
        }
        
        // Check invoice structures
        const [invoiceStructures] = await conn.execute(
            'SELECT * FROM invoice_structures LIMIT 3'
        );
        
        console.log('\nInvoice structures available:', invoiceStructures.length);
        if (invoiceStructures.length > 0) {
            console.log('Sample invoice structures:');
            invoiceStructures.forEach(invoice => {
                console.log(`  - Class ID: ${invoice.gradelevel_class_id}, Term: ${invoice.term}, Year: ${invoice.academic_year}, Amount: ${invoice.total_amount}`);
            });
        }
        
        // Test boarding fee lookup for non-existent combination
        console.log('\nTesting boarding fee lookup for non-existent combination...');
        const [nonExistentBoardingFee] = await conn.execute(
            'SELECT id, amount, currency_id FROM boarding_fees WHERE hostel_id = ? AND term = ? AND academic_year = ? AND is_active = TRUE',
            [999, '99', '2099']
        );
        
        if (nonExistentBoardingFee.length === 0) {
            console.log('✓ Correctly found no boarding fee for non-existent combination');
        } else {
            console.log('✗ Unexpectedly found boarding fee for non-existent combination');
        }
        
        // Test invoice structure lookup for non-existent combination
        console.log('\nTesting invoice structure lookup for non-existent combination...');
        const [nonExistentInvoice] = await conn.execute(
            'SELECT total_amount, term, academic_year FROM invoice_structures WHERE gradelevel_class_id = ? AND term = ? AND academic_year = ?',
            [999, '99', '2099']
        );
        
        if (nonExistentInvoice.length === 0) {
            console.log('✓ Correctly found no invoice structure for non-existent combination');
        } else {
            console.log('✗ Unexpectedly found invoice structure for non-existent combination');
        }
        
        // Check if there are any enrollments without corresponding fee structures
        console.log('\nChecking for enrollments without fee structures...');
        
        // Boarding enrollments without fee structures
        const [boardingWithoutFees] = await conn.execute(`
            SELECT be.*, h.name as hostel_name
            FROM boarding_enrollments be
            LEFT JOIN hostels h ON be.hostel_id = h.id
            LEFT JOIN boarding_fees bf ON be.hostel_id = bf.hostel_id 
                AND be.term = bf.term 
                AND be.academic_year = bf.academic_year
                AND bf.is_active = TRUE
            WHERE bf.id IS NULL
            LIMIT 5
        `);
        
        console.log('Boarding enrollments without fee structures:', boardingWithoutFees.length);
        if (boardingWithoutFees.length > 0) {
            console.log('Sample enrollments without fees:');
            boardingWithoutFees.forEach(enrollment => {
                console.log(`  - Student: ${enrollment.student_reg_number}, Hostel: ${enrollment.hostel_name}, Term: ${enrollment.term}, Year: ${enrollment.academic_year}`);
            });
        }
        
        // Class enrollments without invoice structures
        const [classWithoutInvoices] = await conn.execute(`
            SELECT e.*, gc.name as class_name
            FROM enrollments_gradelevel_classes e
            LEFT JOIN gradelevel_classes gc ON e.gradelevel_class_id = gc.id
            LEFT JOIN invoice_structures inv ON e.gradelevel_class_id = inv.gradelevel_class_id 
                AND (e.term = inv.term OR e.term IS NULL)
                AND (e.academic_year = inv.academic_year OR e.academic_year IS NULL)
            WHERE inv.id IS NULL
            LIMIT 5
        `);
        
        console.log('Class enrollments without invoice structures:', classWithoutInvoices.length);
        if (classWithoutInvoices.length > 0) {
            console.log('Sample enrollments without invoices:');
            classWithoutInvoices.forEach(enrollment => {
                console.log(`  - Student: ${enrollment.student_regnumber}, Class: ${enrollment.class_name}, Term: ${enrollment.term}, Year: ${enrollment.academic_year}`);
            });
        }
        
    } catch (error) {
        console.error('Error testing enrollment prevention:', error);
    } finally {
        conn.release();
    }
}

// Run the test if called directly
if (require.main === module) {
    testEnrollmentPrevention()
        .then(() => {
            console.log('\nTest completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testEnrollmentPrevention };
