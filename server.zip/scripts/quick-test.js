#!/usr/bin/env node

const { pool } = require('../config/database');

async function quickTest() {
  console.log('🚀 Quick System Test');
  console.log('='.repeat(50));
  
  const connection = await pool.getConnection();
  
  try {
    // Test 1: Database Connection
    console.log('\n1️⃣ Testing Database Connection...');
    const [test] = await connection.execute('SELECT 1 as test');
    console.log('   ✅ Database connection successful');
    
    // Test 2: Core Tables
    console.log('\n2️⃣ Testing Core Tables...');
    const tables = ['students', 'transport_payments', 'journal_entries', 'chart_of_accounts'];
    for (const table of tables) {
      const [result] = await connection.execute(`SHOW TABLES LIKE '${table}'`);
      if (result.length > 0) {
        console.log(`   ✅ Table '${table}' exists`);
      } else {
        console.log(`   ❌ Table '${table}' missing`);
      }
    }
    
    // Test 3: Chart of Accounts
    console.log('\n3️⃣ Testing Chart of Accounts...');
    const [revenueCount] = await connection.execute('SELECT COUNT(*) as count FROM chart_of_accounts WHERE type = "Revenue" AND is_active = 1');
    const [expenseCount] = await connection.execute('SELECT COUNT(*) as count FROM chart_of_accounts WHERE type = "Expense" AND is_active = 1');
    console.log(`   ✅ Revenue accounts: ${revenueCount[0].count}`);
    console.log(`   ✅ Expense accounts: ${expenseCount[0].count}`);
    
    // Test 4: Transport Payments Schema
    console.log('\n4️⃣ Testing Transport Payments Schema...');
    const [routeIdColumn] = await connection.execute("SHOW COLUMNS FROM transport_payments LIKE 'route_id'");
    if (routeIdColumn.length > 0) {
      console.log('   ✅ route_id column exists');
    } else {
      console.log('   ❌ route_id column missing');
    }
    
    const [nullableCheck] = await connection.execute(
      "SELECT IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'transport_payments' AND COLUMN_NAME = 'transport_fee_id'"
    );
    if (nullableCheck.length > 0 && nullableCheck[0].IS_NULLABLE === 'YES') {
      console.log('   ✅ transport_fee_id is nullable');
    } else {
      console.log('   ❌ transport_fee_id is not nullable');
    }
    
    // Test 5: Income Statement Query
    console.log('\n5️⃣ Testing Income Statement Query...');
    const revenueQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.credit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN '2025-01-01' AND '2025-12-31'
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Revenue' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [revenue] = await connection.execute(revenueQuery);
    console.log(`   ✅ Revenue query returns ${revenue.length} accounts`);
    
    const expenseQuery = `
      SELECT 
        coa.id as account_id,
        coa.code as account_code,
        coa.name as account_name,
        COALESCE(SUM(jel.debit), 0) as amount
      FROM chart_of_accounts coa
      LEFT JOIN journal_entry_lines jel ON jel.account_id = coa.id
      LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id 
        AND je.entry_date BETWEEN '2025-01-01' AND '2025-12-31'
        AND je.description NOT LIKE '%Opening Balances B/D%'
        AND je.description NOT LIKE '%Close % to Income Summary%'
        AND je.description NOT LIKE '%Close Income Summary to Retained Earnings%'
      WHERE coa.type = 'Expense' 
        AND coa.is_active = 1
      GROUP BY coa.id, coa.code, coa.name
      ORDER BY coa.code
    `;
    
    const [expenses] = await connection.execute(expenseQuery);
    console.log(`   ✅ Expense query returns ${expenses.length} accounts`);
    
    // Test 6: Student Transactions
    console.log('\n6️⃣ Testing Student Transactions...');
    const [debitCount] = await connection.execute('SELECT COUNT(*) as count FROM student_transactions WHERE transaction_type = "DEBIT"');
    const [creditCount] = await connection.execute('SELECT COUNT(*) as count FROM student_transactions WHERE transaction_type = "CREDIT"');
    console.log(`   ✅ DEBIT transactions: ${debitCount[0].count}`);
    console.log(`   ✅ CREDIT transactions: ${creditCount[0].count}`);
    
    // Test 7: Transport Integration
    console.log('\n7️⃣ Testing Transport Integration...');
    const [transportPayments] = await connection.execute('SELECT COUNT(*) as count FROM transport_payments');
    const [transportTransactions] = await connection.execute('SELECT COUNT(*) as count FROM student_transactions WHERE description LIKE "%Transport Payment%"');
    console.log(`   ✅ Transport payments: ${transportPayments[0].count}`);
    console.log(`   ✅ Transport transactions: ${transportTransactions[0].count}`);
    
    console.log('\n' + '='.repeat(50));
    console.log('🎉 Quick Test Completed Successfully!');
    console.log('✅ All core systems are operational');
    console.log('📊 System is ready for use');
    
  } catch (error) {
    console.error('\n❌ Quick Test Failed:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run quick test if this script is executed directly
if (require.main === module) {
  quickTest()
    .then(() => {
      console.log('\n✅ Quick test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Quick test failed:', error.message);
      process.exit(1);
    });
}

module.exports = quickTest;
