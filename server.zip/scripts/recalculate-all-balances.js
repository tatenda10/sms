const { pool } = require('../config/database');
const StudentBalanceService = require('../services/studentBalanceService');

async function recalculateAllBalances() {
    const conn = await pool.getConnection();
    try {
        console.log('Starting balance recalculation for all students...');
        
        // Get all students
        const [students] = await conn.execute(
            'SELECT RegNumber FROM students WHERE Active = "Yes"'
        );
        
        console.log(`Found ${students.length} active students. Recalculating balances...`);
        
        let successCount = 0;
        let errorCount = 0;
        
        for (const student of students) {
            try {
                await StudentBalanceService.recalculateBalance(student.RegNumber, conn);
                successCount++;
                console.log(`✓ Recalculated balance for student: ${student.RegNumber}`);
            } catch (error) {
                errorCount++;
                console.error(`✗ Error recalculating balance for student ${student.RegNumber}:`, error.message);
            }
        }
        
        console.log('\n=== Balance Recalculation Complete ===');
        console.log(`Total students processed: ${students.length}`);
        console.log(`Successful recalculations: ${successCount}`);
        console.log(`Errors: ${errorCount}`);
        
        if (errorCount > 0) {
            console.log('\n⚠️  Some balances could not be recalculated. Check the errors above.');
        } else {
            console.log('\n✅ All student balances have been successfully recalculated!');
        }
        
    } catch (error) {
        console.error('Error in balance recalculation script:', error);
        throw error;
    } finally {
        conn.release();
    }
}

// Run the script if called directly
if (require.main === module) {
    recalculateAllBalances()
        .then(() => {
            console.log('Balance recalculation script completed successfully.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Balance recalculation script failed:', error);
            process.exit(1);
        });
}

module.exports = { recalculateAllBalances };
