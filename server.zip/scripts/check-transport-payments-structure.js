const { pool } = require('../config/database');

async function checkTransportPaymentsStructure() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking current transport_payments table structure...');
    
    // Get table structure
    const [columns] = await connection.execute('DESCRIBE transport_payments');
    
    console.log('\n📋 Current table structure:');
    console.log('┌─────────────────────┬─────────────┬──────┬─────┬─────────┬─────┐');
    console.log('│ Field               │ Type        │ Null │ Key │ Default │ Extra│');
    console.log('├─────────────────────┼─────────────┼──────┼─────┼─────────┼─────┤');
    
    columns.forEach(col => {
      const field = col.Field.padEnd(19);
      const type = col.Type.padEnd(11);
      const nullAllowed = col.Null.padEnd(4);
      const key = (col.Key || '').padEnd(3);
      const defaultVal = (col.Default || '').padEnd(7);
      const extra = col.Extra || '';
      
      console.log(`│ ${field} │ ${type} │ ${nullAllowed} │ ${key} │ ${defaultVal} │ ${extra} │`);
    });
    
    console.log('└─────────────────────┴─────────────┴──────┴─────┴─────────┴─────┘');
    
    // Check specific column
    const transportFeeIdColumn = columns.find(col => col.Field === 'transport_fee_id');
    if (transportFeeIdColumn) {
      console.log(`\n🎯 transport_fee_id column analysis:`);
      console.log(`   • Type: ${transportFeeIdColumn.Type}`);
      console.log(`   • Null allowed: ${transportFeeIdColumn.Null === 'YES' ? '✅ YES' : '❌ NO'}`);
      console.log(`   • Default: ${transportFeeIdColumn.Default || 'NULL'}`);
      console.log(`   • Key: ${transportFeeIdColumn.Key || 'None'}`);
      
      if (transportFeeIdColumn.Null === 'NO') {
        console.log('\n⚠️  ISSUE FOUND: transport_fee_id does not allow NULL values');
        console.log('   This needs to be fixed for direct payments to work.');
      } else {
        console.log('\n✅ transport_fee_id allows NULL values - direct payments should work');
      }
    } else {
      console.log('\n❌ transport_fee_id column not found!');
    }
    
    // Check for indexes
    console.log('\n🔍 Checking indexes...');
    const [indexes] = await connection.execute('SHOW INDEX FROM transport_payments');
    
    if (indexes.length > 0) {
      console.log('\n📊 Current indexes:');
      indexes.forEach(index => {
        console.log(`   • ${index.Key_name}: ${index.Column_name} (${index.Non_unique ? 'Non-unique' : 'Unique'})`);
      });
    } else {
      console.log('\n📊 No indexes found');
    }
    
  } catch (error) {
    console.error('\n❌ Error checking table structure:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkTransportPaymentsStructure()
    .then(() => {
      console.log('\n✅ Structure check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Structure check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkTransportPaymentsStructure;
