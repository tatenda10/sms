const { pool } = require('../config/database');

async function checkRoles() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking available roles...\n');
    
    // Get all roles
    const [roles] = await connection.execute('SELECT * FROM roles ORDER BY name');
    
    console.log('📋 Available roles:');
    console.log('===================');
    roles.forEach(role => {
      console.log(`- ${role.name} (ID: ${role.id})`);
    });
    
    // Get current user roles (if you have a user ID)
    console.log('\n👤 To check your user roles, run:');
    console.log('node -e "const { pool } = require(\'./config/database\'); pool.execute(\'SELECT u.username, GROUP_CONCAT(r.name) as roles FROM users u LEFT JOIN user_roles ur ON u.id = ur.user_id LEFT JOIN roles r ON ur.role_id = r.id WHERE u.username = \"YOUR_USERNAME\" GROUP BY u.id\').then(([rows]) => { console.log(rows); process.exit(0); });"');
    
  } catch (error) {
    console.error('❌ Error checking roles:', error);
  } finally {
    connection.release();
  }
}

checkRoles();
