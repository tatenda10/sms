const { pool } = require('../config/database');

async function testStudentFinancialRecordFix() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Testing Student Financial Record endpoint fix...');
    
    const studentRegNumber = 'R22121C';
    
    // Simulate the exact queries from the fixed getStudentTransactions method
    console.log(`\n📋 Testing for student: ${studentRegNumber}`);
    
    // Test DEBIT transactions query
    console.log('\n⚡ Testing DEBIT transactions query...');
    const [debitTransactions] = await connection.execute(
      `SELECT 
          st.id,
          st.student_reg_number,
          CASE 
              WHEN st.description LIKE '%Boarding%' THEN 'boarding'
              WHEN st.description LIKE '%Class%' THEN 'tuition'
              WHEN st.description LIKE '%Transport%' THEN 'transport'
              WHEN st.description LIKE '%Uniform%' THEN 'uniform'
              ELSE 'other'
          END as fee_type,
          st.amount,
          st.description as notes,
          st.transaction_date as payment_date,
          st.transaction_date as created_at,
          CONCAT('TRANSACTION-', st.id) as reference_number,
          'Enrollment' as payment_method,
          'paid' as status,
          'USD' as currency_symbol,
          'DEBIT' as transaction_type,
          st.term,
          st.academic_year,
          NULL as hostel_name,
          NULL as class_name
       FROM student_transactions st
       WHERE st.student_reg_number = ? AND st.transaction_type = "DEBIT"
       AND st.enrollment_id IS NULL
       ORDER BY st.transaction_date DESC`,
      [studentRegNumber]
    );
    
    console.log(`   ✅ Found ${debitTransactions.length} DEBIT transactions:`);
    debitTransactions.forEach((transaction, index) => {
      console.log(`   ${index + 1}. ${transaction.transaction_type}: $${transaction.amount} - ${transaction.notes}`);
    });
    
    // Test CREDIT transactions query (this is the new one that should include transport payments)
    console.log('\n⚡ Testing CREDIT transactions query (NEW - should include transport payments)...');
    const [creditTransactions] = await connection.execute(
      `SELECT 
          st.id,
          st.student_reg_number,
          CASE 
              WHEN st.description LIKE '%Transport Payment%' THEN 'transport'
              WHEN st.description LIKE '%Fee Payment%' THEN 'tuition'
              WHEN st.description LIKE '%Uniform%' THEN 'uniform'
              WHEN st.description LIKE '%Boarding%' THEN 'boarding'
              ELSE 'other'
          END as fee_type,
          st.amount,
          st.description as notes,
          st.transaction_date as payment_date,
          st.transaction_date as created_at,
          CONCAT('TRANSACTION-', st.id) as reference_number,
          'Payment' as payment_method,
          'paid' as status,
          'USD' as currency_symbol,
          'CREDIT' as transaction_type,
          st.term,
          st.academic_year,
          NULL as hostel_name,
          NULL as class_name
       FROM student_transactions st
       WHERE st.student_reg_number = ? AND st.transaction_type = "CREDIT"
       ORDER BY st.transaction_date DESC`,
      [studentRegNumber]
    );
    
    console.log(`   ✅ Found ${creditTransactions.length} CREDIT transactions:`);
    creditTransactions.forEach((transaction, index) => {
      console.log(`   ${index + 1}. ${transaction.transaction_type}: $${transaction.amount} - ${transaction.notes}`);
      if (transaction.fee_type === 'transport') {
        console.log(`      🚌 TRANSPORT PAYMENT DETECTED!`);
      }
    });
    
    // Check specifically for transport payments
    const transportPayments = creditTransactions.filter(t => t.fee_type === 'transport');
    console.log(`\n🚌 Transport payments found: ${transportPayments.length}`);
    transportPayments.forEach((payment, index) => {
      console.log(`   ${index + 1}. ${payment.transaction_type}: $${payment.amount} - ${payment.notes}`);
    });
    
    // Total transactions that should now be returned
    const totalTransactions = debitTransactions.length + creditTransactions.length;
    console.log(`\n📊 Total transactions that should now be returned: ${totalTransactions}`);
    console.log(`   • DEBIT transactions: ${debitTransactions.length}`);
    console.log(`   • CREDIT transactions: ${creditTransactions.length}`);
    console.log(`   • Transport payments: ${transportPayments.length}`);
    
    if (transportPayments.length > 0) {
      console.log('\n🎉 SUCCESS! Transport payments are now included in the Student Financial Record!');
    } else {
      console.log('\n❌ No transport payments found - there might be an issue with the query.');
    }
    
  } catch (error) {
    console.error('\n❌ Error testing Student Financial Record fix:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the test if this script is executed directly
if (require.main === module) {
  testStudentFinancialRecordFix()
    .then(() => {
      console.log('\n✅ Student Financial Record fix test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Student Financial Record fix test failed:', error.message);
      process.exit(1);
    });
}

module.exports = testStudentFinancialRecordFix;
