const { pool } = require('../config/database');
const AccountBalanceService = require('../services/accountBalanceService');

async function testAccountBalanceService() {
    const conn = await pool.getConnection();
    
    try {
        console.log('🧪 Testing Account Balance Service...');
        
        // Test 1: Get account balance
        console.log('\n1. Testing getAccountBalance...');
        const balance = await AccountBalanceService.getAccountBalance(conn, 1, 1);
        console.log(`Account 1 balance: ${balance}`);
        
        // Test 2: Check if we have any journal entries
        console.log('\n2. Checking journal entries...');
        const [journalEntries] = await conn.execute(`
            SELECT je.id, je.entry_date, je.description, 
                   COUNT(jel.id) as line_count
            FROM journal_entries je
            LEFT JOIN journal_entry_lines jel ON je.id = jel.journal_entry_id
            GROUP BY je.id
            ORDER BY je.entry_date DESC
            LIMIT 5
        `);
        
        console.log(`Found ${journalEntries.length} recent journal entries:`);
        journalEntries.forEach(entry => {
            console.log(`  - Entry ${entry.id}: ${entry.description} (${entry.line_count} lines)`);
        });
        
        // Test 3: Check current account balances
        console.log('\n3. Checking current account balances...');
        const [balances] = await conn.execute(`
            SELECT ab.account_id, coa.name as account_name, ab.balance, ab.as_of_date
            FROM account_balances ab
            JOIN chart_of_accounts coa ON ab.account_id = coa.id
            ORDER BY ab.balance DESC
            LIMIT 10
        `);
        
        console.log(`Found ${balances.length} account balances:`);
        balances.forEach(balance => {
            console.log(`  - ${balance.account_name}: ${balance.balance} (as of ${balance.as_of_date})`);
        });
        
        console.log('\n✅ Test completed successfully!');
        
    } catch (error) {
        console.error('❌ Test failed:', error);
        throw error;
    } finally {
        conn.release();
        process.exit(0);
    }
}

// Run the test
testAccountBalanceService().catch(console.error);
