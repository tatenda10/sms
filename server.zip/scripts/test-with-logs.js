const axios = require('axios');

async function testWithLogs() {
  try {
    console.log('🔍 Testing sync with detailed logging...');
    
    // Test with a single table first
    const testData = {
      database_export: {
        test_single_table: {
          schema: 'CREATE TABLE `test_single_table` (`id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
          structure: [
            { COLUMN_NAME: 'id', DATA_TYPE: 'int', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null },
            { COLUMN_NAME: 'name', DATA_TYPE: 'varchar', IS_NULLABLE: 'NO', COLUMN_DEFAULT: null }
          ],
          data: [
            { id: 1, name: 'Test Record 1' },
            { id: 2, name: 'Test Record 2' },
            { id: 3, name: 'Test Record 3' }
          ],
          record_count: 3
        }
      },
      timestamp: new Date().toISOString(),
      source: 'test_with_logs'
    };
    
    console.log('📤 Sending test data to server...');
    console.log('📊 Test data summary:', {
      tables: Object.keys(testData.database_export).length,
      totalRecords: Object.values(testData.database_export).reduce((sum, table) => sum + (table.record_count || 0), 0)
    });
    
    const syncResponse = await axios.post('https://server.learningladder.site/api/sync-full-db.php', testData, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    console.log('✅ Server response:', JSON.stringify(syncResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testWithLogs();
