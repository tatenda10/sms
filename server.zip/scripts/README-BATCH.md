# Database Sync - One-Click Solution

## 🚀 Quick Start

**Just double-click `sync-database.bat` and follow the prompts!**

## What It Does

This batch file will automatically:

1. **Test Connections** - Verifies both local and remote database connections
2. **Sync Data** - Transfers all data from local to DigitalOcean database
3. **Verify Results** - Confirms the sync was successful

## Files Included

- `sync-database.bat` - Main sync tool (double-click to run)
- `test-connections.js` - Tests database connections
- `sync-with-dependencies.js` - Performs the actual synchronization

## How to Use

1. **Double-click** `sync-database.bat`
2. **Press any key** when prompted to start
3. **Wait** for the process to complete (usually 1-2 minutes)
4. **Press any key** to exit when done

## What You'll See

```
========================================
   DATABASE SYNCHRONIZATION TOOL
========================================

[1/3] Testing database connections...
✅ Local Database connection successful
✅ Remote Database connection successful

[2/3] Starting database synchronization...
🔄 Processing table: currencies
📥 Inserting 2 new records to remote
...

[3/3] Verifying synchronization...
✅ Both connections successful!

========================================
   SYNCHRONIZATION COMPLETED!
========================================
```

## Troubleshooting

### If the sync fails:

1. **Check your internet connection**
2. **Verify database credentials** in the script files
3. **Make sure both databases are running**
4. **Contact your system administrator**

### Common Issues:

- **Connection timeout** - Check internet connection
- **Access denied** - Verify database credentials
- **Table errors** - Some tables may have dependency issues (this is normal)

## Safety Features

- ✅ **Reads before writing** - Analyzes data before making changes
- ✅ **Backs up existing data** - Preserves remote data
- ✅ **Handles conflicts** - Resolves duplicate records intelligently
- ✅ **Detailed logging** - Shows exactly what's happening

## Need Help?

If you encounter any issues, save the error messages and contact your system administrator with the details.

---

**Note**: This tool syncs from your local database TO the remote database. It will not delete any existing data on the remote server.
