const { pool } = require('../config/database');

async function checkChartOfAccounts() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🔍 Checking Chart of Accounts for Revenue and Expense categories...');
    
    const [revenueAccounts] = await connection.execute(
      'SELECT code, name, type FROM chart_of_accounts WHERE type = "Revenue" AND is_active = 1 ORDER BY code'
    );
    
    const [expenseAccounts] = await connection.execute(
      'SELECT code, name, type FROM chart_of_accounts WHERE type = "Expense" AND is_active = 1 ORDER BY code'
    );
    
    console.log('\n💰 Revenue Accounts:');
    if (revenueAccounts.length === 0) {
      console.log('   No revenue accounts found');
    } else {
      revenueAccounts.forEach(account => {
        console.log(`   ${account.code} - ${account.name}`);
      });
    }
    
    console.log('\n💸 Expense Accounts:');
    if (expenseAccounts.length === 0) {
      console.log('   No expense accounts found');
    } else {
      expenseAccounts.forEach(account => {
        console.log(`   ${account.code} - ${account.name}`);
      });
    }
    
    console.log(`\n📊 Summary:`);
    console.log(`   • Revenue accounts: ${revenueAccounts.length}`);
    console.log(`   • Expense accounts: ${expenseAccounts.length}`);
    console.log(`   • Total accounts: ${revenueAccounts.length + expenseAccounts.length}`);
    
  } catch (error) {
    console.error('\n❌ Error checking chart of accounts:', error.message);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the check if this script is executed directly
if (require.main === module) {
  checkChartOfAccounts()
    .then(() => {
      console.log('\n✅ Chart of accounts check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Chart of accounts check failed:', error.message);
      process.exit(1);
    });
}

module.exports = checkChartOfAccounts;
