const { pool } = require('../config/database');
const fs = require('fs');
const path = require('path');

async function runTransportPaymentsMigration() {
  const connection = await pool.getConnection();
  
  try {
    console.log('🚀 Starting transport payments migration...');
    
    // Read the migration SQL file
    const migrationPath = path.join(__dirname, '../migrations/update_transport_payments_for_direct_payments.sql');
    const migrationSQL = fs.readFileSync(migrationPath, 'utf8');
    
    // Split into individual statements and filter out empty ones
    const statements = migrationSQL
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt && !stmt.startsWith('--'));
    
    console.log(`📝 Found ${statements.length} SQL statements to execute`);
    
    // Execute each statement
    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i];
      if (statement) {
        console.log(`\n⚡ Executing statement ${i + 1}/${statements.length}:`);
        console.log(`   ${statement.substring(0, 80)}${statement.length > 80 ? '...' : ''}`);
        
        try {
          await connection.execute(statement);
          console.log(`   ✅ Statement ${i + 1} executed successfully`);
        } catch (error) {
          // Check if it's a "duplicate key" error for indexes (which is okay)
          if (error.code === 'ER_DUP_KEYNAME') {
            console.log(`   ⚠️  Index already exists (skipping): ${error.message}`);
          } else {
            throw error;
          }
        }
      }
    }
    
    console.log('\n🎉 Migration completed successfully!');
    console.log('\n📋 Changes made:');
    console.log('   • Made transport_fee_id column nullable');
    console.log('   • Added performance indexes');
    console.log('   • Updated column comments');
    
  } catch (error) {
    console.error('\n❌ Migration failed:', error.message);
    console.error('Error details:', error);
    throw error;
  } finally {
    connection.release();
  }
}

// Run the migration if this script is executed directly
if (require.main === module) {
  runTransportPaymentsMigration()
    .then(() => {
      console.log('\n✅ Migration script completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Migration script failed:', error.message);
      process.exit(1);
    });
}

module.exports = runTransportPaymentsMigration;
